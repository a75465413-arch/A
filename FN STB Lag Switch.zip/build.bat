@echo off
echo ====================================
echo Static Build Script
echo ====================================
echo.
 
echo [1/5] Installing static GLFW library...
C:\vcpkg\vcpkg.exe install glfw3:x64-windows-static
if errorlevel 1 (
    echo ERROR: Failed to install static GLFW
    pause
    exit /b 1
)
echo.
 
echo [2/5] Cloning ImGui (if needed)...
if not exist imgui (
    git clone https://github.com/ocornut/imgui.git
)
echo.
 
echo [3/5] Cleaning build directory...
if exist build (
    rmdir /s /q build
)
mkdir build
cd build
echo.
 
echo [4/5] Running CMake configuration...
cmake .. -DVCPKG_TARGET_TRIPLET=x64-windows-static -DCMAKE_TOOLCHAIN_FILE=C:/vcpkg/scripts/buildsystems/vcpkg.cmake
if errorlevel 1 (
    echo ERROR: CMake configuration failed!
    cd ..
    pause
    exit /b 1
)
echo.
 
echo [5/5] Building project (Release)...
cmake --build . --config Release
if errorlevel 1 (
    echo ERROR: Build failed!
    cd ..
    pause
    exit /b 1
)
echo.
 
cd ..
 
echo ====================================
echo Build completed successfully!
echo ====================================
echo.
echo Executable location: build\Release\LagSwitch.exe
echo This is a standalone EXE with no DLL dependencies!
echo.
pause