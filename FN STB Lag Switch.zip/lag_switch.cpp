#include "lag_switch.h"
#include <iostream>
#include <chrono>
#include <thread>

LagSwitch* LagSwitch::s_instance = nullptr;

LagSwitch::LagSwitch()
    : m_enabled(false)
    , m_threadCount(6)
    , m_hotkey('X')
    , m_shouldStop(false)
    , m_waitingForKey(false)
    , m_beepEnabled(true)
    , m_keyboardHook(nullptr)
{
    s_instance = this;
    
    for (int i = 0; i < 50; i++) {
        m_workers.emplace_back(&LagSwitch::ScrollWorker, this, i);
    }
}

LagSwitch::~LagSwitch()
{
    StopListening();
    m_shouldStop = true;
    for (auto& worker : m_workers) {
        if (worker.joinable()) {
            worker.join();
        }
    }
    
    s_instance = nullptr;
}

void LagSwitch::SetEnabled(bool enabled)
{
    m_enabled = enabled;
    if (m_beepEnabled) {
        if (enabled) {
            Beep(500, 300); // ON: 500Hz, 300ms
        } else {
            Beep(350, 300); // OFF: 350Hz, 300ms
        }
    }
    
    std::cout << "Lag Switch: " << (enabled ? "ENABLED" : "DISABLED") << std::endl;
}

void LagSwitch::SetThreadCount(int count)
{
    if (count >= 1 && count <= 10) {
        m_threadCount = count;
        std::cout << "Thread count changed to: " << count << std::endl;
    }
}

void LagSwitch::SetHotkey(int vkCode)
{
    m_hotkey = vkCode;
    std::cout << "Hotkey changed to: " << (char)vkCode << std::endl;
}

void LagSwitch::ScrollWorker(int workerId)
{
    while (!m_shouldStop) {
        if (m_enabled && workerId < m_threadCount) {
            int currentSpeed = m_threadCount;
            int boost = currentSpeed / 10;
            int repeatCount = 5 + (boost * 3);            
            for (int i = 0; i < repeatCount && m_enabled; i++) {
                INPUT inputDown = {0};
                inputDown.type = INPUT_MOUSE;
                inputDown.mi.dwFlags = MOUSEEVENTF_WHEEL;
                inputDown.mi.mouseData = -WHEEL_DELTA * 2;
                SendInput(1, &inputDown, sizeof(INPUT));
            }
            
            if (currentSpeed >= 20) {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
            else if (currentSpeed > 18) {
                std::this_thread::sleep_for(std::chrono::milliseconds(2));
            }
            else {
                int delay = (20 - currentSpeed) / 2 + 2;
                std::this_thread::sleep_for(std::chrono::milliseconds(delay));
            }
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void LagSwitch::StartListening()
{
    if (m_keyboardHook) return;
    
    m_keyboardHook = SetWindowsHookEx(
        WH_KEYBOARD_LL,
        KeyboardHookProc,
        GetModuleHandle(nullptr),
        0
    );
    
    if (m_keyboardHook) {
        std::cout << "Keyboard hook installed successfully" << std::endl;
    } else {
        std::cerr << "Failed to install keyboard hook" << std::endl;
    }
}

void LagSwitch::StopListening()
{
    if (m_keyboardHook) {
        UnhookWindowsHookEx(m_keyboardHook);
        m_keyboardHook = nullptr;
        std::cout << "Keyboard hook removed" << std::endl;
    }
}

LRESULT CALLBACK LagSwitch::KeyboardHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
    if (nCode >= 0 && wParam == WM_KEYDOWN) {
        KBDLLHOOKSTRUCT* pKeyboard = (KBDLLHOOKSTRUCT*)lParam;
        
        if (s_instance) {
            int vkCode = pKeyboard->vkCode;
            if (s_instance->m_waitingForKey) {
                if (vkCode != VK_SHIFT && vkCode != VK_CONTROL && vkCode != VK_MENU &&
                    vkCode != VK_ESCAPE && vkCode != VK_RETURN && vkCode != VK_SPACE &&
                    vkCode != VK_TAB && vkCode != VK_BACK) {
                    
                    s_instance->SetHotkey(vkCode);
                    s_instance->m_waitingForKey = false;
                    std::cout << "New hotkey set!" << std::endl;
                    return 1;
                }
            }
            else if (vkCode == s_instance->GetHotkey()) {
                s_instance->SetEnabled(!s_instance->IsEnabled());
            }
        }
    }
    
    return CallNextHookEx(nullptr, nCode, wParam, lParam);
}
