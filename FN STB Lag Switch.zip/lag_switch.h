#pragma once
#include <windows.h>
#include <thread>
#include <atomic>
#include <vector>

class LagSwitch {
public:
    LagSwitch();
    ~LagSwitch();
    
    void SetEnabled(bool enabled);
    bool IsEnabled() const { return m_enabled; }
    
    void SetThreadCount(int count);
    int GetThreadCount() const { return m_threadCount; }
    
    void SetHotkey(int vkCode);
    int GetHotkey() const { return m_hotkey; }
    
    void StartListening();
    void StopListening();
    
    void StartWaitingForKey() { m_waitingForKey = true; }
    bool IsWaitingForKey() const { return m_waitingForKey; }
    
    void SetBeepEnabled(bool enabled) { m_beepEnabled = enabled; }
    bool IsBeepEnabled() const { return m_beepEnabled; }
    
private:
    void ScrollWorker(int workerId);
    static LRESULT CALLBACK KeyboardHookProc(int nCode, WPARAM wParam, LPARAM lParam);
    
    std::atomic<bool> m_enabled;
    std::atomic<int> m_threadCount;
    std::atomic<int> m_hotkey;
    std::atomic<bool> m_shouldStop;
    std::atomic<bool> m_waitingForKey;
    std::atomic<bool> m_beepEnabled;
    
    std::vector<std::thread> m_workers;
    HHOOK m_keyboardHook;
    
    static LagSwitch* s_instance;
};
