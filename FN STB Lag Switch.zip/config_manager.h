#pragma once
#include <string>
#include <vector>
#include <fstream>
#include <windows.h>
#include "imgui.h"

struct AppConfig {
    bool lagSwitchEnabled = false;
    int threadCount = 2;
    int hotkey = 'X';
    
    // カラー設定
    ImVec4 accentColor = ImVec4(0.20f, 0.60f, 0.80f, 1.00f);
    ImVec4 backgroundColor = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    ImVec4 buttonColor = ImVec4(0.20f, 0.60f, 0.80f, 1.00f);
    ImVec4 buttonHoveredColor = ImVec4(0.30f, 0.70f, 0.90f, 1.00f);
    ImVec4 buttonActiveColor = ImVec4(0.15f, 0.50f, 0.70f, 1.00f);
    
    // Settings設定
    bool autoStart = false;
    bool minimizeToTray = true;
    bool enableBeep = true;
    int showHideHotkey = VK_F2;
};

class ConfigManager {
public:
    ConfigManager();
    
    bool SaveConfig(const std::string& name, const AppConfig& config);
    bool LoadConfig(const std::string& name, AppConfig& config);
    bool DeleteConfig(const std::string& name);
    std::vector<std::string> GetConfigList();
    
    void ApplyColors(const AppConfig& config);
    
private:
    std::string GetConfigPath(const std::string& name);
    std::string m_configDir;
};
