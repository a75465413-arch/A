#include "config_manager.h"
#include <windows.h>
#include <shlobj.h>
#include <iostream>
#include <filesystem>
#include <sstream>

namespace fs = std::filesystem;

ConfigManager::ConfigManager()
{
    char appDataPath[MAX_PATH];
    if (SHGetFolderPathA(NULL, CSIDL_APPDATA, NULL, 0, appDataPath) == S_OK) {
        m_configDir = std::string(appDataPath) + "\\ImGuiLagSwitch\\configs";
        fs::create_directories(m_configDir);
    } else {
        m_configDir = ".\\configs";
        fs::create_directories(m_configDir);
    }
    
    std::cout << "Config directory: " << m_configDir << std::endl;
}

std::string ConfigManager::GetConfigPath(const std::string& name)
{
    return m_configDir + "\\" + name + ".cfg";
}

bool ConfigManager::SaveConfig(const std::string& name, const AppConfig& config)
{
    std::string path = GetConfigPath(name);
    std::ofstream file(path, std::ios::binary);
    
    if (!file.is_open()) {
        std::cerr << "Failed to save config: " << path << std::endl;
        return false;
    }
    
    file.write(reinterpret_cast<const char*>(&config), sizeof(AppConfig));
    file.close();
    
    std::cout << "Config saved: " << name << std::endl;
    return true;
}

bool ConfigManager::LoadConfig(const std::string& name, AppConfig& config)
{
    std::string path = GetConfigPath(name);
    std::ifstream file(path, std::ios::binary);
    
    if (!file.is_open()) {
        std::cerr << "Failed to load config: " << path << std::endl;
        return false;
    }

    file.read(reinterpret_cast<char*>(&config), sizeof(AppConfig));
    file.close();
    
    std::cout << "Config loaded: " << name << std::endl;
    return true;
}

bool ConfigManager::DeleteConfig(const std::string& name)
{
    std::string path = GetConfigPath(name);
    
    if (fs::exists(path)) {
        fs::remove(path);
        std::cout << "Config deleted: " << name << std::endl;
        return true;
    }
    
    std::cerr << "Config not found: " << name << std::endl;
    return false;
}

std::vector<std::string> ConfigManager::GetConfigList()
{
    std::vector<std::string> configs;
    
    if (!fs::exists(m_configDir)) {
        return configs;
    }
    
    for (const auto& entry : fs::directory_iterator(m_configDir)) {
        if (entry.is_regular_file() && entry.path().extension() == ".cfg") {
            configs.push_back(entry.path().stem().string());
        }
    }
    
    return configs;
}

void ConfigManager::ApplyColors(const AppConfig& config)
{
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;
    
    colors[ImGuiCol_WindowBg] = config.backgroundColor;
    colors[ImGuiCol_ChildBg] = config.backgroundColor;
    
    colors[ImGuiCol_Button] = config.buttonColor;
    colors[ImGuiCol_ButtonHovered] = config.buttonHoveredColor;
    colors[ImGuiCol_ButtonActive] = config.buttonActiveColor;
    
    colors[ImGuiCol_Header] = ImVec4(config.accentColor.x, config.accentColor.y, config.accentColor.z, 0.55f);
    colors[ImGuiCol_HeaderHovered] = ImVec4(config.buttonHoveredColor.x, config.buttonHoveredColor.y, config.buttonHoveredColor.z, 0.80f);
    colors[ImGuiCol_HeaderActive] = config.buttonActiveColor;
    
    colors[ImGuiCol_TitleBgActive] = config.accentColor;
    colors[ImGuiCol_CheckMark] = config.buttonHoveredColor;
    colors[ImGuiCol_SliderGrab] = config.accentColor;
    colors[ImGuiCol_SliderGrabActive] = config.buttonHoveredColor;
}
