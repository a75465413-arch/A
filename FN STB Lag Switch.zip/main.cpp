#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"
#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3.h>
#include <GLFW/glfw3native.h>
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <iostream>
#include <algorithm>
#include <unordered_map>
#include <cmath>
#include "lag_switch.h"
#include "config_manager.h"

static GLFWwindow* CreateOverlayWindow()
{
    glfwWindowHint(GLFW_DECORATED,          GLFW_FALSE);
    glfwWindowHint(GLFW_FLOATING,           GLFW_TRUE);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_TRUE);
    glfwWindowHint(GLFW_FOCUS_ON_SHOW,      GLFW_FALSE);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE,     GLFW_OPENGL_CORE_PROFILE);
    GLFWwindow* ow = glfwCreateWindow(200, 60, "Overlay", NULL, NULL);
    glfwWindowHint(GLFW_DECORATED,          GLFW_TRUE);
    glfwWindowHint(GLFW_FLOATING,           GLFW_FALSE);
    glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, GLFW_FALSE);
    glfwWindowHint(GLFW_FOCUS_ON_SHOW,      GLFW_TRUE);

    if (!ow) return nullptr;

    HWND hwnd = glfwGetWin32Window(ow);
    LONG exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
    exStyle |= WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
    SetWindowLong(hwnd, GWL_EXSTYLE, exStyle);
    int monW = GetSystemMetrics(SM_CXSCREEN);
    SetWindowPos(hwnd, HWND_TOPMOST, monW - 220, 20, 200, 60,
                 SWP_NOACTIVATE | SWP_SHOWWINDOW);

    return ow;
}

static float Lerp(float a, float b, float t) { return a + (b - a) * t; }
static ImVec4 LerpColor(const ImVec4& a, const ImVec4& b, float t)
{
    return ImVec4(Lerp(a.x, b.x, t), Lerp(a.y, b.y, t),
                  Lerp(a.z, b.z, t), Lerp(a.w, b.w, t));
}

static bool SliderIntStyled(const char* id, int* v, int v_min, int v_max,
                             float& smoothVal, float dt)
{
    float target = (float)(*v - v_min) / (float)(v_max - v_min);
    smoothVal = Lerp(smoothVal, target, 1.0f - expf(-16.0f * dt));

    bool changed = false;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos    = ImGui::GetCursorScreenPos();
    float  width  = ImGui::GetContentRegionAvail().x;
    const float trackH  = 6.0f;
    const float grabR   = 9.0f;
    const float totalH  = grabR * 2.0f + 14.0f;
    ImGui::InvisibleButton(id, ImVec2(width, totalH));
    bool hovered = ImGui::IsItemHovered();
    bool active  = ImGui::IsItemActive();

    if (active)
    {
        float mx = ImGui::GetIO().MousePos.x;
        float ratio = (mx - (pos.x + grabR)) / (width - grabR * 2.0f);
        ratio = ratio < 0.0f ? 0.0f : (ratio > 1.0f ? 1.0f : ratio);
        int newVal = v_min + (int)(ratio * (float)(v_max - v_min) + 0.5f);
        if (newVal != *v) { *v = newVal; changed = true; }
    }

    float trackY  = pos.y + 14.0f + grabR;
    float trackX0 = pos.x + grabR;
    float trackX1 = pos.x + width - grabR;

    ImU32 trackBg  = IM_COL32(60, 60, 60, 255);
    ImU32 trackFill= IM_COL32(50, 180, 230, 255);
    ImU32 grabCol  = active  ? IM_COL32(80, 210, 255, 255)
                   : hovered ? IM_COL32(60, 200, 245, 255)
                             : IM_COL32(50, 180, 230, 255);

    dl->AddRectFilled(ImVec2(trackX0, trackY - trackH * 0.5f),
                      ImVec2(trackX1, trackY + trackH * 0.5f),
                      trackBg, trackH * 0.5f);

    float fillX = trackX0 + smoothVal * (trackX1 - trackX0);
    dl->AddRectFilled(ImVec2(trackX0, trackY - trackH * 0.5f),
                      ImVec2(fillX,   trackY + trackH * 0.5f),
                      trackFill, trackH * 0.5f);

    float grabX = fillX;
    dl->AddCircleFilled(ImVec2(grabX, trackY), grabR, grabCol);
    dl->AddCircle(      ImVec2(grabX, trackY), grabR,
                        IM_COL32(150, 230, 255, 180), 0, 1.5f);

    char buf[16];
    sprintf_s(buf, "%d", *v);
    ImVec2 textSz = ImGui::CalcTextSize(buf);
    float  textX  = grabX - textSz.x * 0.5f;
    float  textY  = pos.y;
    if (textX < pos.x) textX = pos.x;
    if (textX + textSz.x > pos.x + width) textX = pos.x + width - textSz.x;
    dl->AddText(ImVec2(textX, textY), IM_COL32(200, 240, 255, 255), buf);

    return changed;
}

static bool AnimButton(const char* label, ImVec2 size)
{
    ImGuiID id = ImGui::GetID(label);
    static std::unordered_map<ImGuiID, float> pressAnim;
    float& anim = pressAnim[id];

    float dt = ImGui::GetIO().DeltaTime;
    bool hovered = false, held = false;
    ImVec2 btnPos = ImGui::GetCursorScreenPos();
    ImVec2 btnMax = ImVec2(btnPos.x + size.x, btnPos.y + size.y);
    ImVec2 mouse  = ImGui::GetIO().MousePos;
    held    = ImGui::IsMouseDown(0) &&
              mouse.x >= btnPos.x && mouse.x < btnMax.x &&
              mouse.y >= btnPos.y && mouse.y < btnMax.y;
    hovered = mouse.x >= btnPos.x && mouse.x < btnMax.x &&
              mouse.y >= btnPos.y && mouse.y < btnMax.y;
    float target = held ? 1.0f : 0.0f;
    anim = Lerp(anim, target, 1.0f - expf(-20.0f * dt));
    float shrink = anim * 3.0f;
    ImVec2 origPad = ImGui::GetStyle().FramePadding;
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,
                        ImVec2(origPad.x - shrink, origPad.y - shrink));
    bool result = ImGui::Button(label, size);
    ImGui::PopStyleVar();
    return result;
}

int main()
{
    if (!glfwInit())
    {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_DECORATED, GLFW_FALSE);
    GLFWwindow* window = glfwCreateWindow(1000, 600, "LagSwitch", NULL, NULL);
    if (window == NULL)
    {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1); // V-Sync有効

    GLFWwindow* overlayWindow = CreateOverlayWindow();
    bool overlayVisible = true;
    glfwMakeContextCurrent(window);

    IMGUI_CHECKVERSION();
    ImGuiContext* mainCtx = ImGui::CreateContext();
    ImGui::SetCurrentContext(mainCtx);
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    
    ImGui::StyleColorsDark();
    
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    style.WindowRounding    = 12.0f;
    style.ChildRounding     = 10.0f;
    style.FrameRounding     = 8.0f;
    style.GrabRounding      = 8.0f;
    style.ScrollbarRounding = 10.0f;
    style.TabRounding       = 8.0f;
    style.PopupRounding     = 8.0f;
    style.WindowPadding     = ImVec2(12.0f, 12.0f);
    style.FramePadding      = ImVec2(8.0f, 5.0f);
    style.ItemSpacing       = ImVec2(8.0f, 6.0f);
    style.ScrollbarSize     = 10.0f;
    
    colors[ImGuiCol_WindowBg] = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    colors[ImGuiCol_ChildBg] = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    
    colors[ImGuiCol_Button] = ImVec4(0.20f, 0.60f, 0.80f, 1.00f);
    colors[ImGuiCol_ButtonHovered] = ImVec4(0.30f, 0.70f, 0.90f, 1.00f);
    colors[ImGuiCol_ButtonActive] = ImVec4(0.15f, 0.50f, 0.70f, 1.00f);
    
    colors[ImGuiCol_Header] = ImVec4(0.20f, 0.60f, 0.80f, 0.55f);
    colors[ImGuiCol_HeaderHovered] = ImVec4(0.30f, 0.70f, 0.90f, 0.80f);
    colors[ImGuiCol_HeaderActive] = ImVec4(0.15f, 0.50f, 0.70f, 1.00f);
    
    colors[ImGuiCol_FrameBg] = ImVec4(0.20f, 0.20f, 0.20f, 1.00f);
    colors[ImGuiCol_FrameBgHovered] = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
    colors[ImGuiCol_FrameBgActive] = ImVec4(0.30f, 0.30f, 0.30f, 1.00f);
    
    colors[ImGuiCol_TitleBg] = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
    colors[ImGuiCol_TitleBgActive] = ImVec4(0.20f, 0.60f, 0.80f, 1.00f);
    colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.10f, 0.10f, 0.10f, 0.75f);
    
    colors[ImGuiCol_CheckMark] = ImVec4(0.30f, 0.70f, 0.90f, 1.00f);
    colors[ImGuiCol_SliderGrab] = ImVec4(0.20f, 0.60f, 0.80f, 1.00f);
    colors[ImGuiCol_SliderGrabActive] = ImVec4(0.30f, 0.70f, 0.90f, 1.00f);
    
    colors[ImGuiCol_Text] = ImVec4(0.95f, 0.95f, 0.95f, 1.00f); 

    ImFontConfig fontConfig;
    fontConfig.OversampleH = 3;
    fontConfig.OversampleV = 2;
    fontConfig.RasterizerMultiply = 2.0f;
    io.Fonts->AddFontFromFileTTF("fonts/Nunito.ttf", 17.0f, &fontConfig,
                                  io.Fonts->GetGlyphRangesDefault());
    io.Fonts->Build();

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");
    ImGuiContext* overlayCtx = nullptr;
    if (overlayWindow)
    {
        glfwMakeContextCurrent(overlayWindow);
        overlayCtx = ImGui::CreateContext();
        ImGui::SetCurrentContext(overlayCtx);
        ImGuiIO& oio = ImGui::GetIO(); (void)oio;
        ImGui::StyleColorsDark();
        ImFontConfig ofc;
        ofc.OversampleH = 3; ofc.OversampleV = 2;
        ofc.RasterizerMultiply = 1.4f;
        oio.Fonts->AddFontFromFileTTF("fonts/Nunito.ttf", 16.0f, &ofc,
                                       oio.Fonts->GetGlyphRangesDefault());
        oio.Fonts->Build();
        ImGui_ImplGlfw_InitForOpenGL(overlayWindow, false);
        ImGui_ImplOpenGL3_Init("#version 330");
        glfwMakeContextCurrent(window);
        ImGui::SetCurrentContext(mainCtx);
    }

    ImVec4 clear_color = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    LagSwitch lagSwitch;
    lagSwitch.StartListening();
    ConfigManager configManager;
    AppConfig currentConfig;
    bool windowVisible = true;
    bool showHideKeyPressed = false;
    ImVec4 overlayOnColor  = ImVec4(0.20f, 0.80f, 1.00f, 1.0f);  // ON: 水色
    ImVec4 overlayOffColor = ImVec4(0.50f, 0.50f, 0.50f, 1.0f);  // OFF: グレー
    static float tabAnim[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
    static float contentSlide = 0.0f;
    static float threadCountSmooth = 0.0f;
    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();
        float dt = ImGui::GetIO().DeltaTime;
        bool isShowHideKeyDown = (GetAsyncKeyState(currentConfig.showHideHotkey) & 0x8000) != 0;
        if (isShowHideKeyDown && !showHideKeyPressed) {
            windowVisible = !windowVisible;
            if (windowVisible) {
                glfwShowWindow(window);
            } else {
                glfwHideWindow(window);
            }
            std::cout << "Window visibility: " << (windowVisible ? "VISIBLE" : "HIDDEN") << std::endl;
        }
        showHideKeyPressed = isShowHideKeyDown;

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        {
            int display_w, display_h;
            glfwGetFramebufferSize(window, &display_w, &display_h);
            ImGui::SetNextWindowPos(ImVec2(0, 0));
            ImGui::SetNextWindowSize(ImVec2((float)display_w, (float)display_h));
            ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | 
                                           ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse | 
                                           ImGuiWindowFlags_NoBringToFrontOnFocus;
            
            ImGui::Begin("MainWindow", nullptr, window_flags);

            {
                const float drag_height = 28.0f;

                ImDrawList* draw_list = ImGui::GetWindowDrawList();
                ImVec2 bar_min = ImGui::GetWindowPos();
                ImVec2 bar_max = ImVec2(bar_min.x + (float)display_w, bar_min.y + drag_height);
                draw_list->AddRectFilled(bar_min, bar_max, IM_COL32(20, 20, 20, 255));
                ImVec2 text_pos = ImVec2(bar_min.x + 10, bar_min.y + 6);
                draw_list->AddText(text_pos, IM_COL32(200, 200, 200, 255), "LagSwitch");
                draw_list->AddLine(ImVec2(bar_min.x, bar_min.y + drag_height),
                                   ImVec2(bar_max.x, bar_min.y + drag_height),
                                   IM_COL32(50, 50, 50, 255), 1.0f);

                ImGui::SetCursorPos(ImVec2((float)display_w - 36, 4));
                ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0, 0, 0, 0));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.8f, 0.2f, 0.2f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
                if (ImGui::Button("x", ImVec2(28, 20)))
                {
                    glfwSetWindowShouldClose(window, GLFW_TRUE);
                }
                ImGui::PopStyleColor(3);
                bool closeButtonHovered = ImGui::IsItemHovered();

                static bool dragging = false;
                static POINT dragStartCursor = {};
                static int   dragStartWinX   = 0;
                static int   dragStartWinY   = 0;
                
                ImVec2 mouse = ImGui::GetIO().MousePos;
                bool overDragBar = (mouse.x >= bar_min.x && mouse.x < bar_max.x &&
                                    mouse.y >= bar_min.y && mouse.y < bar_min.y + drag_height &&
                                    !closeButtonHovered);
                
                if (overDragBar && ImGui::IsMouseClicked(ImGuiMouseButton_Left))
                {
                    dragging = true;
                    GetCursorPos(&dragStartCursor);
                    glfwGetWindowPos(window, &dragStartWinX, &dragStartWinY);
                }
                if (!ImGui::IsMouseDown(ImGuiMouseButton_Left))
                {
                    dragging = false;
                }
                if (dragging)
                {
                    POINT cur;
                    GetCursorPos(&cur);
                    int newX = dragStartWinX + (cur.x - dragStartCursor.x);
                    int newY = dragStartWinY + (cur.y - dragStartCursor.y);
                    glfwSetWindowPos(window, newX, newY);
                }
                
                ImGui::SetCursorPos(ImVec2(0, drag_height + 4));
            }

            const float tab_width = 150.0f;
            const float version_height = 40.0f;
            static int selected_tab = 0; // 0: Lag Switch, 1: Color, 2: Config, 3: Settings

            for (int i = 0; i < 4; i++)
            {
                float target = (i == selected_tab) ? 1.0f : 0.0f;
                tabAnim[i] = Lerp(tabAnim[i], target, 1.0f - expf(-12.0f * dt));
            }

            ImVec4 tabActiveColor   = currentConfig.buttonColor;
            ImVec4 tabInactiveColor = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
            ImVec4 tabHoveredColor  = currentConfig.buttonHoveredColor;
            ImVec4 tabPressedColor  = currentConfig.buttonActiveColor;
            ImGui::BeginChild("LeftPanel", ImVec2(tab_width, -version_height), true);
            {
                ImGui::Spacing();
                auto DrawTabButton = [&](const char* label, int idx) -> bool
                {
                    ImVec4 col = LerpColor(tabInactiveColor, tabActiveColor, tabAnim[idx]);
                    ImGui::PushStyleColor(ImGuiCol_Button,        col);
                    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, tabHoveredColor);
                    ImGui::PushStyleColor(ImGuiCol_ButtonActive,  tabPressedColor);
                    bool clicked = AnimButton(label, ImVec2(tab_width - 20, 40));
                    ImGui::PopStyleColor(3);
                    return clicked;
                };

                if (DrawTabButton("Lag Switch", 0)) selected_tab = 0;
                ImGui::Spacing();
                if (DrawTabButton("Color",      1)) selected_tab = 1;
                ImGui::Spacing();
                if (DrawTabButton("Config",     2)) selected_tab = 2;

                ImGui::Spacing();
                ImGui::Spacing();
                float available_height = ImGui::GetContentRegionAvail().y;
                ImGui::Dummy(ImVec2(0, available_height - 60));
                
                if (DrawTabButton("Settings",  3)) selected_tab = 3;
                
                ImGui::Spacing();
            }
            ImGui::EndChild();
            ImGui::SameLine();
            ImGui::BeginChild("RightPanel", ImVec2(0, -version_height), true,
                ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
            {
                contentSlide = Lerp(contentSlide, (float)selected_tab,
                                    1.0f - expf(-14.0f * dt));

                ImVec2 panelSize = ImGui::GetContentRegionAvail();
                ImVec2 panelPos  = ImGui::GetCursorScreenPos();
                float  panelW    = panelSize.x;
                float  panelH    = panelSize.y;

                ImGui::GetWindowDrawList()->PushClipRect(
                    panelPos,
                    ImVec2(panelPos.x + panelW, panelPos.y + panelH),
                    true);

                // offset = (tabIdx - contentSlide) * panelH
                auto DrawTabContent = [&](int tabIdx, auto drawFn)
                {
                    float offsetY = ((float)tabIdx - contentSlide) * panelH;
                    if (offsetY <= -panelH || offsetY >= panelH) return;

                    ImGui::SetCursorScreenPos(
                        ImVec2(panelPos.x, panelPos.y + offsetY));

                    char childId[32];
                    sprintf_s(childId, "##tab_content_%d", tabIdx);
                    ImGui::PushClipRect(
                        panelPos,
                        ImVec2(panelPos.x + panelW, panelPos.y + panelH),
                        true);
                    ImGui::BeginChild(childId,
                        ImVec2(panelW, panelH),
                        false,
                        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
                    drawFn();
                    ImGui::EndChild();
                    ImGui::PopClipRect();
                };

                DrawTabContent(0, [&]()
                {
                    ImGui::Text("Lag Switch Settings");
                    ImGui::Separator();
                    ImGui::Spacing();
                    
                    bool enabled = lagSwitch.IsEnabled();
                    if (ImGui::Checkbox("Enable Lag Switch", &enabled))
                        lagSwitch.SetEnabled(enabled);
                    
                    ImGui::Spacing();
                    ImGui::Text("Thread Count (Speed):");
                    ImGui::Spacing();
                    int threadCount = lagSwitch.GetThreadCount();
                    if (SliderIntStyled("##thread_count", &threadCount, 1, 10,
                                        threadCountSmooth, dt))
                        lagSwitch.SetThreadCount(threadCount);
                    ImGui::SameLine();
                    ImGui::TextDisabled("(?)");
                    if (ImGui::IsItemHovered())
                        ImGui::SetTooltip("Higher values = faster scrolling");
                    
                    ImGui::Spacing();
                    ImGui::Spacing();
                    ImGui::Text("Hotkey:");
                    ImGui::SameLine();
                    
                    static bool waitingForKey = false;
                    char hotkeyChar = (char)lagSwitch.GetHotkey();
                    if (lagSwitch.IsWaitingForKey()) {
                        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.70f, 0.90f, 1.00f));
                        AnimButton("Press any key...", ImVec2(150, 30));
                        ImGui::PopStyleColor();
                    } else {
                        if (AnimButton((std::string("Key: ") + hotkeyChar).c_str(), ImVec2(150, 30)))
                        {
                            lagSwitch.StartWaitingForKey();
                            std::cout << "Waiting for key input..." << std::endl;
                        }
                    }
                    ImGui::SameLine();
                    ImGui::TextDisabled("(Press to toggle)");
                    
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();
                    ImGui::Text("Status:");
                    ImGui::SameLine();
                    if (lagSwitch.IsEnabled())
                        ImGui::TextColored(ImVec4(0.30f, 0.70f, 0.90f, 1.00f), "RUNNING");
                    else
                        ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.00f), "READY");
                });

                DrawTabContent(1, [&]()
                {
                    ImGui::Text("Color Settings");
                    ImGui::Separator();
                    ImGui::Spacing();
                    
                    ImGui::Text("Accent Color:");
                    if (ImGui::ColorEdit3("##accent", (float*)&currentConfig.accentColor))
                    {
                        currentConfig.buttonColor = currentConfig.accentColor;
                        float hoverR = currentConfig.accentColor.x + 0.1f; if (hoverR > 1.0f) hoverR = 1.0f;
                        float hoverG = currentConfig.accentColor.y + 0.1f; if (hoverG > 1.0f) hoverG = 1.0f;
                        float hoverB = currentConfig.accentColor.z + 0.1f; if (hoverB > 1.0f) hoverB = 1.0f;
                        currentConfig.buttonHoveredColor = ImVec4(hoverR, hoverG, hoverB, 1.0f);
                        float activeR = currentConfig.accentColor.x - 0.05f; if (activeR < 0.0f) activeR = 0.0f;
                        float activeG = currentConfig.accentColor.y - 0.05f; if (activeG < 0.0f) activeG = 0.0f;
                        float activeB = currentConfig.accentColor.z - 0.05f; if (activeB < 0.0f) activeB = 0.0f;
                        currentConfig.buttonActiveColor = ImVec4(activeR, activeG, activeB, 1.0f);
                        configManager.ApplyColors(currentConfig);
                    }
                    ImGui::Spacing();
                    ImGui::Text("Background Color:");
                    if (ImGui::ColorEdit3("##background", (float*)&currentConfig.backgroundColor))
                        configManager.ApplyColors(currentConfig);
                    ImGui::Spacing();
                    ImGui::Spacing();
                    if (AnimButton("Reset to Default", ImVec2(200, 30)))
                    {
                        currentConfig.accentColor       = ImVec4(0.20f, 0.60f, 0.80f, 1.00f);
                        currentConfig.backgroundColor   = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
                        currentConfig.buttonColor       = ImVec4(0.20f, 0.60f, 0.80f, 1.00f);
                        currentConfig.buttonHoveredColor= ImVec4(0.30f, 0.70f, 0.90f, 1.00f);
                        currentConfig.buttonActiveColor = ImVec4(0.15f, 0.50f, 0.70f, 1.00f);
                        configManager.ApplyColors(currentConfig);
                    }
                });

                DrawTabContent(2, [&]()
                {
                    ImGui::Text("Configuration Management");
                    ImGui::Separator();
                    ImGui::Spacing();
                    
                    static char configName[128] = "Config";
                    ImGui::Text("Config Name:");
                    ImGui::InputText("##configname", configName, IM_ARRAYSIZE(configName));
                    ImGui::Spacing();
                    
                    if (AnimButton("Save Config", ImVec2(150, 30)))
                    {
                        if (strlen(configName) > 0) {
                            currentConfig.lagSwitchEnabled = lagSwitch.IsEnabled();
                            currentConfig.threadCount      = lagSwitch.GetThreadCount();
                            currentConfig.hotkey           = lagSwitch.GetHotkey();
                            if (configManager.SaveConfig(configName, currentConfig))
                                std::cout << "Config saved: " << configName << std::endl;
                        }
                    }
                    ImGui::SameLine();
                    if (AnimButton("Load Config", ImVec2(150, 30)))
                    {
                        if (strlen(configName) > 0) {
                            if (configManager.LoadConfig(configName, currentConfig)) {
                                lagSwitch.SetEnabled(currentConfig.lagSwitchEnabled);
                                lagSwitch.SetThreadCount(currentConfig.threadCount);
                                lagSwitch.SetHotkey(currentConfig.hotkey);
                                configManager.ApplyColors(currentConfig);
                                std::cout << "Config loaded: " << configName << std::endl;
                            }
                        }
                    }
                    ImGui::SameLine();
                    if (AnimButton("Delete Config", ImVec2(150, 30)))
                    {
                        if (strlen(configName) > 0)
                            configManager.DeleteConfig(configName);
                    }
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();
                    ImGui::Text("Saved Configs:");
                    ImGui::BeginChild("ConfigList", ImVec2(0, 200), true);
                    {
                        auto configs = configManager.GetConfigList();
                        for (const auto& name : configs)
                            if (ImGui::Selectable(name.c_str()))
                                strcpy_s(configName, name.c_str());
                        if (configs.empty())
                            ImGui::TextDisabled("No saved configs");
                    }
                    ImGui::EndChild();
                });

                DrawTabContent(3, [&]()
                {
                    ImGui::Text("Application Settings");
                    ImGui::Separator();
                    ImGui::Spacing();
                    
                    bool beepEnabled = lagSwitch.IsBeepEnabled();
                    if (ImGui::Checkbox("Enable Beep Sound", &beepEnabled))
                    {
                        lagSwitch.SetBeepEnabled(beepEnabled);
                        currentConfig.enableBeep = beepEnabled;
                    }
                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();

                    ImGui::Text("Overlay");
                    ImGui::Spacing();
                    if (overlayVisible) {
                        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.20f, 0.60f, 0.80f, 1.00f));
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.30f, 0.70f, 0.90f, 1.00f));
                        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.15f, 0.50f, 0.70f, 1.00f));
                        if (AnimButton("Hide Overlay", ImVec2(160, 34))) {
                            overlayVisible = false;
                            if (overlayWindow) glfwHideWindow(overlayWindow);
                        }
                    } else {
                        ImGui::PushStyleColor(ImGuiCol_Button,        ImVec4(0.25f, 0.25f, 0.25f, 1.00f));
                        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.35f, 0.35f, 0.35f, 1.00f));
                        ImGui::PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.20f, 0.20f, 0.20f, 1.00f));
                        if (AnimButton("Show Overlay", ImVec2(160, 34))) {
                            overlayVisible = true;
                            if (overlayWindow) glfwShowWindow(overlayWindow);
                        }
                    }
                    ImGui::PopStyleColor(3);
                    ImGui::SameLine();
                    ImGui::TextColored(
                        overlayVisible ? ImVec4(0.20f, 0.75f, 1.00f, 1.0f)
                                       : ImVec4(0.55f, 0.55f, 0.55f, 1.0f),
                        overlayVisible ? "Visible" : "Hidden");

                    ImGui::Spacing();
                    ImGui::Text("Overlay ON Color:");
                    ImGui::ColorEdit3("##overlay_on_color",  (float*)&overlayOnColor);
                    ImGui::Spacing();
                    ImGui::Text("Overlay OFF Color:");
                    ImGui::ColorEdit3("##overlay_off_color", (float*)&overlayOffColor);
                    ImGui::Spacing();
                    if (AnimButton("Reset Overlay Colors", ImVec2(200, 30)))
                    {
                        overlayOnColor  = ImVec4(0.20f, 0.80f, 1.00f, 1.0f);
                        overlayOffColor = ImVec4(0.50f, 0.50f, 0.50f, 1.0f);
                    }

                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::Spacing();
                    ImGui::Text("Show/Hide Menu Hotkey:");
                    ImGui::SameLine();
                    
                    static bool waitingForShowHideKey = false;
                    if (waitingForShowHideKey) {
                        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.70f, 0.90f, 1.00f));
                        ImGui::Button("Press any key...", ImVec2(150, 30));
                        ImGui::PopStyleColor();
                        for (int vk = 0x08; vk <= 0xFE; vk++) {
                            if (vk == VK_SHIFT || vk == VK_CONTROL || vk == VK_MENU ||
                                vk == VK_ESCAPE || vk == VK_RETURN || vk == VK_SPACE) continue;
                            if ((GetAsyncKeyState(vk) & 0x8001) == 0x8001) {
                                currentConfig.showHideHotkey = vk;
                                waitingForShowHideKey = false;
                                std::cout << "Show/Hide hotkey set to: " << vk << std::endl;
                                break;
                            }
                        }
                    } else {
                        char keyName[64];
                        if (currentConfig.showHideHotkey >= VK_F1 && currentConfig.showHideHotkey <= VK_F24)
                            sprintf_s(keyName, "F%d", currentConfig.showHideHotkey - VK_F1 + 1);
                        else
                            sprintf_s(keyName, "Key: 0x%X", currentConfig.showHideHotkey);
                        if (AnimButton(keyName, ImVec2(150, 30)))
                            waitingForShowHideKey = true;
                    }
                });

                ImGui::GetWindowDrawList()->PopClipRect();
            }
            ImGui::EndChild();
            ImGui::SetCursorPos(ImVec2(10, (float)display_h - version_height + 10));
            ImGui::Text("MINTO.LOL");
            
            ImGui::End();
        }

        ImGui::Render();
        int display_w, display_h;
        glfwGetFramebufferSize(window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clear_color.x * clear_color.w, clear_color.y * clear_color.w, 
                     clear_color.z * clear_color.w, clear_color.w);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);

        if (overlayWindow && overlayCtx && overlayVisible)
        {
            glfwMakeContextCurrent(overlayWindow);
            ImGui::SetCurrentContext(overlayCtx);

            int ow, oh;
            glfwGetFramebufferSize(overlayWindow, &ow, &oh);
            glViewport(0, 0, ow, oh);
            glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            glClear(GL_COLOR_BUFFER_BIT);

            bool enabled = lagSwitch.IsEnabled();

            ImGui_ImplOpenGL3_NewFrame();
            ImGui_ImplGlfw_NewFrame();
            ImGui::NewFrame();

            ImGui::SetNextWindowPos(ImVec2(0, 0));
            ImGui::SetNextWindowSize(ImVec2((float)ow, (float)oh));
            ImGui::SetNextWindowBgAlpha(0.0f);
            ImGuiWindowFlags ov_flags =
                ImGuiWindowFlags_NoTitleBar    | ImGuiWindowFlags_NoResize  |
                ImGuiWindowFlags_NoMove        | ImGuiWindowFlags_NoScrollbar |
                ImGuiWindowFlags_NoInputs      | ImGuiWindowFlags_NoBringToFrontOnFocus |
                ImGuiWindowFlags_NoNav         | ImGuiWindowFlags_NoDecoration;

            ImGui::Begin("##overlay", nullptr, ov_flags);
            {
                ImDrawList* dl = ImGui::GetWindowDrawList();
                ImVec2 pmin(4.0f, 4.0f), pmax((float)ow - 4, (float)oh - 4);
                ImU32 bgColor = enabled
                    ? IM_COL32(15,  15,  15,  210)
                    : IM_COL32(15,  15,  15,  160);
                dl->AddRectFilled(pmin, pmax, bgColor, 14.0f);
                ImU32 accentColor = enabled
                    ? IM_COL32((int)(overlayOnColor.x  * 255), (int)(overlayOnColor.y  * 255),
                               (int)(overlayOnColor.z  * 255), 255)
                    : IM_COL32((int)(overlayOffColor.x * 255), (int)(overlayOffColor.y * 255),
                               (int)(overlayOffColor.z * 255), 255);
                dl->AddRectFilled(
                    ImVec2(pmin.x,     pmin.y + 8),
                    ImVec2(pmin.x + 4, pmax.y - 8),
                    accentColor, 2.0f);
                float dotY = (pmin.y + pmax.y) * 0.5f;
                dl->AddCircleFilled(ImVec2(pmin.x + 18, dotY), 5.0f, accentColor);
                float textY = ((float)oh - ImGui::GetFontSize()) * 0.5f;
                ImGui::SetCursorPos(ImVec2(30.0f, textY));
                if (enabled) {
                    ImGui::TextColored(overlayOnColor,  "Lag Switch  ON");
                } else {
                    ImGui::TextColored(overlayOffColor, "Lag Switch  OFF");
                }
            }
            ImGui::End();

            ImGui::Render();
            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
            glfwSwapBuffers(overlayWindow);
            glfwMakeContextCurrent(window);
            ImGui::SetCurrentContext(mainCtx);
        }
        // =========================================
    }

    ImGui::SetCurrentContext(mainCtx);
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext(mainCtx);
    if (overlayWindow && overlayCtx)
    {
        glfwMakeContextCurrent(overlayWindow);
        ImGui::SetCurrentContext(overlayCtx);
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplGlfw_Shutdown();
        ImGui::DestroyContext(overlayCtx);
        glfwDestroyWindow(overlayWindow);
    }

    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}
