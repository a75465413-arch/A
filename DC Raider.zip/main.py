"""
py -3.11 -m pip install pywebview flask flask-cors tls_client
"""

import os
import time
import threading
import webview
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import tls_client as _tls

BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
HTML_PATH = os.path.join(BASE_DIR, "menu.html")

FLASK_HOST = "127.0.0.1"
FLASK_PORT = 5001

flask_app = Flask(__name__)
CORS(flask_app)

_FALLBACK = {
    "fingerprint": "1530137140145688598.jtTH1wVfciqh-VToVK6jM0ggr6I",
    "assignments": [
        [3013881204, 5, 11, -1, 1, 3521, 0, 0, None, None, None],
        [2180379513, 0,  1, -1, 4, 4781, 0, 0, None, None, None],
        [1112953678, 1,  1, -1, 0, 3161, 0, 0, None, None, None],
        [4285324985, 0,  1, -1, 0, 4249, 0, 0, None, None, None],
        [1022342504, 1,  1, -1, 0, 6805, 0, 0, None, None, None],
    ],
    "installation": "1530137140145688599.k5FsfnZh-nnVgl1zSOCXd_okVe8",
    "guild_experiments": [],
}

_FORWARD_HEADERS = [
    "authorization", "x-context-properties", "x-debug-options",
    "x-discord-locale", "x-discord-timezone", "x-super-properties",
]

_BASE_HEADERS = {
    "accept": "*/*",
    "accept-language": "ja,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
    "sec-ch-ua": '"Not=A?Brand";v="99", "Microsoft Edge";v="151", "Chromium";v="151"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "x-debug-options": "bugReporterEnabled",
    "Referer": "https://discord.com/channels/@me",
    "Origin": "https://discord.com",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
}

@flask_app.route("/")
def serve_html():
    return send_file(HTML_PATH)

def run_flask():
    import logging
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    flask_app.run(host=FLASK_HOST, port=FLASK_PORT, debug=False, use_reloader=False)

class WindowAPI:
    def __init__(self):
        self._window = None

    def set_window(self, w):
        self._window = w

    def minimize(self):
        if self._window: self._window.minimize()

    def close_window(self):
        if self._window: self._window.destroy()

    def move_window(self, x: int, y: int):
        if self._window: self._window.move(int(x), int(y))

    def get_position(self):
        if self._window:
            return {"x": self._window.x, "y": self._window.y}
        return {"x": 0, "y": 0}

    def save_checker_results(self, valid: list, nitro: list, locked: list, invalid: list):
        output_dir = os.path.join(BASE_DIR, "output")
        os.makedirs(output_dir, exist_ok=True)
        for filename, tokens in [
            ("valid.txt", valid), ("nitro.txt", nitro),
            ("locked.txt", locked), ("invalid.txt", invalid),
        ]:
            with open(os.path.join(output_dir, filename), "w", encoding="utf-8") as f:
                f.write("\n".join(tokens))
        return True

def main():
    t = threading.Thread(target=run_flask, daemon=True)
    t.start()
    time.sleep(1.0)
    api = WindowAPI()
    window = webview.create_window(
        title="Discord Tool",
        url=f"http://{FLASK_HOST}:{FLASK_PORT}/",
        js_api=api,
        width=960,
        height=640,
        min_size=(720, 480),
        resizable=True,
        frameless=True,
        easy_drag=False,
        background_color="#121212",
    )
    api.set_window(window)
    webview.start(debug=False)
if __name__ == "__main__":
    main()