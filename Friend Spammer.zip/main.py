import json
import os
import threading
import time
import webview
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from account_generator import (
    create_multiple_accounts,
    create_multiple_nintendo_accounts,
    warp_rotate,
    get_logs,
    add_log,
)

AUTH_FILE = 'device_auths.json'
ANDROID_TOKEN = "M2Y2OWU1NmM3NjQ5NDkyYzhjYzI5ZjFhZjA4YThhMTI6YjUxZWU5Y2IxMjIzNGY1MGE2OWVmYTY3ZWY1MzgxMmU="

class FortniteAPIClient:
    def __init__(self, auth):
        self.auth = auth
        self.access_token = None
        self.session = requests.Session()

    def login(self):
        url = "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"basic {ANDROID_TOKEN}"
        }
        data = {
            "grant_type": "device_auth",
            "account_id": self.auth.get("account_id") or self.auth.get("accountId"),
            "device_id": self.auth.get("device_id") or self.auth.get("deviceId"),
            "secret": self.auth.get("secret")
        }
        res = self.session.post(url, headers=headers, data=data)
        if res.status_code == 200:
            self.access_token = res.json().get("access_token")
            return True
        return False

    def get_display_name(self, display_name):
        if not self.access_token and not self.login():
            return None
        url = f"https://account-public-service-prod03.ol.epicgames.com/account/api/public/account/displayName/{display_name}"
        headers = {"Authorization": f"bearer {self.access_token}"}
        res = self.session.get(url, headers=headers)
        if res.status_code == 200:
            return res.json()
        return None

    def get_by_external_id(self, display_name, platform):
        if not self.access_token and not self.login():
            return None
        url = (
            f"https://account-public-service-prod.ol.epicgames.com"
            f"/account/api/public/account/lookup/externalAuth/{platform}/displayName/{requests.utils.quote(display_name)}"
            f"?caseInsensitive=true"
        )
        headers = {"Authorization": f"bearer {self.access_token}"}
        res = self.session.get(url, headers=headers)
        if res.status_code == 200:
            data = res.json()
            if isinstance(data, list) and len(data) > 0:
                return data[0]
        return None

    def add_friend(self, target_id):
        if not self.access_token and not self.login():
            return False
        acc_id = self.auth.get("account_id") or self.auth.get("accountId")
        url = f"https://friends-public-service-prod.ol.epicgames.com/friends/api/v1/{acc_id}/friends/{target_id}"
        headers = {"Authorization": f"bearer {self.access_token}"}
        res = self.session.post(url, headers=headers)
        return res.status_code in [200, 204]

    def remove_friend(self, target_id):
        if not self.access_token and not self.login():
            return False
        acc_id = self.auth.get("account_id") or self.auth.get("accountId")
        url = f"https://friends-public-service-prod.ol.epicgames.com/friends/api/v1/{acc_id}/friends/{target_id}"
        headers = {"Authorization": f"bearer {self.access_token}"}
        res = self.session.delete(url, headers=headers)
        return res.status_code in [200, 204]


class Api:
    def __init__(self):
        self.is_looping = False
        self.target = ""
        self.cycle_count = 0
        self.active_clients = []
        self.is_generating = False

    def get_auths(self):
        if os.path.exists(AUTH_FILE):
            try:
                with open(AUTH_FILE, 'r', encoding='utf-8') as f:
                    content = f.read().strip()
                    if content:
                        data = json.loads(content)
                        converted = {}
                        if isinstance(data, list):
                            for acc in data:
                                aid = acc.get("account_id") or acc.get("accountId")
                                if aid:
                                    converted[aid] = acc
                        elif isinstance(data, dict):
                            for aid, acc in data.items():
                                converted[aid] = acc
                        return converted
            except Exception as e:
                add_log(f"[-] アカウント情報の読み込みエラー: {e}")
                return {}
        return {}

    def generate_account(self, count=1):
        if self.is_generating:
            add_log("[!] 既にアカウント生成処理が実行中です。")
            return {"status": "already_running"}
        
        try:
            count = int(count)
            if count < 1:
                count = 1
        except:
            count = 1

        def background_generation():
            self.is_generating = True
            try:
                create_multiple_accounts(count)
            except Exception as e:
                add_log(f"[-] アカウント生成エラー: {e}")
            finally:
                self.is_generating = False

        threading.Thread(target=background_generation, daemon=True).start()
        return {"status": "started", "count": count}

    def generate_nintendo_account(self, count=1, use_warp=True):
        if self.is_generating:
            add_log("[!] 既にアカウント生成処理が実行中です。")
            return {"status": "already_running"}

        try:
            count = int(count)
            if count < 1:
                count = 1
        except:
            count = 1

        use_warp = bool(use_warp)

        def background_nintendo():
            self.is_generating = True
            try:
                create_multiple_nintendo_accounts(count, use_warp=use_warp)
            except Exception as e:
                add_log(f"[-] Nintendoアカウント生成エラー: {e}")
            finally:
                self.is_generating = False

        threading.Thread(target=background_nintendo, daemon=True).start()
        return {"status": "started", "count": count, "use_warp": use_warp}

    def load_accounts(self):
        add_log("[*] 保存されているすべてのデバイス認証をロードしています...")
        auths = self.get_auths()

        def try_login(auth_data):
            name = auth_data.get("display_name") or auth_data.get("displayName") or "Unknown"
            client = FortniteAPIClient(auth_data)
            if client.login():
                add_log(f"[+] アカウント [{name}] ログイン成功")
                return client
            else:
                add_log(f"[-] アカウント [{name}] ログイン失敗 (認証切れの可能性があります)")
                return None

        auth_list = list(auths.values())
        max_workers = min(len(auth_list), 20) if auth_list else 1

        self.active_clients = []
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(try_login, auth_data): auth_data for auth_data in auth_list}
            for future in as_completed(futures):
                result = future.result()
                if result is not None:
                    self.active_clients.append(result)

        add_log(f"[+] ロード完了: 合計 {len(self.active_clients)} 件のアカウントが準備できました。")
        return {"loaded_count": len(self.active_clients)}

    def set_target(self, target_id):
        self.target = target_id.strip()
        add_log(f"[+] ターゲットIDがセットされました: {self.target}")
        return {"status": "success", "target": self.target}

    def search_id(self, name, platform="auto"):
        add_log(f"[*] '{name}' のアカウントIDを検索しています... (プラットフォーム: {platform})")
        if not self.active_clients:
            add_log("[-] エラー: アカウントがロードされていません。先にロードしてください。")
            return {"error": "アカウントがロードされていません。"}

        PLATFORM_LABELS = {
            "epic":     "Epic Games",
            "psn":      "PlayStation Network",
            "xbl":      "Xbox Live",
            "nintendo": "Nintendo",
            "steam":    "Steam",
        }
        if platform != "auto":
            if platform == "epic":
                result = self.active_clients[0].get_display_name(name)
                if result:
                    acc_id    = result.get("id")
                    disp_name = result.get("displayName")
                    add_log(f"[+] 検索成功 (Epic Games) -> 表示名: {disp_name} / ID: {acc_id}")
                    return {"id": acc_id, "displayName": disp_name, "platform": "epic"}
            else:
                label = PLATFORM_LABELS.get(platform, platform)
                add_log(f"[*] {label} で '{name}' を検索中...")
                ext_result = self.active_clients[0].get_by_external_id(name, platform)
                if ext_result:
                    acc_id    = ext_result.get("id") or ext_result.get("accountId")
                    disp_name = ext_result.get("displayName") or name
                    add_log(f"[+] 検索成功 ({label}) -> 表示名: {disp_name} / ID: {acc_id}")
                    return {"id": acc_id, "displayName": disp_name, "platform": platform}

            add_log(f"[-] 検索結果: '{name}' が {PLATFORM_LABELS.get(platform, platform)} で見つかりませんでした。")
            return {"error": f"{PLATFORM_LABELS.get(platform, platform)} で見つかりませんでした。"}

        # 自動モード: Epic → PSN → Xbox → Nintendo → Steam の順に試す
        add_log(f"[*] 自動モード: Epic表示名で検索中...")
        result = self.active_clients[0].get_display_name(name)
        if result:
            acc_id    = result.get("id")
            disp_name = result.get("displayName")
            add_log(f"[+] 検索成功 (Epic Games) -> 表示名: {disp_name} / ID: {acc_id}")
            return {"id": acc_id, "displayName": disp_name, "platform": "epic"}

        add_log(f"[!] Epic表示名では見つかりませんでした。外部プラットフォームで検索します...")
        for platform_key, platform_label in [("psn", "PlayStation Network"), ("xbl", "Xbox Live"), ("nintendo", "Nintendo"), ("steam", "Steam")]:
            add_log(f"[*] {platform_label} で '{name}' を検索中...")
            ext_result = self.active_clients[0].get_by_external_id(name, platform_key)
            if ext_result:
                acc_id    = ext_result.get("id") or ext_result.get("accountId")
                disp_name = ext_result.get("displayName") or name
                add_log(f"[+] 検索成功 ({platform_label}) -> 表示名: {disp_name} / ID: {acc_id}")
                return {"id": acc_id, "displayName": disp_name, "platform": platform_key}

        add_log(f"[-] 検索結果: '{name}' はどのプラットフォームでも見つかりませんでした。")
        return {"error": "見つかりませんでした。"}

    def start_loop(self):
        if not self.target:
            add_log("[-] エラー: ターゲットIDが設定されていません。")
            return {"error": "ターゲットが未設定です。"}
        if not self.active_clients:
            add_log("[-] エラー: アクティブなアカウントがありません。先にロードしてください。")
            return {"error": "アカウントがロードされていません。"}
        
        self.is_looping = True
        self.cycle_count = 0
        add_log(f"=== スパムを開始しました (ターゲット: {self.target}) ===")

        def spam_worker():
            def send_one(client, idx):
                acc_name = client.auth.get("display_name") or f"Acc#{idx+1}"
                try:
                    success = client.add_friend(self.target)
                    if success:
                        self.cycle_count += 1
                        add_log(f"[送信成功] ({acc_name}) 申請送信 (総送信数: {self.cycle_count})")
                    client.remove_friend(self.target)
                except Exception as err:
                    add_log(f"[-] スパム処理中に例外が発生しました ({acc_name}): {err}")

            max_workers = min(len(self.active_clients), 20)
            while self.is_looping:
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [
                        executor.submit(send_one, client, idx)
                        for idx, client in enumerate(self.active_clients)
                        if self.is_looping
                    ]
                    for future in as_completed(futures):
                        future.result()
                time.sleep(0.1)

            add_log("=== スパム処理が停止しました ===")

        threading.Thread(target=spam_worker, daemon=True).start()
        return {"status": "started"}

    def stop_loop(self):
        if self.is_looping:
            add_log("[!] ユーザーによってスパム処理の停止が要求されました。")
            self.is_looping = False
        return {"status": "stopped"}

    def get_status(self):
        return {
            "isLooping": self.is_looping,
            "target": self.target,
            "cycleCount": self.cycle_count,
            "activeCount": len(self.active_clients),
            "isGenerating": self.is_generating
        }

    def fetch_logs(self):
        return get_logs()

    def rotate_warp(self):
        result = warp_rotate()
        return {"status": "success" if result else "skipped"}

    def minimize_window(self):
        window.minimize()

    def close_window(self):
        window.destroy()

if __name__ == '__main__':
    api = Api()
    window = webview.create_window(
        'Fortnite Tool GUI', 
        'gui/index.html', 
        js_api=api, 
        width=850, 
        height=650, 
        frameless=True,
        background_color='#121212'
    )
    webview.start()