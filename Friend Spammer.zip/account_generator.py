import random
import string
import time
import re
import base64
import subprocess
import requests
import json
import os
from playwright.sync_api import sync_playwright

STORE_FILE = "device_auths.json"
SWITCH_TOKEN = "OThmN2U0MmMyZTNhNGY4NmE3NGViNDNmYmI0MWVkMzk6MGEyNDQ5YTItMDAxYS00NTFlLWFmZWMtM2U4MTI5MDFjNGQ3"
ANDROID_TOKEN = "M2Y2OWU1NmM3NjQ5NDkyYzhjYzI5ZjFhZjA4YThhMTI6YjUxZWU5Y2IxMjIzNGY1MGE2OWVmYTY3ZWY1MzgxMmU="

WARP_CLI = r"C:\Program Files\Cloudflare\Cloudflare WARP\warp-cli.exe"

execution_logs = []

def add_log(message):
    timestamp = time.strftime("[%H:%M:%S] ")
    log_entry = timestamp + message
    print(log_entry)
    execution_logs.append(log_entry)
    if len(execution_logs) > 100:
        execution_logs.pop(0)

def get_logs():
    return execution_logs

def generate_random_string(length=8):
    return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

def generate_epic_password():
    lower = random.choice(string.ascii_lowercase)
    upper = random.choice(string.ascii_uppercase)
    digit = random.choice(string.digits)
    symbol = random.choice("!@#$%^&*")
    others = ''.join(random.choice(string.ascii_letters + string.digits + "!@#$%^&*") for _ in range(8))
    password_list = list(lower + upper + digit + symbol + others)
    random.shuffle(password_list)
    return ''.join(password_list)

def human_sleep(min_sec=1.0, max_sec=1.0):
    time.sleep(random.uniform(min_sec, max_sec))

def warp_rotate():
    """Cloudflare WARPをdisconnect→connectしてIPをローテーションする"""
    try:
        add_log("[*] WARP: IPローテーション開始...")
        subprocess.run([WARP_CLI, "disconnect"], capture_output=True, timeout=10)
        time.sleep(1.5)
        subprocess.run([WARP_CLI, "connect"],    capture_output=True, timeout=10)
        time.sleep(2.0)
        add_log("[+] WARP: IPローテーション完了")
        return True
    except FileNotFoundError:
        add_log("[!] WARP: warp-cli.exe が見つかりません。スキップします。")
        return False
    except Exception as e:
        add_log(f"[!] WARP: ローテーション失敗 ({e}). スキップします。")
        return False

def save_account_to_json(new_acc_data):
    accounts = {}
    if os.path.exists(STORE_FILE):
        try:
            with open(STORE_FILE, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    loaded = json.loads(content)
                    if isinstance(loaded, list):
                        for acc in loaded:
                            accounts[acc.get("account_id") or acc.get("accountId")] = acc
                    elif isinstance(loaded, dict):
                        accounts = loaded
        except Exception:
            accounts = {}
    
    acc_id = new_acc_data.get("account_id") or new_acc_data.get("accountId")
    accounts[acc_id] = new_acc_data
    with open(STORE_FILE, "w", encoding="utf-8") as fp:
        json.dump(list(accounts.values()), fp, sort_keys=False, indent=4, ensure_ascii=False)

def generate_email():
    url = "https://api.tempmail.ing/api/generate"
    headers = {"content-type": "application/json"}
    response = requests.post(url, json={"duration": 10}, headers=headers)
    return response.json()

def check_emails(email_address):
    encoded_email = email_address.replace("@", "%40")
    url = f"https://api.tempmail.ing/api/emails/{encoded_email}"
    response = requests.get(url)
    return response.json()

def extract_epic_code(html_content):
    if not html_content:
        return None
    match = re.search(r"font-size:\s*40px[^>]*>[\s\S]*?<p[^>]*>\s*(\d{6})\s*</p>", html_content)
    if match:
        return match.group(1)
    match_fallback = re.search(r">\s*(\d{6})\s*<", html_content)
    if match_fallback:
        return match_fallback.group(1)
    return None

def create_single_account():
    add_log("Chromiumブラウザを起動しています...")
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=False,
            args=["--disable-blink-features=AutomationControlled", "--disable-infobars", "--start-maximized"]
        )
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            viewport={"width": 1280, "height": 800}
        )
        
        try:
            add_log("一時メールアドレスを取得中...")
            gen_data = generate_email()
            if not gen_data.get("success"):
                add_log("[-] エラー: 一時メールの取得に失敗しました。")
                browser.close()
                return False
                
            temp_email = gen_data["email"]["address"]
            add_log(f"[+] 一時メール取得成功: {temp_email}")
            
            add_log("Epic Gamesの登録ページへ移動中...")
            epic_page = context.new_page()
            epic_page.goto("https://www.epicgames.com/id/register/summarized")
            epic_page.wait_for_load_state("networkidle")
            time.sleep(3.0)
            
            add_log("生年月日を入力中...")
            random_year = str(random.randint(1980, 2000))
            random_month = str(random.randint(1, 12))
            random_day = str(random.randint(1, 28))
            
            epic_page.fill("#year", random_year)
            human_sleep(0.5, 1.0)
            
            epic_page.click("#month")
            human_sleep(0.4)
            epic_page.keyboard.type(random_month)
            human_sleep(0.4)
            epic_page.keyboard.press("ArrowDown")
            human_sleep(0.4)
            epic_page.keyboard.press("Enter")
            human_sleep(0.4)
            
            epic_page.fill("#day", random_day)
            human_sleep(0.5)
            
            epic_page.click("#continue")
            human_sleep(0.5)
            
            add_log("一時メールアドレスをフォームに入力中...")
            epic_page.wait_for_selector("#email", timeout=10000)
            epic_page.fill("#email", temp_email)
            human_sleep(0.5)
            epic_page.click("#send")
            human_sleep(0.5)
            
            add_log("アカウントのプロフィールを設定中...")
            epic_page.wait_for_selector("#name", timeout=10000)
            first_name = "User" + generate_random_string(5)
            last_name = "Test" + generate_random_string(5)
            password = generate_epic_password()
            
            epic_page.fill("#name", first_name)
            human_sleep(0.3)
            epic_page.fill("#lastName", last_name)
            human_sleep(0.3)
            epic_page.fill("#password", password)
            human_sleep(0.3)
            
            epic_page.click("#tos")
            human_sleep(0.3)
            epic_page.click("#btn-submit")
            
            add_log("[!] キャプチャ/Cloudflareの画面が表示されています。手動で解決してください。")
            verify_label_selector = "#email-verify-label"
            epic_page.wait_for_selector(verify_label_selector, timeout=300000)
            add_log("[+] キャプチャのクリアを検出しました。")

            add_log("確認メールの到着を待機しています...")
            email_found = False
            verification_code = None
            for i in range(30):
                time.sleep(4.0)
                email_data = check_emails(temp_email)
                if email_data.get("success") and email_data.get("emails"):
                    for mail in email_data["emails"]:
                        from_address = mail.get("from_address", "")
                        if "acct-auth.epicgames.com" in from_address or "epicgames.com" in from_address:
                            html_content = mail.get("content", "")
                            verification_code = extract_epic_code(html_content)
                            email_found = True
                            break
                if email_found:
                    break
            
            if not email_found or not verification_code:
                add_log("[-] エラー: 確認メールの受信がタイムアウトしました。")
                browser.close()
                return False
                
            add_log(f"[+] 認証コード取得成功: {verification_code}")
            
            add_log("確認コードを入力中...")
            epic_page.bring_to_front()
            time.sleep(1)
            
            for index, digit in enumerate(verification_code):
                input_selector = f"input[name='code-input-{index}']"
                epic_page.wait_for_selector(input_selector, timeout=5000)
                epic_page.fill(input_selector, digit)
                time.sleep(0.2)
            
            human_sleep(0.5)
            epic_page.click("#continue")
            time.sleep(4.0)
            
            add_log("DeviceAuthを生成しています...")
            token_res = requests.post(
                "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
                headers={"Content-Type": "application/x-www-form-urlencoded", "Authorization": f"basic {SWITCH_TOKEN}"},
                data={"grant_type": "client_credentials"}
            )
            access_token = token_res.json().get("access_token")
            
            device_res = requests.post(
                "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/deviceAuthorization",
                headers={"Authorization": f"bearer {access_token}", "Content-Type": "application/x-www-form-urlencoded"}
            )
            device_data = device_res.json()
            verification_uri = device_data.get("verification_uri_complete")
            device_code = device_data.get("device_code")
            
            device_page = context.new_page()
            device_page.goto(verification_uri)
            
            try:
                device_page.wait_for_selector("#confirm", timeout=15000)
                human_sleep(1.0, 1.5)
                device_page.click("#confirm")
                add_log("デバイス認証が完了しました。")
            except:
                pass
            
            oauth_token = None
            for _ in range(30):
                poll_res = requests.post(
                    "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/token",
                    headers={"Authorization": f"basic {SWITCH_TOKEN}", "Content-Type": "application/x-www-form-urlencoded"},
                    data={"grant_type": "device_code", "device_code": device_code},
                )
                poll_data = poll_res.json()
                if poll_res.status_code == 200:
                    oauth_token = poll_data.get("access_token")
                    break
                time.sleep(3)
            
            if not oauth_token:
                add_log("[-] エラー: デバイス認証のポーリングがタイムアウトしました。")
                browser.close()
                return False
                
            ex_res = requests.get(
                "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/exchange",
                headers={"Authorization": f"bearer {oauth_token}"}
            )
            ex_code = ex_res.json().get("code")
            
            user_res = requests.post(
                "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
                headers={"Authorization": f"basic {ANDROID_TOKEN}", "Content-Type": "application/x-www-form-urlencoded"},
                data={"grant_type": "exchange_code", "exchange_code": ex_code},
            )
            user_data = user_res.json()
            user_access_token = user_data.get("access_token")
            account_id = user_data.get("account_id")
            display_name = user_data.get("displayName")
            
            da_res = requests.post(
                f"https://account-public-service-prod.ol.epicgames.com/account/api/public/account/{account_id}/deviceAuth",
                headers={"Authorization": f"bearer {user_access_token}", "Content-Type": "application/json"}
            )
            da_data = da_res.json()
            
            account_entry = {
                "display_name": display_name,
                "account_id": da_data["accountId"],
                "device_id": da_data["deviceId"],
                "secret": da_data["secret"]
            }
            
            save_account_to_json(account_entry)
            add_log(f"[SUCCESS] アカウント [{display_name}] の作成と認証情報の保存が完了しました！")
            browser.close()
            return True

        except Exception as e:
            add_log(f"[-] 致命的なエラーが発生しました: {e}")
            try:
                browser.close()
            except:
                pass
            return False

def create_multiple_accounts(count):
    add_log(f"=== 合計 {count} 件のアカウント生成プロセスを開始します ===")
    for i in range(count):
        add_log(f"\n--- [{i+1} / {count}] 件目のアカウント作成を開始 ---")
        success = create_single_account()
        if not success:
            add_log(f"[!] {i+1} 件目のアカウント作成に失敗または中断されました。")
        if i < count - 1:
            add_log("次のアカウント作成まで3秒間待機します...")
            time.sleep(3)
    add_log("=== 全てのアカウント生成処理が完了しました ===")


# ============================================================
# Nintendo アカウント自動作成
# ============================================================

NINTENDO_REGISTER_URL = (
    "https://accounts.nintendo.com/register"
    "?post_register_redirect_uri=https%3A%2F%2Faccounts.nintendo.com%2F"
)

def generate_nintendo_nickname(length=8):
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(min(length, 10)))

def extract_nintendo_email_code(text_content):
    if not text_content:
        return None
    match = re.search(r'▼認証コード\s*\n\s*(\d{4})', text_content)
    if match:
        return match.group(1)
    match2 = re.search(r'\b(\d{4})\b', text_content)
    if match2:
        return match2.group(1)
    return None

def create_nintendo_account(use_warp=True):
    add_log("=== Nintendoアカウント作成を開始します ===")
    if use_warp:
        warp_rotate()
    else:
        add_log("[*] WARP ローテーションはスキップします（無効）")

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=False,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-infobars",
                "--start-maximized",
            ],
        )
        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 800},
        )

        try:
            add_log("一時メールアドレスを取得中...")
            gen_data = generate_email()
            if not gen_data.get("success"):
                add_log("[-] 一時メールの取得に失敗しました。")
                browser.close()
                return None

            temp_email = gen_data["email"]["address"]
            add_log(f"[+] 一時メール: {temp_email}")

            nickname = generate_nintendo_nickname(8)
            password = generate_epic_password()
            birth_year  = str(random.randint(1990, 2000))
            birth_month = str(random.randint(1, 12))
            birth_day   = str(random.randint(1, 28))

            add_log(f"[*] ニックネーム: {nickname} / 誕生日: {birth_year}/{birth_month}/{birth_day}")

            page = context.new_page()
            add_log("Nintendo登録ページへ移動中...")
            page.goto(NINTENDO_REGISTER_URL)
            page.wait_for_load_state("domcontentloaded")

            add_log("フォームを入力中...")
            page.wait_for_selector("#register-form_pc_input_0", timeout=15000)
            page.fill("#register-form_pc_input_0", nickname)
            page.fill("#email", temp_email)
            page.fill("#register-form_pc_input_1", password)
            page.fill("#register-form_pc_input_2", password)
            page.select_option("#birth-year-field",  value=birth_year)
            page.select_option("#birth-month-field", value=birth_month)
            page.select_option("#birth-day-field",   value=birth_day)
            page.select_option("#register-form_pc_select_0", value="unknown")

            add_log("利用規約・プライバシーポリシーに同意中...")
            terms_div = page.locator("#form-terms_consented").locator("xpath=ancestor::div[contains(@class,'c-checkbox')][1]")
            terms_div.scroll_into_view_if_needed()
            terms_div.click()
            policy_div = page.locator("#form-policy_consented").locator("xpath=ancestor::div[contains(@class,'c-checkbox')][1]")
            policy_div.scroll_into_view_if_needed()
            policy_div.click()

            add_log("「作成する」ボタンが有効化されるのを待機しています...")
            register_btn = page.locator("#register-form_pc_button_4")
            register_btn.wait_for(state="visible", timeout=15000)
            for _ in range(20):
                if register_btn.get_attribute("disabled") is None:
                    break
                time.sleep(0.3)
            add_log("「作成する」ボタンをクリックしています...")
            register_btn.click()

            add_log("PINコード入力ページへの遷移を待機中...")
            pincode_reached = False
            deadline = time.time() + 300
            try:
                while time.time() < deadline:
                    err_el = page.locator("p.CdnDisplayErrorErrorMsg_message")
                    if err_el.count() > 0:
                        add_log("[!] Nintendoエラーを検出しました。60秒待機後にリトライします...")
                        time.sleep(60)
                        browser.close()
                        return None

                    if "/register/pincode" in page.url:
                        pincode_reached = True
                        break

                    try:
                        page.wait_for_url("**/register/pincode**", timeout=2000)
                        pincode_reached = True
                        break
                    except Exception:
                        pass

            except Exception:
                pass

            if not pincode_reached:
                add_log("[-] PINコード入力ページへの遷移がタイムアウトしました。")
                browser.close()
                return None

            add_log("[+] PINコード入力ページを検出しました。")

            add_log("確認メールの到着を待機しています（タイムアウト: 10秒）...")
            verification_code = None
            deadline = time.time() + 10.0
            attempt = 0
            while time.time() < deadline:
                attempt += 1
                email_data = check_emails(temp_email)
                if email_data.get("success") and email_data.get("emails"):
                    for mail in email_data["emails"]:
                        if "nintendo" in mail.get("from_address", "").lower():
                            mail_text = mail.get("text") or mail.get("content", "")
                            verification_code = extract_nintendo_email_code(mail_text)
                            if verification_code:
                                break
                if verification_code:
                    add_log(f"[+] PINコード取得成功: {verification_code} ({attempt}回目で発見)")
                    break
                time.sleep(1.0)

            if not verification_code:
                add_log("[-] 10秒以内に確認メールが届きませんでした。このアカウントをスキップします。")
                browser.close()
                return None

            add_log("PINコードをフォームに入力中...")
            page.bring_to_front()
            pincode_selector = "#register-pincode-form_pc_input_0"
            page.wait_for_selector(pincode_selector, timeout=10000)
            page.fill(pincode_selector, verification_code)
            time.sleep(0.3)
            try:
                page.click("button[type='submit'], input[type='submit']")
            except Exception:
                pass
            time.sleep(1.5)
            add_log(f"[+] Nintendoアカウントのメール認証が完了しました！ email={temp_email}")

            # ================================================================
            # EpicヘッドレスアカウントをNintendo OAuthで作成
            # ================================================================
            NINTENDO_OAUTH_URL = (
                "https://accounts.nintendo.com/connect/1.0.0/authorize"
                "?client_id=1f6a6a4806931686"
                "&redirect_uri=https%3A%2F%2Faccounts.epicgames.com%2FOAuthAuthorized"
                "&display=popup&state=egs&force_verify=true"
                "&scope=openid+user.screenName&response_type=code"
            )

            add_log("[*] Nintendo OAuthページを開いています...")
            oauth_page = context.new_page()
            oauth_page.goto(NINTENDO_OAUTH_URL)

            try:
                oauth_page.wait_for_selector("#authorize", timeout=30000)
                human_sleep(0.5, 1.0)
                oauth_page.click("#authorize")
                add_log("[+] 同意ボタンをクリックしました。")
            except Exception:
                add_log("[!] 同意ボタンが見つかりませんでした。")

            try:
                oauth_page.wait_for_url("**/oauth-authorized**", timeout=60000)
            except Exception:
                add_log("[-] Nintendo OAuth リダイレクトがタイムアウトしました。")
                browser.close()
                return None

            redirected_url = oauth_page.url
            add_log(f"[DEBUG] Step1 OAuthリダイレクト先URL: {redirected_url}")
            oauth_code = None
            if "code=" in redirected_url:
                part = redirected_url.split("code=", 1)[1]
                # &state= より前を取る
                oauth_code = part.split("&state=", 1)[0].strip()
            if not oauth_code:
                add_log("[-] OAuthコードの抽出に失敗しました。")
                browser.close()
                return None
            add_log(f"[+] OAuthコード取得成功: {oauth_code[:20]}...")
            oauth_page.close()

            if use_warp:
                add_log("[*] Step2前にWARP IPローテーションを実行します...")
                warp_rotate()

            add_log("[*] Epicヘッドレスアカウントを作成中...")
            SWITCH_TOKEN_TUPLE = ("98f7e42c2e3a4f86a74eb43fbb41ed39", "0a2449a2-001a-451e-afec-3e812901c4d7")
            ANDROID_TOKEN_TUPLE = ("3f69e56c7649492c8cc29f1af08a8a12", "b51ee9cb12234f50a69efa67ef53812e")

            def _basic(creds):
                return "basic " + base64.b64encode(f"{creds[0]}:{creds[1]}".encode()).decode()

            cc_res = requests.post(
                "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
                headers={"Authorization": _basic(SWITCH_TOKEN_TUPLE),
                         "Content-Type": "application/x-www-form-urlencoded"},
                data={"grant_type": "client_credentials"},
            )
            cc_token = cc_res.json().get("access_token")
            if not cc_token:
                add_log(f"[-] client_credentials取得失敗: {cc_res.text}")
                browser.close()
                return None

            create_res = None
            create_data = {}
            for step2_retry in range(3):
                if step2_retry > 0:
                    if use_warp:
                        add_log(f"[*] Step2 リトライ前にWARP IPローテーション ({step2_retry}/2)...")
                        warp_rotate()
                    else:
                        add_log(f"[*] Step2 リトライ {step2_retry}/2 (WARPオフ)...")
                create_res = requests.post(
                    "https://account-public-service-prod.ol.epicgames.com/account/api/public/account",
                    headers={"Authorization": f"bearer {cc_token}",
                             "Content-Type": "application/json"},
                    json={"dateOfBirth": "2000-01-01",
                          "externalAuth": {"authType": "nintendo", "externalAuthToken": oauth_code}},
                )
                create_data = create_res.json()
                add_log(f"[DEBUG] Step2 status={create_res.status_code} / body={json.dumps(create_data)[:400]}")

                if create_res.status_code == 429:
                    wait_sec = int(create_data.get("messageVars", [30])[0]) if create_data.get("messageVars") else 30
                    wait_sec = min(wait_sec, 30)  # 最大30秒に制限
                    add_log(f"[!] 429 Throttled。{wait_sec}秒待機後にIPを変えてリトライします...")
                    time.sleep(wait_sec)
                    continue

                if create_res.status_code in (200, 201):
                    add_log(f"[+] ヘッドレスアカウント作成成功 (status={create_res.status_code})")
                    break
                else:
                    err_code = create_data.get("errorCode", "")
                    if "already" in err_code or "duplicate" in err_code:
                        add_log(f"[+] ヘッドレスアカウントは既に存在します (続行)")
                        break
                    else:
                        add_log(f"[!] ヘッドレスアカウント作成失敗: {err_code}")
                        break
            else:
                add_log("[-] Step2: 3回試行しても429が解消されませんでした。スキップします。")
                browser.close()
                return None

            # Epic側のDB反映を待つ
            add_log("[*] Epicアカウント反映待機中 (5秒)...")
            time.sleep(5)

            # --- Step3 & Step4: OAuthコード取得 → external_auth（コード失効時は取り直してリトライ） ---
            NINTENDO_OAUTH_URL_NOVERIFY = NINTENDO_OAUTH_URL.replace("&force_verify=true", "")

            def fetch_oauth_code_noverify():
                """同意済みNintendoセッションから新鮮なOAuthコードを取得して返す。失敗時はNone。"""
                p2 = context.new_page()
                try:
                    p2.goto(NINTENDO_OAUTH_URL_NOVERIFY)
                    try:
                        p2.wait_for_selector("#authorize", timeout=5000)
                        p2.click("#authorize")
                        add_log("[+] OAuthコード再取得: 同意ボタンをクリックしました。")
                    except Exception:
                        pass
                    try:
                        # OAuthAuthorized (大文字) と oauth-authorized (小文字) 両方に対応
                        p2.wait_for_url("**OAuthAuthorized**", timeout=30000)
                    except Exception:
                        try:
                            p2.wait_for_url("**/oauth-authorized**", timeout=10000)
                        except Exception:
                            add_log(f"[-] OAuthコード再取得: リダイレクトタイムアウト (現在URL: {p2.url})")
                            return None
                    url = p2.url
                    add_log(f"[DEBUG] OAuthリダイレクト先URL: {url}")
                    if "code=" not in url:
                        return None
                    code = url.split("code=", 1)[1].split("&state=", 1)[0].strip()
                    return code if code else None
                finally:
                    p2.close()

            add_log("[*] Epicトークンを取得中（external_auth、失敗時はコード再取得してリトライ）...")
            tok_data = None
            account_id = None
            sw_token = None
            for retry in range(3):
                add_log(f"[*] Nintendo OAuthコードを新規取得中 (試行{retry+1}/3)...")
                oauth_code2 = fetch_oauth_code_noverify()
                if not oauth_code2:
                    add_log(f"[!] OAuthコード取得失敗 (試行{retry+1}/3)")
                    time.sleep(2)
                    continue
                add_log(f"[+] OAuthコード取得成功: {oauth_code2[:20]}...")

                tok_res = requests.post(
                    "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
                    headers={"Authorization": _basic(SWITCH_TOKEN_TUPLE),
                             "Content-Type": "application/x-www-form-urlencoded"},
                    data={"grant_type": "external_auth",
                          "external_auth_type": "nintendo",
                          "external_auth_token": oauth_code2},
                )
                tok_data = tok_res.json()
                account_id = tok_data.get("account_id")
                sw_token   = tok_data.get("access_token")
                if account_id and sw_token:
                    add_log(f"[+] account_id取得成功: {account_id}")
                    break
                add_log(f"[!] external_auth失敗 (試行{retry+1}/3): {tok_data.get('errorCode', tok_res.text)}")
                time.sleep(5)

            if not account_id or not sw_token:
                add_log("[-] external_authトークン取得失敗（3回試行）。このアカウントをスキップします。")
                browser.close()
                return None

            # --- Step5: exchange_code → Androidトークン ---
            xc_res = requests.get(
                "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/exchange",
                headers={"Authorization": f"bearer {sw_token}"},
            )
            exchange_code = xc_res.json().get("code")

            an_res = requests.post(
                "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
                headers={"Authorization": _basic(ANDROID_TOKEN_TUPLE),
                         "Content-Type": "application/x-www-form-urlencoded"},
                data={"grant_type": "exchange_code", "exchange_code": exchange_code},
            )
            android_token = an_res.json().get("access_token")
            display_name  = an_res.json().get("displayName", "")

            # headlessかどうか確認
            acc_info = requests.get(
                f"https://account-public-service-prod.ol.epicgames.com/account/api/public/account/{account_id}",
                headers={"Authorization": f"bearer {android_token}"},
            ).json()
            is_headless = acc_info.get("headless", False)
            add_log(f"[+] headless={is_headless}  displayName='{display_name}'")

            # --- Step6: DeviceAuth作成・保存 ---
            add_log("[*] DeviceAuthを生成・保存中...")
            da_res = requests.post(
                f"https://account-public-service-prod.ol.epicgames.com/account/api/public/account/{account_id}/deviceAuth",
                headers={"Authorization": f"bearer {android_token}",
                         "Content-Type": "application/json"},
                json={},
            )
            da_data = da_res.json()

            account_entry = {
                "display_name": display_name or f"headless_{account_id[:8]}",
                "account_id":   da_data["accountId"],
                "device_id":    da_data["deviceId"],
                "secret":       da_data["secret"],
            }
            save_account_to_json(account_entry)
            add_log(f"[SUCCESS] ヘッドレスアカウント [{account_entry['display_name']}] の作成・保存が完了しました！")

            browser.close()

            return {
                "email":        temp_email,
                "password":     password,
                "nickname":     nickname,
                "account_id":   account_id,
                "display_name": account_entry["display_name"],
                "headless":     is_headless,
            }

        except Exception as e:
            add_log(f"[-] Nintendo作成中に致命的なエラーが発生しました: {e}")
            try:
                browser.close()
            except Exception:
                pass
            return None


def create_multiple_nintendo_accounts(count, use_warp=True):
    """複数のNintendoアカウントを順番に作成し、結果リストを返す。
    失敗（メールタイムアウト等）した場合は別アカウントで再試行する。
    最大試行回数は count × 3。
    """
    add_log(f"=== 合計 {count} 件のNintendoアカウント生成プロセスを開始します (WARP: {'ON' if use_warp else 'OFF'}) ===")
    results = []
    attempts = 0
    max_attempts = count * 3

    while len(results) < count and attempts < max_attempts:
        attempts += 1
        add_log(f"\n--- [{len(results)+1} / {count}] 件目のNintendoアカウント作成を開始 (試行 {attempts}/{max_attempts}) ---")
        result = create_nintendo_account(use_warp=use_warp)
        if result:
            results.append(result)
            add_log(f"[+] 作成成功: {result['email']} (成功 {len(results)}/{count} 件)")
        else:
            add_log(f"[!] 作成失敗。別のアカウントで再試行します...")

    if len(results) < count:
        add_log(f"[!] 最大試行回数 ({max_attempts}) に達しました。")
    add_log(f"=== Nintendo生成完了: 成功 {len(results)} / {count} 件 (総試行: {attempts} 回) ===")
    return results
