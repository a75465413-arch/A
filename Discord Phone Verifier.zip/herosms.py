"""
HeroSMS API ラッパーモジュール
"""

import time
import urllib.request
import urllib.parse

BASE_URL = "https://hero-sms.com/stubs/handler_api.php"

_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
}


def _request(api_key: str, params: dict) -> str:
    """HeroSMS API に GET リクエストを送り、レスポンス文字列を返す。"""
    params["api_key"] = api_key
    url = BASE_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read().decode("utf-8").strip()


# ---------- エラーマップ ----------
_BUY_ERRORS: dict[str, str] = {
    "NO_NUMBERS":     "利用可能な番号がありません。",
    "NO_BALANCE":     "残高が不足しています。",
    "BAD_SERVICE":    "サービスコードが無効です。",
    "BAD_KEY":        "APIキーが無効です。",
    "BANNED":         "アカウントがBANされています。",
    "CHANNELS_LIMIT": "同時購入数の上限に達しました。",
}


# ---------- 公開関数 ----------

def get_balance(api_key: str) -> float:
    """現在の残高（USD）を返す。"""
    res = _request(api_key, {"action": "getBalance"})
    if res.startswith("ACCESS_BALANCE:"):
        return float(res.split(":")[1])
    raise RuntimeError(f"残高取得失敗: {res}")


def buy_number(api_key: str, service: str, country: int) -> tuple[str, str]:
    """
    番号を購入する。
    Returns:
        (activation_id, phone_number)  phone_number は国コード付き・+ なし
    """
    res = _request(api_key, {
        "action":  "getNumber",
        "service": service,
        "country": country,
    })
    if res.startswith("ACCESS_NUMBER:"):
        _, activation_id, phone_number = res.split(":", 2)
        return activation_id, phone_number

    for code, msg in _BUY_ERRORS.items():
        if res.startswith(code):
            raise RuntimeError(msg)
    raise RuntimeError(f"番号購入失敗: {res}")


def set_ready(api_key: str, activation_id: str) -> None:
    """SMS 受信準備完了を通知する（status=1）。"""
    _request(api_key, {"action": "setStatus", "id": activation_id, "status": "1"})


def get_status(api_key: str, activation_id: str) -> str:
    """
    現在のステータス文字列を返す。
    例: "STATUS_WAIT_CODE" / "STATUS_OK:123456" / "STATUS_CANCEL"
    """
    return _request(api_key, {"action": "getStatus", "id": activation_id})


def complete_activation(api_key: str, activation_id: str) -> None:
    """アクティベーションを完了にする（status=6）。"""
    _request(api_key, {"action": "setStatus", "id": activation_id, "status": "6"})


def cancel_activation(api_key: str, activation_id: str) -> None:
    """アクティベーションをキャンセルして払い戻す（status=8）。"""
    _request(api_key, {"action": "setStatus", "id": activation_id, "status": "8"})


def request_resend(api_key: str, activation_id: str) -> None:
    """SMS の再送を HeroSMS に要求する（status=3）。"""
    _request(api_key, {"action": "setStatus", "id": activation_id, "status": "3"})


def poll_sms(
    api_key: str,
    activation_id: str,
    wait_seconds: int = 1200,
    interval: int = 5,
) -> str:
    """
    SMS コードが届くまでポーリングし、コード文字列を返す。
    タイムアウトまたはキャンセルで RuntimeError を送出。
    """
    deadline = time.time() + wait_seconds
    while time.time() < deadline:
        status = get_status(api_key, activation_id)
        if status.startswith("STATUS_OK:"):
            return status.split(":", 1)[1]
        if status == "STATUS_CANCEL":
            raise RuntimeError("アクティベーションがキャンセルされました。")
        time.sleep(interval)
    raise RuntimeError("タイムアウト: SMS コードが届きませんでした。")
