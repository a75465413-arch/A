import discord
from discord.ext import commands
from discord import app_commands
from dotenv import load_dotenv
import os
import traceback

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN", "")

intents = discord.Intents.all()
bot = commands.Bot(
    command_prefix="$",
    intents=intents,
    help_command=None
)

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

async def setup_hook():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    cogs_dir = os.path.join(base_dir, "Cogs")

    print(f"[INFO] Cogs dir: {cogs_dir}")

    if not os.path.exists(cogs_dir):
        print("[ERROR] Cogsフォルダが存在しません")
        return

    for file in os.listdir(cogs_dir):
        if file.endswith(".py") and not file.startswith("_"):
            ext = f"Cogs.{file[:-3]}"
            try:
                await bot.load_extension(ext)
                print(f"[OK] Loaded Cog: {ext}")
            except Exception as e:
                print(f"[NG] Failed Cog: {ext}")
                traceback.print_exc()

    await bot.tree.sync()
    print("[INFO] Slash commands synced")

bot.setup_hook = setup_hook

@bot.event
async def on_ready():
    command_count = len(bot.tree.get_commands())

    C = "\033[96m"  # 水色
    R = "\033[0m"   # リセット

    base_dir = os.path.dirname(os.path.abspath(__file__))
    ui_path = os.path.join(base_dir, "ui.txt")

    with open(ui_path, "r", encoding="utf-8") as f:
        ui_text = f.read()

    ui_text = ui_text.replace("Bot名", str(bot.user))
    ui_text = ui_text.replace("コマンド数", str(command_count))

    # 枠線文字だけ水色にする
    for ch in "╔╗╚╝║═":
        ui_text = ui_text.replace(ch, C + ch + R)

    clear_console()

    print(ui_text)

@bot.tree.error
async def on_app_command_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError
):
    print(error)
    traceback.print_exc()

if __name__ == "__main__":
    bot.run(TOKEN)
