import discord
from discord import app_commands
import json
import os

VENDING_DATA_FILE = "vending_data.json"

# vending / paypay コマンドを使えるロールIDのリスト
# 複数ロールを許可する場合はここに追加してください
ALLOWED_ROLE_IDS: list[int] = [
    1538174509146710077,
    1540286640663166986,
]

# setting コマンドのみを使えるユーザーIDのリスト
# 直接IDを記入し、このユーザー以外は setting コマンドを使えません
SETTING_ALLOWED_USER_IDS: list[int] = [
    573693254877446171,
]


def load_allowed_users() -> list[int]:
    """vending_data.json に保存された動的な許可ユーザーIDを返す"""
    if os.path.exists(VENDING_DATA_FILE):
        with open(VENDING_DATA_FILE, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                return data.get("allowed_user_ids", [])
            except json.JSONDecodeError:
                return []
    return []


def has_allowed_role(interaction: discord.Interaction) -> bool:
    """ALLOWED_ROLE_IDS のいずれかのロールを持っているか確認する"""
    if not interaction.guild:
        return False
    user_role_ids = {r.id for r in interaction.user.roles}
    return bool(user_role_ids & set(ALLOWED_ROLE_IDS))


async def has_global_vending_permission(interaction: discord.Interaction) -> bool:
    """vending / paypay コマンドの利用権限チェック"""
    if await interaction.client.is_owner(interaction.user):
        return True

    # 動的許可ユーザー（setting.py 経由で追加されたユーザー）
    allowed_ids = load_allowed_users()
    if interaction.user.id in allowed_ids:
        return True

    # 許可ロール持ちなら OK
    return has_allowed_role(interaction)


async def can_manage_vending_machine(interaction: discord.Interaction, vm) -> bool:
    if not vm:
        return False

    # サーバーフィルタ: guild_idが設定されていれば、実行サーバーと一致しないと拒否
    guild_id_str = str(interaction.guild.id) if interaction.guild else None
    vm_guild = vm.get("guild_id")
    if vm_guild is not None and guild_id_str != vm_guild:
        return False

    # オーナー本人は常に操作可能
    if vm.get("owner_id") == str(interaction.user.id):
        return True

    # 特権ユーザー（ALLOWED_ROLE_IDS / allowed_user_ids / Botオーナー）も操作可能
    return await has_global_vending_permission(interaction)


async def can_manage_coupon(interaction: discord.Interaction, coupon_info, vending_data=None) -> bool:
    if not coupon_info:
        return False
    if coupon_info.get("owner_id") == str(interaction.user.id):
        return True
    if vending_data is None:
        vending_data = {}
    vending_machine_id = coupon_info.get("vending_machine_id")
    vm = vending_data.get(vending_machine_id)
    return await can_manage_vending_machine(interaction, vm)


def is_allowed():
    """vending / paypay コマンド用: 許可ロールまたは許可ユーザーのみ実行可能"""
    async def predicate(interaction: discord.Interaction) -> bool:
        if await has_global_vending_permission(interaction):
            return True
        if interaction.response.is_done():
            await interaction.followup.send(
                "🚫 あなたはこのBotの機能を利用する権限がありません。",
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                "🚫 あなたはこのBotの機能を利用する権限がありません。",
                ephemeral=True,
            )
        return False

    return app_commands.check(predicate)


def is_setting_allowed():
    """setting コマンド専用: SETTING_ALLOWED_USER_IDS に直接記入されたユーザーのみ実行可能"""
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.user.id in SETTING_ALLOWED_USER_IDS:
            return True
        # レスポンス済みなら followup、未送信なら send_message で拒否通知
        if interaction.response.is_done():
            await interaction.followup.send(
                "🚫 このコマンドはBot管理者のみ使用できます。",
                ephemeral=True,
            )
        else:
            await interaction.response.send_message(
                "🚫 このコマンドはBot管理者のみ使用できます。",
                ephemeral=True,
            )
        return False

    return app_commands.check(predicate)
