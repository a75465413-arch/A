"""
Cogs/admin.py  ―  SMS 自販機 管理者専用コマンド集
────────────────────────────────────────────────────
すべてのコマンドは utils.py の SETTING_ALLOWED_USER_IDS に
記載されたユーザーのみ実行できます。

コマンド一覧:
  /balance            HeroSMS 残高を確認
  /active_list        現在アクティブな番号一覧を表示
  /cancel_activation  指定したアクティベーションを強制キャンセル・払い戻し
  /price_check        サービス・国の現在価格と在庫数を確認
  /sms_status         指定したアクティベーションのステータスを確認
  /set_apikey         HeroSMS API キーを設定（.env に書き込み・即時反映）
"""

import asyncio
import os
import re
import json
import urllib.request
import urllib.parse

import discord
from discord import app_commands, ui
from discord.ext import commands
from dotenv import load_dotenv

import herosms as herosms_api
from utils import is_setting_allowed

load_dotenv()
HEROSMS_APIKEY = os.getenv("HEROSMS_APIKEY", "")
SERVICE_CODE   = os.getenv("HEROSMS_SERVICE", "ds")
COUNTRY_ID     = int(os.getenv("HEROSMS_COUNTRY", "33"))

# HeroSMS API エンドポイント（active_list / price_check 用に直接叩く）
_BASE_URL = "https://hero-sms.com/stubs/handler_api.php"
_HEADERS  = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
}


def _api(params: dict) -> str:
    params["api_key"] = HEROSMS_APIKEY
    url = _BASE_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read().decode("utf-8").strip()


def _api_json(params: dict) -> dict | list:
    return json.loads(_api(params))


# ══════════════════════════════════════════════════════════
#  LayoutView ヘルパー
# ══════════════════════════════════════════════════════════
def _view(text: str, accent: int) -> ui.LayoutView:
    c = ui.Container(accent_color=accent)
    c.add_item(ui.TextDisplay(text))
    lv = ui.LayoutView(timeout=None)
    lv.add_item(c)
    return lv


def _ok(text: str)  -> ui.LayoutView: return _view(text, 0x00CC66)
def _err(text: str) -> ui.LayoutView: return _view(text, 0xFF3333)
def _info(text: str)-> ui.LayoutView: return _view(text, 0x5865F2)


# ══════════════════════════════════════════════════════════
#  .env 書き込みヘルパー
# ══════════════════════════════════════════════════════════
_ENV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")

def _write_env_key(key: str, value: str) -> None:
    """
    .env ファイルの指定キーを上書きする。
    キーが存在しなければ末尾に追記する。
    """
    if os.path.exists(_ENV_PATH):
        with open(_ENV_PATH, "r", encoding="utf-8") as f:
            content = f.read()
    else:
        content = ""

    pattern = rf"^({re.escape(key)}\s*=).*$"
    new_line = f"{key}={value}"

    if re.search(pattern, content, flags=re.MULTILINE):
        content = re.sub(pattern, new_line, content, flags=re.MULTILINE)
    else:
        content = content.rstrip("\n") + f"\n{new_line}\n"

    with open(_ENV_PATH, "w", encoding="utf-8") as f:
        f.write(content)


# ══════════════════════════════════════════════════════════
#  Cog
# ══════════════════════════════════════════════════════════
class AdminCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── /balance ────────────────────────────────────────
    @app_commands.command(
        name="balance",
        description="現在の残高を確認します（管理者専用）",
    )
    @is_setting_allowed()
    async def balance(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            bal = await asyncio.to_thread(herosms_api.get_balance, HEROSMS_APIKEY)
            await interaction.followup.send(
                view=_ok(f"## 残高\n```$ {bal:.4f} USD```"),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(view=_err(f"## ❌ エラー\n```{e}```"), ephemeral=True)

    # ── /active_list ────────────────────────────────────
    @app_commands.command(
        name="active_list",
        description="現在アクティブな番号の一覧を表示します（管理者専用）",
    )
    @is_setting_allowed()
    async def active_list(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            data = await asyncio.to_thread(
                _api_json, {"action": "getActiveActivations"}
            )
            activations = data.get("data", []) if isinstance(data, dict) else []

            if not activations:
                await interaction.followup.send(
                    view=_info("## アクティブな番号\n現在アクティブな番号はありません。"),
                    ephemeral=True,
                )
                return

            lines = []
            for a in activations:
                aid    = a.get("activationId", "不明")
                phone  = a.get("phoneNumber", "不明")
                status = a.get("activationStatus", "不明")
                cost   = a.get("activationCost", "?")
                lines.append(
                    f"**+{phone}**\n"
                    f"```ID: {aid}\nステータス: {status}  コスト: ${cost}```"
                )

            c = ui.Container(accent_color=0x5865F2)
            c.add_item(ui.TextDisplay(f"## アクティブな番号一覧（{len(activations)} 件）"))
            c.add_item(ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small))
            c.add_item(ui.TextDisplay("\n".join(lines)))
            lv = ui.LayoutView(timeout=None)
            lv.add_item(c)
            await interaction.followup.send(view=lv, ephemeral=True)

        except Exception as e:
            await interaction.followup.send(view=_err(f"## ❌ エラー\n```{e}```"), ephemeral=True)

    # ── /cancel_activation ──────────────────────────────
    @app_commands.command(
        name="cancel_activation",
        description="指定したアクティベーションを強制キャンセルして払い戻します（管理者専用）",
    )
    @is_setting_allowed()
    @app_commands.describe(activation_id="キャンセルするアクティベーション ID")
    async def cancel_activation(
        self, interaction: discord.Interaction, activation_id: str
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            await asyncio.to_thread(
                herosms_api.cancel_activation, HEROSMS_APIKEY, activation_id
            )
            await interaction.followup.send(
                view=_ok(
                    f"## ✅ キャンセル完了\n"
                    f"アクティベーション `{activation_id}` をキャンセルし、払い戻しを申請しました。"
                ),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(view=_err(f"## ❌ エラー\n```{e}```"), ephemeral=True)

    # ── /price_check ────────────────────────────────────
    @app_commands.command(
        name="price_check",
        description="現在のサービス・価格と在庫数を確認します（管理者専用）",
    )
    @is_setting_allowed()
    async def price_check(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            data = await asyncio.to_thread(
                _api_json,
                {"action": "getPrices", "service": SERVICE_CODE, "country": COUNTRY_ID},
            )
            # レスポンス: { "<countryId>": { "<serviceCode>": { cost, count } } }
            country_data  = data.get(str(COUNTRY_ID), {})
            service_data  = country_data.get(SERVICE_CODE, {})

            if not service_data:
                await interaction.followup.send(
                    view=_err(
                        f"## ❌ データなし\n"
                        f"国 ID `{COUNTRY_ID}` / サービス `{SERVICE_CODE}` の情報が取得できません。"
                    ),
                    ephemeral=True,
                )
                return

            cost  = service_data.get("cost",  "不明")
            count = service_data.get("count", "不明")

            await interaction.followup.send(
                view=_info(
                    f"## 現在の価格情報\n"
                    f"```\n"
                    f"サービス : {SERVICE_CODE}\n"
                    f"国 ID   : {COUNTRY_ID}\n"
                    f"価格    : $ {cost} USD\n"
                    f"在庫数  : {count} 件\n"
                    f"```"
                ),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(view=_err(f"## ❌ エラー\n```{e}```"), ephemeral=True)

    # ── /sms_status ─────────────────────────────────────
    @app_commands.command(
        name="sms_status",
        description="指定したアクティベーションの現在のステータスを確認します（管理者専用）",
    )
    @is_setting_allowed()
    @app_commands.describe(activation_id="確認するアクティベーション ID")
    async def sms_status(
        self, interaction: discord.Interaction, activation_id: str
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            status = await asyncio.to_thread(
                herosms_api.get_status, HEROSMS_APIKEY, activation_id
            )

            # ステータスを日本語に変換
            if status.startswith("STATUS_OK:"):
                code   = status.split(":", 1)[1]
                label  = f"✅ コード受信済み"
                detail = f"**認証コード**\n```{code}```"
                accent = 0x00CC66
            elif status == "STATUS_WAIT_CODE":
                label  = "⏳ SMS 待機中"
                detail = "まだ SMS が届いていません。"
                accent = 0xFFD205
            elif status == "STATUS_CANCEL":
                label  = "❌ キャンセル済み"
                detail = "このアクティベーションはキャンセルされています。"
                accent = 0xFF3333
            else:
                label  = f"❓ 不明なステータス"
                detail = f"```{status}```"
                accent = 0x888888

            c = ui.Container(accent_color=accent)
            c.add_item(ui.TextDisplay(f"## 📡 ステータス確認\n**{label}**"))
            c.add_item(ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small))
            c.add_item(ui.TextDisplay(
                f"**アクティベーション ID**\n```{activation_id}```\n{detail}"
            ))
            lv = ui.LayoutView(timeout=None)
            lv.add_item(c)
            await interaction.followup.send(view=lv, ephemeral=True)

        except Exception as e:
            await interaction.followup.send(view=_err(f"## ❌ エラー\n```{e}```"), ephemeral=True)

    # ── /set_apikey ──────────────────────────────────────
    @app_commands.command(
        name="set_apikey",
        description="API キーを設定します（管理者専用・即時反映）",
    )
    @is_setting_allowed()
    @app_commands.describe(api_key="ダッシュボードで取得した API キー")
    async def set_apikey(
        self, interaction: discord.Interaction, api_key: str
    ) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            # .env に書き込み
            await asyncio.to_thread(_write_env_key, "HEROSMS_APIKEY", api_key)

            # このモジュールと herosms_api が参照するグローバル変数を即時更新
            global HEROSMS_APIKEY
            HEROSMS_APIKEY = api_key

            # Cogs/herosms.py の HEROSMS_APIKEY も更新
            import Cogs.herosms as herosms_cog
            herosms_cog.HEROSMS_APIKEY = api_key

            # 動作確認として残高を取得
            bal = await asyncio.to_thread(herosms_api.get_balance, api_key)

            await interaction.followup.send(
                view=_ok(
                    f"## ✅ API キー設定完了\n"
                    f"API キーを更新し、.env に保存しました。\n\n"
                    f"**接続確認**\n```残高: $ {bal:.4f} USD```"
                ),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(
                view=_err(
                    f"## ❌ 設定失敗\n"
                    f"API キーの設定中にエラーが発生しました。\n"
                    f"キーが正しいか確認してください。\n```{e}```"
                ),
                ephemeral=True,
            )


# ══════════════════════════════════════════════════════════
#  setup
# ══════════════════════════════════════════════════════════
async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(AdminCog(bot))
