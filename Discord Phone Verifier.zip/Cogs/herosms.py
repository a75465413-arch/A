"""
Cogs/sms.py  ―  HeroSMS × PayPay 電話番号購入 Cog
────────────────────────────────────────────────────────
フロー:
  1. /sms_panel  → パネルをチャンネルに設置
  2. [📱 購入]  → PayPay リンク入力モーダルを表示
  3. リンク検証 → 金額確認 → link_rev で受取 → HeroSMS で番号購入
  4. DM に「電話番号 / 有効期限 / アクティベーション ID」を送信
  5. バックグラウンドで SMS をポーリング → 届くたびに DM へ自動送信
  6. [✅ 完了]       → アクティベーション ID 入力モーダル → 完了処理
  7. [🔄 再送要求]   → アクティベーション ID 入力モーダル → setStatus(3)

事前準備:
  - .env に以下を追加
      HEROSMS_APIKEY=...
      HEROSMS_PRICE=150        # PayPay で要求する金額（円）
      HEROSMS_SERVICE=ds       # サービスコード（Discord = ds）
      HEROSMS_COUNTRY=33       # 国 ID（コロンビア = 33）
  - paypay_data.json に受取用 PayPay アカウントを登録
      /paypayログイン コマンド（Cogs/paypay.py）で登録
  - RECEIVER_USER_ID を受取アカウントの Discord ユーザー ID に設定
"""

import asyncio
import json
import os
import uuid
from datetime import datetime, timezone, timedelta

import discord
from discord import app_commands, ui
from discord.ext import commands
from dotenv import load_dotenv

import paypayu
import herosms as herosms_api
from utils import is_setting_allowed

# ───────── 設定読み込み ─────────
load_dotenv()
HEROSMS_APIKEY  = os.getenv("HEROSMS_APIKEY", "")
HEROSMS_PRICE   = int(os.getenv("HEROSMS_PRICE", "20"))     # 円
SERVICE_CODE    = os.getenv("HEROSMS_SERVICE", "ds")
COUNTRY_ID      = int(os.getenv("HEROSMS_COUNTRY", "33"))
COUNTRY_PHONE_CODE = os.getenv("HEROSMS_PHONE_CODE", "57")  # コロンビア国番号
POLL_INTERVAL   = int(os.getenv("POLL_INTERVAL", "5"))
WAIT_SECONDS    = int(os.getenv("WAIT_SECONDS", "1200"))

# PayPay 受取アカウントの Discord ユーザー ID（paypay_data.json のキー）
# paypay_data.json に登録した Discord ユーザーの ID を文字列で入れてください
RECEIVER_USER_ID = os.getenv("PAYPAY_RECEIVER_USER_ID", "")

PAYPAY_DATA_FILE  = "paypay_data.json"
SMS_LOG_DATA_FILE = "sms_log_data.json"

# ── カスタム ID ──────────────────────────────────────────
BTN_BUY      = "hs_buy"
BTN_COMPLETE = "hs_complete"
BTN_RESEND   = "hs_resend"


# ══════════════════════════════════════════════════════════
#  JSON ヘルパー
# ══════════════════════════════════════════════════════════
def load_paypay_data() -> dict:
    if os.path.exists(PAYPAY_DATA_FILE):
        with open(PAYPAY_DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def load_sms_log_data() -> dict:
    if os.path.exists(SMS_LOG_DATA_FILE):
        with open(SMS_LOG_DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_sms_log_data(data: dict) -> None:
    with open(SMS_LOG_DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def register_activation(activation_id: str, user_id: int) -> None:
    """購入時にアクティベーション ID を未受信状態で登録する。"""
    data = load_sms_log_data()
    data.setdefault("activations", {})[activation_id] = {
        "user_id": user_id,
        "code_received": False,
    }
    save_sms_log_data(data)


def mark_code_received(activation_id: str) -> None:
    """SMS 受信時に受信済みフラグを立てる。"""
    data = load_sms_log_data()
    entry = data.get("activations", {}).get(activation_id)
    if entry is not None:
        entry["code_received"] = True
        save_sms_log_data(data)


def is_code_received(activation_id: str) -> bool:
    """アクティベーション ID の SMS 受信済みフラグを返す。未登録の場合は False。"""
    data = load_sms_log_data()
    entry = data.get("activations", {}).get(activation_id)
    if entry is None:
        return False
    return entry.get("code_received", False)


# ══════════════════════════════════════════════════════════
#  LayoutView ファクトリ関数
# ══════════════════════════════════════════════════════════
def make_panel_view() -> ui.LayoutView:
    """チャンネル設置用パネル。"""
    c = ui.Container(accent_color=0xC2BEFF)
    c.add_item(ui.TextDisplay("## 📲 Discord 電話番号購入"))
    c.add_item(ui.Separator(visible=True))
    c.add_item(ui.TextDisplay(
        f"**[📱 購入]** を押すと PayPay 送金リンクの入力画面が開きます。\n"
        f"**{HEROSMS_PRICE} 円**の送金リンクを送信すると、自動で決済と番号取得が完了します。\n\n"
        "取得した番号・認証コードは DM に届きます。\n"
        "認証が完了したら **[✅ 完了]** を押してください。\n"
        "コードが届かない場合は **[🔄 再送要求]** を押してください。"
    ))
    c.add_item(ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small))
    c.add_item(ui.TextDisplay(
        "⚠️ **注意事項**\n"
        "```\n"
        "・決済完了後の返金は原則対応しておりません\n"
        "・ただし、こちら側の不備（番号未発行・システムエラー等）が\n"
        "  原因の場合に限り返金対応いたします\n"
        "・その場合は管理者までお問い合わせください\n"
        "・購入前に必ず内容をご確認ください\n"
        "```"
    ))
    c.add_item(ui.Separator(visible=True))
    row = ui.ActionRow()
    row.add_item(ui.Button(label="📱 購入", style=discord.ButtonStyle.primary,   custom_id=BTN_BUY))
    row.add_item(ui.Button(label="✅ 完了",       style=discord.ButtonStyle.success,   custom_id=BTN_COMPLETE))
    row.add_item(ui.Button(label="🔄 再送要求",   style=discord.ButtonStyle.secondary, custom_id=BTN_RESEND))
    c.add_item(row)

    lv = ui.LayoutView(timeout=None)
    lv.add_item(c)
    return lv


def make_purchase_view(phone_number: str, activation_id: str, expire_at: datetime) -> ui.LayoutView:
    """番号購入直後に DM へ送る Components v2 メッセージ。"""
    expire_str = expire_at.strftime("%Y-%m-%d %H:%M:%S UTC")

    # 国番号と市内番号の間にスペースを挿入（例: 573228452602 → +57 3228452602）
    country_code = str(COUNTRY_PHONE_CODE)
    if phone_number.startswith(country_code):
        display_phone = f"+{country_code} {phone_number[len(country_code):]}"
    else:
        display_phone = f"+{phone_number}"
    c = ui.Container(accent_color=0x00FF76)
    c.add_item(ui.TextDisplay("### 📱 電話番号を取得しました"))
    c.add_item(ui.Separator(visible=True))
    c.add_item(ui.TextDisplay(
        f"**電話番号**\n```{display_phone}```\n"
        f"**有効期限**\n```{expire_str}```\n"
        f"**アクティベーション ID**\n```{activation_id}```"
    ))
    c.add_item(ui.Separator(visible=True))
    c.add_item(ui.TextDisplay(
        "SMS コードが届いたら自動でこの DM に通知します。\n"
        "コードが届かない場合はパネルの **[🔄 再送要求]** を押してください。"
    ))
    lv = ui.LayoutView(timeout=None)
    lv.add_item(c)
    return lv


def make_code_view(sms_code: str, activation_id: str) -> ui.LayoutView:
    """SMS コード受信時に DM へ送る Components v2 メッセージ。"""
    c = ui.Container(accent_color=0xFFD205)
    c.add_item(ui.TextDisplay("### 🔑 認証コードが届きました"))
    c.add_item(ui.Separator(visible=True))
    c.add_item(ui.TextDisplay(
        f"**コード**\n```{sms_code}```\n"
        f"**アクティベーション ID**\n```{activation_id}```"
    ))
    c.add_item(ui.Separator(visible=True))
    c.add_item(ui.TextDisplay(
        "Discord に入力後、パネルの **[✅ 完了]** を押してアクティベーションを終了してください。\n"
        "再度コードが必要な場合は **[🔄 再送要求]** を押すと新しいコードが届きます。"
    ))
    lv = ui.LayoutView(timeout=None)
    lv.add_item(c)
    return lv


def _err_view(text: str, accent: int = 0xFF3333) -> ui.LayoutView:
    """エラー用の簡易 LayoutView。"""
    c = ui.Container(accent_color=accent)
    c.add_item(ui.TextDisplay(text))
    lv = ui.LayoutView(timeout=None)
    lv.add_item(c)
    return lv


def _ok_view(text: str, accent: int = 0x00CC66) -> ui.LayoutView:
    """成功用の簡易 LayoutView。"""
    c = ui.Container(accent_color=accent)
    c.add_item(ui.TextDisplay(text))
    lv = ui.LayoutView(timeout=None)
    lv.add_item(c)
    return lv


# ══════════════════════════════════════════════════════════
#  購入ログ送信
# ══════════════════════════════════════════════════════════
async def send_purchase_log(
    bot: commands.Bot,
    user: discord.User,
    amount: int,
    is_test: bool = False,
) -> None:
    """設定済みのログチャンネルに購入情報を送信する。"""
    log_data = load_sms_log_data()
    channel_id = log_data.get("channel_id")
    if not channel_id:
        return

    channel = bot.get_channel(int(channel_id))
    if not channel:
        return

    JST = timezone(timedelta(hours=9))
    now_jst = datetime.now(JST).strftime("%Y/%m/%d %H:%M:%S (JST)")
    amount_str = f"0 円（テスト）" if is_test else f"{amount} 円"
    title = "## 電話番号番号購入ログ（テスト）" if is_test else "## 電話番号購入ログ"
    accent = 0xFFA500 if is_test else 0x5865F2

    c = ui.Container(accent_color=accent)
    c.add_item(ui.TextDisplay(title))
    c.add_item(ui.Separator(visible=True, spacing=discord.SeparatorSpacing.small))
    c.add_item(ui.TextDisplay(
        f"**購入者**\n{user.mention} (`{user.id}`)\n"
        f"**購入日時**\n```{now_jst}```\n"
        f"**支払金額**\n```{amount_str}```"
    ))
    lv = ui.LayoutView(timeout=None)
    lv.add_item(c)

    try:
        await channel.send(view=lv)
    except Exception as e:
        print(f"[SMS Log Error]: {e}")


# ══════════════════════════════════════════════════════════
#  モーダル ── PayPay リンク入力（購入）
# ══════════════════════════════════════════════════════════
class BuyModal(ui.Modal, title="PayPay 送金リンクを入力"):
    paypay_link = ui.TextInput(
        label=f"PayPay 送金リンク（{HEROSMS_PRICE} 円）",
        placeholder="https://pay.paypay.ne.jp/...",
        min_length=10,
        max_length=200,
    )

    def __init__(self, bot: commands.Bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)
        await process_buy(interaction, self.paypay_link.value.strip(), self.bot)


# ══════════════════════════════════════════════════════════
#  モーダル ── アクティベーション完了
# ══════════════════════════════════════════════════════════
class FinishModal(ui.Modal, title="アクティベーション完了"):
    activation_id = ui.TextInput(
        label="アクティベーション ID",
        placeholder="123456789",
        min_length=5,
        max_length=30,
    )

    async def on_submit(self, interaction: discord.Interaction) -> None:
        aid = self.activation_id.value.strip()
        await interaction.response.defer(ephemeral=True, thinking=True)

        # SMS 未受信なら完了不可
        if not is_code_received(aid):
            await interaction.followup.send(
                view=_err_view(
                    "## ❌ 完了不可\n"
                    "認証コードをまだ受け取っていません。\n"
                    "SMS が届いてから完了処理を行ってください。"
                ),
                ephemeral=True,
            )
            return

        try:
            await asyncio.to_thread(herosms_api.complete_activation, HEROSMS_APIKEY, aid)
            await interaction.followup.send(
                view=_ok_view(f"## ✅ 完了\nアクティベーション `{aid}` を完了しました。"),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(
                view=_err_view(f"## ❌ 完了処理失敗\n```{e}```"),
                ephemeral=True,
            )


# ══════════════════════════════════════════════════════════
#  モーダル ── SMS 再送要求
# ══════════════════════════════════════════════════════════
class ResendModal(ui.Modal, title="SMS 再送要求"):
    activation_id = ui.TextInput(
        label="アクティベーション ID",
        placeholder="123456789",
        min_length=5,
        max_length=30,
    )

    async def on_submit(self, interaction: discord.Interaction) -> None:
        aid = self.activation_id.value.strip()
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            await asyncio.to_thread(herosms_api.request_resend, HEROSMS_APIKEY, aid)
            await interaction.followup.send(
                view=_ok_view(
                    f"## 🔄 再送要求完了\n"
                    f"アクティベーション `{aid}` に SMS 再送を要求しました。\n"
                    "新しいコードが届いたら自動で DM に通知されます。",
                    accent=0x5865F2,
                ),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(
                view=_err_view(f"## ❌ 再送要求失敗\n```{e}```"),
                ephemeral=True,
            )


# ══════════════════════════════════════════════════════════
#  PayPay 決済 → 番号購入 メイン処理
# ══════════════════════════════════════════════════════════
async def process_buy(
    interaction: discord.Interaction,
    pay_link: str,
    bot: commands.Bot,
) -> None:
    """
    1. PayPay リンクを検証
    2. 金額チェック
    3. link_rev で受取
    4. HeroSMS で番号購入
    5. DM 送信
    6. SMS ポーリング開始
    """

    # ── 受取アカウント取得 ──────────────────────────────
    paypay_data = load_paypay_data()
    receiver = paypay_data.get(RECEIVER_USER_ID)
    if not receiver:
        await interaction.followup.send(
            view=_err_view(
                "## ❌ 設定エラー\n"
                "受取 PayPay アカウントが未設定です。\n"
                "管理者に連絡してください。"
            ),
            ephemeral=True,
        )
        return

    # ── リンク検証 ──────────────────────────────────────
    link_info = await paypayu.check_link(pay_link)
    if not link_info:
        await interaction.followup.send(
            view=_err_view(
                "## ❌ 無効なリンク\n"
                "PayPay 送金リンクが無効か、すでに受け取り済みです。\n"
                "新しいリンクを作成してもう一度お試しください。"
            ),
            ephemeral=True,
        )
        return

    # ── 金額チェック ────────────────────────────────────
    amount = (
        link_info.get("payload", {})
        .get("message", {})
        .get("data", {})
        .get("amount", 0)
    )
    if amount < HEROSMS_PRICE:
        await interaction.followup.send(
            view=_err_view(
                f"## ❌ 金額不足\n"
                f"必要な金額: **{HEROSMS_PRICE} 円**\n"
                f"送金リンクの金額: **{amount} 円**\n\n"
                f"正確な金額のリンクを作成してください。"
            ),
            ephemeral=True,
        )
        return

    # ── PayPay 受取 ─────────────────────────────────────
    result = await paypayu.link_rev(
        pay_link,
        receiver["phone"],
        receiver["password"],
        receiver["uuid"],
    )
    # セッション切れのとき自動再ログインして再試行
    if result == "LOGINERR":
        try:
            await paypayu.login(receiver["phone"], receiver["password"], receiver["uuid"])
            result = await paypayu.link_rev(
                pay_link,
                receiver["phone"],
                receiver["password"],
                receiver["uuid"],
            )
        except Exception as e:
            print(f"[PayPay 再ログインエラー]: {e}")

    if result is not True:
        await interaction.followup.send(
            view=_err_view(
                "## ❌ PayPay 決済失敗\n"
                "送金リンクの受取処理に失敗しました。\n"
                "リンクが正しいか確認してもう一度お試しください。"
            ),
            ephemeral=True,
        )
        return

    # ── DM チャンネルを開く ─────────────────────────────
    try:
        dm = await interaction.user.create_dm()
    except discord.Forbidden:
        await interaction.followup.send(
            view=_err_view(
                "## ❌ DM 送信不可\n"
                "DM を送信できません。\n"
                "プライバシー設定で「サーバーメンバーからの DM」を許可してください。\n\n"
                "※ PayPay の決済は完了しています。\n"
                "管理者に連絡してアクティベーション情報を受け取ってください。"
            ),
            ephemeral=True,
        )
        return

    # ── HeroSMS で番号購入 ──────────────────────────────
    try:
        activation_id, phone_number = await asyncio.to_thread(
            herosms_api.buy_number, HEROSMS_APIKEY, SERVICE_CODE, COUNTRY_ID
        )
    except RuntimeError as e:
        await interaction.followup.send(
            view=_err_view(
                f"## ❌ 番号取得失敗\n```{e}```\n\n"
                "PayPay の決済は完了しています。\n"
                "管理者に連絡してください。"
            ),
            ephemeral=True,
        )
        return

    # SMS 受信準備
    try:
        await asyncio.to_thread(herosms_api.set_ready, HEROSMS_APIKEY, activation_id)
    except Exception:
        pass

    # アクティベーション ID を未受信状態で登録
    register_activation(activation_id, interaction.user.id)

    # 有効期限
    expire_at = datetime.now(timezone.utc) + timedelta(seconds=WAIT_SECONDS)

    # ── DM に購入情報を送信 ─────────────────────────────
    await dm.send(view=make_purchase_view(phone_number, activation_id, expire_at))
    await interaction.followup.send(
        view=_ok_view(
            f"## ✅ 購入完了\n"
            f"PayPay 決済が完了し、電話番号を取得しました。\n"
            f"詳細は DM をご確認ください。"
        ),
        ephemeral=True,
    )

    # ── 購入ログ送信 ────────────────────────────────────
    await send_purchase_log(bot, interaction.user, amount)

    # ── SMS ポーリング開始 ──────────────────────────────
    bot.loop.create_task(
        sms_poll_task(dm, activation_id),
        name=f"sms_poll_{activation_id}",
    )


# ══════════════════════════════════════════════════════════
#  SMS ポーリングタスク
# ══════════════════════════════════════════════════════════
async def sms_poll_task(dm: discord.DMChannel, activation_id: str) -> None:
    """
    新しいコードが届くたびに DM へ送信する。
    2回目以降の再送コードも検知するため STATUS_OK 後も継続。
    タイムアウトまたはキャンセルで終了。
    """
    deadline = asyncio.get_event_loop().time() + WAIT_SECONDS
    last_code: str | None = None
    code_received: bool = False  # SMS を一度でも受信したら True

    while asyncio.get_event_loop().time() < deadline:
        try:
            status = await asyncio.to_thread(
                herosms_api.get_status, HEROSMS_APIKEY, activation_id
            )
        except Exception as e:
            await dm.send(f"⚠️ ステータス確認中にエラーが発生しました: `{e}`")
            return

        if status.startswith("STATUS_OK:"):
            sms_code = status.split(":", 1)[1]
            if sms_code != last_code:
                last_code = sms_code
                code_received = True  # 受信済みフラグを立てる
                mark_code_received(activation_id)  # JSON に受信済みを記録
                await dm.send(view=make_code_view(sms_code, activation_id))
            # return しない → 再送コードも拾い続ける

        elif status == "STATUS_CANCEL":
            await dm.send(
                view=_err_view(
                    f"## ❌ キャンセル\nアクティベーション `{activation_id}` がキャンセルされました。"
                )
            )
            return

        await asyncio.sleep(POLL_INTERVAL)

    # タイムアウト時: SMS を一度も受信していない場合のみキャンセル・払い戻し
    if not code_received:
        try:
            await asyncio.to_thread(herosms_api.cancel_activation, HEROSMS_APIKEY, activation_id)
        except Exception:
            pass
        await dm.send(
            view=_err_view(
                f"## ⏰ タイムアウト\n"
                f"アクティベーション `{activation_id}` の SMS が届きませんでした。\n"
                "自動的にキャンセルし、払い戻し申請しました。",
                accent=0xFF8C00,
            )
        )
    else:
        # SMS 受信済みなのでポーリング監視期間が終了したことを通知するのみ
        await dm.send(
            view=_err_view(
                f"## ⏰ 監視終了\n"
                f"アクティベーション `{activation_id}` の監視期間が終了しました。\n"
                "認証コードはすでに受け取り済みです。\n"
                "完了処理がまだの場合はパネルの **[✅ 完了]** を押してください。",
                accent=0xFF8C00,
            )
        )


# ══════════════════════════════════════════════════════════
#  Cog 本体
# ══════════════════════════════════════════════════════════
class HeroSMSCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ── ボタンイベント ──────────────────────────────────
    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction) -> None:
        """パネルボタンのクリックをすべてここで受け取る。"""
        if interaction.type != discord.InteractionType.component:
            return

        # 既にレスポンス済み（他のハンドラや重複イベント）の場合はスキップ
        if interaction.response.is_done():
            return

        custom_id = interaction.data.get("custom_id", "")

        if custom_id == BTN_BUY:
            await interaction.response.send_modal(BuyModal(self.bot))

        elif custom_id == BTN_COMPLETE:
            await interaction.response.send_modal(FinishModal())

        elif custom_id == BTN_RESEND:
            await interaction.response.send_modal(ResendModal())

    # ── /sms_panel ──────────────────────────────────
    @app_commands.command(
        name="sms_panel",
        description="電話番号購入パネルを設置します",
    )
    async def sms_panel(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True)
        await interaction.channel.send(view=make_panel_view())
        await interaction.followup.send("✅ パネルを設置しました。", ephemeral=True)

    # ── /sms_log ────────────────────────────────────
    @app_commands.command(
        name="sms_log",
        description="電話番号購入ログの送信チャンネルを設定します（管理者専用）",
    )
    @is_setting_allowed()
    @app_commands.describe(channel="ログを送信するチャンネル")
    async def sms_log(
        self, interaction: discord.Interaction, channel: discord.TextChannel
    ) -> None:
        await interaction.response.defer(ephemeral=True)

        log_data = load_sms_log_data()
        log_data["channel_id"] = channel.id
        save_sms_log_data(log_data)

        c = ui.Container(accent_color=0x00CC66)
        c.add_item(ui.TextDisplay(
            f"## ✅ ログチャンネル設定完了\n"
            f"購入ログの送信先を {channel.mention} に設定しました。"
        ))
        lv = ui.LayoutView(timeout=None)
        lv.add_item(c)
        await interaction.followup.send(view=lv, ephemeral=True)

    # ── /sms_test ───────────────────────────────────
    @app_commands.command(
        name="sms_test",
        description="【テスト用】PayPay 決済をスキップして番号を無料取得します（管理者専用）",
    )
    @is_setting_allowed()
    async def sms_test(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer(ephemeral=True, thinking=True)

        # DM チャンネルを開く
        try:
            dm = await interaction.user.create_dm()
        except discord.Forbidden:
            await interaction.followup.send(
                view=_err_view("## ❌ DM 送信不可\nDM を許可してください。"),
                ephemeral=True,
            )
            return

        # HeroSMS で番号購入（決済スキップ）
        try:
            activation_id, phone_number = await asyncio.to_thread(
                herosms_api.buy_number, HEROSMS_APIKEY, SERVICE_CODE, COUNTRY_ID
            )
        except RuntimeError as e:
            await interaction.followup.send(
                view=_err_view(f"## ❌ 番号取得失敗\n```{e}```"),
                ephemeral=True,
            )
            return

        # SMS 受信準備
        try:
            await asyncio.to_thread(herosms_api.set_ready, HEROSMS_APIKEY, activation_id)
        except Exception:
            pass

        # アクティベーション ID を未受信状態で登録
        register_activation(activation_id, interaction.user.id)

        expire_at = datetime.now(timezone.utc) + timedelta(seconds=WAIT_SECONDS)

        # DM に購入情報を送信
        await dm.send(view=make_purchase_view(phone_number, activation_id, expire_at))
        await interaction.followup.send(
            view=_ok_view(
                "## ✅ テスト購入完了\n"
                "PayPay 決済をスキップして番号を取得しました。\n"
                "詳細は DM をご確認ください。"
            ),
            ephemeral=True,
        )

        # ログ送信（テスト購入として 0 円で記録）
        await send_purchase_log(self.bot, interaction.user, 0, is_test=True)

        # SMS ポーリング開始
        self.bot.loop.create_task(
            sms_poll_task(dm, activation_id),
            name=f"sms_poll_{activation_id}",
        )


# ══════════════════════════════════════════════════════════
#  setup
# ══════════════════════════════════════════════════════════
async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(HeroSMSCog(bot))
