"""









pip install playwright requests
playwright install       









"""

import random
import string
import time
import re
import requests
import json
import sys
import os
import subprocess
from playwright.sync_api import sync_playwright

# --- ANSI Colors & Spinner for Cool CLI Vibe ---
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'

STORE_FILE = "account.json"
FORTNITE_PATH = r"C:\Program Files\Epic Games\Fortnite\FortniteGame\Binaries\Win64\FortniteLauncher.exe"

def print_banner():
    banner = f"""
{Colors.CYAN}{Colors.BOLD}
        ███████╗██████╗ ██╗ ██████╗     █████╗  ██████╗ ██████╗     ██████╗ ███████╗███╗   ██╗
        ██╔════╝██╔══██╗██║██╔════╝    ██╔══██╗██╔════╝██╔════╝    ██╔════╝ ██╔════╝████╗  ██║
        █████╗  ██████╔╝██║██║         ███████║██║     ██║         ██║  ███╗█████╗  ██╔██╗ ██║
        ██╔══╝  ██╔═══╝ ██║██║         ██╔══██║██║     ██║         ██║   ██║██╔══╝  ██║╚██╗██║
        ███████╗██║     ██║╚██████╗    ██║  ██║╚██████╗╚██████╗    ╚██████╔╝███████╗██║ ╚████║
        ╚══════╝╚═╝     ╚═╝ ╚═════╝    ╚═╝  ╚═╝ ╚═════╝ ╚═════╝     ╚═════╝ ╚══════╝╚═╝  ╚═══╝                                                                           
        {Colors.DIM} Created By Mint {Colors.ENDC}
"""
    print(banner)

def spinner(duration, message):
    """Loading spinner animation"""
    chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    end_time = time.time() + duration
    i = 0
    while time.time() < end_time:
        sys.stdout.write(f'\r{Colors.YELLOW}{chars[i % len(chars)]}{Colors.ENDC} {message}')
        sys.stdout.flush()
        time.sleep(0.1)
        i += 1
    sys.stdout.write('\r' + ' ' * (len(message) + 4) + '\r')
    sys.stdout.flush()

def generate_random_string(length=8):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))

def generate_epic_password():
    lower = random.choice(string.ascii_lowercase)
    upper = random.choice(string.ascii_uppercase)
    digit = random.choice(string.digits)
    symbol = random.choice("!@#$%^&*")
    
    remaining_chars = string.ascii_letters + string.digits + "!@#$%^&*"
    others = ''.join(random.choice(remaining_chars) for _ in range(8))
    
    password_list = list(lower + upper + digit + symbol + others)
    random.shuffle(password_list)
    return ''.join(password_list)

def human_sleep(min_sec=1.0, max_sec=1):
    time.sleep(random.uniform(min_sec, max_sec))

def save_account_to_json(new_acc_data):
    accounts = []
    if os.path.exists(STORE_FILE):
        try:
            with open(STORE_FILE, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    loaded = json.loads(content)
                    if isinstance(loaded, list):
                        accounts = loaded
                    elif isinstance(loaded, dict):
                        accounts = [loaded]
        except Exception:
            accounts = []
    
    accounts.append(new_acc_data)
    with open(STORE_FILE, "w", encoding="utf-8") as fp:
        json.dump(accounts, fp, sort_keys=False, indent=4, ensure_ascii=False)

def generate_email():
    url = "https://api.tempmail.ing/api/generate"
    headers = {"content-type": "application/json"}
    response = requests.post(url, json={"duration": 10}, headers=headers)
    return response.json()

def check_emails(email_address):
    encoded_email = email_address.replace("@", "%40")
    url = f"https://api.tempmail.ing/api/emails/{encoded_email}"
    response = requests.get(url)
    return response.json()

def extract_epic_code(html_content):
    if not html_content:
        return None

    match = re.search(
        r"font-size:\s*40px[^>]*>[\s\S]*?<p[^>]*>\s*(\d{6})\s*</p>", html_content
    )
    if match:
        return match.group(1)

    match_fallback = re.search(r">\s*(\d{6})\s*<", html_content)
    if match_fallback:
        return match_fallback.group(1)

    return None

def create_single_account(p, switch_token, android_token):
    browser = p.chromium.launch(
        headless=False,
        args=[
            "--disable-blink-features=AutomationControlled",
            "--disable-infobars",
            "--start-maximized"
        ]
    )
    
    context = browser.new_context(
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        viewport={"width": 1280, "height": 800}
    )
    
    try:
        # 1. Fetch temp email via API[cite: 2]
        print(f"{Colors.BLUE}[*] Generating temp email...{Colors.ENDC}")
        gen_data = generate_email()
        if not gen_data.get("success"):
            print(f"{Colors.FAIL}[-] Error: Failed to generate temp email.{Colors.ENDC}")
            browser.close()
            return False
            
        temp_email = gen_data["email"]["address"]
        print(f"{Colors.GREEN}[+] Temp Email Acquired: {Colors.BOLD}{temp_email}{Colors.ENDC}")
        
        # 2. Navigate to Epic Games register
        print(f"{Colors.BLUE}[*] Navigating to Epic Games Registration Portal...{Colors.ENDC}")
        epic_page = context.new_page()
        epic_page.goto("https://www.epicgames.com/id/register/summarized")
        spinner(3.0, "Loading registration page...")
        
        # 3. Generate & Input DOB
        print(f"{Colors.BLUE}[*] Generating random date of birth...{Colors.ENDC}")
        epic_page.wait_for_load_state("networkidle")
        
        random_year = str(random.randint(1980, 2000))
        random_month = str(random.randint(1, 12))
        random_day = str(random.randint(1, 28))
        
        epic_page.fill("#year", random_year)
        human_sleep(0.5, 1.0)
        
        epic_page.click("#month")
        human_sleep(0.25)
        epic_page.keyboard.type(random_month)
        human_sleep(0.25)
        epic_page.keyboard.press("ArrowDown")
        human_sleep(0.25)
        epic_page.keyboard.press("Enter")
        human_sleep(0.25)
        
        epic_page.fill("#day", random_day)
        human_sleep(0.25)
        print(f"{Colors.GREEN}[+] DOB entered successfully [{random_year}/{random_month}/{random_day}].{Colors.ENDC}")
        
        # 4. Click continue
        epic_page.click("#continue")
        human_sleep(0.25)
        
        # 5. Input Email & Next
        print(f"{Colors.BLUE}[*] Entering temporary email into form...{Colors.ENDC}")
        epic_page.wait_for_selector("#email", timeout=10000)
        epic_page.fill("#email", temp_email)
        human_sleep(0.25)
        
        epic_page.click("#send")
        human_sleep(0.25)
        
        # 6. Name, Password, TOS
        print(f"{Colors.BLUE}[*] Generating credentials and filling out profile...{Colors.ENDC}")
        epic_page.wait_for_selector("#name", timeout=10000)
        
        first_name = "User" + generate_random_string(5)
        last_name = "Test" + generate_random_string(5)
        password = generate_epic_password()
        
        epic_page.fill("#name", first_name)
        human_sleep(0.25)
        epic_page.fill("#lastName", last_name)
        human_sleep(0.25)
        epic_page.fill("#password", password)
        human_sleep(0.25)
        print(f"{Colors.CYAN}[i] Generated Secure Password: {password}{Colors.ENDC}")
        
        epic_page.click("#tos")
        human_sleep(0.25)
        print(f"{Colors.GREEN}[+] Terms of Service accepted.{Colors.ENDC}")
        
        # 7. Submit registration
        epic_page.click("#btn-submit")
        
        # 8. Captcha Wait
        print(f"\n{Colors.WARNING}========================================================")
        print(f"[!] ACTION REQUIRED: Solve Cloudflare/Captcha manually if prompted!")
        print(f"========================================================{Colors.ENDC}\n")
        
        verify_label_selector = "#email-verify-label"
        epic_page.wait_for_selector(verify_label_selector, timeout=300000)
        print(f"{Colors.GREEN}[+] Captcha solve detected!{Colors.ENDC}")

        # 9. Wait for email & extract code via API[cite: 2]
        print(f"{Colors.BLUE}[*] Waiting for verification email...{Colors.ENDC}")
        email_found = False
        verification_code = None
        
        for i in range(30):
            spinner(4.0, f"Checking inbox...")
            email_data = check_emails(temp_email)
            
            if email_data.get("success") and email_data.get("emails"):
                for mail in email_data["emails"]:
                    from_address = mail.get("from_address", "")
                    if "acct-auth.epicgames.com" in from_address or "epicgames.com" in from_address:
                        print(f"{Colors.GREEN}[+] Epic Games verification email received!{Colors.ENDC}")
                        html_content = mail.get("content", "")
                        verification_code = extract_epic_code(html_content)
                        email_found = True
                        break
            if email_found:
                break
        
        if not email_found or not verification_code:
            print(f"{Colors.FAIL}[-] Error: Timeout reached or code could not be extracted.{Colors.ENDC}")
            browser.close()
            return False
            
        print(f"{Colors.GREEN}[+] Extracted Verification Code: {Colors.BOLD}{verification_code}{Colors.ENDC}")
        
        # 10. Bring Epic page to front and input code
        epic_page.bring_to_front()
        time.sleep(1)
        
        print(f"{Colors.BLUE}[*] Entering verification code digits...{Colors.ENDC}")
        for index, digit in enumerate(verification_code):
            input_selector = f"input[name='code-input-{index}']"
            epic_page.wait_for_selector(input_selector, timeout=5000)
            epic_page.fill(input_selector, digit)
        print(f"{Colors.GREEN}[+] Code entry completed.{Colors.ENDC}")
        
        # 11. Continue button & Session Processing
        print(f"{Colors.BLUE}[*] Finalizing account creation...{Colors.ENDC}")
        human_sleep(0.25)
        epic_page.click("#continue")
        spinner(4.0, "Processing authentication session...")
        print(f"{Colors.GREEN}[+] Core account provisioning completed!{Colors.ENDC}")
        
        # 12. DeviceAuth API Flow
        print(f"{Colors.BLUE}[*] Creating DeviceAuth URL...{Colors.ENDC}")
        
        token_res = requests.post(
            "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": f"basic {switch_token}"
            },
            data={"grant_type": "client_credentials"}
        )
        token_data = token_res.json()
        access_token = token_data.get("access_token")
        
        if not access_token:
            print(f"{Colors.FAIL}[-] Error: Failed to retrieve client access token: {token_data}{Colors.ENDC}")
            browser.close()
            return False
            
        device_res = requests.post(
            "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/deviceAuthorization",
            headers={
                "Authorization": f"bearer {access_token}",
                "Content-Type": "application/x-www-form-urlencoded"
            }
        )
        device_data = device_res.json()
        verification_uri = device_data.get("verification_uri_complete")
        device_code = device_data.get("device_code")
        
        if not verification_uri or not device_code:
            print(f"{Colors.FAIL}[-] Error: Failed to retrieve verification URI: {device_data}{Colors.ENDC}")
            browser.close()
            return False
            
        print(f"{Colors.CYAN}[i] Device Auth URL: {verification_uri}{Colors.ENDC}")
        print(f"{Colors.BLUE}[*] Opening device authorization tab...{Colors.ENDC}")
        device_page = context.new_page()
        device_page.goto(verification_uri)
        
        # 13. Click Confirm
        try:
            device_page.wait_for_selector("#confirm", timeout=15000)
            human_sleep(1.0, 1.5)
            device_page.click("#confirm")
            print(f"{Colors.GREEN}[+] Device authorization confirmed automatically.{Colors.ENDC}")
        except Exception as e:
            print(f"{Colors.WARNING}[!] Auto-confirm failed (please click manually): {e}{Colors.ENDC}")
        
        # 14. Polling for token
        print(f"{Colors.BLUE}[*] Polling OAuth server for device session token...{Colors.ENDC}")
        oauth_token = None
        for _ in range(30):
            poll_res = requests.post(
                "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/token",
                headers={
                    "Authorization": f"basic {switch_token}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data={"grant_type": "device_code", "device_code": device_code},
            )
            poll_data = poll_res.json()
            if poll_res.status_code == 200:
                oauth_token = poll_data.get("access_token")
                break
            time.sleep(3)
        
        if not oauth_token:
            print(f"{Colors.FAIL}[-] Error: Device auth polling timed out.{Colors.ENDC}")
            browser.close()
            return False
            
        ex_res = requests.get(
            "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/exchange",
            headers={"Authorization": f"bearer {oauth_token}"}
        )
        ex_code = ex_res.json().get("code")
        
        user_res = requests.post(
            "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
            headers={
                "Authorization": f"basic {android_token}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data={"grant_type": "exchange_code", "exchange_code": ex_code},
        )
        user_data = user_res.json()
        user_access_token = user_data.get("access_token")
        account_id = user_data.get("account_id")
        display_name = user_data.get("displayName")
        
        da_res = requests.post(
            f"https://account-public-service-prod.ol.epicgames.com/account/api/public/account/{account_id}/deviceAuth",
            headers={
                "Authorization": f"bearer {user_access_token}",
                "Content-Type": "application/json",
            }
        )
        da_data = da_res.json()
        
        account_entry = {
            "display_name": display_name,
            "account_id": da_data["accountId"],
            "device_id": da_data["deviceId"],
            "secret": da_data["secret"]
        }
        
        print(f"\n{Colors.GREEN}{Colors.BOLD}==========================================")
        print(f"[SUCCESS] Account [{display_name}] created & DeviceAuth generated!")
        print(json.dumps(account_entry, indent=4))
        print(f"=========================================={Colors.ENDC}")
        
        save_account_to_json(account_entry)
        print(f"{Colors.GREEN}[+] Credentials successfully appended to {STORE_FILE}{Colors.ENDC}")
        
        browser.close()
        return True

    except Exception as e:
        print(f"{Colors.FAIL}[-] Critical Exception Occurred: {e}{Colors.ENDC}")
        try:
            browser.close()
        except:
            pass
        return False

def run_generator():
    SWITCH_TOKEN = "OThmN2U0MmMyZTNhNGY4NmE3NGViNDNmYmI0MWVkMzk6MGEyNDQ5YTItMDAxYS00NTFlLWFmZWMtM2U4MTI5MDFjNGQ3"
    ANDROID_TOKEN = "M2Y2OWU1NmM3NjQ5NDkyYzhjYzI5ZjFhZjA4YThhMTI6YjUxZWU5Y2IxMjIzNGY1MGE2OWVmYTY3ZWY1MzgxMmU="
    
    try:
        count_str = input(f"{Colors.CYAN}[?] How many accounts do you want to generate? > {Colors.ENDC}")
        count = int(count_str)
    except ValueError:
        print(f"{Colors.FAIL}Invalid number entered.{Colors.ENDC}")
        return

    with sync_playwright() as p:
        for i in range(count):
            print(f"\n{Colors.HEADER}[*] Starting generation process for account {i+1} of {count}...{Colors.ENDC}")
            success = create_single_account(p, SWITCH_TOKEN, ANDROID_TOKEN)
            if not success:
                print(f"{Colors.WARNING}[!] Account generation {i+1} failed or was interrupted.{Colors.ENDC}")
            if i < count - 1:
                print(f"{Colors.BLUE}[*] Waiting 5 seconds before next account...{Colors.ENDC}")
                time.sleep(5)

    print(f"\n{Colors.GREEN}[+] All processing has been completed{Colors.ENDC}")
    time.sleep(2)
    main()

def run_fortnite_launcher():
    if not os.path.exists(STORE_FILE):
        print(f"{Colors.FAIL}[-] No {STORE_FILE} found! Please generate an account first.{Colors.ENDC}")
        return

    try:
        with open(STORE_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                print(f"{Colors.FAIL}[-] {STORE_FILE} is empty!{Colors.ENDC}")
                return
            accounts = json.loads(content)
            if isinstance(accounts, dict):
                accounts = [accounts]
    except Exception as e:
        print(f"{Colors.FAIL}[-] Failed to parse {STORE_FILE}: {e}{Colors.ENDC}")
        return

    if not accounts:
        print(f"{Colors.FAIL}[-] No accounts found in {STORE_FILE}.{Colors.ENDC}")
        return

    print(f"\n{Colors.HEADER}=== AVAILABLE ACCOUNTS ==={Colors.ENDC}")
    for idx, acc in enumerate(accounts):
        name = acc.get("display_name", "Unknown Account")
        aid = acc.get("account_id", "N/A")
        print(f"[{idx + 1}] Display Name: {Colors.GREEN}{name}{Colors.ENDC} (ID: {aid})")
    
    try:
        choice = input(f"\n{Colors.CYAN}[?] Select account number to launch Fortnite > {Colors.ENDC}")
        idx = int(choice) - 1
        if idx < 0 or idx >= len(accounts):
            print(f"{Colors.FAIL}Invalid selection.{Colors.ENDC}")
            return
        selected_acc = accounts[idx]
    except ValueError:
        print(f"{Colors.FAIL}Invalid input.{Colors.ENDC}")
        return

    print(f"{Colors.BLUE}[*] Logging in via device auth for [{selected_acc.get('display_name', 'Unknown')}]{Colors.ENDC}")
    
    import base64
    android_c = ("3f69e56c7649492c8cc29f1af08a8a12", "b51ee9cb12234f50a69efa67ef53812e")
    auth_header = "basic " + base64.b64encode(f"{android_c[0]}:{android_c[1]}".encode()).decode()

    try:
        token_res = requests.post(
            "https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token",
            headers={
                "Authorization": auth_header,
                "Content-Type": "application/x-www-form-urlencoded",
            },
            data={
                "grant_type": "device_auth",
                "account_id": selected_acc["account_id"],
                "device_id": selected_acc["device_id"],
                "secret": selected_acc["secret"]
            }
        )
        token_data = token_res.json()
        access_token = token_data.get("access_token")
        
        if not access_token:
            print(f"{Colors.FAIL}[-] Authentication failed: {token_data}{Colors.ENDC}")
            return

        ex_res = requests.get(
            "https://account-public-service-prod03.ol.epicgames.com/account/api/oauth/exchange",
            headers={"Authorization": f"bearer {access_token}"}
        )
        ex_code = ex_res.json().get("code")

        if not ex_code:
            print(f"{Colors.FAIL}[-] Failed to get exchange code.{Colors.ENDC}")
            return

        if not os.path.exists(FORTNITE_PATH):
            print(f"{Colors.FAIL}[-] Fortnite executable not found at: {FORTNITE_PATH}{Colors.ENDC}")
            return

        print(f"{Colors.GREEN}[+] Launching Fortnite...{Colors.ENDC}")
        subprocess.Popen([
            FORTNITE_PATH,
            "-AUTH_LOGIN=unused",
            "-AUTH_PASSWORD=" + ex_code,
            "-AUTH_TYPE=exchangecode",
            "-epicapp=Fortnite",
            "-epicenv=Prod",
            "-EpicPortal"
        ], cwd=os.path.dirname(FORTNITE_PATH))
        print(f"{Colors.GREEN}[+] Successfully launched Fortnite as [{selected_acc.get('display_name')}]!{Colors.ENDC}")

    except Exception as e:
        print(f"{Colors.FAIL}[-] Error during launch: {e}{Colors.ENDC}")

def main():
    os.system('cls')
    print_banner()
    print(f"{Colors.YELLOW}[1] Account Generator (Create new Epic Games accounts){Colors.ENDC}")
    print(f"{Colors.YELLOW}[2] Launch Fortnite (Select account & start game){Colors.ENDC}")
    
    mode = input(f"\n{Colors.CYAN}[?] Select mode > {Colors.ENDC}").strip()
    
    if mode == "1":
        run_generator()
    elif mode == "2":
        run_fortnite_launcher()
    else:
        print(f"{Colors.FAIL}Invalid option selected. Exiting.{Colors.ENDC}")

if __name__ == "__main__":
    main()
