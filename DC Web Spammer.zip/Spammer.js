const X_SUPER_PROPERTIES = "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiaGFzX2NsaWVudF9tb2RzIjpmYWxzZSwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEzNC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTM0LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiJodHRwczovL2Rpc2NvcmQuY29tIiwicmVmZXJyaW5nX2RvbWFpbiI6ImRpc2NvcmQuY29tIiwicmVmZXJyZXJfY3VycmVudCI6IiIsInJlZmVycmluZ19kb21haW5fY3VycmVudCI6IiIsInJlbGVhc2VfY2hhbm5lbCI6InN0YWJsZSIsImNsaWVudF9idWlsZF9udW1iZXIiOjQ4MjI4NSwiY2xpZW50X2V2ZW50X3NvdXJjZSI6bnVsbH0=";

const logEl = document.getElementById("log");

const form = document.getElementById("form");
const tokensInput = document.getElementById("tokens");
const guildInput = document.getElementById("guildId");
const channelInput = document.getElementById("channelIds");
const messageContentInput = document.getElementById("messageContent");

const autoFillBtn = document.getElementById("autoFillChannels");

const randomizeCheckbox = document.getElementById("randomize");
const allMentionCheckbox = document.getElementById("allmention");

const delayInput = document.getElementById("delay");
const limitInput = document.getElementById("limit");

const mentionInput = document.getElementById("mentionIds");
const fetchMentionsBtn = document.getElementById("fetchMentions");
const mentionCountInput = document.getElementById("mentionCount");

const pollTitleInput = document.getElementById("pollTitle");
const pollAnswersInput = document.getElementById("pollAnswers");

const submitBtn = document.getElementById("submitBtn");
const stopBtn = document.getElementById("stopSpam");
const leaveBtn = document.getElementById("leaveBtn");

const checkBtn = document.getElementById("checkTokens");
const customIdInput = document.getElementById("customIdInput");
const applicationIdInput = document.getElementById("applicationIdInput");
const verifyBtn = document.getElementById("clickVerifyBtn");
const authUrlInput = document.getElementById("authUrlInput");

let shouldStopSpam = false;

function appendLog(message) {
  const time = new Date().toLocaleTimeString();
  logEl.textContent += `\n${time} - ${message}`;
  logEl.scrollTop = logEl.scrollHeight;
}

function clearLog() {
  logEl.textContent = "";
}

function parseList(value) {
  const parts = value
    .split(/[\s,]+/)
    .map((s) => s.trim())
    .filter(Boolean);
  return [...new Set(parts)];
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function leaveGuild(token, guildId) {
  try {
    const res = await fetch(
      `https://discord.com/api/v9/users/@me/guilds/${guildId}`,
      {
        method: "DELETE",
        headers: {
          Authorization: token,
          "Content-Type": "application/json",
          "x-super-properties": X_SUPER_PROPERTIES,
        },
        body: JSON.stringify({ lurking: false }),
        referrerPolicy: "no-referrer",
      }
    );

    if (res.status === 204) {
      appendLog(`✅ 退出成功: ${token.slice(0, 10)}*****`);
    } else {
      const body = await res.json().catch(() => ({}));
      appendLog(
        `❌ 退出失敗(${res.status}) ${token.slice(
          0,
          10
        )}***** ${JSON.stringify(body) || "詳細不明"}`
      );
    }
  } catch (e) {
    appendLog(
      `❌ 退出エラー: ${token.slice(0, 10)}***** - ${e.message || e}`
    );
  }
}

async function sendMessage(token, channelId, baseContent, options = {}) {
  const headers = {
    Authorization: token,
    "Content-Type": "application/json",
    "x-super-properties": X_SUPER_PROPERTIES,
  };

  let content = baseContent || "";

  if (options.randomize) {
    const rand =
      typeof crypto !== "undefined" && crypto.randomUUID
        ? crypto.randomUUID()
        : Math.random().toString(36).slice(2);
    content += "\n" + rand;
  }

  // 全体メンション
  if (options.allMention) {
    content = "@everyone\n" + content;
  }

  if (options.randomMentions && Array.isArray(options.mentionIds) && options.mentionIds.length > 0) {
    const ids = options.mentionIds;
    const count = Math.min(options.mentionCount || 1, ids.length);
    const selectedIds = [];
    
    const shuffled = [...ids].sort(() => Math.random() - 0.5);
    for (let i = 0; i < count; i++) {
      selectedIds.push(shuffled[i]);
    }

    const mentions = selectedIds.map(id => `<@${id}>`).join(" ");
    content = mentions + "\n" + content;
  }

  const body = { content };

  if (options.pollTitle && Array.isArray(options.pollAnswers)) {
    body.poll = {
      question: { text: options.pollTitle },
      answers: options.pollAnswers.map((answer) => ({
        poll_media: { text: String(answer).trim() },
      })),
      allow_multiselect: false,
      duration: 1,
      layout_type: 1,
    };
  }

  const res = await fetch(
    `https://discord.com/api/v9/channels/${channelId}/messages`,
    {
      method: "POST",
      headers,
      body: JSON.stringify(body),
      referrerPolicy: "no-referrer",
    }
  );

  return res;
}

async function sendMessageWithRetry(
  token,
  channelId,
  content,
  options = {},
  maxRetries = 5,
  defaultDelayMs = 3000
) {
  let attempt = 0;

  while (attempt < maxRetries) {
    try {
      const res = await sendMessage(token, channelId, content, options);

      if (res.ok) {
        appendLog(`✅ 送信成功: ${token.slice(0, 10)}*****`);
        return true;
      }

      if (res.status === 429) {
        const data = await res.json().catch(() => ({}));
        const retryAfterSec = data.retry_after || 1;
        appendLog(
          `***** - レート制限: ${token.slice(
            0,
            10
          )}***** /messages 再試行まで ${retryAfterSec}s`
        );
        await sleep(retryAfterSec * 1000);
        attempt++;
        continue;
      }

      if (res.status === 400 || res.status === 401 || res.status === 403) {
        const data = await res.json().catch(() => ({}));
        appendLog(
          `❌ 送信エラー(${res.status}): ${token.slice(
            0,
            10
          )}***** ${JSON.stringify(data) || "詳細不明"}`
        );

        const authed = await authenticateOnly(token);
        if (!authed) return false;
      } else {
        const data = await res.json().catch(() => ({}));
        appendLog(
          `❌ 送信エラー(${res.status}): ${token.slice(
            0,
            10
          )}***** ${JSON.stringify(data) || "詳細不明"}`
        );
        return false;
      }
    } catch (e) {
      appendLog(
        `user エラー: ${token.slice(
          0,
          10
        )}***** - エラー: ${e.message || e} ) 最大リトライ回数に達しました。`
      );
      await sleep(defaultDelayMs);
      attempt++;
    }
  }

  appendLog(`value エラー: ${token.slice(0, 10)}***** send`);
  return false;
}

async function authenticateOnly(token) {
  return new Promise((resolve) => {
    const ws = new WebSocket("wss://gateway.discord.gg/?v=9&encoding=json");

    ws.onopen = () => {
      ws.send(
        JSON.stringify({
          op: 2,
          d: {
            token,
            properties: {
              os: "Windows",
              browser: "Chrome",
              device: "pc",
            },
            intents: 0,
          },
        })
      );
    };

    ws.onmessage = (event) => {
      const payload = JSON.parse(event.data);
      if (payload.t === "READY") {
        appendLog(`✅ 認証完了: ${token.slice(0, 10)}*****`);
        ws.close();
        resolve(true);
      } else if (payload.t === "INVALID_SESSION") {
        appendLog(`❌ 認証失敗: ${token.slice(0, 10)}*****`);
        ws.close();
        resolve(false);
      }
    };

    ws.onerror = () => {
      appendLog(`❌ WebSocket エラー: ${token.slice(0, 10)}*****`);
      ws.close();
      resolve(false);
    };

    ws.onclose = () => {};
  });
}

checkBtn.addEventListener("click", async () => {
    const tokens = parseList(tokensInput.value);
    if (!tokens.length) return appendLog("⚠️ トークンを入力してください");

    appendLog("🔍 詳細な生存確認を開始...");
    checkBtn.disabled = true;
    const validTokens = [];

    for (const token of tokens) {
        try {
            const res = await fetch("https://discord.com/api/v9/users/@me", {
                headers: { 
                    Authorization: token, 
                    "x-super-properties": X_SUPER_PROPERTIES 
                }
            });

            if (res.ok) {
                const user = await res.json();
                let statusMsg = `✅ 有効: ${user.username}`;
                let isInvalid = false;
                if (user.verified === false) {
                    statusMsg = `❌ 無効 (メール未認証): ${user.username}`;
                    isInvalid = true;
                } else if (user.phone === null && user.mfa_enabled === false) {
                }

                if (isInvalid) {
                    appendLog(statusMsg);
                } else {
                    appendLog(statusMsg);
                    validTokens.push(token);
                }

            } else if (res.status === 401) {
                appendLog(`❌ 無効 (トークン失効): ${token.slice(0, 10)}...`);
            } else if (res.status === 403) {
                appendLog(`❌ 無効 (電話認証/ロック): ${token.slice(0, 10)}...`);
            } else {
                appendLog(`❓ 不明なエラー(${res.status}): ${token.slice(0, 10)}...`);
            }
        } catch (e) { 
            appendLog(`❌ 通信エラー: ${token.slice(0, 5)}...`); 
        }
        await sleep(300);
    }
    
    tokensInput.value = validTokens.join("\n");
    appendLog(`✨ チェック完了！ 有効なトークン: ${validTokens.length}`);
    checkBtn.disabled = false;
});

verifyBtn.addEventListener("click", async () => {
    const tokens = parseList(tokensInput.value);
    const guildId = guildInput.value.trim();
    const channelId = parseList(channelInput.value)[0];
    
    let targetAppId = applicationIdInput.value.trim();
    let targetCustomId = customIdInput.value.trim();

    if (!tokens.length || !guildId || !channelId) {
        return appendLog("⚠️ トークン、サーバーID、チャンネルIDを入力してください");
    }


    for (const token of tokens) {
        try {
            const getSessionId = () => {
                return new Promise((resolve) => {
                    const ws = new WebSocket("wss://gateway.discord.gg/?v=9&encoding=json");
                    ws.onmessage = (event) => {
                        const data = JSON.parse(event.data);
                        if (data.t === "READY") {
                            const sid = data.d.session_id;
                            ws.close();
                            resolve(sid);
                        }
                    };
                    ws.onopen = () => {
                        ws.send(JSON.stringify({
                            op: 2,
                            d: {
                                token: token,
                                capabilities: 16381,
                                properties: { os: "Windows", browser: "Chrome", device: "" },
                                presence: { status: "online", since: 0, activities: [], afk: false },
                                compress: false,
                            }
                        }));
                    };
                    setTimeout(() => { ws.close(); resolve(null); }, 5000);
                });
            };

            const sessionId = await getSessionId();
            if (!sessionId) {
                appendLog(`❌ Session取得失敗: ${token.slice(0, 10)}...`);
                continue;
            }

            const msgRes = await fetch(`https://discord.com/api/v9/channels/${channelId}/messages?limit=1`, {
                headers: { Authorization: token }
            });
            const msgs = await msgRes.json();
            const lastMsg = msgs[0];

            if (!lastMsg) {
                appendLog("❌ メッセージが見つかりません");
                continue;
            }

            const button = lastMsg.components?.[0]?.components?.find(c => c.type === 2);
            const finalAppId = targetAppId || lastMsg.application_id;
            const finalCustomId = targetCustomId || button?.custom_id;

            if (!finalAppId || !finalCustomId) {
                appendLog("❌ ボタン情報が見つかりません。");
                continue;
            }

            const res = await fetch("https://discord.com/api/v9/interactions", {
                method: "POST",
                headers: { 
                    Authorization: token, 
                    "Content-Type": "application/json",
                    "x-super-properties": X_SUPER_PROPERTIES 
                },
                body: JSON.stringify({
                    type: 3,
                    guild_id: guildId,
                    channel_id: channelId,
                    message_id: lastMsg.id,
                    application_id: finalAppId,
                    session_id: sessionId,
                    data: { 
                        component_type: 2, 
                        custom_id: finalCustomId 
                    }
                })
            });

            if (res.ok) {
                appendLog(`✅ 認証成功: ${token.slice(0, 10)}*****`);
            } else {
                const errData = await res.json();
                appendLog(`❌ 失敗: ${JSON.stringify(errData)}`);
            }
        } catch (e) {
            appendLog(`❌ エラー発生: ${e.message}`);
        }
        await sleep(1000); 
    }
    appendLog("✅ 認証成功");
});

autoFillBtn.addEventListener("click", async () => {
  clearLog();

  const tokens = parseList(tokensInput.value);
  const guildId = guildInput.value.trim();

  if (!tokens.length) {
    appendLog("⚠️ トークンを入力してください");
    return;
  }
  if (!guildId) {
    appendLog("⚠️ サーバーIDを入力してください");
    return;
  }

  try {
    const res = await fetch(
      `https://discord.com/api/v9/guilds/${guildId}/channels`,
      {
        headers: {
          Authorization: tokens[0],
          "Content-Type": "application/json",
          "x-super-properties": X_SUPER_PROPERTIES,
        },
        referrerPolicy: "no-referrer",
      }
    );

    if (!res.ok) {
      throw new Error(JSON.stringify(await res.json().catch(() => ({}))));
    }

    const channels = await res.json();
    const ids = channels
      .filter((ch) => ch.type === 0)
      .map((ch) => ch.id);

    if (!ids.length) {
      appendLog("チャンネルが見つかりません");
      return;
    }

    channelInput.value = ids.join(",");
    appendLog("✅ チャンネル取得完了");
  } catch (e) {
    appendLog(
      `❌ エラー: ${tokens[0].slice(
        0,
        10
      )}***** - エラー：${e.message || "詳細不明"}`
    );
  }
});

fetchMentionsBtn.addEventListener("click", async () => {
  clearLog();

  const tokens = parseList(tokensInput.value);
  const guildId = guildInput.value.trim();
  const channels = parseList(channelInput.value);

  if (!tokens.length) {
    appendLog("⚠️ トークンを入力してください");
    return;
  }
  if (!guildId) {
    appendLog("⚠️ サーバーIDを入力してください");
    return;
  }
  if (!channels.length) {
    appendLog("⚠️ チャンネルIDを入力してください");
    return;
  }

  const token = tokens[0];
  const channelId = channels[0];

  const ws = new WebSocket("wss://gateway.discord.gg/?v=9&encoding=json");

  ws.onopen = () => {
    ws.send(
      JSON.stringify({
        op: 2,
        d: {
          token,
          properties: { os: "Windows", browser: "Chrome", device: "pc" },
          intents: 1 << 12,
        },
      })
    );
  };

  ws.onmessage = (event) => {
    const payload = JSON.parse(event.data);

    if (payload.op === 0 && payload.t === "READY") {
      ws.send(
        JSON.stringify({
          op: 14,
          d: {
            guild_id: guildId,
            typing: false,
            activities: false,
            threads: true,
            channels: {
              [channelId]: [[0, 0]],
            },
          },
        })
      );
    }

    if (payload.t === "GUILD_MEMBER_LIST_UPDATE") {
      const ops = payload.d.ops || [];
      const items = ops[0]?.items || [];
      const memberIds = items
        .map((it) => it.member)
        .filter(Boolean)
        .map((m) => m.user.id);

      if (memberIds.length) {
        mentionInput.value = memberIds.join(",");
        appendLog("✅ メンション取得完了");
      } else {
        appendLog("メンションが見つかりません");
      }

      ws.close();
    }
  };

  ws.onerror = () => {
    appendLog("❌ WebSocketエラー");
    ws.close();
  };
});

function checkFormValidity() {
  const hasTokens = tokensInput.value.trim().length > 0;
  const hasGuild = guildInput.value.trim().length > 0;
  submitBtn.disabled = !(hasTokens && hasGuild);
}

tokensInput.addEventListener("input", checkFormValidity);
guildInput.addEventListener("input", checkFormValidity);
checkFormValidity();

form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  clearLog();

  const baseContent = messageContentInput.value.trim();
  if (!baseContent) {
    appendLog("⚠️ メッセージ内容が入力されていません");
    return;
  }

  submitBtn.disabled = true;
  submitBtn.classList.add("loading");
  submitBtn.textContent = "実行中...";
  shouldStopSpam = false;
  stopBtn.disabled = false;

  const tokens = parseList(tokensInput.value);
  const guildId = guildInput.value.trim();
  const channelIds = parseList(channelInput.value);

  const randomize = randomizeCheckbox.checked;
  const allMention = allMentionCheckbox.checked;
  const delaySec = parseFloat(delayInput.value) || 0;
  const limit =
    limitInput.value.trim() !== ""
      ? parseInt(limitInput.value, 10)
      : Infinity;

  const mentionIds =
    mentionInput.value.trim() !== ""
      ? parseList(mentionInput.value)
      : null;

  const mentionCount = parseInt(mentionCountInput.value, 10) || 1;

  const pollTitle =
    pollTitleInput.value.trim() !== "" ? pollTitleInput.value.trim() : null;

  const pollAnswers =
    pollAnswersInput.value.trim() !== ""
      ? parseList(pollAnswersInput.value)
      : null;

  let sentCount = 0;

  const workers = tokens.map((token) => {
    return async () => {
      let idx = 0;
      while (!shouldStopSpam && sentCount < limit) {
        if (idx >= channelIds.length) idx = 0;
        const channelId = channelIds[idx++];
        const ok = await sendMessageWithRetry(token, channelId, baseContent, {
          randomize,
          allMention,
          randomMentions: !!mentionIds,
          mentionIds,
          mentionCount,
          pollTitle,
          pollAnswers,
        });
        if (ok) {
          sentCount++;
        }
        if (sentCount >= limit) {
          appendLog("✅ 指定数に達しました");
          break;
        }
        if (delaySec > 0) {
          await sleep(delaySec * 1000);
        }
      }
    };
  });

  await Promise.all(workers.map((fn) => fn()));

  submitBtn.disabled = false;
  submitBtn.classList.remove("loading");
  submitBtn.textContent = "実行";
  stopBtn.disabled = true;

  appendLog("✅ 完了");
});

stopBtn.addEventListener("click", () => {
  shouldStopSpam = true;
  appendLog("🛑 スパムを停止します...");
});

leaveBtn.addEventListener("click", async () => {
  shouldStopSpam = true;
  stopBtn.disabled = true;
  appendLog("🛑 スパムを停止します...");

  const tokens = parseList(tokensInput.value);
  const guildId = guildInput.value.trim();

  if (!tokens.length) {
    appendLog("⚠️ トークンを入力してください");
    return;
  }
  if (!guildId) {
    appendLog("⚠️ サーバーIDを入力してください");
    return;
  }

  for (const token of tokens) {
    await leaveGuild(token, guildId);
  }

  appendLog("✅ 退出処理完了");
});
