@echo off
setlocal EnableDelayedExpansion

REM Change BIOS Release Date to match the default from your provided data
AMIDEWINx64 /ID "12/15/2023"

REM Change BIOS Vendor
AMIDEWINx64 /IVN "American Megatrends International, LLC."

REM Change BIOS Version
AMIDEWINx64 /IV "F8"

REM Change System Family
AMIDEWINx64 /SF "B760 MB"

REM Change Product Name
AMIDEWINx64 /SP "B760 AORUS MASTER DDR4"

REM Change SKU Number
AMIDEWINx64 /SK "Default string"

REM Change System Serial Number
AMIDEWINx64 /SS "Default string"

REM Change System Manufacturer
AMIDEWINx64 /SM "Gigabyte Technology Co., Ltd."

REM Change System Version
AMIDEWINx64 /SV "Default string"

REM Auto-generate System UUID
AMIDEWINx64 /SU AUTO

REM Change Baseboard Asset Tag
AMIDEWINx64 /BT "Default string"

REM Change Baseboard Manufacturer
AMIDEWINx64 /BM "Gigabyte Technology Co., Ltd."

REM Change Location in Chassis
AMIDEWINx64 /BLC "Default string"

REM Change Baseboard Product Name
AMIDEWINx64 /BP "B760 AORUS MASTER DDR4"

REM Change Baseboard Serial Number
AMIDEWINx64 /BS "Default string"

REM Change Baseboard Version
AMIDEWINx64 /BV "Default string"

REM Change Chassis Asset Tag
AMIDEWINx64 /CA "Default string"

REM Change Chassis Manufacturer
AMIDEWINx64 /CM "Default string"

REM Change Chassis Serial Number
AMIDEWINx64 /CS "Default string"

REM Change Chassis Version
AMIDEWINx64 /CV "Default string"

REM Change Processor Asset Tag
AMIDEWINx64 /PAT "To Be Filled By O.E.M."

REM Change Processor Part Number
AMIDEWINx64 /PPN "To Be Filled By O.E.M."

REM Change Processor Serial Number
AMIDEWINx64 /PSN "To Be Filled By O.E.M."

echo DMI update completed.
pause
