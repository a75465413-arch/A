@echo off
setlocal EnableDelayedExpansion

REM Function to generate a random 5-digit number
set RAND_NUM=
for /L %%n in (1,1,5) do (
    set /A RAND=!RANDOM! %% 10
    set RAND_NUM=!RAND_NUM!!RAND!
)

REM Change BIOS Release Date
AMIDEWINx64 /ID "02/07/2020"

REM Change BIOS Vendor
AMIDEWINx64 /IVN "American Megatrends Inc."

REM Change BIOS Version
AMIDEWINx64 /IV "3006"

REM Change System Family
AMIDEWINx64 /SF "To be filled by O.E.M."

REM Change Product Name
AMIDEWINx64 /SP "System Product Name"

REM Change SKU Number
AMIDEWINx64 /SK "ASUS_MB_KBLX"

REM Change System Serial Number
AMIDEWINx64 /SS "System Serial Number"

REM Change System Manufacturer
AMIDEWINx64 /SM "System manufacturer"

REM Change System Version
AMIDEWINx64 /SV "System Version"

REM Auto-generate System UUID
AMIDEWINx64 /SU AUTO

REM Change Baseboard Asset Tag
AMIDEWINx64 /BT "Default string"

REM Change Baseboard Manufacturer
AMIDEWINx64 /BM "ASUSTeK COMPUTER INC."

REM Change Location in Chassis
AMIDEWINx64 /BLC "Default string"

REM Change Baseboard Product Name
AMIDEWINx64 /BP "TUF X299 MARK 2"

REM Change Baseboard Serial Number with randomized last 5 digits
set BASE_SERIAL="20107606748!RAND_NUM!"
AMIDEWINx64 /BS %BASE_SERIAL%

REM Change Baseboard Version
AMIDEWINx64 /BV "Rev 1.xx"

REM Change Chassis Asset Tag
AMIDEWINx64 /CA "Default string"

REM Change Chassis Manufacturer
AMIDEWINx64 /CM "Default string"

REM Change Chassis Serial Number
AMIDEWINx64 /CS "Default string"

REM Change Chassis Version
AMIDEWINx64 /CV "Default string"

REM Change Processor Asset Tag
AMIDEWINx64 /PAT "Unknown"

REM Change Processor Part Number
AMIDEWINx64 /PPN "Unknown"

REM Change Processor Serial Number
AMIDEWINx64 /PSN "Unknown"

REM Change all System Enclosure (Type 3) fields to "Default string"
AMIDEWINx64 /CM "Default string"
AMIDEWINx64 /CV "Default string"
AMIDEWINx64 /CS "Default string"
AMIDEWINx64 /CA "Default string"
AMIDEWINx64 /CSK "Default string"

echo DMI update completed.
pause
