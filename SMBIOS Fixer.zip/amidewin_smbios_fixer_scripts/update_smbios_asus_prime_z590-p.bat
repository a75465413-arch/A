REM Just another shitty smbios restoration script written by Reported.lol
REM Thanks to all perm spoofers for giving us hours upon hours of work.

@echo off
setlocal EnableDelayedExpansion

REM Function to generate a random 5-digit number
set RAND_NUM=
for /L %%n in (1,1,5) do (
    set /A RAND=!RANDOM! %% 10
    set RAND_NUM=!RAND_NUM!!RAND!
)

REM Set BIOS Release Date
AMIDEWINx64 /ID "01/27/2022"

REM Set BIOS Vendor
AMIDEWINx64 /IVN "American Megatrends International, LLC."

REM Set BIOS Version
AMIDEWINx64 /IV "1410"

REM Set System Family
AMIDEWINx64 /SF "To be filled by O.E.M."

REM Set Product Name
AMIDEWINx64 /SP "System Product Name"

REM Set SKU Number
AMIDEWINx64 /SK "To be filled by O.E.M."

REM Set System Serial Number
AMIDEWINx64 /SS "American Megatrends International, LLC."

REM Set System Manufacturer
AMIDEWINx64 /SM "System manufacturer"

REM Set System Version
AMIDEWINx64 /SV "6.0"

REM Set Baseboard Asset Tag
AMIDEWINx64 /BT "To be filled by O.E.M."

REM Set Baseboard Manufacturer
AMIDEWINx64 /BM "ASUSTeK COMPUTER INC."

REM Set Location in Chassis
AMIDEWINx64 /BLC "To be filled by O.E.M."

REM Set Baseboard Product Name
AMIDEWINx64 /BP "PRIME Z590-P"

REM Set Baseboard Serial Number with randomized last 5 digits
set BASE_SERIAL="2105859200!RAND_NUM!"
AMIDEWINx64 /BS %BASE_SERIAL%

REM Set Baseboard Version
AMIDEWINx64 /BV "Rev 1.xx"

REM Set Chassis Asset Tag
AMIDEWINx64 /CA "To be filled by O.E.M."

REM Set Chassis Manufacturer
AMIDEWINx64 /CM "American Megatrends International, LLC."

REM Set Chassis Serial Number
AMIDEWINx64 /CS "To be filled by O.E.M."

REM Set Chassis Version
AMIDEWINx64 /CV "5.0"

REM Set Processor Asset Tag
AMIDEWINx64 /PAT "Default string"

REM Set Processor Part Number
AMIDEWINx64 /PPN "Default string"

REM Set Processor Serial Number
AMIDEWINx64 /PSN "Unknown"

echo DMI update completed.
pause
