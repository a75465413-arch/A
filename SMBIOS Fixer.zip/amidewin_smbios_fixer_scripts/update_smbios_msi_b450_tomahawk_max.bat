@echo off
REM ============================================================
REM SMBIOS Restoration Script for B450 TOMAHAWK MAX (MS-7C02) 
REM Written by Reported.lol
REM Thanks to all perm spoofers for their contributions fucking up every single motherboard.
REM ============================================================

setlocal EnableDelayedExpansion

REM Function to generate a random 8-digit number for the Baseboard Serial Number
set "RAND_NUM="
for /L %%n in (1,1,8) do (
    set /A RAND=!RANDOM! %% 10
    set "RAND_NUM=!RAND_NUM!!RAND!"
)

REM ============================================================
REM BIOS Information
REM ============================================================

REM Change BIOS Release Date to "10/14/2023"
AMIDEWINx64 /ID "10/14/2023"

REM Change BIOS Vendor to "American Megatrends International, LLC."
AMIDEWINx64 /IVN "American Megatrends International, LLC."

REM Change BIOS Version to "3.I0"
AMIDEWINx64 /IV "3.I0"

REM ============================================================
REM System Information
REM ============================================================

REM Change System Family to "To be filled by O.E.M."
AMIDEWINx64 /SF "To be filled by O.E.M."

REM Change Product Name to "MS-7C02"
AMIDEWINx64 /SP "MS-7C02"

REM Change SKU Number to "To be filled by O.E.M."
AMIDEWINx64 /SK "To be filled by O.E.M."

REM Change System Serial Number to "To be filled by O.E.M."
AMIDEWINx64 /SS "To be filled by O.E.M."

REM Change System Manufacturer to "Micro-Star International Co., Ltd"
AMIDEWINx64 /SM "Micro-Star International Co., Ltd"

REM Change System Version to "1.0"
AMIDEWINx64 /SV "1.0"

REM Auto-generate System UUID
AMIDEWINx64 /SU AUTO

REM ============================================================
REM Baseboard (Motherboard) Information
REM ============================================================

REM Change Baseboard Asset Tag to "Default string"
AMIDEWINx64 /BT "Default string"

REM Change Baseboard Manufacturer to "Micro-Star International Co., Ltd."
AMIDEWINx64 /BM "Micro-Star International Co., Ltd."

REM Change Location in Chassis to "To be filled by O.E.M."
AMIDEWINx64 /BLC "To be filled by O.E.M."

REM Change Baseboard Product Name to "B450 TOMAHAWK MAX (MS-7C02)"
AMIDEWINx64 /BP "B450 TOMAHAWK MAX (MS-7C02)"

REM Change Baseboard Serial Number to "07C02IV_" followed by 8 random digits
set "BASE_SERIAL=07C02IV_K3%RAND_NUM%"
AMIDEWINx64 /BS "%BASE_SERIAL%"

REM Change Baseboard Version to "1.0"
AMIDEWINx64 /BV "1.0"

REM ============================================================
REM Chassis Information
REM ============================================================

REM Change Chassis Asset Tag to "To be filled by O.E.M."
AMIDEWINx64 /CA "To be filled by O.E.M."

REM Change Chassis Manufacturer to "Micro-Star International Co., Ltd"
AMIDEWINx64 /CM "Micro-Star International Co., Ltd"

REM Change Chassis Serial Number to "To be filled by O.E.M."
AMIDEWINx64 /CS "To be filled by O.E.M."

REM Change Chassis Version to "1.0"
AMIDEWINx64 /CV "1.0"

REM ============================================================
REM Processor Information
REM ============================================================

REM Change Processor Asset Tag to "Unknown"
AMIDEWINx64 /PAT "Unknown"

REM Change Processor Part Number to "Unknown"
AMIDEWINx64 /PPN "Unknown"

REM Change Processor Serial Number to "Unknown"
AMIDEWINx64 /PSN "Unknown"

REM ============================================================
REM Reset Any Remaining Enclosure (Type 3) Fields to Default
REM ============================================================

REM Optional: Uncomment the lines below if you want to reset these fields
REM AMIDEWINx64 /CM "Default string"
REM AMIDEWINx64 /CV "Default string"
REM AMIDEWINx64 /CS "Default string"
REM AMIDEWINx64 /CA "Default string"
REM AMIDEWINx64 /CSK "Default string"

REM ============================================================
REM Completion Message
REM ============================================================

echo.
echo ================================
echo SMBIOS Update Completed Successfully!
echo ================================
pause
