REM Just another shitty smbios restoration script written by Reported.lol
REM Thanks to all perm spoofers for giving us hours upon hours of work.

@echo off
setlocal EnableDelayedExpansion

REM Change BIOS Release Date
AMIDEWINx64 /ID "11/09/2023"

REM Change BIOS Vendor
AMIDEWINx64 /IVN "American Megatrends International, LLC."

REM Change BIOS Version
AMIDEWINx64 /IV "FHc"

REM Change System Family
AMIDEWINx64 /SF "Z790 MB"

REM Change Product Name
AMIDEWINx64 /SP "Z790 AORUS ELITE AX"

REM Change SKU Number
AMIDEWINx64 /SK "Default string"

REM Change System Serial Number
AMIDEWINx64 /SS "Default string"

REM Change System Manufacturer
AMIDEWINx64 /SM "Gigabyte Technology Co., Ltd."

REM Change System Version
AMIDEWINx64 /SV "Default string"

REM Auto-generate System UUID
AMIDEWINx64 /SU AUTO

REM Change Baseboard Asset Tag
AMIDEWINx64 /BT "Default string"

REM Change Baseboard Manufacturer
AMIDEWINx64 /BM "Gigabyte Technology Co., Ltd."

REM Change Location in Chassis
AMIDEWINx64 /BLC "Default string"

REM Change Baseboard Product Name
AMIDEWINx64 /BP "Z790 AORUS ELITE AX"

REM Change Baseboard Serial Number
AMIDEWINx64 /BS "Default string"

REM Change Baseboard Version
AMIDEWINx64 /BV "x.x"

REM Change Chassis Asset Tag
AMIDEWINx64 /CA "Default string"

REM Change Chassis Manufacturer
AMIDEWINx64 /CM "Default string"

REM Change Chassis Serial Number
AMIDEWINx64 /CS "Default string"

REM Change Chassis Version
AMIDEWINx64 /CV "Default string"

REM Change Processor Asset Tag
AMIDEWINx64 /PAT "To Be Filled By O.E.M."

REM Change Processor Part Number
AMIDEWINx64 /PPN "To Be Filled By O.E.M."

REM Change Processor Serial Number
AMIDEWINx64 /PSN "To Be Filled By O.E.M."

REM Change all System Enclosure (Type 3) fields to "Default string"
AMIDEWINx64 /CM "Default string"
AMIDEWINx64 /CV "Default string"
AMIDEWINx64 /CS "Default string"
AMIDEWINx64 /CA "Default string"
AMIDEWINx64 /CSK "Default string"

echo DMI update completed.
pause
