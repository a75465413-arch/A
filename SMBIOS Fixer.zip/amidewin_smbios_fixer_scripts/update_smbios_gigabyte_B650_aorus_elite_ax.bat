@echo off
setlocal EnableDelayedExpansion

REM Change BIOS Release Date
AMIDEWINx64 /ID "01/10/2024"

REM Change BIOS Vendor
AMIDEWINx64 /IVN "American Megatrends International, LLC."

REM Change BIOS Version
AMIDEWINx64 /IV "FA2"

REM Change System Family
AMIDEWINx64 /SF "B650 MB"

REM Change Product Name
AMIDEWINx64 /SP "B650 AORUS ELITE AX"

REM Change SKU Number
AMIDEWINx64 /SK "Default string"

REM Change System Serial Number
AMIDEWINx64 /SS "Default string"

REM Change System Manufacturer
AMIDEWINx64 /SM "Gigabyte Technology Co., Ltd."

REM Change System Version
AMIDEWINx64 /SV "Default string"

REM Change Baseboard Asset Tag
AMIDEWINx64 /BT "Default string"

REM Change Baseboard Manufacturer
AMIDEWINx64 /BM "Gigabyte Technology Co., Ltd."

REM Change Location in Chassis
AMIDEWINx64 /BLC "Default string"

REM Change Baseboard Product Name
AMIDEWINx64 /BP "B650 AORUS ELITE AX"

REM Change Baseboard Serial Number
AMIDEWINx64 /BS "Default string"

REM Change Baseboard Version
AMIDEWINx64 /BV "x.x"

REM Change Chassis Asset Tag
AMIDEWINx64 /CA "Default string"

REM Change Chassis Manufacturer
AMIDEWINx64 /CM "Default string"

REM Change Chassis Serial Number
AMIDEWINx64 /CS "Default string"

REM Change Chassis Version
AMIDEWINx64 /CV "Default string"

REM Change Processor Asset Tag
AMIDEWINx64 /PAT "Unknown"

REM Change Processor Part Number
AMIDEWINx64 /PPN "Unknown"

REM Change Processor Serial Number
AMIDEWINx64 /PSN "Unknown"

echo DMI update completed.
pause
