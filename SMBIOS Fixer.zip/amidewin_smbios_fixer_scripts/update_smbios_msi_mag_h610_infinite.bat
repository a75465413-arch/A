REM Just another shitty smbios restoration script written by Reported.lol
REM Thanks to all perm spoofers for giving us hours upon hours of work.

@echo off
setlocal EnableDelayedExpansion

REM Function to generate a random 5-digit number (for the serial number modification)
set RAND_SYS=
for /L %%n in (1,1,5) do (
    set /A RAND=!RANDOM! %% 10
    set RAND_SYS=!RAND_SYS!!RAND!
)

set RAND_BASE=
for /L %%n in (1,1,5) do (
    set /A RAND=!RANDOM! %% 10
    set RAND_BASE=!RAND_BASE!!RAND!
)

REM Change BIOS Release Date
AMIDEWINx64 /ID "02/23/2023"

REM Change BIOS Vendor
AMIDEWINx64 /IVN "American Megatrends International, LLC."

REM Change BIOS Version
AMIDEWINx64 /IV "A.00"

REM Change System Family
AMIDEWINx64 /SF "Desktop"

REM Change Product Name
AMIDEWINx64 /SP "Desktop MAG H610 Infinite S3 13E"

REM Change SKU Number
AMIDEWINx64 /SK "B938.A"

REM Change System Serial Number with unique randomized last 5 digits
set SYS_SERIAL="MSB938N4S01!RAND_SYS!"
AMIDEWINx64 /SS %SYS_SERIAL%

REM Change System Manufacturer
AMIDEWINx64 /SM "Micro-Star International Co., Ltd."

REM Change System Version
AMIDEWINx64 /SV "2.3"

REM Change Baseboard Asset Tag
AMIDEWINx64 /BT "Default string"

REM Change Baseboard Manufacturer
AMIDEWINx64 /BM "Micro-Star International Co., Ltd."

REM Change Location in Chassis
AMIDEWINx64 /BLC "Default string"

REM Change Baseboard Product Name
AMIDEWINx64 /BP "PRO H610M-G (MS-7D46)"

REM Change Baseboard Serial Number with unique randomized last 5 digits
set BASE_SERIAL="07D4623_N31E9!RAND_BASE!"
AMIDEWINx64 /BS %BASE_SERIAL%

REM Change Baseboard Version
AMIDEWINx64 /BV "2.3"

REM Change Chassis Asset Tag
AMIDEWINx64 /CA "Default string"

REM Change Chassis Manufacturer
AMIDEWINx64 /CM "Micro-Star International Co., Ltd."

REM Change Chassis Serial Number
AMIDEWINx64 /CS "Default string"

REM Change Chassis Version
AMIDEWINx64 /CV "2.3"

REM Change Processor Asset Tag
AMIDEWINx64 /PAT "To Be Filled By O.E.M."

REM Change Processor Part Number
AMIDEWINx64 /PPN "To Be Filled By O.E.M."

REM Change Processor Serial Number
AMIDEWINx64 /PSN "To Be Filled By O.E.M."

REM Change all System Enclosure (Type 3) fields to "Default string"
AMIDEWINx64 /CM "Default string"
AMIDEWINx64 /CV "Default string"
AMIDEWINx64 /CS "Default string"
AMIDEWINx64 /CA "Default string"
AMIDEWINx64 /CSK "Default string"

echo DMI update completed.
pause
