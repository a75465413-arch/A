using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class V2PackageResponse
{
	[JsonPropertyName("isEncrypted")]
	public bool IsEncrypted { get; set; }

	[JsonPropertyName("resolved")]
	public V2Resolved? Resolved { get; set; }
}
