using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class V4ContentItem
{
	[JsonPropertyName("binaries")]
	public V4Binaries? Binaries { get; set; }
}
