using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace UEFNMapInstaller;

internal static class BpsDownloader
{
	private sealed class BpsManifest
	{
		public BpsFileRecord[] Files { get; set; } = Array.Empty<BpsFileRecord>();
	}

	private sealed class BpsFileRecord
	{
		public string Filename { get; set; } = "";

		public string SymlinkTarget { get; set; } = "";

		public string Sha1 { get; set; } = "";

		public byte Flags { get; set; }

		public long FileSize { get; set; }

		public List<BpsChunkPart> ChunkParts { get; } = new List<BpsChunkPart>();
	}

	private sealed class BpsChunk
	{
		public string Guid { get; set; } = "";

		public string GuidHex => Guid.Replace("-", "").ToUpperInvariant();

		public ulong Hash { get; set; }

		public string Sha1 { get; set; } = "";

		public byte Group { get; set; }

		public uint WindowSize { get; set; }

		public ulong FileSize { get; set; }
	}

	private sealed class BpsChunkPart
	{
		public BpsChunk Chunk { get; set; }

		public uint Offset { get; set; }

		public uint Size { get; set; }
	}

	private sealed class ByteReader
	{
		private readonly byte[] _data;

		private int _pos;

		public int Position => _pos;

		public ByteReader(byte[] data)
		{
			_data = data;
			_pos = 0;
		}

		public void Seek(int offset)
		{
			_pos = offset;
		}

		public void Skip(int n)
		{
			_pos += n;
		}

		public byte ReadByte()
		{
			return _data[_pos++];
		}

		public int ReadInt32()
		{
			int result = BitConverter.ToInt32(_data, _pos);
			_pos += 4;
			return result;
		}

		public uint ReadUInt32()
		{
			uint result = BitConverter.ToUInt32(_data, _pos);
			_pos += 4;
			return result;
		}

		public ulong ReadUInt64()
		{
			ulong result = BitConverter.ToUInt64(_data, _pos);
			_pos += 8;
			return result;
		}

		public byte[] ReadBytes(int n)
		{
			byte[] array = new byte[n];
			Array.Copy(_data, _pos, array, 0, n);
			_pos += n;
			return array;
		}

		public string ReadFString()
		{
			int num = ReadInt32();
			if (num == 0)
			{
				return "";
			}
			if (num > 0)
			{
				byte[] array = ReadBytes(num);
				return Encoding.UTF8.GetString((array[^1] == 0) ? array[..^1] : array);
			}
			byte[] array2 = ReadBytes(-num * 2);
			return Encoding.Unicode.GetString((array2.Length >= 2 && array2[^1] == 0 && array2[^2] == 0) ? array2[..^2] : array2);
		}

		public string ReadGuid()
		{
			byte[] array = ReadBytes(16);
			byte[] array2 = new byte[16];
			for (int i = 0; i < 4; i++)
			{
				uint num = (uint)((array[i * 4] << 24) | (array[i * 4 + 1] << 16) | (array[i * 4 + 2] << 8) | array[i * 4 + 3]);
				array2[i * 4] = (byte)(num & 0xFF);
				array2[i * 4 + 1] = (byte)((num >> 8) & 0xFF);
				array2[i * 4 + 2] = (byte)((num >> 16) & 0xFF);
				array2[i * 4 + 3] = (byte)((num >> 24) & 0xFF);
			}
			return new Guid(array2).ToString("D");
		}
	}

	private const uint ManifestMagic = 1153351692u;

	private const uint ChunkMagic = 2986228386u;

	public static async Task<List<string>> ReconstructFilesAsync(string manifestPath, string baseUrl, string outputDir, string channel = "alt", CancellationToken ct = default(CancellationToken))
	{
		BpsManifest bpsManifest = ParseManifest(await File.ReadAllBytesAsync(manifestPath, ct));
		string cacheDir = Path.Combine(outputDir, ".chunks");
		Directory.CreateDirectory(cacheDir);
		List<string> written = new List<string>();
		BpsFileRecord[] files = bpsManifest.Files;
		foreach (BpsFileRecord file in files)
		{
			string filename = Path.GetFileName(file.Filename);
			string target = Path.Combine(outputDir, filename);
			Console.WriteLine($"  [{file.FileSize:N0} B] {filename}");
			using SHA1 sha1 = SHA1.Create();
			await using FileStream fs = File.Create(target);
			foreach (BpsChunkPart part in file.ChunkParts)
			{
				byte[] sourceArray = await FetchChunkAsync(baseUrl, part.Chunk, cacheDir, channel, ct);
				byte[] piece = new byte[part.Size];
				Array.Copy(sourceArray, (int)part.Offset, piece, 0, (int)part.Size);
				await fs.WriteAsync(piece, 0, piece.Length, ct);
				sha1.TransformBlock(piece, 0, piece.Length, null, 0);
			}
			sha1.TransformFinalBlock(Array.Empty<byte>(), 0, 0);
			string text = sha1.Hash.ToHexString();
			if (!string.Equals(text, file.Sha1, StringComparison.OrdinalIgnoreCase))
			{
				fs.Close();
				File.Delete(target);
				throw new InvalidDataException($"SHA1 mismatch: {filename} (got={text}, expected={file.Sha1})");
			}
			written.Add(target);
		}
		try
		{
			Directory.Delete(cacheDir, recursive: true);
		}
		catch
		{
		}
		return written;
	}

	private static BpsManifest ParseManifest(byte[] raw)
	{
		ByteReader byteReader = new ByteReader(raw);
		uint num = byteReader.ReadUInt32();
		if (num != 1153351692)
		{
			throw new InvalidDataException($"Invalid BPS manifest magic: 0x{num:X8}");
		}
		int num2 = byteReader.ReadInt32();
		int num3 = byteReader.ReadInt32();
		int num4 = byteReader.ReadInt32();
		byteReader.Skip(20);
		byte b = byteReader.ReadByte();
		if (num2 > 37)
		{
			byteReader.ReadInt32();
		}
		byteReader.Seek(num2);
		byte[] array = byteReader.ReadBytes(((b & 1) != 0) ? num4 : num3);
		byte[] array2;
		if ((b & 1) != 0)
		{
			using MemoryStream memoryStream = new MemoryStream(array);
			memoryStream.Seek(2L, SeekOrigin.Begin);
			using DeflateStream deflateStream = new DeflateStream(memoryStream, CompressionMode.Decompress);
			using MemoryStream memoryStream2 = new MemoryStream();
			deflateStream.CopyTo(memoryStream2);
			array2 = memoryStream2.ToArray();
		}
		else
		{
			array2 = array;
		}
		if (array2.Length != num3)
		{
			throw new InvalidDataException("BPS manifest decompressed size mismatch");
		}
		ByteReader byteReader2 = new ByteReader(array2);
		int position = byteReader2.Position;
		int num5 = byteReader2.ReadInt32();
		byteReader2.Seek(position + num5);
		int position2 = byteReader2.Position;
		int num6 = byteReader2.ReadInt32();
		byteReader2.ReadByte();
		int num7 = byteReader2.ReadInt32();
		BpsChunk[] array3 = new BpsChunk[num7];
		for (int i = 0; i < num7; i++)
		{
			array3[i] = new BpsChunk
			{
				Guid = byteReader2.ReadGuid()
			};
		}
		for (int j = 0; j < num7; j++)
		{
			array3[j].Hash = byteReader2.ReadUInt64();
		}
		for (int k = 0; k < num7; k++)
		{
			array3[k].Sha1 = byteReader2.ReadBytes(20).ToHexString();
		}
		for (int l = 0; l < num7; l++)
		{
			array3[l].Group = byteReader2.ReadByte();
		}
		for (int m = 0; m < num7; m++)
		{
			array3[m].WindowSize = byteReader2.ReadUInt32();
		}
		for (int n = 0; n < num7; n++)
		{
			array3[n].FileSize = byteReader2.ReadUInt64();
		}
		byteReader2.Seek(position2 + num6);
		Dictionary<string, BpsChunk> dictionary = array3.ToDictionary((BpsChunk c) => c.Guid);
		_ = byteReader2.Position;
		byteReader2.ReadInt32();
		byteReader2.ReadByte();
		int num8 = byteReader2.ReadInt32();
		BpsFileRecord[] array4 = new BpsFileRecord[num8];
		for (int num9 = 0; num9 < num8; num9++)
		{
			array4[num9] = new BpsFileRecord
			{
				Filename = byteReader2.ReadFString()
			};
		}
		for (int num10 = 0; num10 < num8; num10++)
		{
			array4[num10].SymlinkTarget = byteReader2.ReadFString();
		}
		for (int num11 = 0; num11 < num8; num11++)
		{
			array4[num11].Sha1 = byteReader2.ReadBytes(20).ToHexString();
		}
		for (int num12 = 0; num12 < num8; num12++)
		{
			array4[num12].Flags = byteReader2.ReadByte();
		}
		for (int num13 = 0; num13 < num8; num13++)
		{
			int num14 = byteReader2.ReadInt32();
			for (int num15 = 0; num15 < num14; num15++)
			{
				byteReader2.ReadFString();
			}
		}
		for (int num16 = 0; num16 < num8; num16++)
		{
			int num17 = byteReader2.ReadInt32();
			long num18 = 0L;
			for (int num19 = 0; num19 < num17; num19++)
			{
				byteReader2.ReadUInt32();
				string text = byteReader2.ReadGuid();
				uint offset = byteReader2.ReadUInt32();
				uint num20 = byteReader2.ReadUInt32();
				if (!dictionary.TryGetValue(text, out var value))
				{
					throw new InvalidDataException("Chunk GUID not found: " + text);
				}
				array4[num16].ChunkParts.Add(new BpsChunkPart
				{
					Chunk = value,
					Offset = offset,
					Size = num20
				});
				num18 += num20;
			}
			array4[num16].FileSize = num18;
		}
		return new BpsManifest
		{
			Files = array4
		};
	}

	private static async Task<byte[]> FetchChunkAsync(string baseUrl, BpsChunk chunk, string cacheDir, string channel, CancellationToken ct)
	{
		string cachePath = Path.Combine(cacheDir, $"{chunk.Group:D2}_{chunk.Hash:X16}_{chunk.GuidHex}.chunk");
		if (!File.Exists(cachePath) || new FileInfo(cachePath).Length != (long)chunk.FileSize)
		{
			string url = $"{baseUrl.TrimEnd('/')}/{Uri.EscapeDataString(channel)}/ChunksV4/{chunk.Group:D2}/{chunk.Hash:X16}_{chunk.GuidHex}.chunk";
			Console.Write("    chunk: " + chunk.GuidHex.Substring(0, 8) + "... ");
			await EpicHttp.DownloadFileAsync(url, cachePath, null, null, ct);
			Console.WriteLine("OK");
		}
		return ParseChunk(await File.ReadAllBytesAsync(cachePath, ct));
	}

	private static byte[] ParseChunk(byte[] raw)
	{
		ByteReader byteReader = new ByteReader(raw);
		uint num = byteReader.ReadUInt32();
		if (num != 2986228386u)
		{
			throw new InvalidDataException($"Invalid BPS chunk magic: 0x{num:X8}");
		}
		byteReader.ReadUInt32();
		int offset = byteReader.ReadInt32();
		int n = byteReader.ReadInt32();
		byteReader.Skip(16);
		byteReader.Skip(8);
		byte b = byteReader.ReadByte();
		byteReader.Seek(offset);
		byte[] array = byteReader.ReadBytes(n);
		if ((b & 1) != 0)
		{
			using (MemoryStream memoryStream = new MemoryStream(array))
			{
				memoryStream.Seek(2L, SeekOrigin.Begin);
				using DeflateStream deflateStream = new DeflateStream(memoryStream, CompressionMode.Decompress);
				using MemoryStream memoryStream2 = new MemoryStream();
				deflateStream.CopyTo(memoryStream2);
				return memoryStream2.ToArray();
			}
		}
		return array;
	}
}
