#nullable enable

using System;
using System.IO;
using System.Linq;
using System.Text;
using CUE4Parse.Encryption.Aes;
using CUE4Parse.FileProvider;
using CUE4Parse.FileProvider.Objects;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Versions;

namespace UEFNMapInstaller;

internal static class LocalBundleFinder
{
	private static readonly string[] RequiredFiles = { "plugin.pak", "plugin.ucas", "plugin.utoc" };

	public static string? FindMatchingBundle(string installedBundlesDirectory, string moduleId, string aesKeyHex, string? pakGuid)
	{
		if (!Directory.Exists(installedBundlesDirectory))
		{
			return null;
		}

		FAesKey key = new FAesKey(aesKeyHex.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? aesKeyHex : "0x" + aesKeyHex);
		string[] bundleDirectories = Directory.GetDirectories(installedBundlesDirectory)
			.OrderByDescending(Directory.GetLastWriteTimeUtc)
			.ToArray();
		int failedBundles = 0;
		string? lastError = null;

		foreach (string bundleDirectory in bundleDirectories)
		{
			if (RequiredFiles.Any(file => !File.Exists(Path.Combine(bundleDirectory, file))))
			{
				continue;
			}
			if (!ManifestContainsModuleId(bundleDirectory, moduleId))
			{
				continue;
			}

			try
			{
				using DefaultFileProvider provider = new DefaultFileProvider(
					bundleDirectory,
					SearchOption.TopDirectoryOnly,
					new VersionContainer(EGame.GAME_UE5_8));
				provider.Initialize();
				provider.SubmitKey(default, key);
				if (!string.IsNullOrWhiteSpace(pakGuid))
				{
					string normalizedGuid = pakGuid.Replace("-", "").Replace("{", "").Replace("}", "");
					if (normalizedGuid.Length != 32)
					{
						throw new FormatException("Invalid pak GUID format.");
					}
					provider.SubmitKey(new FGuid(normalizedGuid), key);
				}
				provider.PostMount();

				bool matchesModule = provider.Files.Values.Any(file =>
					string.Equals(file.Extension, "uplugin", StringComparison.OrdinalIgnoreCase) &&
					file.Path.Contains(moduleId, StringComparison.OrdinalIgnoreCase));
				if (matchesModule)
				{
					return bundleDirectory;
				}
			}
			catch (Exception ex)
			{
				failedBundles++;
				lastError = ex.Message;
			}
		}

		if (failedBundles > 0)
		{
			ConsoleLog.WriteLine($"Could not inspect {failedBundles} local bundle(s). Last error: {lastError}", ConsoleColor.Yellow);
		}
		return null;
	}

	private static bool ManifestContainsModuleId(string bundleDirectory, string moduleId)
	{
		string manifestPath = Path.Combine(bundleDirectory, "CachedBPSManifest.manifest");
		if (!File.Exists(manifestPath))
		{
			return false;
		}

		try
		{
			byte[] raw = File.ReadAllBytes(manifestPath);
			if (!Guid.TryParse(moduleId, out Guid parsedModuleId))
			{
				return false;
			}

			string dashedModuleId = parsedModuleId.ToString("D");
			string compactModuleId = parsedModuleId.ToString("N");
			return ContainsModuleId(Encoding.ASCII.GetString(raw), dashedModuleId, compactModuleId) ||
				ContainsModuleId(Encoding.Unicode.GetString(raw), dashedModuleId, compactModuleId);
		}
		catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
		{
			ConsoleLog.WriteLine($"Could not read the cached manifest in {Path.GetFileName(bundleDirectory)}: {ex.Message}", ConsoleColor.Yellow);
			return false;
		}
	}

	private static bool ContainsModuleId(string text, string dashedModuleId, string compactModuleId)
	{
		return text.Contains(dashedModuleId, StringComparison.OrdinalIgnoreCase) ||
			text.Contains(compactModuleId, StringComparison.OrdinalIgnoreCase);
	}
}
