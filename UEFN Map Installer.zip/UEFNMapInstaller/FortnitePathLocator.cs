using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace UEFNMapInstaller;

internal static class FortnitePathLocator
{
	private static readonly string[] PaksRelativePaths = new string[2] { "FortniteGame\\Content\\Paks", "FortniteGame\\Content\\paks" };

	private static readonly JsonSerializerOptions JsonOpts = new JsonSerializerOptions
	{
		PropertyNameCaseInsensitive = true
	};

	public const string UnrealEditorExeName = "UnrealEditorFortnite-Win64-Shipping.exe";

	private static readonly string[] Win64RelativePaths = new string[2] { "FortniteGame\\Binaries\\Win64", "Engine\\Binaries\\Win64" };

	public static string FindFortnitePaksFolder()
	{
		foreach (string item in EnumerateDatPaths())
		{
			if (!File.Exists(item))
			{
				continue;
			}
			try
			{
				string text = ReadFortniteInstallDir(item);
				if (text != null)
				{
					string text2 = FindPaksDir(text);
					if (text2 != null)
					{
						return text2;
					}
				}
			}
			catch (Exception ex)
			{
				Console.Error.WriteLine("Could not read " + item + ": " + ex.Message);
			}
		}
		throw new DirectoryNotFoundException("Fortnite paks folder not found.\n  Please check <drive>:\\ProgramData\\Epic\\UnrealEngineLauncher\\LauncherInstalled.dat.");
	}

	private static IEnumerable<string> EnumerateDatPaths()
	{
		foreach (DriveInfo item in from d in DriveInfo.GetDrives()
			where d.DriveType == DriveType.Fixed
			select d)
		{
			yield return Path.Combine(item.RootDirectory.FullName.TrimEnd('\\'), "ProgramData\\Epic\\UnrealEngineLauncher\\LauncherInstalled.dat");
		}
	}

	private static string? ReadFortniteInstallDir(string datPath)
	{
		return JsonSerializer.Deserialize<LauncherInstalled>(File.ReadAllText(datPath), JsonOpts)?.InstallationList?.FirstOrDefault((InstallationEntry e) => string.Equals(e.AppName, "Fortnite", StringComparison.OrdinalIgnoreCase) || string.Equals(e.AppName, "Fortnite_Studio", StringComparison.OrdinalIgnoreCase))?.InstallLocation;
	}

	private static string? FindPaksDir(string installDir)
	{
		string[] paksRelativePaths = PaksRelativePaths;
		foreach (string path in paksRelativePaths)
		{
			string text = Path.Combine(installDir, path);
			if (Directory.Exists(text))
			{
				return text;
			}
		}
		return null;
	}

	public static IEnumerable<string> EnumerateInstallDirs()
	{
		foreach (string item in EnumerateDatPaths())
		{
			if (File.Exists(item))
			{
				string text = null;
				try
				{
					text = ReadFortniteInstallDir(item);
				}
				catch
				{
				}
				if (!string.IsNullOrEmpty(text) && Directory.Exists(text))
				{
					yield return text;
				}
			}
		}
	}

	public static string? FindUnrealEditorExe()
	{
		foreach (string item in EnumerateInstallDirs())
		{
			string[] win64RelativePaths = Win64RelativePaths;
			foreach (string path in win64RelativePaths)
			{
				string text = Path.Combine(item, path, "UnrealEditorFortnite-Win64-Shipping.exe");
				if (File.Exists(text))
				{
					return text;
				}
			}
			string text2 = SafeFindFile(item, "UnrealEditorFortnite-Win64-Shipping.exe");
			if (text2 != null)
			{
				return text2;
			}
		}
		return null;
	}

	private static string? SafeFindFile(string root, string fileName)
	{
		try
		{
			using IEnumerator<string> enumerator = Directory.EnumerateFiles(root, fileName, SearchOption.AllDirectories).GetEnumerator();
			if (enumerator.MoveNext())
			{
				return enumerator.Current;
			}
		}
		catch
		{
		}
		return null;
	}
}
