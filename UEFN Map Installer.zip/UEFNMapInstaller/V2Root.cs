using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class V2Root
{
	[JsonPropertyName("moduleId")]
	public string? ModuleId { get; set; }

	[JsonPropertyName("version")]
	public object? Version { get; set; }
}
