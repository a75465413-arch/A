using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class LauncherInstalled
{
	[JsonPropertyName("InstallationList")]
	public List<InstallationEntry>? InstallationList { get; set; }
}
