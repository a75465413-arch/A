using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace UEFNMapInstaller;

internal sealed class EpicAuthService
{
	private readonly string _dataDir;

	private readonly JsonSerializerOptions _jsonOpts = new JsonSerializerOptions
	{
		WriteIndented = true
	};

	private string DeviceAuthPath => Path.Combine(_dataDir, "device_auth.json");

	public EpicAuthService(string dataDir)
	{
		_dataDir = dataDir;
		Directory.CreateDirectory(dataDir);
	}

	public async Task<string> GetContentAccessTokenAsync(CancellationToken ct = default(CancellationToken))
	{
		DeviceAuthRecord deviceAuthRecord = LoadDeviceAuth();
		if (deviceAuthRecord == null)
		{
			Console.WriteLine("Device credentials not found. Starting first-time login.");
			deviceAuthRecord = await DeviceCodeLoginAsync(ct);
		}
		try
		{
			return await ExchangeToContentTokenAsync(deviceAuthRecord, ct);
		}
		catch (EpicApiException ex)
		{
			Console.WriteLine("Token refresh failed: " + ex.Message);
			Console.WriteLine("Re-login started...");
			return await ExchangeToContentTokenAsync(await DeviceCodeLoginAsync(ct), ct);
		}
	}

	private async Task<DeviceAuthRecord> DeviceCodeLoginAsync(CancellationToken ct)
	{
		TokenResponse tokenResponse = await EpicHttp.FormRequestAsync<TokenResponse>("https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token", new Dictionary<string, string> { ["grant_type"] = "client_credentials" }, "NzlhOTMxYjM3NTMzNDU3MGFjMzY5MjM0ZjVkYTA1ZWM6ZWU3MzM1ZGYzYzRhNDEyY2I1NzA1NWFiN2FkZTY5M2U=", ct);
		if (string.IsNullOrEmpty(tokenResponse.AccessToken))
		{
			throw new EpicApiException("client_credentials returned no access token");
		}
		TokenResponse deviceResp = await EpicHttp.PostJsonAsync<TokenResponse>("https://account-public-service-prod.ol.epicgames.com/account/api/oauth/deviceAuthorization", new
		{
			prompt = "login"
		}, tokenResponse.AccessToken, ct);
		string text = deviceResp.VerificationUri ?? "https://www.epicgames.com/activate";
		Console.WriteLine();
		Console.ForegroundColor = ConsoleColor.Yellow;
		Console.WriteLine("======================================================");
		Console.WriteLine(" Epic account authentication required");
		Console.WriteLine("======================================================");
		Console.ResetColor();
		Console.WriteLine(" Open the URL below in your browser and log in:\n");
		Console.ForegroundColor = ConsoleColor.Cyan;
		Console.WriteLine("  " + text);
		Console.ResetColor();
		Console.WriteLine("\n After logging in, this window will continue automatically...");
		Console.WriteLine();
		if (string.IsNullOrEmpty(deviceResp.DeviceCode))
		{
			throw new EpicApiException("Failed to obtain device_code");
		}
		int num = ((deviceResp.ExpiresIn > 0) ? deviceResp.ExpiresIn : 300);
		int interval = ((deviceResp.Interval > 0) ? deviceResp.Interval : 5);
		DateTime deadline = DateTime.UtcNow.AddSeconds(num);
		TokenResponse userToken = null;
		while (DateTime.UtcNow < deadline)
		{
			await Task.Delay(TimeSpan.FromSeconds(interval), ct);
			try
			{
				userToken = await EpicHttp.FormRequestAsync<TokenResponse>("https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token", new Dictionary<string, string>
				{
					["grant_type"] = "device_code",
					["device_code"] = deviceResp.DeviceCode
				}, "NzlhOTMxYjM3NTMzNDU3MGFjMzY5MjM0ZjVkYTA1ZWM6ZWU3MzM1ZGYzYzRhNDEyY2I1NzA1NWFiN2FkZTY5M2U=", ct);
			}
			catch (EpicApiException ex) when (ex.Message.Contains("authorization_pending") || ex.Message.Contains("slow_down"))
			{
				Console.Write(".");
				continue;
			}
			break;
		}
		if (userToken == null || string.IsNullOrEmpty(userToken.AccessToken))
		{
			throw new EpicApiException("Device-code login timed out");
		}
		Console.WriteLine();
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("Login successful: " + (userToken.DisplayName ?? userToken.AccountId));
		Console.ResetColor();
		string value = await GetExchangeCodeAsync(userToken.AccessToken, ct);
		TokenResponse tokenResponse2 = await EpicHttp.FormRequestAsync<TokenResponse>("https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token", new Dictionary<string, string>
		{
			["grant_type"] = "exchange_code",
			["exchange_code"] = value
		}, EpicEndpoints.AndroidBasic, ct);
		if (string.IsNullOrEmpty(tokenResponse2.AccessToken) || string.IsNullOrEmpty(userToken.AccountId))
		{
			throw new EpicApiException("Failed to obtain Android exchange token");
		}
		DeviceAuthCreatedRecord deviceAuthCreatedRecord = await EpicHttp.PostJsonAsync<DeviceAuthCreatedRecord>("https://account-public-service-prod.ol.epicgames.com/account/api/public/account/" + Uri.EscapeDataString(userToken.AccountId) + "/deviceAuth", new { }, tokenResponse2.AccessToken, ct);
		if (string.IsNullOrEmpty(deviceAuthCreatedRecord.DeviceId) || string.IsNullOrEmpty(deviceAuthCreatedRecord.Secret))
		{
			throw new EpicApiException("Failed to create deviceAuth");
		}
		DeviceAuthRecord deviceAuthRecord = new DeviceAuthRecord
		{
			AccountId = userToken.AccountId,
			DeviceId = deviceAuthCreatedRecord.DeviceId,
			Secret = deviceAuthCreatedRecord.Secret,
			DisplayName = (userToken.DisplayName ?? userToken.AccountId)
		};
		SaveDeviceAuth(deviceAuthRecord);
		Console.WriteLine("Device credentials saved: " + DeviceAuthPath);
		return deviceAuthRecord;
	}

	private async Task<string> ExchangeToContentTokenAsync(DeviceAuthRecord record, CancellationToken ct)
	{
		TokenResponse tokenResponse = await EpicHttp.FormRequestAsync<TokenResponse>("https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token", new Dictionary<string, string>
		{
			["grant_type"] = "device_auth",
			["account_id"] = record.AccountId,
			["device_id"] = record.DeviceId,
			["secret"] = record.Secret,
			["token_type"] = "eg1"
		}, EpicEndpoints.AndroidBasic, ct);
		if (string.IsNullOrEmpty(tokenResponse.AccessToken))
		{
			throw new EpicApiException("device_auth token response contains no access token");
		}
		string value = await GetExchangeCodeAsync(tokenResponse.AccessToken, ct);
		TokenResponse tokenResponse2 = await EpicHttp.FormRequestAsync<TokenResponse>("https://account-public-service-prod.ol.epicgames.com/account/api/oauth/token", new Dictionary<string, string>
		{
			["grant_type"] = "exchange_code",
			["exchange_code"] = value
		}, "M2UxM2M1YzU3ZjU5NGE1NzhhYmU1MTZlZWNiNjczZmU6NTMwZTMxNmMzMzdlNDA5ODkzYzU1ZWM0NGYyMmNkNjI=", ct);
		if (string.IsNullOrEmpty(tokenResponse2.AccessToken))
		{
			throw new EpicApiException("Failed to obtain Content Service token");
		}
		return tokenResponse2.AccessToken;
	}

	private async Task<string> GetExchangeCodeAsync(string accessToken, CancellationToken ct)
	{
		TokenResponse tokenResponse = await EpicHttp.GetJsonAsync<TokenResponse>("https://account-public-service-prod.ol.epicgames.com/account/api/oauth/exchange", accessToken, ct);
		if (string.IsNullOrEmpty(tokenResponse.Code))
		{
			throw new EpicApiException("exchange response contains no code");
		}
		return tokenResponse.Code;
	}

	private DeviceAuthRecord? LoadDeviceAuth()
	{
		if (!File.Exists(DeviceAuthPath))
		{
			return null;
		}
		try
		{
			DeviceAuthRecord deviceAuthRecord = JsonSerializer.Deserialize<DeviceAuthRecord>(File.ReadAllText(DeviceAuthPath));
			if (deviceAuthRecord == null)
			{
				return null;
			}
			if (string.IsNullOrEmpty(deviceAuthRecord.AccountId) || string.IsNullOrEmpty(deviceAuthRecord.DeviceId) || string.IsNullOrEmpty(deviceAuthRecord.Secret))
			{
				return null;
			}
			return deviceAuthRecord;
		}
		catch
		{
			return null;
		}
	}

	private void SaveDeviceAuth(DeviceAuthRecord record)
	{
		Directory.CreateDirectory(_dataDir);
		File.WriteAllText(DeviceAuthPath, JsonSerializer.Serialize(record, _jsonOpts));
	}
}
