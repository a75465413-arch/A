using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class DillyMappings
{
	[JsonPropertyName("version")]
	public string? Version { get; set; }
}
