using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace UEFNMapInstaller;

internal static class IniEditor
{
	public static void SetValue(string path, string section, string key, string value, string? template = null)
	{
		List<string> list = (File.Exists(path) ? File.ReadAllLines(path).ToList() : (template ?? "").Replace("\r\n", "\n").Split('\n').ToList());
		SetValue(list, section, key, value);
		File.WriteAllText(path, string.Join("\r\n", list).TrimEnd(new char[2] { '\r', '\n' }) + "\r\n");
	}

	public static bool RemoveValue(string path, string section, string key, string? expectedValue = null)
	{
		if (!File.Exists(path))
		{
			return false;
		}

		List<string> lines = File.ReadAllLines(path).ToList();
		int sectionIndex = FindSectionIndex(lines, section);
		if (sectionIndex < 0)
		{
			return false;
		}

		int nextSectionIndex = NextSectionIndex(lines, sectionIndex + 1);
		for (int i = sectionIndex + 1; i < nextSectionIndex; i++)
		{
			string line = lines[i].TrimStart();
			if (line.StartsWith(';') || line.StartsWith('#'))
			{
				continue;
			}

			int equalsIndex = line.IndexOf('=');
			if (equalsIndex <= 0 ||
				!string.Equals(line.Substring(0, equalsIndex).Trim(), key, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}

			if (expectedValue != null &&
				!string.Equals(line.Substring(equalsIndex + 1).Trim(), expectedValue, StringComparison.Ordinal))
			{
				continue;
			}

			lines.RemoveAt(i);
			File.WriteAllText(path, string.Join("\r\n", lines).TrimEnd('\r', '\n') + "\r\n");
			return true;
		}

		return false;
	}

	public static void SetValue(List<string> lines, string section, string key, string value)
	{
		string text = key + "=" + value;
		int num = FindSectionIndex(lines, section);
		if (num < 0)
		{
			if (lines.Count > 0)
			{
				if (lines[lines.Count - 1].Trim().Length > 0)
				{
					lines.Add("");
				}
			}
			lines.Add("[" + section + "]");
			lines.Add(text);
			return;
		}
		int num2 = NextSectionIndex(lines, num + 1);
		for (int i = num + 1; i < num2; i++)
		{
			string text2 = lines[i].TrimStart();
			if (!text2.StartsWith(';') && !text2.StartsWith('#'))
			{
				int num3 = text2.IndexOf('=');
				if (num3 > 0 && string.Equals(text2.Substring(0, num3).Trim(), key, StringComparison.OrdinalIgnoreCase))
				{
					lines[i] = text;
					return;
				}
			}
		}
		int num4 = num2;
		while (num4 - 1 > num && lines[num4 - 1].Trim().Length == 0)
		{
			num4--;
		}
		lines.Insert(num4, text);
	}

	private static int FindSectionIndex(List<string> lines, string section)
	{
		for (int i = 0; i < lines.Count; i++)
		{
			if (TryGetSectionName(lines[i], out string name) && string.Equals(name, section, StringComparison.OrdinalIgnoreCase))
			{
				return i;
			}
		}
		return -1;
	}

	private static int NextSectionIndex(List<string> lines, int from)
	{
		for (int i = from; i < lines.Count; i++)
		{
			if (TryGetSectionName(lines[i], out string _))
			{
				return i;
			}
		}
		return lines.Count;
	}

	private static bool TryGetSectionName(string line, out string name)
	{
		string text = line.Trim();
		if (text.Length >= 2 && text[0] == '[')
		{
			if (text[text.Length - 1] == ']')
			{
				string text2 = text;
				name = text2.Substring(1, text2.Length - 1 - 1).Trim();
				return true;
			}
		}
		name = "";
		return false;
	}
}
