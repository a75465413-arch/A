using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class MnemonicResponse
{
	[JsonPropertyName("metadata")]
	public MnemonicMetadata? Metadata { get; set; }

	[JsonPropertyName("version")]
	public object? Version { get; set; }
}
