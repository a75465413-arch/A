using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class TokenResponse
{
	[JsonPropertyName("access_token")]
	public string? AccessToken { get; set; }

	[JsonPropertyName("refresh_token")]
	public string? RefreshToken { get; set; }

	[JsonPropertyName("expires_at")]
	public string? ExpiresAt { get; set; }

	[JsonPropertyName("account_id")]
	public string? AccountId { get; set; }

	[JsonPropertyName("displayName")]
	public string? DisplayName { get; set; }

	[JsonPropertyName("device_code")]
	public string? DeviceCode { get; set; }

	[JsonPropertyName("verification_uri_complete")]
	public string? VerificationUri { get; set; }

	[JsonPropertyName("expires_in")]
	public int ExpiresIn { get; set; }

	[JsonPropertyName("interval")]
	public int Interval { get; set; }

	[JsonPropertyName("code")]
	public string? Code { get; set; }
}
