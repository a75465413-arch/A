using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class V4Binaries
{
	[JsonPropertyName("baseUrl")]
	public string? BaseUrl { get; set; }

	[JsonPropertyName("totalSizeKb")]
	public double TotalSizeKb { get; set; }
}
