using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class V2Resolved
{
	[JsonPropertyName("root")]
	public V2Root? Root { get; set; }
}
