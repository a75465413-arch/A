using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class MnemonicMetadata
{
	[JsonPropertyName("title")]
	public string? Title { get; set; }

	[JsonPropertyName("projectId")]
	public string? ProjectId { get; set; }

	[JsonPropertyName("public_modules")]
	public List<object>? PublicModules { get; set; }
}
