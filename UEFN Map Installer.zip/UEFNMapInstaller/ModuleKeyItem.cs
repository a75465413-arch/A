using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class ModuleKeyItem
{
	[JsonPropertyName("key")]
	public ModuleKeyData? Key { get; set; }
}
