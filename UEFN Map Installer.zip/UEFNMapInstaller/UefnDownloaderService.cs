using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace UEFNMapInstaller;

internal sealed class UefnDownloaderService
{
	private static readonly JsonSerializerOptions _jsonOpts = new JsonSerializerOptions
	{
		PropertyNameCaseInsensitive = true
	};

	private readonly string _dataDir;

	public UefnDownloaderService(string dataDir)
	{
		_dataDir = dataDir;
	}

	public static string NormalizeMapCode(string raw)
	{
		string text = Regex.Replace(raw, "\\D", "");
		if (text.Length != 12)
		{
			throw new ArgumentException("Map code must be a 12-digit number");
		}
		return $"{text.Substring(0, 4)}-{text.Substring(4, 4)}-{text.Substring(8)}";
	}

	public static async Task<string> FetchProjectIdAsync(string mapCode, string outputDirectory, CancellationToken ct = default(CancellationToken))
	{
		string mnemonicPath = Path.Combine(outputDirectory, "mnemonic.json");
		if (File.Exists(mnemonicPath))
		{
			try
			{
				using JsonDocument cached = JsonDocument.Parse(await File.ReadAllTextAsync(mnemonicPath, ct));
				string cachedProjectId = ReadProjectId(cached.RootElement);
				if (!string.IsNullOrWhiteSpace(cachedProjectId))
				{
					return cachedProjectId;
				}
			}
			catch (JsonException)
			{
			}
		}

		string url = EpicEndpoints.DefaultMnemonicApi
			.Replace("{namespace}", "fn", StringComparison.Ordinal)
			.Replace("{map_code}", Uri.EscapeDataString(mapCode), StringComparison.Ordinal);
		JsonElement response = await EpicHttp.GetJsonAsync<JsonElement>(url, null, ct);
		string projectId = ReadProjectId(response);
		if (string.IsNullOrWhiteSpace(projectId))
		{
			throw new EpicApiException("The map metadata did not include a projectId.");
		}

		Directory.CreateDirectory(outputDirectory);
		await File.WriteAllTextAsync(mnemonicPath, response.GetRawText(), ct);
		return projectId;
	}

	private static string ReadProjectId(JsonElement response)
	{
		if (response.ValueKind == JsonValueKind.Array)
		{
			response = response.EnumerateArray().FirstOrDefault();
		}
		if (response.ValueKind != JsonValueKind.Object)
		{
			return string.Empty;
		}

		if (response.TryGetProperty("metadata", out JsonElement metadata) &&
			metadata.ValueKind == JsonValueKind.Object &&
			metadata.TryGetProperty("projectId", out JsonElement metadataProjectId) &&
			metadataProjectId.ValueKind == JsonValueKind.String)
		{
			return metadataProjectId.GetString() ?? string.Empty;
		}

		return response.TryGetProperty("projectId", out JsonElement projectId) && projectId.ValueKind == JsonValueKind.String
			? projectId.GetString() ?? string.Empty
			: string.Empty;
	}

	public async Task<(string AesKeyHex, string Guid)?> FetchAesKeyAsync(string mapCode, string token, string outputDir, CancellationToken ct = default(CancellationToken))
	{
		Console.WriteLine("[AES] Resolving v2 package...");
		var (value, value2, value3) = await GetLatestDillyVersionAsync(ct);
		Console.WriteLine($"[AES] Fortnite version: {value}.{value2}-CL-{value3}");
		string url = $"{"https://content-service.bfda.live.use1a.on.epicgames.com"}/api/content/v2/link/{Uri.EscapeDataString(mapCode)}/cooked-content-package?role=client&platform=windows&major={value}&minor={value2}&patch={value3}";
		V2PackageResponse v2PackageResponse;
		try
		{
			v2PackageResponse = await EpicHttp.GetJsonAsync<V2PackageResponse>(url, token, ct);
		}
		catch (EpicApiException ex)
		{
			if (ex.Message.Contains("unexpected_link_type"))
			{
				Console.WriteLine("[AES] This map has no encryption (v1.0 map)");
				return null;
			}
			Console.WriteLine("[AES] Failed to fetch v2 package: " + ex.Message);
			return null;
		}
		if (!v2PackageResponse.IsEncrypted)
		{
			Console.WriteLine("[AES] This map is not encrypted");
			return null;
		}
		string text = v2PackageResponse.Resolved?.Root?.ModuleId;
		object obj = v2PackageResponse.Resolved?.Root?.Version;
		if (string.IsNullOrEmpty(text) || obj == null)
		{
			Console.WriteLine("[AES] Could not obtain moduleId/moduleVersion");
			return null;
		}
		Console.WriteLine($"[AES] moduleId={text}, moduleVersion={obj}");
		var payload = new[]
		{
			new
			{
				moduleId = text,
				version = obj
			}
		};
		ModuleKeyData keyData = (await EpicHttp.PostJsonAsync<List<ModuleKeyItem>>("https://content-service.bfda.live.use1a.on.epicgames.com/api/content/v4/module/key/batch", payload, token, ct))?.FirstOrDefault()?.Key;
		if (keyData == null || string.IsNullOrEmpty(keyData.Key))
		{
			throw new EpicApiException("AES key batch response is empty");
		}
		string aesKeyHex = Convert.FromBase64String(keyData.Key).ToHexString().ToUpperInvariant();
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("[AES] AES key retrieved: 0x" + aesKeyHex);
		Console.WriteLine("[AES] GUID: " + keyData.Guid);
		Console.ResetColor();
		Directory.CreateDirectory(outputDir);
		await File.WriteAllTextAsync(Path.Combine(outputDir, "aes_key.txt"), $"AESKey=0x{aesKeyHex}\nGUID={keyData.Guid}\n", ct);
		return ("0x" + aesKeyHex, keyData.Guid ?? "");
	}

	public async Task<List<string>> DownloadMapFilesAsync(string mapCode, string token, string outputDir, CancellationToken ct = default(CancellationToken))
	{
		Console.WriteLine("[DL] Resolving v4 package...");
		string url = "https://api.fortnitejp.news/api/fortnite/discovery/mnemonic/{namespace}/{map_code}".Replace("{namespace}", "fn").Replace("{map_code}", mapCode);
		MnemonicResponse mnemonicResponse;
		try
		{
			JsonElement element = await EpicHttp.GetJsonAsync<JsonElement>(url, null, ct);
			mnemonicResponse = ((element.ValueKind == JsonValueKind.Array) ? element.EnumerateArray().First().Deserialize<MnemonicResponse>(_jsonOpts) : element.Deserialize<MnemonicResponse>(_jsonOpts));
		}
		catch (Exception ex)
		{
			Console.WriteLine("[DL] mnemonic fetch error (continuing): " + ex.Message);
			mnemonicResponse = new MnemonicResponse();
		}
		string version = mnemonicResponse.Version?.ToString();
		string text = BuildV4PackageUrl(mapCode, version);
		Console.WriteLine("[DL] v4 package URL: " + text);
		V4PackageResponse v4PackageResponse = await EpicHttp.GetJsonAsync<V4PackageResponse>(text, token, ct);
		if (v4PackageResponse.Content == null || v4PackageResponse.Content.Count == 0)
		{
			throw new EpicApiException("v4 package has no content (status=" + v4PackageResponse.Status + ")");
		}
		V4ContentItem v4ContentItem = v4PackageResponse.Content.Where((V4ContentItem i) => !string.IsNullOrEmpty(i.Binaries?.BaseUrl)).MaxBy((V4ContentItem i) => i.Binaries?.TotalSizeKb ?? 0.0) ?? throw new EpicApiException("No downloadable binaries found");
		string baseUrl = v4ContentItem.Binaries.BaseUrl;
		Console.WriteLine("[DL] baseUrl=" + baseUrl);
		Directory.CreateDirectory(outputDir);
		string url2 = baseUrl.TrimEnd('/') + "/alt/plugin.manifest";
		string manifestPath = Path.Combine(outputDir, "plugin.manifest");
		Console.WriteLine("[DL] Downloading plugin.manifest...");
		await EpicHttp.DownloadFileAsync(url2, manifestPath, null, null, ct);
		Console.WriteLine("[DL] plugin.manifest download complete");
		Console.WriteLine("[DL] Reconstructing files from BPS chunks...");
		List<string> list = await BpsDownloader.ReconstructFilesAsync(manifestPath, baseUrl, outputDir, "alt", ct);
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine($"[DL] {list.Count} file(s) downloaded:");
		foreach (string item in list)
		{
			Console.WriteLine("  " + Path.GetFileName(item));
		}
		Console.ResetColor();
		return list;
	}

	private static string BuildV4PackageUrl(string mapCode, string? version)
	{
		string text = "platform=Windows&role=client";
		if (version != null)
		{
			text = text + "&version=" + Uri.EscapeDataString(version);
		}
		return $"{"https://content-service.bfda.live.use1a.on.epicgames.com"}/api/content/v4/link/{Uri.EscapeDataString(mapCode)}/cooked-content-package?{text}";
	}

	private static async Task<(string major, string minor, string patch)> GetLatestDillyVersionAsync(CancellationToken ct)
	{
		DillyMappings dillyMappings = await EpicHttp.GetJsonAsync<DillyMappings>("https://export-service-new.dillyapis.com/v1/mappings", null, ct);
		if (string.IsNullOrEmpty(dillyMappings.Version))
		{
			throw new EpicApiException("Dilly mappings contain no version info");
		}
		Match match = Regex.Match(dillyMappings.Version, "Release-(\\d+)\\.(\\d+)-CL-(\\d+)");
		if (!match.Success)
		{
			throw new EpicApiException("Failed to parse version string: " + dillyMappings.Version);
		}
		return (major: match.Groups[1].Value, minor: match.Groups[2].Value, patch: match.Groups[3].Value);
	}
}
