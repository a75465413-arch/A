using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class V4PackageResponse
{
	[JsonPropertyName("content")]
	public List<V4ContentItem>? Content { get; set; }

	[JsonPropertyName("status")]
	public string? Status { get; set; }
}
