using System;

namespace UEFNMapInstaller;

internal sealed class InstallationProgress
{
	private int _percentage = -1;
	private string _stage = string.Empty;
	private bool _lineOpen;

	public void Report(int percentage, string stage)
	{
		percentage = Math.Clamp(percentage, 0, 100);
		if (percentage < _percentage || (percentage == _percentage && string.Equals(stage, _stage, StringComparison.Ordinal)))
		{
			return;
		}

		_percentage = percentage;
		_stage = stage;
		ConsoleLog.WriteProgress($"\rProgress: {percentage,3}% - {stage}", percentage == 100);
		_lineOpen = true;
		if (percentage == 100)
		{
			Console.WriteLine();
			_lineOpen = false;
		}
	}

	public void CompleteLine()
	{
		if (_lineOpen)
		{
			Console.WriteLine();
			_lineOpen = false;
		}
	}
}
