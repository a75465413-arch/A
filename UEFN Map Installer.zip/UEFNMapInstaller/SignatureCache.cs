using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class SignatureCache
{
	[JsonPropertyName("gameVersion")]
	public string? GameVersion { get; set; }

	[JsonPropertyName("signature")]
	public string? Signature { get; set; }

	[JsonPropertyName("functionRva")]
	public string? FunctionRva { get; set; }

	[JsonPropertyName("updatedAtUtc")]
	public string? UpdatedAtUtc { get; set; }
}
