using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace UEFNMapInstaller;

internal static class EpicHttp
{
	private static readonly HttpClient _http = new HttpClient(new HttpClientHandler
	{
		AllowAutoRedirect = true,
		MaxAutomaticRedirections = 5
	})
	{
		Timeout = TimeSpan.FromSeconds(60L),
		DefaultRequestHeaders = 
		{
			UserAgent = { ProductInfoHeaderValue.Parse("uefn-installer/1.0") }
		}
	};

	private static readonly JsonSerializerOptions _json = new JsonSerializerOptions
	{
		PropertyNameCaseInsensitive = true,
		DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
	};

	public static async Task<T> FormRequestAsync<T>(string url, Dictionary<string, string> form, string basicValue, CancellationToken ct = default(CancellationToken))
	{
		using HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Post, url);
		req.Headers.Authorization = new AuthenticationHeaderValue("Basic", basicValue);
		req.Content = new FormUrlEncodedContent(form);
		using HttpResponseMessage resp = await _http.SendAsync(req, ct);
		string text = await resp.Content.ReadAsStringAsync(ct);
		if (!resp.IsSuccessStatusCode)
		{
			throw new EpicApiException($"HTTP {(int)resp.StatusCode} from {url}: {text}");
		}
		T val = JsonSerializer.Deserialize<T>(text, _json);
		if (val == null)
		{
			throw new EpicApiException("Empty response from " + url);
		}
		return val;
	}

	public static async Task<T> GetJsonAsync<T>(string url, string? bearerToken = null, CancellationToken ct = default(CancellationToken))
	{
		using HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, url);
		if (bearerToken != null)
		{
			req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
		}
		using HttpResponseMessage resp = await _http.SendAsync(req, ct);
		string text = await resp.Content.ReadAsStringAsync(ct);
		if (!resp.IsSuccessStatusCode)
		{
			throw new EpicApiException($"HTTP {(int)resp.StatusCode} from {url}: {text}");
		}
		T val = JsonSerializer.Deserialize<T>(text, _json);
		if (val == null)
		{
			throw new EpicApiException("Empty response from " + url);
		}
		return val;
	}

	public static async Task<T> PostJsonAsync<T>(string url, object payload, string bearerToken, CancellationToken ct = default(CancellationToken))
	{
		string content = JsonSerializer.Serialize(payload, _json);
		using HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Post, url)
		{
			Content = new StringContent(content, Encoding.UTF8, "application/json")
		};
		req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
		using HttpResponseMessage resp = await _http.SendAsync(req, ct);
		string text = await resp.Content.ReadAsStringAsync(ct);
		if (!resp.IsSuccessStatusCode)
		{
			throw new EpicApiException($"HTTP {(int)resp.StatusCode} from {url}: {text}");
		}
		T val = JsonSerializer.Deserialize<T>(text, _json);
		if (val == null)
		{
			throw new EpicApiException("Empty response from " + url);
		}
		return val;
	}

	public static async Task DownloadFileAsync(string url, string outputPath, string? bearerToken = null, IProgress<long>? progress = null, CancellationToken ct = default(CancellationToken))
	{
		using HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, url);
		req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/octet-stream"));
		if (bearerToken != null)
		{
			req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", bearerToken);
		}
		using HttpResponseMessage resp = await _http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
		if (!resp.IsSuccessStatusCode)
		{
			string value = await resp.Content.ReadAsStringAsync(ct);
			throw new EpicApiException($"HTTP {(int)resp.StatusCode} from {url}: {value}");
		}
		Directory.CreateDirectory(Path.GetDirectoryName(outputPath));
		_ = resp.Content.Headers.ContentLength ?? (-1);
		await using Stream src = await resp.Content.ReadAsStreamAsync(ct);
		await using FileStream dst = File.Create(outputPath);
		byte[] buf = new byte[262144];
		long downloaded = 0L;
		while (true)
		{
			int num;
			int read = (num = await src.ReadAsync(buf, ct));
			if (num <= 0)
			{
				break;
			}
			await dst.WriteAsync(buf.AsMemory(0, read), ct);
			downloaded += read;
			progress?.Report(downloaded);
		}
	}
}
