using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class DeviceAuthCreatedRecord
{
	[JsonPropertyName("deviceId")]
	public string? DeviceId { get; set; }

	[JsonPropertyName("secret")]
	public string? Secret { get; set; }
}
