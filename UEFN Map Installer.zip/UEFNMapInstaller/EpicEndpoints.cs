using System;
using System.Text;

namespace UEFNMapInstaller;

internal static class EpicEndpoints
{
	public const string AccountBase = "https://account-public-service-prod.ol.epicgames.com";

	public const string ContentServiceBase = "https://content-service.bfda.live.use1a.on.epicgames.com";

	public const string DefaultMnemonicApi = "https://api.fortnitejp.news/api/fortnite/discovery/mnemonic/{namespace}/{map_code}";

	public const string ModuleKeyBatchUrl = "https://content-service.bfda.live.use1a.on.epicgames.com/api/content/v4/module/key/batch";

	public const string DillyMappingsUrl = "https://export-service-new.dillyapis.com/v1/mappings";

	public const string JsDeviceAuthBasic = "NzlhOTMxYjM3NTMzNDU3MGFjMzY5MjM0ZjVkYTA1ZWM6ZWU3MzM1ZGYzYzRhNDEyY2I1NzA1NWFiN2FkZTY5M2U=";

	public const string JsContentExchangeBasic = "M2UxM2M1YzU3ZjU5NGE1NzhhYmU1MTZlZWNiNjczZmU6NTMwZTMxNmMzMzdlNDA5ODkzYzU1ZWM0NGYyMmNkNjI=";

	public const string AndroidClientId = "3f69e56c7649492c8cc29f1af08a8a12";

	public const string AndroidClientSecret = "b51ee9cb12234f50a69efa67ef53812e";

	public static string AndroidBasic => Convert.ToBase64String(Encoding.UTF8.GetBytes("3f69e56c7649492c8cc29f1af08a8a12:b51ee9cb12234f50a69efa67ef53812e"));
}
