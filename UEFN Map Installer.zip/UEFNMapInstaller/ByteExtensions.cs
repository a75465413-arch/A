using System;

namespace UEFNMapInstaller;

internal static class ByteExtensions
{
	public static string ToHexString(this byte[] bytes)
	{
		return BitConverter.ToString(bytes).Replace("-", "");
	}
}
