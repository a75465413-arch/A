using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class InstallationEntry
{
	[JsonPropertyName("InstallLocation")]
	public string? InstallLocation { get; set; }

	[JsonPropertyName("AppName")]
	public string? AppName { get; set; }
}
