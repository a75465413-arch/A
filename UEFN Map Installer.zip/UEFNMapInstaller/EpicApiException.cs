using System;

namespace UEFNMapInstaller;

internal sealed class EpicApiException : Exception
{
	public EpicApiException(string message)
		: base(message)
	{
	}
}
