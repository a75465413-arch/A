using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace UEFNMapInstaller;

internal static class DecrypterSettingsCommand
{
	private const string IniFileName = "DecrypterSettings.ini";

	private const string IniTemplate = "[Settings]\r\nModuleName=unrealeditorfortnite-engine-win64-shipping.dll\r\nSignature=??\r\nTimeout=10000\r\n\r\n[ContentKeys]\r\n";

	private static readonly Regex KeychainPattern = new Regex("^[0-9A-Fa-f]{32}:[A-Za-z0-9+/]+={0,2}$", RegexOptions.Compiled);

	private const string SignatureCacheFileName = "signature_cache.json";

	public static int Run(string exeDir)
	{
		Console.WriteLine();
		Console.WriteLine("== Updating DecrypterSettings.ini ==");
		string text = FortnitePathLocator.FindUnrealEditorExe();
		if (text == null)
		{
			Error("UnrealEditorFortnite-Win64-Shipping.exe was not found.");
			Error("Please verify that UEFN (Fortnite) is installed.");
			Pause();
			return 1;
		}
		string directoryName = Path.GetDirectoryName(text);
		string text2 = Path.Combine(directoryName, "DecrypterSettings.ini");
		ConsoleLog.WriteLine("[INI] Output: " + text2, ConsoleColor.Cyan);
		var (keychain, moduleId) = ResolveKeychain(exeDir);
		string item = ResolveSignature(exeDir, directoryName).Signature;
		if (keychain == null && item == null)
		{
			Warn("Neither a ModuleID key nor Signature has an update target. Exiting.");
			Pause();
			return 1;
		}
		try
		{
			if (keychain != null && moduleId != null)
			{
				IniEditor.SetValue(text2, "ContentKeys", moduleId, keychain, IniTemplate);
				IniEditor.RemoveValue(text2, "ContentKeys", "Key0");
				ConsoleLog.WriteLine("[INI] " + moduleId + " = " + keychain, ConsoleColor.Green);
			}
			if (item != null)
			{
				IniEditor.SetValue(text2, "Settings", "Signature", item, IniTemplate);
				ConsoleLog.WriteLine("[INI] Signature = " + item, ConsoleColor.Green);
			}
		}
		catch (UnauthorizedAccessException)
		{
			Error(text2 + ": write access denied.");
			Error("Please run as administrator or check write permissions.");
			Pause();
			return 1;
		}
		catch (Exception ex2)
		{
			Error("Failed to update ini: " + ex2.Message);
			Pause();
			return 1;
		}
		ConsoleLog.WriteLine("DecrypterSettings.ini updated: " + text2, ConsoleColor.Green);
		Pause();
		return 0;
	}

	private static (string? Keychain, string? ModuleId) ResolveKeychain(string exeDir)
	{
		Console.WriteLine();
		Console.Write("Enter map code or key chain (GUID:base64) for ModuleID\n  (press Enter to skip ContentKeys): ");
		string text = Console.ReadLine()?.Trim() ?? "";
		if (text.Length == 0)
		{
			return (Keychain: null, ModuleId: null);
		}
		if (text.StartsWith("KeyChain:", StringComparison.OrdinalIgnoreCase))
		{
			text = text.Substring("KeyChain:".Length).Trim();
		}
		if (KeychainPattern.IsMatch(text))
		{
			Console.Write("Enter the ModuleID for this key chain: ");
			string moduleId = Console.ReadLine()?.Trim() ?? "";
			if (!Guid.TryParse(moduleId, out _))
			{
				Warn("A valid ModuleID GUID is required. Skipping ContentKeys.");
				return (Keychain: null, ModuleId: null);
			}
			return (Keychain: text, ModuleId: moduleId);
		}
		string mapCode;
		try
		{
			mapCode = UefnDownloaderService.NormalizeMapCode(text);
		}
		catch
		{
			Warn("Input is neither a map code (12 digits) nor a key chain (GUID:base64). Skipping ContentKeys.");
			return (Keychain: null, ModuleId: null);
		}
		return FetchKeychainByMapCode(exeDir, mapCode);
	}

	private static (string? Keychain, string? ModuleId) FetchKeychainByMapCode(string exeDir, string mapCode)
	{
		string text = Path.Combine(exeDir, "uefn_downloader.py");
		if (!File.Exists(text))
		{
			Warn("uefn_downloader.py not found; skipping key chain fetch: " + text);
			return (Keychain: null, ModuleId: null);
		}
		Dictionary<string, string> env = new Dictionary<string, string> { ["UEFN_QUIET"] = "1" };
		string text2 = Path.Combine(exeDir, "Data");
		string text3 = Path.Combine(text2, "auth");
		Directory.CreateDirectory(text3);
		if (!File.Exists(Path.Combine(text3, "device_auth.json")))
		{
			int num = PythonRunner.Run(text, new string[3] { "device-login", "--data-dir", text3 }, exeDir, env);
			if (num != 0)
			{
				Warn($"Login failed (exit code {num}). Skipping ContentKeys.");
				return (Keychain: null, ModuleId: null);
			}
		}
		if (PythonRunner.Run(text, new string[6] { "resolve-v2", mapCode, "--data-dir", text3, "--out", text2 }, exeDir, env) != 0)
		{
			Warn("Failed to fetch AES key (unencrypted map etc.). Skipping ContentKeys.");
			return (Keychain: null, ModuleId: null);
		}
		string text4 = Path.Combine(text2, mapCode, "module_key_v4.json");
		if (!File.Exists(text4))
		{
			Warn("module_key_v4.json not found: " + text4 + ". Skipping ContentKeys.");
			return (Keychain: null, ModuleId: null);
		}
		try
		{
			return BuildKeychainFromModuleKeyJson(text4);
		}
		catch (Exception ex)
		{
			Warn("Failed to build key chain: " + ex.Message + ". Skipping ContentKeys.");
			return (Keychain: null, ModuleId: null);
		}
	}

	private static (string? Keychain, string? ModuleId) BuildKeychainFromModuleKeyJson(string jsonPath)
	{
		using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(jsonPath));
		JsonElement rootElement = jsonDocument.RootElement;
		string? moduleId = rootElement.TryGetProperty("moduleId", out var moduleIdElement) ? moduleIdElement.GetString() : null;
		if (!Guid.TryParse(moduleId, out _))
		{
			throw new InvalidDataException("Missing or invalid moduleId field");
		}
		string? obj = (rootElement.TryGetProperty("guid", out var value) ? value.GetString() : null);
		if (string.IsNullOrEmpty(obj))
		{
			throw new InvalidDataException("Missing guid field");
		}
		string text = null;
		if (rootElement.TryGetProperty("raw", out var value2) && value2.TryGetProperty("key", out var value3) && value3.TryGetProperty("Key", out var value4))
		{
			text = value4.GetString();
		}
		if (string.IsNullOrEmpty(text))
		{
			string? obj2 = (rootElement.TryGetProperty("aesKeyHex", out var value5) ? value5.GetString() : null);
			if (string.IsNullOrEmpty(obj2))
			{
				throw new InvalidDataException("Neither aesKeyHex nor raw.key.Key is present");
			}
			text = Convert.ToBase64String(HexToBytes(obj2));
		}
		return (Keychain: obj.Replace("-", "").ToUpperInvariant() + ":" + text, ModuleId: moduleId);
	}

	private static byte[] HexToBytes(string hex)
	{
		if (hex.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
		{
			hex = hex.Substring(2);
		}
		if (hex.Length % 2 != 0)
		{
			throw new FormatException("Hex string has invalid length");
		}
		byte[] array = new byte[hex.Length / 2];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);
		}
		return array;
	}

	private static (string? Signature, string? FunctionRva) ResolveSignature(string exeDir, string win64Dir)
	{
		Console.WriteLine();
		Console.Write("Auto-fetch Signature? [Y/n]: ");
		if (string.Equals(Console.ReadLine()?.Trim(), "n", StringComparison.OrdinalIgnoreCase))
		{
			return (Signature: null, FunctionRva: null);
		}
		string text = Path.Combine(exeDir, "uefn_downloader.py");
		if (!File.Exists(text))
		{
			Warn("uefn_downloader.py not found: " + text + ". Skipping Signature.");
			return (Signature: null, FunctionRva: null);
		}
		string text2 = Path.Combine(win64Dir, "UnrealEditorFortnite-Engine-Win64-Shipping.dll");
		if (!File.Exists(text2))
		{
			Warn("DLL not found: " + text2 + ". Skipping Signature.");
			return (Signature: null, FunctionRva: null);
		}
		string text3 = Path.Combine(exeDir, "Data");
		Directory.CreateDirectory(text3);
		string text4 = Path.Combine(text3, "signature_cache.json");
		SignatureCache signatureCache = LoadSignatureCache(text4);
		string text5 = FetchGameVersion(text, exeDir);
		if (text5 != null)
		{
			ConsoleLog.WriteLine("[SIG] Current game version: " + text5, ConsoleColor.Cyan);
		}
		else
		{
			Warn("Failed to get game version. Skipping version comparison and re-scanning DLL.");
		}
		if (text5 != null && signatureCache != null && string.Equals(signatureCache.GameVersion, text5, StringComparison.Ordinal) && !string.IsNullOrEmpty(signatureCache.Signature))
		{
			Console.ForegroundColor = ConsoleColor.Green;
			ConsoleLog.WriteLine("[SIG] Game version unchanged (" + text5 + ") -> Reusing cached Signature", ConsoleColor.Green);
			ConsoleLog.WriteLine("[SIG] Signature (cache): " + signatureCache.Signature, ConsoleColor.Green);
			Console.ResetColor();
			return (Signature: signatureCache.Signature, FunctionRva: signatureCache.FunctionRva);
		}
		(int exitCode, string stdout) tuple = PythonRunner.RunCaptureWithLiveStderr(text, new string[2] { "find-signature", text2 }, exeDir);
		int item = tuple.exitCode;
		string item2 = tuple.stdout;
		string text6 = null;
		string text7 = null;
		string[] array = item2.Split('\n');
		for (int i = 0; i < array.Length; i++)
		{
			string text8 = array[i].Trim();
			if (text8.StartsWith("Signature=", StringComparison.OrdinalIgnoreCase))
			{
				text6 = text8.Substring("Signature=".Length).Trim();
			}
			else if (text8.StartsWith("FunctionRVA=", StringComparison.OrdinalIgnoreCase))
			{
				text7 = text8.Substring("FunctionRVA=".Length).Trim();
			}
		}
		if (item == 0 && !string.IsNullOrEmpty(text6))
		{
			Console.ForegroundColor = ConsoleColor.Green;
			ConsoleLog.WriteLine("[SIG] Signature retrieved: " + text6, ConsoleColor.Green);
			Console.ResetColor();
			if (text5 != null)
			{
				SaveSignatureCache(text4, new SignatureCache
				{
					GameVersion = text5,
					Signature = text6,
					FunctionRva = text7,
					UpdatedAtUtc = DateTime.UtcNow.ToString("O")
				});
				ConsoleLog.WriteLine("[SIG] Cache updated: " + text4, ConsoleColor.Green);
			}
			return (Signature: text6, FunctionRva: text7);
		}
		Warn("Failed to retrieve Signature. Please set Signature in DecrypterSettings.ini manually.");
		return (Signature: null, FunctionRva: null);
	}

	private static string? FetchGameVersion(string scriptPath, string exeDir)
	{
		try
		{
			var (num, text, _) = PythonRunner.RunCapture(scriptPath, new string[1] { "game-version" }, exeDir);
			if (num != 0)
			{
				return null;
			}
			string text2 = text.Trim();
			return (text2.Length > 0) ? text2 : null;
		}
		catch
		{
			return null;
		}
	}

	private static SignatureCache? LoadSignatureCache(string cachePath)
	{
		if (!File.Exists(cachePath))
		{
			return null;
		}
		try
		{
			return JsonSerializer.Deserialize<SignatureCache>(File.ReadAllText(cachePath));
		}
		catch
		{
			return null;
		}
	}

	private static void SaveSignatureCache(string cachePath, SignatureCache cache)
	{
		try
		{
			string contents = JsonSerializer.Serialize(cache, new JsonSerializerOptions
			{
				WriteIndented = true
			});
			File.WriteAllText(cachePath, contents);
		}
		catch (Exception ex)
		{
			Warn("Failed to save signature cache: " + ex.Message);
		}
	}

	private static void Warn(string msg)
	{
		Console.ForegroundColor = ConsoleColor.Yellow;
		Console.WriteLine("[!!] " + msg);
		Console.ResetColor();
	}

	private static void Error(string msg)
	{
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine("[ERROR] " + msg);
		Console.ResetColor();
	}

	private static void Pause()
	{
		Console.WriteLine();
		Console.WriteLine("Press Enter to exit...");
		Console.ReadLine();
	}
}
