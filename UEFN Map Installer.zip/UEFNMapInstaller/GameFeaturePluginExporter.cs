using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using CUE4Parse.Encryption.Aes;
using CUE4Parse.FileProvider;
using CUE4Parse.FileProvider.Objects;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Versions;

namespace UEFNMapInstaller;

internal static class GameFeaturePluginExporter
{
	/// <summary>
	/// プラグインをエクスポートし、成功した場合は .uplugin のプラグイン名（NameWithoutExtension）を返す。
	/// 失敗時は null を返す。
	/// この名前が -enableplugins に渡すべき正しい名前になる。
	/// </summary>
	public static string? ExportPlugin(string sourceFolder, string moduleId, string aesKeyHex, string? pakGuid = null, string targetPaksFolder = "")
	{
		if (string.IsNullOrWhiteSpace(moduleId))
		{
			return null;
		}

		string basePaks = string.IsNullOrEmpty(targetPaksFolder) ? sourceFolder : targetPaksFolder;
		string text = Directory.GetParent(basePaks)?.FullName;
		string text2 = ((text == null) ? null : Directory.GetParent(text)?.FullName);
		if (text2 == null)
		{
			return null;
		}
		string text3 = Path.Combine(text2, "Plugins", "GameFeatures");
		Directory.CreateDirectory(text3);
		string text4 = Path.Combine(text3, moduleId);
		Directory.CreateDirectory(text4);

		FAesKey key;
		try
		{
			key = new FAesKey(aesKeyHex.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? aesKeyHex : ("0x" + aesKeyHex));
		}
		catch (Exception ex)
		{
			ConsoleLog.WriteError("Invalid AES key format: " + ex.Message);
			return null;
		}

		using DefaultFileProvider defaultFileProvider = new DefaultFileProvider(sourceFolder, SearchOption.AllDirectories, new VersionContainer(EGame.GAME_UE5_8));
		try
		{
			defaultFileProvider.Initialize();
			defaultFileProvider.SubmitKey(default, key);
			if (!string.IsNullOrWhiteSpace(pakGuid))
			{
				string text5 = pakGuid.Replace("-", "").Replace("{", "").Replace("}", "");
				if (text5.Length == 32)
				{
					FGuid guid = new FGuid(text5);
					defaultFileProvider.SubmitKey(guid, key);
				}
				else
				{
					ConsoleLog.WriteError("Invalid pak GUID; skipping its AES key.");
				}
			}
			defaultFileProvider.PostMount();
		}
		catch (Exception ex2)
		{
			ConsoleLog.WriteError("Failed to load game files: " + ex2.Message);
			return null;
		}

		var upluginFiles = defaultFileProvider.Files.Values
			.Where((GameFile f) => string.Equals(f.Extension, "uplugin", StringComparison.OrdinalIgnoreCase))
			.ToList();

		if (upluginFiles.Count == 0)
		{
			ConsoleLog.WriteError("No .uplugin file is visible in the mounted containers.");
			return null;
		}

		GameFile? gameFile = upluginFiles.FirstOrDefault(f =>
			f.Path.Contains(moduleId, StringComparison.OrdinalIgnoreCase) &&
			!f.Path.Contains("/Content/", StringComparison.OrdinalIgnoreCase) &&
			!f.Path.Contains("\\Content\\", StringComparison.OrdinalIgnoreCase));

		if (gameFile == null)
		{
			gameFile = upluginFiles.FirstOrDefault(f => f.Path.Contains(moduleId, StringComparison.OrdinalIgnoreCase));
		}

		if (gameFile == null)
		{
			ConsoleLog.WriteError($"No .uplugin matched ModuleID '{moduleId}'.");
			return null;
		}

		// .uplugin の NameWithoutExtension が UEFN が認識するプラグイン名
		string pluginName = gameFile.NameWithoutExtension;

		if (!defaultFileProvider.TrySaveAsset(gameFile, out byte[] data))
		{
			ConsoleLog.WriteError("Failed to extract the .uplugin descriptor.");
			return null;
		}

		try
		{
			JsonObject obj = JsonNode.Parse(Encoding.UTF8.GetString(data).TrimStart('\ufeff'))?.AsObject()
				?? throw new InvalidOperationException("Failed to parse uplugin JSON.");
			obj["EnabledByDefault"] = true;
			obj["CanContainVerse"] = false;
			string contents = obj.ToJsonString(new JsonSerializerOptions
			{
				WriteIndented = true
			});

			string descriptorPath = Path.Combine(text4, moduleId + ".uplugin");
			File.WriteAllText(descriptorPath, contents, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
		}
		catch (Exception ex3)
		{
			ConsoleLog.WriteError("Failed to edit the .uplugin descriptor: " + ex3.Message);
			return null;
		}

		var gfdFiles = defaultFileProvider.Files.Values
			.Where((GameFile f) => string.Equals(f.NameWithoutExtension, "GameFeatureData", StringComparison.OrdinalIgnoreCase) &&
									string.Equals(f.Extension, "uasset", StringComparison.OrdinalIgnoreCase))
			.ToList();

		if (gfdFiles.Count > 1)
		{
			ConsoleLog.WriteError($"Multiple GameFeatureData.uasset files found ({gfdFiles.Count}); aborting export.");
			return null;
		}

		GameFile? gfdFile = gfdFiles.FirstOrDefault();
		if (gfdFile != null)
		{
			string contentDir = Path.Combine(text4, "Content");
			Directory.CreateDirectory(contentDir);

			if (defaultFileProvider.TrySaveAsset(gfdFile, out byte[] gfdData))
			{
				string gfdPath = Path.Combine(contentDir, "GameFeatureData.uasset");
				File.WriteAllBytes(gfdPath, gfdData);

				string uexpPathInPak = Path.ChangeExtension(gfdFile.Path, "uexp");
				if (defaultFileProvider.Files.TryGetValue(uexpPathInPak, out GameFile uexpFile))
				{
					if (defaultFileProvider.TrySaveAsset(uexpFile, out byte[] uexpData))
					{
						string uexpOutPath = Path.Combine(contentDir, "GameFeatureData.uexp");
						File.WriteAllBytes(uexpOutPath, uexpData);
					}
				}
			}
			else
			{
				ConsoleLog.WriteError("Failed to save GameFeatureData.uasset data.");
			}
		}

		// .uplugin の NameWithoutExtension を返す（-enableplugins に使う名前）
		return pluginName;
	}

	public static (string? ModuleId, string? AesKeyHex, string? Guid) ReadModuleKeyJson(string jsonPath)
	{
		if (!File.Exists(jsonPath))
		{
			return (ModuleId: null, AesKeyHex: null, Guid: null);
		}
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(jsonPath));
			JsonElement rootElement = jsonDocument.RootElement;
			string? item = (rootElement.TryGetProperty("moduleId", out var value) ? value.GetString() : null);
			string item2 = (rootElement.TryGetProperty("aesKeyHex", out var value2) ? value2.GetString() : null);
			string item3 = (rootElement.TryGetProperty("guid", out var value3) ? value3.GetString() : null);
			return (ModuleId: item, AesKeyHex: item2, Guid: item3);
		}
		catch
		{
			return (ModuleId: null, AesKeyHex: null, Guid: null);
		}
	}
}
