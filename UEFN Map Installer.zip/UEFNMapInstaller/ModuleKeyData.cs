using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class ModuleKeyData
{
	[JsonPropertyName("Key")]
	public string? Key { get; set; }

	[JsonPropertyName("Guid")]
	public string? Guid { get; set; }
}
