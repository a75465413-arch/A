using System;

namespace UEFNMapInstaller;

internal static class ConsoleLog
{
	private static readonly object SyncRoot = new object();

	public static void WriteLine(string message, ConsoleColor color)
	{
		lock (SyncRoot)
		{
			Console.ForegroundColor = color;
			Console.WriteLine(message);
			Console.ResetColor();
		}
	}

	public static void WriteError(string message)
	{
		lock (SyncRoot)
		{
			Console.ForegroundColor = ConsoleColor.Red;
			Console.Error.WriteLine(message);
			Console.ResetColor();
		}
	}

	public static void WriteProgress(string message, bool complete)
	{
		lock (SyncRoot)
		{
			Console.ForegroundColor = complete ? ConsoleColor.Green : ConsoleColor.Cyan;
			Console.Write(message);
			Console.ResetColor();
		}
	}
}
