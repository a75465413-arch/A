using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace UEFNMapInstaller;

internal static class PythonRunner
{
	private static readonly Regex ProgressPercentage = new Regex(@"(?<percent>\d+(?:\.\d+)?)%", RegexOptions.Compiled);

	public static int Run(string scriptPath, string[] args, string workingDir, IDictionary<string, string>? env = null)
	{
		return RunInternal(scriptPath, args, workingDir, env ?? new Dictionary<string, string>(), captureProgress: false, _ => { });
	}

	public static int RunWithProgress(string scriptPath, string[] args, string workingDir, IDictionary<string, string> env, Action<double> progress)
	{
		return RunInternal(scriptPath, args, workingDir, env, captureProgress: true, progress);
	}

	private static int RunInternal(string scriptPath, string[] args, string workingDir, IDictionary<string, string> env, bool captureProgress, Action<double> progress)
	{
		string text = FindPython();
		if (text == null)
		{
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("[ERROR] Python not found.");
			Console.WriteLine("  Make sure python.exe or python3.exe is on your PATH.");
			Console.ResetColor();
			return -1;
		}
		List<string> list = new List<string> { "\"" + scriptPath + "\"" };
		list.AddRange(args.Select(QuoteArg));
		string arguments = string.Join(" ", list);
		ProcessStartInfo processStartInfo = new ProcessStartInfo
		{
			FileName = text,
			Arguments = arguments,
			WorkingDirectory = workingDir,
			UseShellExecute = false,
			RedirectStandardOutput = captureProgress,
			RedirectStandardError = true,
			CreateNoWindow = false
		};
		if (env != null)
		{
			foreach (var (key, value) in env)
			{
				processStartInfo.Environment[key] = value;
			}
		}
		using Process process = new Process
		{
			StartInfo = processStartInfo
		};
		if (captureProgress)
		{
			process.OutputDataReceived += (_, eventArgs) =>
			{
				if (eventArgs.Data == null)
				{
					return;
				}

				Match match = ProgressPercentage.Match(eventArgs.Data);
				if (match.Success && double.TryParse(match.Groups["percent"].Value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double percentage))
				{
					progress(Math.Clamp(percentage, 0, 100));
				}
			};
		}
		process.ErrorDataReceived += (_, eventArgs) =>
		{
			if (eventArgs.Data != null)
			{
				ConsoleLog.WriteError(eventArgs.Data);
			}
		};
		process.Start();
		if (captureProgress)
		{
			process.BeginOutputReadLine();
		}
		process.BeginErrorReadLine();
		process.WaitForExit();
		if (captureProgress)
		{
			process.WaitForExit();
		}
		process.WaitForExit();
		return process.ExitCode;
	}

	public static (int exitCode, string stdout, string stderr) RunCapture(string scriptPath, string[] args, string workingDir)
	{
		string fileName = FindPython() ?? throw new FileNotFoundException("Python not found");
		List<string> list = new List<string> { "\"" + scriptPath + "\"" };
		list.AddRange(args.Select(QuoteArg));
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = fileName,
			Arguments = string.Join(" ", list),
			WorkingDirectory = workingDir,
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			CreateNoWindow = true
		};
		using Process process = new Process
		{
			StartInfo = startInfo
		};
		process.Start();
		string item = process.StandardOutput.ReadToEnd();
		string item2 = process.StandardError.ReadToEnd();
		process.WaitForExit();
		return (exitCode: process.ExitCode, stdout: item, stderr: item2);
	}

	public static (int exitCode, string stdout) RunCaptureWithLiveStderr(string scriptPath, string[] args, string workingDir)
	{
		string fileName = FindPython() ?? throw new FileNotFoundException("Python not found");
		List<string> list = new List<string> { "\"" + scriptPath + "\"" };
		list.AddRange(args.Select(QuoteArg));
		ProcessStartInfo startInfo = new ProcessStartInfo
		{
			FileName = fileName,
			Arguments = string.Join(" ", list),
			WorkingDirectory = workingDir,
			UseShellExecute = false,
			RedirectStandardOutput = true,
			RedirectStandardError = true,
			CreateNoWindow = true
		};
		new StringBuilder();
		using Process process = new Process
		{
			StartInfo = startInfo
		};
		process.EnableRaisingEvents = true;
		process.ErrorDataReceived += (object _, DataReceivedEventArgs e) =>
		{
			if (e.Data != null)
			{
				ConsoleLog.WriteError(e.Data);
			}
		};
		process.Start();
		process.BeginErrorReadLine();
		Task<string> task = process.StandardOutput.ReadToEndAsync();
		process.WaitForExit();
		string result = task.GetAwaiter().GetResult();
		return (exitCode: process.ExitCode, stdout: result);
	}

	private static string? FindPython()
	{
		string[] array = new string[3] { "python", "python3", "py" };
		foreach (string text in array)
		{
			string text2 = FindInPath(text + ".exe") ?? FindInPath(text);
			if (text2 != null)
			{
				return text2;
			}
		}
		return null;
	}

	private static string? FindInPath(string exe)
	{
		string[] array = (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator);
		for (int i = 0; i < array.Length; i++)
		{
			string text = Path.Combine(array[i], exe);
			if (File.Exists(text))
			{
				return text;
			}
		}
		return null;
	}

	private static string QuoteArg(string arg)
	{
		if (!arg.Contains(' ') && !arg.Contains('"'))
		{
			return arg;
		}
		return "\"" + arg.Replace("\"", "\\\"") + "\"";
	}
}
