using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class AppSettings
{
    [JsonPropertyName("extraArgs")]
    public List<string> ExtraArgs { get; set; } = new();
    [JsonPropertyName("disabledPlugins")]
    public List<string> DisabledPlugins { get; set; } = new();
    [JsonPropertyName("enabledPlugins")]
    public List<string> EnabledPlugins { get; set; } = new();
    [JsonPropertyName("signature")]
    public string Signature { get; set; } = "";
    [JsonPropertyName("autoLaunchUefn")]
    public bool AutoLaunchUefn { get; set; } = true;

    private static readonly JsonSerializerOptions _opts = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public static AppSettings Load(string path)
    {
        if (!File.Exists(path))
            return new AppSettings();

        try
        {
            return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(path), _opts)
                   ?? new AppSettings();
        }
        catch
        {
            return new AppSettings();
        }
    }

    public void Save(string path)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, JsonSerializer.Serialize(this, _opts));
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("[!!] 設定の保存に失敗しました: " + ex.Message);
            Console.ResetColor();
        }
    }
    public IEnumerable<string> BuildArgTokens()
    {
        foreach (var arg in ExtraArgs)
        {
            if (!string.IsNullOrWhiteSpace(arg))
                yield return arg.Trim();
        }
    }
    public void RunSettingsMenu(string settingsPath)
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("╔══════════════════════════════════════════════╗");
            Console.WriteLine("║              Settings                        ║");
            Console.WriteLine("╠══════════════════════════════════════════════╣");
            Console.WriteLine("║  1  ExtraArgs                                ║");
            Console.WriteLine("║  2  disableplugins                           ║");
            Console.WriteLine("║  3  enableplugins                            ║");
            Console.WriteLine("║  4  Set Signature                            ║");
            Console.WriteLine("║  5  View current settings                    ║");
            Console.WriteLine("║  6  Auto-launch UEFN: " + (AutoLaunchUefn ? "ON " : "OFF") + "                    ║");
            Console.WriteLine("║  0  Back                                     ║");
            Console.WriteLine("╚══════════════════════════════════════════════╝");
            Console.Write("Select [0-6]: ");

            string input = Console.ReadLine()?.Trim() ?? "";

            switch (input)
            {
                case "1":
                    Console.Clear();
                    EditExtraArgs(settingsPath);
                    Pause();
                    break;
                case "2":
                    Console.Clear();
                    EditDisabledPlugins(settingsPath);
                    Pause();
                    break;
                case "3":
                    Console.Clear();
                    EditEnabledPlugins(settingsPath);
                    Pause();
                    break;
                case "4":
                    Console.Clear();
                    EditSignature(settingsPath);
                    Pause();
                    break;
                case "5":
                    Console.Clear();
                    ShowCurrentSettings();
                    Pause();
                    break;
                case "6":
                    AutoLaunchUefn = !AutoLaunchUefn;
                    Save(settingsPath);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Auto-launch UEFN: " + (AutoLaunchUefn ? "ON" : "OFF"));
                    Console.ResetColor();
                    Pause();
                    break;
                case "0":
                    return;
                default:
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("[ERROR] Please enter 0-6.");
                    Console.ResetColor();
                    Pause();
                    break;
            }
        }
    }

    private static void Pause()
    {
        Console.WriteLine();
        Console.WriteLine("Press Enter to back...");
        Console.ReadLine();
    }

    private void EditExtraArgs(string settingsPath)
    {
        Console.WriteLine("ExtraArgs: " + (ExtraArgs.Count > 0 ? string.Join(", ", ExtraArgs) : "(None)"));
        Console.WriteLine("  Press Enter while empty to make no changes. Type clear to delete everything.");
        Console.Write("> ");

        string line = Console.ReadLine()?.Trim() ?? "";
        if (string.IsNullOrEmpty(line))
        {
            Console.WriteLine("no changes");
            return;
        }
        if (line.Equals("clear", StringComparison.OrdinalIgnoreCase))
        {
            ExtraArgs.Clear();
            Save(settingsPath);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("ExtraArgs have been cleared.");
            Console.ResetColor();
            return;
        }

        var tokens = ParseArgTokens(line, out var skippedDisablePlugins);

        if (skippedDisablePlugins.Count > 0)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("[!!] -disableplugins の指定が含まれていたため、プラグイン名を「無効化プラグイン」リストへ追加しました:");
            foreach (var p in skippedDisablePlugins)
                Console.WriteLine("     + " + p);
            Console.ResetColor();
            foreach (var p in skippedDisablePlugins)
                if (!DisabledPlugins.Contains(p, StringComparer.OrdinalIgnoreCase))
                    DisabledPlugins.Add(p);
        }

        ExtraArgs = tokens;
        Save(settingsPath);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Saved");
        Console.ResetColor();
    }

    private void EditDisabledPlugins(string settingsPath)
    {
        Console.WriteLine("Current disableplugins: " + (DisabledPlugins.Count > 0 ? string.Join(", ", DisabledPlugins) : "(None)"));
        Console.WriteLine("  Press Enter while empty to make no changes. Type clear to delete everything.");
        Console.Write("> ");

        string line = Console.ReadLine()?.Trim() ?? "";
        if (string.IsNullOrEmpty(line))
        {
            Console.WriteLine("no changes");
            return;
        }
        if (line.Equals("clear", StringComparison.OrdinalIgnoreCase))
        {
            DisabledPlugins.Clear();
            Save(settingsPath);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("disableplugins have been cleared.");
            Console.ResetColor();
            return;
        }

        var plugins = ExtractPluginNames(line, "-disableplugins");
        if (plugins.Count == 0)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("[ERROR] No valid plugin name was found.");
            Console.ResetColor();
            return;
        }

        DisabledPlugins = plugins;
        Save(settingsPath);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Saved: " + string.Join(", ", DisabledPlugins));
        Console.ResetColor();
    }

    private void ShowCurrentSettings()
    {
        Console.WriteLine("── Current Settings ──────────────────────────────────");
        Console.WriteLine("ExtraArgs: " + (ExtraArgs.Count > 0 ? string.Join(", ", ExtraArgs) : "(None)"));
        Console.WriteLine("disableplugins (-disableplugins): " +
                          (DisabledPlugins.Count > 0 ? string.Join(", ", DisabledPlugins) : "(None)"));
        Console.WriteLine("enableplugins (-enableplugins):  " +
                          (EnabledPlugins.Count > 0 ? string.Join(", ", EnabledPlugins) : "(None)"));
        Console.WriteLine("Signature: " + (string.IsNullOrEmpty(Signature) ? "(未設定 - 自動取得を使用)" : Signature));
        Console.WriteLine("Auto-launch UEFN: " + (AutoLaunchUefn ? "ON" : "OFF"));
        Console.WriteLine("────────────────────────────────────────────────");
    }

    private void EditSignature(string settingsPath)
    {
        Console.WriteLine("Set Signature: " + (string.IsNullOrEmpty(Signature) ? "(未設定)" : Signature));
        Console.WriteLine();
        Console.WriteLine("  Press Enter while empty to make no changes. Type clear to delete everything.");
        Console.Write("> ");

        string line = Console.ReadLine()?.Trim() ?? "";
        if (string.IsNullOrEmpty(line))
        {
            Console.WriteLine("no changes");
            return;
        }
        if (line.Equals("clear", StringComparison.OrdinalIgnoreCase))
        {
            Signature = "";
            Save(settingsPath);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Signature have been cleared.");
            Console.ResetColor();
            return;
        }

        Signature = line;
        Save(settingsPath);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Saved: " + Signature);
        Console.ResetColor();
    }

    private void EditEnabledPlugins(string settingsPath)
    {
        Console.WriteLine("Current enableplugins: " + (EnabledPlugins.Count > 0 ? string.Join(", ", EnabledPlugins) : "(None)"));
        Console.WriteLine("  Press Enter while empty to make no changes. Type clear to delete everything.");
        Console.Write("> ");

        string line = Console.ReadLine()?.Trim() ?? "";
        if (string.IsNullOrEmpty(line))
        {
            Console.WriteLine("no chnages");
            return;
        }
        if (line.Equals("clear", StringComparison.OrdinalIgnoreCase))
        {
            EnabledPlugins.Clear();
            Save(settingsPath);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("enableplugins have been cleared.");
            Console.ResetColor();
            return;
        }

        var plugins = ExtractPluginNames(line, "-enableplugins");
        if (plugins.Count == 0)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("[ERROR] No valid plugin name was found.");
            Console.ResetColor();
            return;
        }

        EnabledPlugins = plugins;
        Save(settingsPath);
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Saved: " + string.Join(", ", EnabledPlugins));
        Console.ResetColor();
    }

    private static List<string> ParseArgTokens(string raw, out List<string> disablePluginNames)
    {
        disablePluginNames = new List<string>();
        var result = new List<string>();

        foreach (var token in SplitByComma(raw))
        {
            if (IsDisablePluginsArg(token, out var names))
            {
                disablePluginNames.AddRange(names);
            }
            else
            {
                result.Add(token);
            }
        }
        return result;
    }

    private static List<string> ExtractPluginNames(string raw, string argName = "-disableplugins")
    {
        var m = System.Text.RegularExpressions.Regex.Match(
            raw,
            System.Text.RegularExpressions.Regex.Escape(argName) + @"\s*[=:]\s*""?([^""]+)""?",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        if (m.Success)
        {
            raw = m.Groups[1].Value;
        }

        return SplitByComma(raw)
            .Where(s => !string.IsNullOrWhiteSpace(s)
                        && !s.StartsWith("-", StringComparison.Ordinal))
            .ToList();
    }

    private static bool IsDisablePluginsArg(string token, out IEnumerable<string> names)
    {
        names = Enumerable.Empty<string>();
        if (!token.StartsWith("-disableplugins", StringComparison.OrdinalIgnoreCase))
            return false;

        int eq = token.IndexOf('=');
        if (eq < 0)
        {
            names = Enumerable.Empty<string>();
            return true;
        }
        string value = token[(eq + 1)..].Trim('"', '\'', ' ');
        names = value.Split(',', StringSplitOptions.RemoveEmptyEntries)
                     .Select(s => s.Trim())
                     .Where(s => !string.IsNullOrEmpty(s));
        return true;
    }

    private static IEnumerable<string> SplitByComma(string raw)
    {
        return raw.Split(',', StringSplitOptions.RemoveEmptyEntries)
                  .Select(s => s.Trim())
                  .Where(s => !string.IsNullOrEmpty(s));
    }
}
