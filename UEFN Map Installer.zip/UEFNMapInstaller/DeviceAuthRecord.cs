using System.Text.Json.Serialization;

namespace UEFNMapInstaller;

internal sealed class DeviceAuthRecord
{
	[JsonPropertyName("accountId")]
	public string AccountId { get; set; } = "";

	[JsonPropertyName("deviceId")]
	public string DeviceId { get; set; } = "";

	[JsonPropertyName("secret")]
	public string Secret { get; set; } = "";

	[JsonPropertyName("displayName")]
	public string DisplayName { get; set; } = "";
}
