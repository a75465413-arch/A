using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("UEFNMapInstaller")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+5b003a6ee8ce9558b9c71d8c021b82823709e98a")]
[assembly: AssemblyProduct("UEFNMapInstaller")]
[assembly: AssemblyTitle("UEFNMapInstaller")]
[assembly: AssemblyVersion("1.0.0.0")]
