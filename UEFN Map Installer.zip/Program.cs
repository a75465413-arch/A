using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using UEFNMapInstaller;

[CompilerGenerated]
internal class Program
{
    private static async Task<int> Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.Title = "UEFN Map Installer";
        if (OperatingSystem.IsWindows() && !IsRunningAsAdministrator())
        {
            if (TryRelaunchAsAdministrator())
            {
                return 0;
            }
            Warn("Not running as administrator; write operations may fail.");
            Warn("If possible, right-click the tool and select \"Run as administrator\".");
        }
        Dictionary<string, string> quietEnv = new Dictionary<string, string> { ["UEFN_QUIET"] = "1" };
        string exeDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? Directory.GetCurrentDirectory();
        KillFortniteProcesses(verbose: false);
        CancellationTokenSource watcherCts = new CancellationTokenSource();
        Task.Run(() => FortniteWatcherLoop(watcherCts.Token));
        string scriptPath = Path.Combine(exeDir, "uefn_downloader.py");
        if (!File.Exists(scriptPath))
        {
            Error("uefn_downloader.py not found: " + scriptPath);
            Pause();
            return 1;
        }
        string dataDir = Path.Combine(exeDir, "Data");
        Directory.CreateDirectory(dataDir);
        string paksFolder;
        string text;
        try
        {
            paksFolder = FortnitePathLocator.FindFortnitePaksFolder();
            text = FortnitePathLocator.FindUnrealEditorExe();
        }
        catch (Exception ex)
        {
            Error(ex.Message);
            Pause();
            return 1;
        }
        string win64Dir = ((text != null) ? Path.GetDirectoryName(text) : null);
        string text2 = ((win64Dir != null) ? Path.Combine(win64Dir, "DecrypterSettings.ini") : null);
        string text3 = Directory.GetParent(paksFolder)?.FullName;
        string text4 = ((text3 == null) ? null : Directory.GetParent(text3)?.FullName);
        string text5 = ((text4 != null) ? Path.Combine(text4, "Plugins", "GameFeatures") : null);
        string installedPluginsJson = Path.Combine(dataDir, "installed_plugins.json");
        string settingsPath = Path.Combine(dataDir, "settings.json");
        AppSettings appSettings = AppSettings.Load(settingsPath);
        int num = 0;
        while (true)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("╔══════════════════════════════════╗");
            Console.WriteLine("║      UEFN Map Installer          ║");
            Console.WriteLine("╠══════════════════════════════════╣");
            Console.WriteLine("║  1  Install map                  ║");
            Console.WriteLine("║  2  Remove installed data        ║");
            Console.WriteLine("║  3  Settings                     ║");
            Console.WriteLine("╚══════════════════════════════════╝");
            Console.WriteLine();

            num = 0;
            while (num != 1 && num != 2 && num != 3)
            {
                Console.Write("Select [1/2/3]: ");
                string text6 = Console.ReadLine()?.Trim();
                if (text6 == "1") { num = 1; }
                else if (text6 == "2") { num = 2; }
                else if (text6 == "3") { num = 3; }
                else { Error("Please enter 1, 2 or 3."); }
            }

            if (num == 3)
            {
                appSettings = AppSettings.Load(settingsPath);
                appSettings.RunSettingsMenu(settingsPath);
                continue;
            }
            break;
        }
        if (num == 2)
        {
            Console.WriteLine();
            Console.WriteLine("-- Uninstall ───────────────────────────────────────");
            List<string> list = LoadInstalledPlugins(installedPluginsJson);
            string installedUefnPaksFolder = Path.Combine(paksFolder, "UEFN");
            string[] array = new string[4] { "plugin.pak", "plugin.ucas", "plugin.utoc", "plugin.sig" };
            int num2 = 0;
            string[] array2 = array;
            foreach (string path in array2)
            {
                string text7 = Path.Combine(paksFolder, path);
                if (File.Exists(text7))
                {
                    try
                    {
                        ClearReadOnly(text7);
                        File.Delete(text7);
                        Console.WriteLine("[DEL] " + text7);
                        num2++;
                    }
                    catch (Exception ex2)
                    {
                        Warn(text7 + ": deletion failed: " + ex2.Message);
                    }
                }
            }
            foreach (string moduleId in list)
            {
                foreach (string extension in new[] { ".pak", ".ucas", ".utoc", ".sig" })
                {
                    string pluginFile = Path.Combine(installedUefnPaksFolder, moduleId + extension);
                    if (!File.Exists(pluginFile))
                    {
                        continue;
                    }

                    try
                    {
                        ClearReadOnly(pluginFile);
                        File.Delete(pluginFile);
                        Console.WriteLine("[DEL] " + pluginFile);
                        num2++;
                    }
                    catch (Exception ex2)
                    {
                        Warn(pluginFile + ": deletion failed: " + ex2.Message);
                    }
                }

                if (text2 != null)
                {
                    try
                    {
                        if (IniEditor.RemoveValue(text2, "ContentKeys", moduleId))
                        {
                            Console.WriteLine("[DEL] Removed ContentKeys entry: " + moduleId);
                        }
                    }
                    catch (Exception ex2)
                    {
                        Warn("Failed to remove ContentKeys entry for " + moduleId + ": " + ex2.Message);
                    }
                }
            }
            if (num2 == 0)
            {
                Console.WriteLine("[DEL] No installed map container files found.");
            }
            if (list.Count == 0)
            {
                Console.WriteLine("[DEL] No recorded GameFeatures folders.");
            }
            else if (text5 == null)
            {
                Warn("Could not determine GameFeatures folder path. Please remove manually.");
                foreach (string item3 in list)
                {
                    Warn("  To remove: " + item3);
                }
            }
            else
            {
                List<string> list2 = new List<string>();
                foreach (string item4 in list)
                {
                    string text8 = Path.Combine(text5, item4);
                    if (!Directory.Exists(text8))
                    {
                        Console.WriteLine("[DEL] Already gone: " + text8);
                        continue;
                    }
                    try
                    {
                        Directory.Delete(text8, recursive: true);
                        Console.WriteLine("[DEL] " + text8);
                    }
                    catch (Exception ex3)
                    {
                        Warn(text8 + ": deletion failed: " + ex3.Message);
                        list2.Add(item4);
                    }
                }
                SaveInstalledPlugins(installedPluginsJson, list2);
            }
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Removal complete.");
            Console.ResetColor();
            watcherCts.Cancel();
            AutoClose();
            return 0;
        }
        if (text2 == null)
        {
            Warn("UnrealEditorFortnite-Win64-Shipping.exe not found; skipping DecrypterSettings.ini update.");
        }
        string text9;
        while (true)
        {
            Console.Write("Enter map code (e.g. 1234-5678-9012): ");
            text9 = Regex.Replace(Console.ReadLine()?.Trim() ?? "", "\\D", "");
            if (text9.Length == 12)
            {
                break;
            }
            Error("Please enter a 12-digit number.");
        }
        string mapCode = $"{text9.Substring(0, 4)}-{text9.Substring(4, 4)}-{text9.Substring(8)}";
        string authDir = Path.Combine(dataDir, "auth");
        string mapOutDir = Path.Combine(dataDir, mapCode);
        string mapContainerDir = mapOutDir;
        string keyJsonPath = Path.Combine(mapOutDir, "module_key_v4.json");
        var (cachedModuleId, cachedAesKey, _) = GameFeaturePluginExporter.ReadModuleKeyJson(keyJsonPath);
        bool hasCachedAesKey = Guid.TryParse(cachedModuleId, out _) && !string.IsNullOrWhiteSpace(cachedAesKey);

        bool useLocalBundle;
        bool useCachedAesKey;
        {
            Console.WriteLine();
            Console.WriteLine("インストール元を選んでください:");
            Console.WriteLine("  1  InstalledBundles");
            Console.WriteLine("  2  Download from cloud");
            string modeInput = "";
            while (modeInput != "1" && modeInput != "2")
            {
                Console.Write("Select [1/2]: ");
                modeInput = Console.ReadLine()?.Trim() ?? "";
                if (modeInput != "1" && modeInput != "2")
                    Error("Please enter 1 or 2.");
            }
            useLocalBundle = modeInput == "1";
        }

        useCachedAesKey = useLocalBundle && hasCachedAesKey;
        InstallationProgress progress = new InstallationProgress();
        progress.Report(2, "Authenticating");
        progress.CompleteLine();
        if (!File.Exists(Path.Combine(authDir, "device_auth.json")) && !useCachedAesKey)
        {
            int num4 = PythonRunner.Run(scriptPath, new string[3]
            {
                "device-login",
                "--data-dir",
                authDir
            }, exeDir, quietEnv);
            if (num4 != 0)
            {
                Error($"Login failed (exit code {num4})");
                Pause();
                return 1;
            }
        }
        if (!useCachedAesKey)
        {
            progress.Report(4, "Getting AES key");
            if (PythonRunner.RunWithProgress(scriptPath, new string[6] { "resolve-v2", mapCode, "--data-dir", authDir, "--out", dataDir }, exeDir, quietEnv, _ => { }) != 0)
            {
                Warn("Failed to fetch AES key (no issue if the map is unencrypted).");
            }
            else if (text2 != null)
            {
                WriteContentKey(text2, keyJsonPath);
            }
        }
        else
        {
            ConsoleLog.WriteLine("Using cached AES key for local bundle matching.", ConsoleColor.Cyan);
            if (text2 != null)
            {
                WriteContentKey(text2, keyJsonPath);
            }
        }
        progress.Report(10, "AES key ready");
        progress.CompleteLine();
        if (text2 != null && !string.IsNullOrEmpty(appSettings.Signature))
        {
            WriteIni(text2, "Settings", "Signature", appSettings.Signature);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("[SIG] Signature (settings): " + appSettings.Signature);
            Console.ResetColor();
        }
        else if (text2 != null && string.IsNullOrEmpty(appSettings.Signature))
        {
            Warn("Signature not set. Set it in Settings (3) if decryption fails.");
        }
        if (useLocalBundle)
        {
            progress.Report(20, "Finding local map data");
            progress.CompleteLine();
            var (localModuleId, localAesKey, localPakGuid) = GameFeaturePluginExporter.ReadModuleKeyJson(keyJsonPath);
            if (!Guid.TryParse(localModuleId, out _) || string.IsNullOrWhiteSpace(localAesKey))
            {
                Error("A valid cached AES key is required to identify the matching local map bundle.");
                Pause();
                return 1;
            }

            string installedBundlesDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "FortniteGame", "Saved", "PersistentDownloadDir", "GameCustom", "InstalledBundles");
            string bundleDirectory;
            try
            {
                bundleDirectory = LocalBundleFinder.FindMatchingBundle(installedBundlesDirectory, localModuleId!, localAesKey!, localPakGuid);
            }
            catch (Exception ex)
            {
                Error("Failed to search local InstalledBundles: " + ex.Message);
                Pause();
                return 1;
            }
            if (bundleDirectory == null)
            {
                Error("No local bundle matched this map. Download the map in Fortnite first, or choose cloud download (option 2).");
                Pause();
                return 1;
            }

            mapContainerDir = bundleDirectory;
            ConsoleLog.WriteLine("Matched local map bundle: " + Path.GetFileName(bundleDirectory), ConsoleColor.Green);
        }
        else
        {
            progress.Report(18, "Checking game version");
            progress.CompleteLine();
            string text16 = await GetLatestFortniteVersion();
            progress.Report(20, "Downloading map data");
            List<string> list3 = new List<string> { "download", mapCode, "--data-dir", authDir, "--out", dataDir, "--skip-aes-key" };
            if (!string.IsNullOrEmpty(text16))
            {
                list3.AddRange(new _003C_003Ez__ReadOnlyArray<string>(new string[2]
                {
                    "--fortnite-user-agent",
                    "Fortnite/" + text16 + " Windows/10.0.26100.8162.64bit"
                }));
                progress.CompleteLine();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("[UA] Fortnite version: " + text16);
                Console.ResetColor();
            }
            int num5 = PythonRunner.RunWithProgress(scriptPath, list3.ToArray(), exeDir, quietEnv, percentage =>
                progress.Report(20 + (int)Math.Round(percentage * 0.6), "Downloading map data"));
            if (num5 != 0)
            {
                progress.CompleteLine();
                Error($"Download failed (exit code {num5})");
                Pause();
                return 1;
            }
        }
        progress.CompleteLine();
        progress.Report(80, "Preparing plugin");
        progress.CompleteLine();

        string moduleKeyJsonPath = Path.Combine(mapOutDir, "module_key_v4.json");
        if (!File.Exists(moduleKeyJsonPath))
        {
            Warn($"module_key_v4.json not found at: {moduleKeyJsonPath}");
        }

        var (text19, text20, pakGuid) = GameFeaturePluginExporter.ReadModuleKeyJson(moduleKeyJsonPath);

        if (!string.IsNullOrEmpty(text19) && !string.IsNullOrEmpty(text20))
        {
            try
            {
                string? exportedPluginName = GameFeaturePluginExporter.ExportPlugin(mapContainerDir, text19, text20, pakGuid, paksFolder);
                if (exportedPluginName != null)
                {
                    text19 = exportedPluginName;
                    List<string> list4 = LoadInstalledPlugins(installedPluginsJson);
                    if (!list4.Contains(text19, StringComparer.OrdinalIgnoreCase))
                    {
                        list4.Add(text19);
                        SaveInstalledPlugins(installedPluginsJson, list4);
                    }
                }
                else
                {
                    Warn("Could not export the GameFeature plugin.");
                }
            }
            catch (Exception ex6)
            {
                Warn("Failed to place GameFeatures plugin: " + ex6.Message);
            }
        }

        progress.Report(88, "Installing plugin");
        progress.CompleteLine();
        string uefnPaksFolder = Path.Combine(paksFolder, "UEFN");
        string[] array3 = new string[4] { ".pak", ".ucas", ".utoc", ".sig" };
        int num6 = 0;
        try
        {
            if (!Guid.TryParse(text19, out _))
            {
                Warn("A valid ModuleID is required to install the map containers.");
            }
            else
            {
                Directory.CreateDirectory(uefnPaksFolder);
                foreach (string extension in array3)
                {
                    string sourceFile = Path.Combine(mapContainerDir, "plugin" + extension);
                    if (!File.Exists(sourceFile))
                    {
                        continue;
                    }

                    string targetFile = Path.Combine(uefnPaksFolder, text19 + extension);
                    if (File.Exists(targetFile))
                    {
                        ClearReadOnly(targetFile);
                    }
                    File.Copy(sourceFile, targetFile, overwrite: true);
                    num6++;
                }
            }
        }
        catch (UnauthorizedAccessException)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("[ERROR] " + uefnPaksFolder + ": write access denied.");
            Console.WriteLine("          icacls \"" + uefnPaksFolder + "\" /grant *S-1-5-32-544:(OI)(CI)F /T");
            Console.ResetColor();
            Pause();
            return 1;
        }
        catch (IOException ex5)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("[ERROR] Write to " + uefnPaksFolder + " failed. Please fully exit Epic Games Launcher and Fortnite, then try again.");
            Console.WriteLine("        Details: " + ex5.Message);
            Console.ResetColor();
            Pause();
            return 1;
        }
        progress.Report(95, "Finalizing installation");
        progress.CompleteLine();
        if (num6 == 0)
        {
            Warn("No files could be copied.");
            Warn("Please check the download folder: " + mapOutDir);
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Installation complete! {num6} file(s) copied.");
            Console.WriteLine("Installed to: " + uefnPaksFolder);
            Console.ResetColor();
            if (!string.IsNullOrEmpty(text19))
            {
                List<string> installedPlugins = LoadInstalledPlugins(installedPluginsJson);
                if (!installedPlugins.Contains(text19, StringComparer.OrdinalIgnoreCase))
                {
                    installedPlugins.Add(text19);
                    SaveInstalledPlugins(installedPluginsJson, installedPlugins);
                }
            }
        }

        if (!string.IsNullOrEmpty(text19))
        {
            InlineArray6<string> buffer = default;
            buffer[0] = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            buffer[1] = "UnrealEditorFortnite";
            buffer[2] = "Saved";
            buffer[3] = "Config";
            buffer[4] = "WindowsEditor";
            buffer[5] = "EditorPerProjectUserSettings.ini";
            UpdateContentBrowserSelectedPaths(Path.Combine(buffer), text19);
        }
        progress.Report(98, "Launching UEFN");
        progress.CompleteLine();
        string text21 = ((win64Dir != null) ? Path.Combine(win64Dir, "amfrt64.dll") : null);
        string text22 = ((win64Dir != null) ? Path.Combine(win64Dir, "UnrealEditorFortnite-Win64-Shipping.exe") : null);
        if (!appSettings.AutoLaunchUefn)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("[INFO] Auto-launch UEFN is OFF. Launch UEFN manually.");
            Console.ResetColor();
        }
        else if (text21 == null || !File.Exists(text21))
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("[!!] amfrt64.dll not found.");
            Console.WriteLine("[!!] AES Loader setup required:");
            Console.WriteLine("[!!]   https://github.com/Aleman-sein-Vater/UEFN-AES-Loader");
            Console.ResetColor();
            Console.WriteLine();
            Console.Write("Open the above URL in your browser? [Y/n]: ");
            if (!string.Equals(Console.ReadLine()?.Trim(), "n", StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    Process.Start(new ProcessStartInfo("https://github.com/Aleman-sein-Vater/UEFN-AES-Loader")
                    {
                        UseShellExecute = true
                    });
                }
                catch
                {
                    Warn("Could not open browser. Please visit the URL manually.");
                }
            }
        }
        else if (text22 == null || !File.Exists(text22))
        {
            Warn("UnrealEditorFortnite-Win64-Shipping.exe not found. Please launch manually.");
        }
        else
        {
            string text23 = ((!string.IsNullOrEmpty(text19)) ? text19 : "");

            var disableList = appSettings.DisabledPlugins
                .Where(p => !string.IsNullOrWhiteSpace(p))
                .ToList();

            var enableList = new List<string>();
            if (!string.IsNullOrEmpty(text23))
                enableList.Add(text23);
            foreach (var p in appSettings.EnabledPlugins)
                if (!enableList.Contains(p, StringComparer.OrdinalIgnoreCase))
                    enableList.Add(p);

            string disableArg = disableList.Count > 0
                ? "-disableplugins=\"" + string.Join(",", disableList) + "\""
                : "";
            string enableArg  = "-enableplugins=\""  + string.Join(",", enableList) + "\"";
            var extraTokens = appSettings.BuildArgTokens().ToList();
            string extraStr  = extraTokens.Count > 0 ? " " + string.Join(" ", extraTokens) : "";

            string text24 = string.IsNullOrEmpty(disableArg)
                ? $"{enableArg}{extraStr}"
                : $"{disableArg} {enableArg}{extraStr}";
            try
            {
                Process.Start(new ProcessStartInfo(text22, text24)
                {
                    UseShellExecute = true,
                    WorkingDirectory = win64Dir
                });
                progress.Report(100, "UEFN launched");
            }
            catch (Exception ex7)
            {
                progress.CompleteLine();
                Warn("Launch failed: " + ex7.Message);
            }
        }
        progress.CompleteLine();
        watcherCts.Cancel();
        AutoClose();
        return 0;
        static void AutoClose(int delaySeconds = 3)
        {
            Console.WriteLine();
            Console.WriteLine($"Closing automatically in {delaySeconds} seconds... (press Enter to close now)");
            CancellationTokenSource cts = new CancellationTokenSource();
            Task task = Task.Run(async () =>
            {
                int i = delaySeconds;
                while (i > 0 && !cts.Token.IsCancellationRequested)
                {
                    Console.Write($"\r  {i}... ");
                    await Task.Delay(1000, cts.Token).ContinueWith((Task _) =>
                    {
                    });
                    i--;
                }
            });
            Task task2 = Task.Run(() =>
            {
                try
                {
                    Console.ReadLine();
                }
                catch
                {
                }
            });
            Task.WhenAny(task, task2).GetAwaiter().GetResult();
            cts.Cancel();
            Console.WriteLine();
        }
        static void ClearReadOnly(string path3)
        {
            try
            {
                FileAttributes attributes = File.GetAttributes(path3);
                if ((attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                {
                    File.SetAttributes(path3, attributes & ~FileAttributes.ReadOnly);
                }
            }
            catch
            {
            }
        }
        static void Error(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("[ERROR] " + msg);
            Console.ResetColor();
        }
        static string? FetchGameVersion(string scriptPath2, string workingDir) => null; // 未使用（Sig自動取得廃止）
        static async Task FortniteWatcherLoop(CancellationToken ct)
        {
            try
            {
                while (!ct.IsCancellationRequested)
                {
                    await Task.Delay(1000, ct);
                    KillFortniteProcesses(verbose: false);
                }
            }
            catch (OperationCanceledException)
            {
            }
            catch
            {
            }
        }
        static async Task<string?> GetLatestFortniteVersion()
        {
            try
            {
                using HttpClient client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(15L);
                using JsonDocument jsonDocument = JsonDocument.Parse(await client.GetStringAsync("https://uedb.dev/svc/api/v1/fortnite/mappings"));
                return jsonDocument.RootElement.GetProperty("version").GetString();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"[UA] Failed to fetch latest Fortnite version (uedb.dev timeout/error): {ex.Message}");
                Console.WriteLine("[UA] Proceeding without custom User-Agent...");
                Console.ResetColor();
                return null;
            }
        }
        static bool IsRunningAsAdministrator()
        {
            using WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent();
            return new WindowsPrincipal(ntIdentity).IsInRole(WindowsBuiltInRole.Administrator);
        }
        static void KillFortniteProcesses(bool verbose)
        {
            List<string> list5 = new List<string>();
            try
            {
                Process[] processes = Process.GetProcesses();
                foreach (Process process in processes)
                {
                    try
                    {
                        if (process.ProcessName.Contains("Fortnite", StringComparison.OrdinalIgnoreCase))
                        {
                            string processName = process.ProcessName;
                            process.Kill(entireProcessTree: true);
                            process.WaitForExit(3000);
                            list5.Add(processName);
                        }
                    }
                    catch
                    {
                    }
                    finally
                    {
                        process.Dispose();
                    }
                }
            }
            catch
            {
            }
            if (verbose && list5.Count > 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                foreach (string item5 in list5)
                {
                    Console.WriteLine("[GUARD] Killed: " + item5);
                }
                Console.ResetColor();
            }
        }
        static List<string> LoadInstalledPlugins(string jsonPath)
        {
            if (!File.Exists(jsonPath))
            {
                return new List<string>();
            }
            try
            {
                return JsonSerializer.Deserialize<List<string>>(File.ReadAllText(jsonPath)) ?? new List<string>();
            }
            catch
            {
                return new List<string>();
            }
        }
        static void SaveInstalledPlugins(string jsonPath, List<string> folders)
        {
            try
            {
                File.WriteAllText(jsonPath, JsonSerializer.Serialize(folders, new JsonSerializerOptions
                {
                    WriteIndented = true
                }));
            }
            catch (Exception ex8)
            {
                Warn("Failed to save installed_plugins.json: " + ex8.Message);
            }
        }
        static void Pause()
        {
            Console.WriteLine();
            Console.WriteLine("Press Enter to exit...");
            Console.ReadLine();
        }
        static string? TryBuildKeychain(string jsonPath)
        {
            if (!File.Exists(jsonPath))
            {
                return null;
            }
            try
            {
                using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(jsonPath));
                JsonElement rootElement = jsonDocument.RootElement;
                string text25 = (rootElement.TryGetProperty("guid", out var value) ? value.GetString() : null);
                if (string.IsNullOrEmpty(text25))
                {
                    return null;
                }
                string text26 = null;
                if (rootElement.TryGetProperty("raw", out var value2) && value2.TryGetProperty("key", out var value3) && value3.TryGetProperty("Key", out var value4))
                {
                    text26 = value4.GetString();
                }
                if (string.IsNullOrEmpty(text26))
                {
                    string text27 = (rootElement.TryGetProperty("aesKeyHex", out var value5) ? value5.GetString() : null);
                    if (string.IsNullOrEmpty(text27))
                    {
                        return null;
                    }
                    if (text27.StartsWith("0x", StringComparison.OrdinalIgnoreCase))
                    {
                        text27 = text27.Substring(2);
                    }
                    text26 = Convert.ToBase64String(Convert.FromHexString(text27));
                }
                return text25.Replace("-", "").ToUpperInvariant() + ":" + text26;
            }
            catch
            {
                return null;
            }
        }
        static void WriteContentKey(string iniPath, string jsonPath)
        {
            string keychain = TryBuildKeychain(jsonPath);
            if (keychain == null)
            {
                Warn("Could not build a key chain from the cached AES key.");
                return;
            }

            var (moduleId, _, _) = GameFeaturePluginExporter.ReadModuleKeyJson(jsonPath);
            if (!Guid.TryParse(moduleId, out _))
            {
                Warn("Could not read a valid ModuleID; skipping ContentKeys update.");
                return;
            }

            if (!WriteIni(iniPath, "ContentKeys", moduleId!, keychain))
            {
                return;
            }

            try
            {
                IniEditor.RemoveValue(iniPath, "ContentKeys", "Key0");
            }
            catch (Exception ex)
            {
                Warn("Failed to remove legacy Key0 entry: " + ex.Message);
            }
        }
        static bool TryRelaunchAsAdministrator()
        {
            try
            {
                string text25 = Process.GetCurrentProcess().MainModule?.FileName ?? Environment.ProcessPath;
                if (string.IsNullOrEmpty(text25))
                {
                    return false;
                }
                Process.Start(new ProcessStartInfo(text25)
                {
                    UseShellExecute = true,
                    Verb = "runas",
                    WorkingDirectory = Environment.CurrentDirectory
                });
                return true;
            }
            catch
            {
                return false;
            }
        }
        static void UpdateContentBrowserSelectedPaths(string iniPath, string moduleId)
        {
            string text25 = "/" + moduleId;
            if (!File.Exists(iniPath))
            {
                Console.WriteLine("[CB] EditorPerProjectUserSettings.ini not found; skipping: " + iniPath);
                return;
            }
            try
            {
                string[] array4 = File.ReadAllLines(iniPath);
                bool flag = false;
                for (int i = 0; i < array4.Length; i++)
                {
                    string text26 = array4[i].TrimStart();
                    if (text26.StartsWith("ContentBrowserDrawer.SelectedPaths=", StringComparison.OrdinalIgnoreCase))
                    {
                        if (!string.Equals(text26.Substring("ContentBrowserDrawer.SelectedPaths".Length + 1), text25, StringComparison.Ordinal))
                        {
                            int length = array4[i].Length - text26.Length;
                            array4[i] = array4[i].Substring(0, length) + "ContentBrowserDrawer.SelectedPaths=" + text25;
                            flag = true;
                            break;
                        }
                        return;
                    }
                }
                if (!flag)
                {
                    List<string> list5 = array4.ToList();
                    int num7 = -1;
                    for (int j = 0; j < list5.Count; j++)
                    {
                        if (list5[j].TrimStart().Equals("[/Script/ContentBrowser.ContentBrowserSettings]", StringComparison.OrdinalIgnoreCase))
                        {
                            num7 = j + 1;
                            break;
                        }
                    }
                    string item2 = "ContentBrowserDrawer.SelectedPaths=" + text25;
                    if (num7 >= 0)
                    {
                        list5.Insert(num7, item2);
                    }
                    else
                    {
                        list5.Add(item2);
                    }
                    array4 = list5.ToArray();
                }
                File.WriteAllLines(iniPath, array4, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            }
            catch (UnauthorizedAccessException)
            {
                Warn("Write access denied for EditorPerProjectUserSettings.ini: " + iniPath);
            }
            catch (Exception ex9)
            {
                Warn("EditorPerProjectUserSettings.Failed to update ini: " + ex9.Message);
            }
        }
        static void Warn(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("[!!] " + msg);
            Console.ResetColor();
        }
        static bool WriteIni(string iniPath, string section, string key, string value)
        {
            try
            {
                IniEditor.SetValue(iniPath, section, key, value, "[Settings]\r\nModuleName=unrealeditorfortnite-engine-win64-shipping.dll\r\nSignature=??\r\nTimeout=10000\r\n\r\n[ContentKeys]\r\n");
                return true;
            }
            catch (UnauthorizedAccessException)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[ERROR] " + iniPath + ": write access denied. Please run as administrator.");
                Console.ResetColor();
                return false;
            }
            catch (Exception ex9)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[ERROR] Failed to update ini: " + ex9.Message);
                Console.ResetColor();
                return false;
            }
        }
    }
}