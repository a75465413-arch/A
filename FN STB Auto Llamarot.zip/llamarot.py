import time
import numpy as np
import cv2
from mss import mss
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import keyboard
import sys
import colorsys
import json
import os
import random
import winsound

CONFIG_FILE = 'llamarot_config.json'
DEFAULT_REGION = {'left': 650, 'top': 450, 'width': 600, 'height': 120}
BASE_POST_PRESS_SLEEP = 0.25

class RegionSelectionWindow:
    def __init__(self, master, callback):
        self.master = master
        self.callback = callback
        self.top = tk.Toplevel(master)
        self.top.attributes('-alpha', 0.3)
        self.top.attributes("-fullscreen", True)
        self.top.configure(bg='black')
        self.canvas = tk.Canvas(self.top, cursor='cross', bg='black', highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<Button-1>', self.on_mouse_down)
        self.canvas.bind('<B1-Motion>', self.on_mouse_drag)
        self.canvas.bind('<ButtonRelease-1>', self.on_mouse_up)
        self.top.bind('<Escape>', self.cancel)
        self.start_x = 0
        self.start_y = 0
        self.rect_id = None

    def on_mouse_down(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.rect_id = self.canvas.create_rectangle(self.start_x, self.start_y, self.start_x, self.start_y, outline='red', width=2)

    def on_mouse_drag(self, event):
        self.canvas.coords(self.rect_id, self.start_x, self.start_y, event.x, event.y)

    def on_mouse_up(self, event):
        x1, y1 = self.start_x, self.start_y
        x2, y2 = event.x, event.y
        left, top = min(x1, x2), min(y1, y2)
        width, height = abs(x2 - x1), abs(y2 - y1)
        if width > 10 and height > 10:
            self.callback({'left': left, 'top': top, 'width': width, 'height': height})
        self.top.destroy()
        self.master.deiconify()

    def cancel(self, event):
        self.top.destroy()
        self.master.deiconify()

class ModernAutoClicker:
    def __init__(self, root):
        self.root = root
        self.root.title("LLAMAROT")
        self.root.geometry("450x600")
        self.root.configure(bg='#1C1C1C')
        self.root.attributes("-alpha", 0.95)
        self.root.attributes("-topmost", True)
        
        self.is_running = False
        self.target_key = 'e'
        self.hotkey = 'z'
        self.delay_value = 0.65
        self.use_sound = tk.BooleanVar(value=True)
        self.use_humanize = tk.BooleanVar(value=False)
        self.capture_region = DEFAULT_REGION.copy()
        self.stop_event = threading.Event()
        
        self.load_settings()
        self.create_widgets()
        self.register_hotkey_internal()
        self.start_logic_thread()

    def load_settings(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    data = json.load(f)
                    self.target_key = data.get('target_key', 'e')
                    self.hotkey = data.get('hotkey', 'z')
                    self.delay_value = data.get('delay', 0.65)
                    self.use_sound.set(data.get('sound', True))
                    self.use_humanize.set(data.get('humanize', False))
                    self.capture_region = data.get('region', DEFAULT_REGION.copy())
            except: pass

    def save_settings(self):
        data = {
            'target_key': self.target_key,
            'hotkey': self.hotkey,
            'delay': self.delay_value,
            'sound': self.use_sound.get(),
            'humanize': self.use_humanize.get(),
            'region': self.capture_region
        }
        with open(CONFIG_FILE, 'w') as f:
            json.dump(data, f)

    def create_widgets(self):
        main_frame = tk.Frame(self.root, bg='#1C1C1C')
        main_frame.pack(fill='both', expand=True, padx=40, pady=30)

        tk.Label(main_frame, text="LLAMAROT", font=("Segoe UI", 24, "bold"), fg="white", bg='#1C1C1C').pack(pady=(0, 20))

        self.btn_region = tk.Button(main_frame, text="SELECT REGION", font=("Segoe UI", 9, "bold"), 
                                    bg="#3C3C3C", fg="white", activebackground="#505050", activeforeground="white",
                                    relief="flat", height=2, command=self.start_region_selection)
        self.btn_region.pack(fill='x', pady=(10, 0))

        self.lbl_region_info = tk.Label(main_frame, text=self.get_region_str(), font=("Segoe UI", 8), fg="gray", bg='#1C1C1C')
        self.lbl_region_info.pack(pady=(0, 20))

        self.create_key_row(main_frame, "TARGET KEY", self.target_key, self.change_target_key)
        self.create_key_row(main_frame, "TOGGLE KEY", self.hotkey, self.change_hotkey)

        tk.Label(main_frame, text="REACTION DELAY", font=("Segoe UI", 9), fg="white", bg='#1C1C1C').pack(anchor='w', pady=(20, 5))
        self.slider = ttk.Scale(main_frame, from_=-1.0, to=2.0, orient='horizontal', command=self.on_slider_change)
        self.slider.set(self.delay_value)
        self.slider.pack(fill='x')

        toggle_frame = tk.Frame(main_frame, bg='#1C1C1C')
        toggle_frame.pack(fill='x', pady=30)

        tk.Checkbutton(toggle_frame, text="SOUND ALERT", variable=self.use_sound, font=("Segoe UI", 8),
                       bg='#1C1C1C', fg="white", selectcolor="#282828", activebackground="#1C1C1C", 
                       activeforeground="white", command=self.save_settings).pack(side='left', expand=True)
        
        tk.Checkbutton(toggle_frame, text="HUMANIZE", variable=self.use_humanize, font=("Segoe UI", 8),
                       bg='#1C1C1C', fg="white", selectcolor="#282828", activebackground="#1C1C1C", 
                       activeforeground="white", command=self.save_settings).pack(side='left', expand=True)

        self.lbl_status = tk.Label(main_frame, text="STATUS: STOPPED", font=("Yu Gothic UI", 10, "bold"), fg="gray", bg='#1C1C1C')
        self.lbl_status.pack(pady=10)

        tk.Label(main_frame, text="discord.gg/3JzEfWHgSF", font=("Segoe UI", 8), fg="gray", bg='#1C1C1C').pack(side='bottom', pady=10)

    def create_key_row(self, parent, label_text, key_val, command_func):
        row = tk.Frame(parent, bg='#1C1C1C')
        row.pack(fill='x', pady=5)
        tk.Label(row, text=label_text, font=("Segoe UI", 9), fg="white", bg='#1C1C1C', width=12, anchor='w').pack(side='left')
        btn = tk.Button(row, text=f"Key: {key_val.upper()}", font=("Segoe UI", 9, "bold"), 
                        bg="#232323", fg="white", relief="flat", width=15, command=lambda: command_func(btn))
        btn.pack(side='right')

    def get_region_str(self):
        r = self.capture_region
        return f"L:{r['left']} T:{r['top']} W:{r['width']} H:{r['height']}"

    def on_slider_change(self, val):
        self.delay_value = float(val)
        self.save_settings()

    def change_target_key(self, btn):
        btn.config(text="PRESS ANY KEY...")
        self.root.update()
        key = keyboard.read_event(suppress=True).name
        self.target_key = key
        btn.config(text=f"Key: {key.upper()}")
        self.save_settings()

    def change_hotkey(self, btn):
        btn.config(text="PRESS ANY KEY...")
        self.root.update()
        key = keyboard.read_event(suppress=True).name
        self.hotkey = key
        btn.config(text=f"Key: {key.upper()}")
        self.register_hotkey_internal()
        self.save_settings()

    def register_hotkey_internal(self):
        try: keyboard.unhook_all_hotkeys()
        except: pass
        try:
            keyboard.add_hotkey(self.hotkey, self.toggle_automation)
        except Exception as e:
            print(f"Hotkey registration failed: {e}")

    def toggle_automation(self):
        self.is_running = not self.is_running
        color = "#A071FF" if self.is_running else "gray"
        status_text = "STATUS: RUNNING !!!" if self.is_running else "STATUS: STOPPED"
        self.lbl_status.config(text=status_text, fg=color)
        if self.use_sound.get():
            threading.Thread(target=winsound.Beep, args=(1000 if self.is_running else 500, 200)).start()

    def start_region_selection(self):
        self.root.withdraw()
        RegionSelectionWindow(self.root, self.on_region_selected)

    def on_region_selected(self, reg):
        self.capture_region = reg
        self.lbl_region_info.config(text=self.get_region_str())
        self.save_settings()

    def detect_white_line_x(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        _, binary = cv2.threshold(gray, 220, 255, cv2.THRESH_BINARY)
        col_sum = np.sum(binary, axis=0)
        peak = np.argmax(col_sum)
        return int(peak) if col_sum[peak] >= 50 else None

    def detect_zone(self, frame):
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        r, g, b = rgb[:,:,0], rgb[:,:,1], rgb[:,:,2]
        mask = (r >= 60) & (r <= 140) & (g >= 130) & (g <= 220) & (b >= 190)
        xs = np.where(np.sum(mask, axis=0) > 5)[0]
        return (int(xs.min()), int(xs.max())) if len(xs) > 0 else None

    def run_logic(self):
        sct = mss()
        last_x = 0
        last_press_time = 0
        while not self.stop_event.is_set():
            if not self.is_running:
                time.sleep(0.1); continue
            reg = self.capture_region
            if reg['width'] <= 10:
                time.sleep(0.5); continue
            sct_img = sct.grab(reg)
            frame = np.array(sct_img)[:, :, :3]
            current_x = self.detect_white_line_x(frame)
            zone = self.detect_zone(frame)
            if zone is not None and current_x is not None:
                z_min, z_max = zone
                z_center = (z_min + z_max) // 2
                z_radius = (z_max - z_min) / 2
                speed = current_x - last_x if last_x != 0 else 0
                if abs(speed) > 50: speed = 0
                curr_delay = self.delay_value
                curr_sleep = BASE_POST_PRESS_SLEEP
                if self.use_humanize.get():
                    curr_delay += random.uniform(-0.05, 0.05)
                    curr_sleep += random.uniform(0, 0.05)
                predicted_x = current_x + (speed * curr_delay)
                dist = abs(predicted_x - z_center)
                threshold = max(z_radius * 0.8, 10.0)
                now = time.time()
                if dist <= threshold and (now - last_press_time) > curr_sleep:
                    keyboard.press_and_release(self.target_key)
                    last_press_time = now
                last_x = current_x
            time.sleep(0.001)

    def start_logic_thread(self):
        t = threading.Thread(target=self.run_logic, daemon=True)
        t.start()

if __name__ == '__main__':
    root = tk.Tk()
    style = ttk.Style()
    style.theme_use('default')
    style.configure("Horizontal.TScale", background='#1C1C1C', troughcolor='#333333')
    
    ModernAutoClicker(root)
    root.mainloop()