using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CUE4Parse.Encryption.Aes;
using CUE4Parse.FileProvider;
using CUE4Parse.FileProvider.Objects;
using CUE4Parse.MappingsProvider.Usmap;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Versions;
using FModel.Services.Verse;
using UEFNMapInstaller;

internal class Program
{
    private static readonly List<(FGuid Guid, FAesKey Key)> _fortniteAesKeys = new();

    private static async Task<int> Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.Title = "STB Spawn Leak";

        string exeDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
                        ?? Directory.GetCurrentDirectory();
        string scriptPath = Path.Combine(exeDir, "uefn_downloader.py");
        if (!File.Exists(scriptPath))
        {
            Error("uefn_downloader.py not found: " + scriptPath);
            Pause();
            return 1;
        }

        string dataDir = Path.Combine(exeDir, "Data");
        Directory.CreateDirectory(dataDir);
        string authDir = Path.Combine(dataDir, "auth");

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Fortnite mappings / AES キーを取得中...");
        Console.ResetColor();

        string? usmapPath = await FetchMappings(dataDir);
        await FetchFortniteAesKeys();

        const string mapCode = "3225-0366-8885";

        string mapOutDir = Path.Combine(dataDir, mapCode);
        string keyJsonPath = Path.Combine(mapOutDir, "module_key_v4.json");

        bool useLocalBundle;
        {
            Console.WriteLine();
            Console.WriteLine("ソースを選んでください:");
            Console.WriteLine("  1  InstalledBundles");
            Console.WriteLine("  2  Download From Cloud");
            string input = "";
            while (input != "1" && input != "2")
            {
                Console.Write("Select [1/2]: ");
                input = Console.ReadLine()?.Trim() ?? "";
                if (input != "1" && input != "2") Error("Please enter 1 or 2.");
            }
            useLocalBundle = input == "1";
        }

        var (cachedModuleId, cachedAesKey, _) = GameFeaturePluginExporter.ReadModuleKeyJson(keyJsonPath);
        bool hasCachedAesKey = Guid.TryParse(cachedModuleId, out _) && !string.IsNullOrWhiteSpace(cachedAesKey);
        bool useCachedAesKey = useLocalBundle && hasCachedAesKey;

        Dictionary<string, string> quietEnv = new() { ["UEFN_QUIET"] = "1" };

        if (!File.Exists(Path.Combine(authDir, "device_auth.json")) && !useCachedAesKey)
        {
            int r = PythonRunner.Run(scriptPath, ["device-login", "--data-dir", authDir], exeDir, quietEnv);
            if (r != 0)
            {
                Error($"Login failed (exit code {r})");
                Pause();
                return 1;
            }
        }

        if (!useCachedAesKey)
        {
            string? fortniteVersion = GetFortniteVersionString();
            var aesArgs = new List<string> { "resolve-v2", mapCode, "--data-dir", authDir, "--out", dataDir };
            if (!string.IsNullOrEmpty(fortniteVersion))
            {
                var vm = Regex.Match(fortniteVersion, @"Release-(\d+)\.(\d+)-CL-(\d+)");
                if (vm.Success)
                    aesArgs.AddRange(["--major", vm.Groups[1].Value,
                                      "--minor", vm.Groups[2].Value,
                                      "--patch", vm.Groups[3].Value]);
            }
            if (PythonRunner.RunWithProgress(scriptPath, [.. aesArgs], exeDir, quietEnv, _ => { }) != 0)
            {
                Error("AESキーの取得に失敗しました。");
                Pause();
                return 1;
            }
        }

        string containerDir;
        if (useLocalBundle)
        {
            var (localModuleId, localAesKey, localPakGuid) = GameFeaturePluginExporter.ReadModuleKeyJson(keyJsonPath);
            if (!Guid.TryParse(localModuleId, out _) || string.IsNullOrWhiteSpace(localAesKey))
            {
                Error("有効なキャッシュAESキーが必要です。先にクラウドダウンロード(2)でキーを取得してください。");
                Pause();
                return 1;
            }
            string installedBundlesDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "FortniteGame", "Saved", "PersistentDownloadDir", "GameCustom", "InstalledBundles");
            try
            {
                containerDir = LocalBundleFinder.FindMatchingBundle(installedBundlesDir, localModuleId!, localAesKey!, localPakGuid);
            }
            catch (Exception ex)
            {
                Error("ローカルバンドル検索失敗: " + ex.Message);
                Pause();
                return 1;
            }
            if (containerDir == null)
            {
                Error("ローカルにマップが見つかりません。先にFortniteでマップをダウンロードしてください。");
                Pause();
                return 1;
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("ローカルバンドル: " + Path.GetFileName(containerDir));
            Console.ResetColor();
        }
        else
        {
            Console.WriteLine();
            string? fortniteVersion = GetFortniteVersionString();
            var dlArgs = new List<string> { "download", mapCode, "--data-dir", authDir, "--out", dataDir, "--skip-aes-key" };
            if (!string.IsNullOrEmpty(fortniteVersion))
            {
                dlArgs.AddRange(["--fortnite-user-agent",
                                 "Fortnite/" + fortniteVersion + " Windows/10.0.26100.8162.64bit"]);
                var vm = Regex.Match(fortniteVersion, @"Release-(\d+)\.(\d+)-CL-(\d+)");
                if (vm.Success)
                    dlArgs.AddRange(["--major", vm.Groups[1].Value,
                                     "--minor", vm.Groups[2].Value,
                                     "--patch", vm.Groups[3].Value]);
            }
            int dlResult = PythonRunner.RunWithProgress(scriptPath, [.. dlArgs], exeDir, quietEnv, _ => { });
            if (dlResult != 0)
            {
                Error($"Download failed (exit code {dlResult})");
                Pause();
                return 1;
            }
            containerDir = mapOutDir;
        }

        // ─── マップの AES キー読み込み ────────────────────────────────
        var (moduleId, aesKeyHex, pakGuid) = GameFeaturePluginExporter.ReadModuleKeyJson(keyJsonPath);
        if (string.IsNullOrWhiteSpace(aesKeyHex))
        {
            Error("AES キーが見つかりません。");
            Pause();
            return 1;
        }

        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Verseを復元しています...");
        Console.ResetColor();

        string? verseCode = RecoverVerseCode(containerDir, aesKeyHex, pakGuid, usmapPath);
        if (verseCode == null)
        {
            Error("Verseを復元できませんでした。");
            Pause();
            return 1;
        }

        string? parseResult = RunParseSpawns(exeDir, verseCode);
        if (parseResult == null)
        {
            Error("parse_spawns.py の実行に失敗しました。");
            Pause();
            return 1;
        }

        Console.Clear();
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("╔══════════════════════════════════════════════════════╗");
        Console.WriteLine("║           Parsed Spawn Results                       ║");
        Console.WriteLine("╚══════════════════════════════════════════════════════╝");
        Console.ResetColor();
        Console.WriteLine();
        Console.Write(parseResult);

        Console.WriteLine();
        Console.Write("Press Enter to exit...");
        Console.ReadLine();
        return 0;
    }

    // ─── parse_spawns.py 実行 ──────────────────────────────────────────
    private static string? RunParseSpawns(string exeDir, string verseCode)
    {
        // parse_spawns.py は verse.txt を読み込むため、一時ファイルに書き出す
        string parseScriptPath = Path.Combine(exeDir, "parse_spawns.py");
        if (!File.Exists(parseScriptPath))
        {
            Error("parse_spawns.py not found: " + parseScriptPath);
            return null;
        }

        // parse_spawns.py は verse.txt をスクリプトと同じフォルダから読む
        string verseTxtPath = Path.Combine(exeDir, "verse.txt");
        try
        {
            File.WriteAllText(verseTxtPath, verseCode, Encoding.UTF8);
        }
        catch (Exception ex)
        {
            Error("verse.txt への書き出し失敗: " + ex.Message);
            return null;
        }

        // python parse_spawns.py を実行
        try
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("parse_spawns.py を実行しています...");
            Console.ResetColor();

            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "python",
                Arguments = $"\"{parseScriptPath}\"",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                WorkingDirectory = exeDir,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };

            using var proc = System.Diagnostics.Process.Start(psi);
            if (proc == null)
            {
                Error("python プロセスを起動できませんでした。");
                return null;
            }

            string stdout = proc.StandardOutput.ReadToEnd();
            string stderr = proc.StandardError.ReadToEnd();
            proc.WaitForExit();

            if (proc.ExitCode != 0)
            {
                Warn($"parse_spawns.py がエラーコード {proc.ExitCode} で終了しました。");
                if (!string.IsNullOrWhiteSpace(stderr))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(stderr);
                    Console.ResetColor();
                }
            }

            if (string.IsNullOrWhiteSpace(stdout))
            {
                Warn("parse_spawns.py が出力を返しませんでした。");
                if (!string.IsNullOrWhiteSpace(stderr))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(stderr);
                    Console.ResetColor();
                }
                return stdout;
            }

            return stdout;
        }
        catch (Exception ex)
        {
            Error("parse_spawns.py 実行エラー: " + ex.Message);
            return null;
        }
        finally
        {
            try { if (File.Exists(verseTxtPath)) File.Delete(verseTxtPath); }
            catch {}
        }
    }

    private static string? RecoverVerseCode(
        string containerDir, string aesKeyHex, string? pakGuid, string? usmapPath)
    {
        FAesKey mapKey;
        try
        {
            var hex = aesKeyHex.StartsWith("0x", StringComparison.OrdinalIgnoreCase)
                ? aesKeyHex : ("0x" + aesKeyHex);
            mapKey = new FAesKey(hex);
        }
        catch (Exception ex)
        {
            Error("AES キー形式エラー: " + ex.Message);
            return null;
        }
        string? fortniteInstallDir = null;
        try
        {
            var paks = FortnitePathLocator.FindFortnitePaksFolder();
            fortniteInstallDir = Path.GetFullPath(Path.Combine(paks, "..", "..", ".."));
        }
        catch { }

        string providerRoot = fortniteInstallDir ?? containerDir;

        using var provider = new DefaultFileProvider(
            providerRoot,
            SearchOption.AllDirectories,
            new VersionContainer(EGame.GAME_UE5_8));

        if (!string.IsNullOrEmpty(usmapPath) && File.Exists(usmapPath))
        {
            try
            {
                provider.MappingsContainer = new FileUsmapTypeMappingsProvider(usmapPath);
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("[MAP] mappings loaded: " + Path.GetFileName(usmapPath));
                Console.ResetColor();
            }
            catch (Exception ex)
            {
                Warn("mappings 読み込み失敗: " + ex.Message);
            }
        }

        try
        {
            provider.Initialize();

            foreach (var (guid, key) in _fortniteAesKeys)
                provider.SubmitKey(guid, key);
            var zeroKey = new FAesKey("0x0000000000000000000000000000000000000000000000000000000000000000");
            provider.SubmitKey(new FGuid(), zeroKey);
            provider.SubmitKey(new FGuid(), mapKey);
            if (!string.IsNullOrWhiteSpace(pakGuid))
            {
                var hex2 = pakGuid.Replace("-", "").Replace("{", "").Replace("}", "");
                if (hex2.Length == 32)
                    provider.SubmitKey(new FGuid(hex2), mapKey);
            }

            var containerDirFull = Path.GetFullPath(containerDir);
            var providerRootFull = Path.GetFullPath(providerRoot);
            bool containerOutside = !containerDirFull.StartsWith(providerRootFull, StringComparison.OrdinalIgnoreCase);

            if (containerOutside)
            {
                foreach (var utoc in Directory.EnumerateFiles(containerDir, "*.utoc", SearchOption.TopDirectoryOnly))
                {
                    try
                    {
                        provider.RegisterVfs(utoc);
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("[VFS] " + Path.GetFileName(utoc));
                        Console.ResetColor();
                    }
                    catch (Exception ex) { Warn("RegisterVfs 失敗 " + Path.GetFileName(utoc) + ": " + ex.Message); }
                }
                foreach (var pak in Directory.EnumerateFiles(containerDir, "*.pak", SearchOption.TopDirectoryOnly))
                {
                    try
                    {
                        provider.RegisterVfs(pak);
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("[VFS] " + Path.GetFileName(pak));
                        Console.ResetColor();
                    }
                    catch (Exception ex) { Warn("RegisterVfs 失敗 " + Path.GetFileName(pak) + ": " + ex.Message); }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("[VFS] コンテナは Fortnite ディレクトリ内 — AllDirectories スキャンで自動登録済み");
                Console.ResetColor();
            }

            provider.PostMount();
        }
        catch (Exception ex)
        {
            Error("ファイルプロバイダー初期化失敗: " + ex.Message);
            return null;
        }

        const string verseGuid = "d66cb9b1-4ae0-a552-f882-50be01682c3a";
        const string expectedSuffix = "/Content/_Verse.uasset";

        static string NormPath(string p) => p.Replace('\\', '/');

        GameFile? verseFile = provider.Files.Values.FirstOrDefault(f =>
        {
            var p = NormPath(f.Path);
            return p.Contains(verseGuid, StringComparison.OrdinalIgnoreCase)
                && p.EndsWith(expectedSuffix, StringComparison.OrdinalIgnoreCase);
        });

        if (verseFile == null)
        {
            Error($"_Verse.uasset が見つかりません。");
            Warn($"期待パス: FortniteGame/Plugins/GameFeatures/{verseGuid}/Content/_Verse.uasset");
            var related = provider.Files.Values
                .Where(f => NormPath(f.Path).Contains(verseGuid, StringComparison.OrdinalIgnoreCase))
                .Take(20).ToList();
            if (related.Count > 0)
            {
                Warn($"{verseGuid} を含むファイル ({related.Count} 件):");
                foreach (var f in related) Warn("  " + f.Path);
            }
            else
            {
                Warn($"{verseGuid} を含むファイルがマウントされていません。");
                Warn($"マウントされたファイル数: {provider.Files.Count}");
                foreach (var f in provider.Files.Values.Take(20)) Warn("  " + f.Path);
            }
            return null;
        }

        if (verseFile == null)
        {
            Error("_Verse.uasset が見つかりません。");
            return null;
        }

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"[OK] {verseFile.Path}");
        Console.ResetColor();

        try
        {
            provider.ReadScriptData = true;
            var package = provider.LoadPackage(verseFile);
            var rawBytes = verseFile.Read();
            return VerseDeclarationRecovery.FromPackage(package, VerseBodyMode.Rebuilt);
        }
        catch (Exception ex)
        {
            Error("Verse 復元エラー: " + ex.Message);
            return null;
        }
    }

    private static string? _cachedFortniteVersion;

    private static async Task<string?> FetchMappings(string dataDir)
    {
        try
        {
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
            using var metaDoc = JsonDocument.Parse(
                await client.GetStringAsync("https://uedb.dev/svc/api/v1/fortnite/mappings"));

            _cachedFortniteVersion = metaDoc.RootElement.GetProperty("version").GetString();
            var zstUrl = metaDoc.RootElement
                .GetProperty("mappings")
                .GetProperty("ZStandard")
                .GetString();
            if (string.IsNullOrEmpty(zstUrl)) return null;
            var safeName = Regex.Replace(_cachedFortniteVersion ?? "mappings", @"[^\w\-\+\.]", "_");
            string usmapPath = Path.Combine(dataDir, safeName + ".usmap");
            if (File.Exists(usmapPath))
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("[MAP] キャッシュ済み mappings を使用: " + Path.GetFileName(usmapPath));
                Console.ResetColor();
                return usmapPath;
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("[MAP] mappings ダウンロード中...");
            Console.ResetColor();
            var compressedBytes = await client.GetByteArrayAsync(zstUrl);
            File.WriteAllBytes(usmapPath, compressedBytes);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("[MAP] mappings 保存: " + Path.GetFileName(usmapPath));
            Console.ResetColor();
            return usmapPath;
        }
        catch (Exception ex)
        {
            Warn("mappings 取得失敗: " + ex.Message);
            return null;
        }
    }

    private static async Task FetchFortniteAesKeys()
    {
        try
        {
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
            using var doc = JsonDocument.Parse(
                await client.GetStringAsync("https://uedb.dev/svc/api/v1/fortnite/aes"));
            var mainKeyStr = doc.RootElement.GetProperty("mainKey").GetString();
            if (!string.IsNullOrEmpty(mainKeyStr))
                _fortniteAesKeys.Add((new FGuid(), new FAesKey(mainKeyStr)));
            foreach (var dk in doc.RootElement.GetProperty("dynamicKeys").EnumerateArray())
            {
                var guidStr = dk.GetProperty("guid").GetString() ?? "";
                var keyStr  = dk.GetProperty("key").GetString()  ?? "";
                if (guidStr.Length == 32 && !string.IsNullOrEmpty(keyStr))
                    _fortniteAesKeys.Add((new FGuid(guidStr), new FAesKey(keyStr)));
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"[AES] {_fortniteAesKeys.Count} キー取得済み");
            Console.ResetColor();
        }
        catch (Exception ex)
        {
            Warn("AES キー取得失敗: " + ex.Message);
        }
    }
    private static string? GetFortniteVersionString() => _cachedFortniteVersion;
    private static void Error(string msg)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine("[ERROR] " + msg);
        Console.ResetColor();
    }

    private static void Warn(string msg)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("[WARN] " + msg);
        Console.ResetColor();
    }

    private static void Pause()
    {
        Console.Write("Press Enter to exit...");
        Console.ReadLine();
    }
}
