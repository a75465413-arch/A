import re
from pathlib import Path
VERSE_FILE = Path(__file__).parent / "verse.txt"
text = VERSE_FILE.read_text(encoding="utf-8")

def parse_id_module(module_name: str) -> dict[int, str]:
    pattern = rf"{re.escape(module_name)}<concrete> := module:(.*?)(?=\n# |\Z)"
    m = re.search(pattern, text, re.DOTALL)
    if not m:
        return {}
    block = m.group(1)
    result = {}
    for name, val in re.findall(r"(\w+):int\s*=\s*(\d+)", block):
        result[int(val)] = name
    return result

CHAR_IDS   = parse_id_module("CharacterIDs")
TYPE_IDS   = parse_id_module("CharacterTypeIDs")
def resolve_character(char_field: str) -> str:
    m = re.search(r"CharacterId\s*:=\s*CharacterIDs\.(\w+)", char_field)
    if m:
        return m.group(1)
    m = re.search(r"GetFunc\s*:=\s*(\w+)", char_field)
    if m:
        return f"[func] {m.group(1)}"
    return char_field.strip()

def resolve_type(type_field: str) -> str:
    m = re.search(r"Type\s*:=\s*(\d+)", type_field)
    if m:
        type_id = int(m.group(1))
        type_name = TYPE_IDS.get(type_id, str(type_id))
        return f"{type_name} (id={type_id})"
    m = re.search(r"GetFunc\s*:=\s*(\w+)", type_field)
    if m:
        return f"[func] {m.group(1)}"
    return type_field.strip()

def parse_weekly_time(swt: str) -> str:
    h_m = re.search(r"([\d.]+)\s*\*\s*_Root\.OneHour\s*\+\s*([\d.]+)\s*\*\s*_Root\.OneMinute\s*\+\s*([\d.]+)\s*-\s*([\d.]+)\s*\*\s*_Root\.OneHour", swt)
    if h_m:
        h   = float(h_m.group(1))
        m   = float(h_m.group(2))
        s   = float(h_m.group(3))
        off = float(h_m.group(4))
        sign = "-" if off >= 0 else "+"
        return f"{int(h):02d}:{int(m):02d}:{int(s):02d} (UTC{sign}{int(abs(off))})"
    return swt.strip()

def find_matching_brace(s: str, start: int) -> int:
    depth = 0
    i = start
    while i < len(s):
        if s[i] == "{":
            depth += 1
        elif s[i] == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1

main_line_match = re.search(r"MainScript\s*:=\s*array\{(.+)", text)
if not main_line_match:
    raise SystemExit("MainScript が見つかりません")

main_content = main_line_match.group(1)
spawns = []
pattern_conditional = re.compile(
    r"if\s*\(GetRandomFloat\(0\.0,\s*1\.0\)\s*<=\s*([\d.]+)\)\s*then\s*event_action_spawn_character\{"
)

processed_spans = []

for m in pattern_conditional.finditer(main_content):
    prob = float(m.group(1))
    brace_start = m.end() - 1
    brace_end   = find_matching_brace(main_content, brace_start)
    if brace_end == -1:
        continue
    block = main_content[brace_start + 1 : brace_end]
    processed_spans.append((m.start(), brace_end + 1))
    look_back = main_content[max(0, m.start() - 600) : m.start()]
    spawn_count_m = None
    for hit in re.finditer(r"SpawningAround(\d+)Level\d+", look_back):
        spawn_count_m = hit
    spawn_count = int(spawn_count_m.group(1)) if spawn_count_m else None
    swt_m = re.search(r"StartWeeklyTime\s*:=\s*([^,]+)", block)
    weekly_time = parse_weekly_time(swt_m.group(1)) if swt_m else "?"
    char_m = re.search(r"Character\s*:=\s*(spawn_character_[^,}]+)", block)
    character = resolve_character(char_m.group(1)) if char_m else "?"
    type_m = re.search(r"Type\s*:=\s*(spawn_type_[^,}]+)", block)
    spawn_type = resolve_type(type_m.group(1)) if type_m else "?"
    level_m = re.search(r"Level\s*:=\s*(\d+)", block)
    level = int(level_m.group(1)) if level_m else "?"
    amount_m = re.search(r"Amount\s*:=\s*(\d+)", block)
    amount = int(amount_m.group(1)) if amount_m else 1
    conveyor_m = re.search(r"OnLuckConveyor\s*:=\s*option\{(\d+)\}", block)
    conveyor = int(conveyor_m.group(1)) if conveyor_m else None

    spawns.append({
        "character":    character,
        "level":        level,
        "probability":  prob,
        "spawn_type":   spawn_type,
        "amount":       amount,
        "conveyor":     conveyor,
        "weekly_time":  weekly_time,
        "conditional":  True,
        "spawn_count":  spawn_count,
    })
pattern_direct = re.compile(r"event_action_spawn_character\{")
for m in pattern_direct.finditer(main_content):
    if any(s <= m.start() < e for s, e in processed_spans):
        continue

    brace_start = m.end() - 1
    brace_end   = find_matching_brace(main_content, brace_start)
    if brace_end == -1:
        continue
    block = main_content[brace_start + 1 : brace_end]

    swt_m   = re.search(r"StartWeeklyTime\s*:=\s*([^,]+)", block)
    weekly_time = parse_weekly_time(swt_m.group(1)) if swt_m else "?"

    char_m  = re.search(r"Character\s*:=\s*(spawn_character_[^,}]+)", block)
    character = resolve_character(char_m.group(1)) if char_m else "?"

    type_m  = re.search(r"Type\s*:=\s*(spawn_type_[^,}]+)", block)
    spawn_type = resolve_type(type_m.group(1)) if type_m else "?"

    level_m = re.search(r"Level\s*:=\s*(\d+)", block)
    level   = int(level_m.group(1)) if level_m else "?"

    amount_m = re.search(r"Amount\s*:=\s*(\d+)", block)
    amount = int(amount_m.group(1)) if amount_m else 1

    conveyor_m = re.search(r"OnLuckConveyor\s*:=\s*option\{(\d+)\}", block)
    conveyor = int(conveyor_m.group(1)) if conveyor_m else None

    spawns.append({
        "character":    character,
        "level":        level,
        "probability":  None,
        "spawn_type":   spawn_type,
        "amount":       amount,
        "conveyor":     conveyor,
        "weekly_time":  weekly_time,
        "conditional":  False,
    })

conditional = [s for s in spawns if s["conditional"]]
conditional.sort(key=lambda s: s["probability"] if s["probability"] is not None else 0, reverse=True)

for i, s in enumerate(conditional, 1):
    prob_str  = f"{s['probability']*100:.1f}%"
    count_str = f"{s['spawn_count']:,}" if s.get("spawn_count") is not None else "?"
    print(f"{i:<4} {s['character']:<35} lvl{s['level']:<6} {prob_str:<10} {count_str}")
