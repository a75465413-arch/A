// Stub for VerseExpressionWriter — the full implementation requires additional
// FModel source files not included in this project.  VerseLegacyBodyWriter uses
// this class for its legacy (non-structured) code path; without it the structured
// code path in VerseBodyWriter / VersePrinter is still fully functional.

using System.Collections.Generic;
using CUE4Parse.UE4.Kismet;

namespace FModel.Services.Verse;

internal sealed class VerseExpressionWriter
{
    public VerseExpressionWriter(VerseTypeResolver resolver,
        Dictionary<string, string> localNames,
        string? returnSlot)
    { }

    /// <summary>Render a single Kismet expression as a Verse text fragment.</summary>
    public string Write(KismetExpression expression)
        => $"# <legacy expression: {expression.GetType().Name}>";

    /// <summary>Returns the callee name of a final-function call, or null.</summary>
    public static string? CalleeName(KismetExpression expression)
    {
        if (expression is not EX_FinalFunction f) return null;
        var parts = f.StackNode?.ToString()?.Split(':');
        if (parts == null || parts.Length == 0) return null;
        return parts[parts.Length - 1].Trim('\'');
    }

    /// <summary>
    /// True for runtime-only housekeeping statements that carry no Verse semantics
    /// (e.g. EX_Nothing, EX_EndOfScript, EX_Return with no value).
    /// </summary>
    public static bool IsHousekeeping(KismetExpression expression)
        => expression is EX_Nothing or EX_EndOfScript;
}
