(()=>{function o(e){postMessage({source:"MINT",...e})}function l(e){o(e)}})();
