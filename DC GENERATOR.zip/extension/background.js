// ローカル実行のためのバックグラウンドスクリプト
(()=>{
  
  console.log('Local extension background loaded');

  const DEFAULT_SETTINGS = {
    version: 1,
    enabled: true,
    key: "",
    hcaptcha_auto_solve: true,
  };
  
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getSettings') {
      chrome.storage.local.get('settings', (result) => {
        const settings = result.settings || DEFAULT_SETTINGS;
        sendResponse(settings);
      });
      return true;
    }
    
    if (request.action === 'updateSettings') {
      chrome.storage.local.set({ settings: request.settings }, () => {
        sendResponse({ ok: true });
      });
      return true;
    }
    
    sendResponse(null);
  });
  
  // コンテンツスクリプトの登録
  if (chrome.scripting) {
    chrome.scripting.getRegisteredContentScripts().catch(() => {
      // コンテンツスクリプトが登録されていない場合
      console.log('Content scripts not yet registered');
    });
  }
})();
