(()=>{
  console.log('Extension loaded for local captcha solving');
})();
