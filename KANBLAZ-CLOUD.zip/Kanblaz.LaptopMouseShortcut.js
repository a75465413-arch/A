// Registered by the native host ONLY on detected laptops. No global keyboard hook.
(() => {
  'use strict';
  if (window.top !== window) return;
  const host = location.hostname.toLowerCase();
  if (location.protocol !== 'https:' || !(
    ((host === 'www.xbox.com' || host === 'xbox.com') && /^\/(?:[a-z]{2}-[a-z]{2}\/)?play(?:\/|$)/i.test(location.pathname)) ||
    host === 'play.xbox.com' || host === 'play.geforcenow.com' ||
    (host === 'luna.amazon.com' && !/^\/(?:ap|signin|login|auth)(?:\/|$)/i.test(location.pathname))
  )) return;

  let ownsQ = false;
  const isQ = event => typeof event.key === 'string' && event.key.toLowerCase() === 'q';
  const stop = event => { event.preventDefault(); event.stopImmediatePropagation(); };
  window.addEventListener('keydown', event => {
    if (!event.isTrusted || !isQ(event)) return;
    if (ownsQ) { stop(event); return; }
    if (event.repeat || event.ctrlKey || event.altKey || event.metaKey || event.shiftKey) return;
    if (!document.pointerLockElement) return;
    const field = document.activeElement;
    if (field && (field.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(field.tagName))) return;
    if (!window.chrome || !window.chrome.webview) return;
    // Inform only the Kanblaz host. It performs the same native release as F1/F9.
    window.chrome.webview.postMessage('kanblaz.release-mouse.q.v1');
    ownsQ = true;
    stop(event);
  }, true);
  window.addEventListener('keyup', event => {
    if (event.isTrusted && isQ(event) && ownsQ) { ownsQ = false; stop(event); }
  }, true);
  // Key-up may occur in another native window after the mouse was released.
  window.addEventListener('focus', () => { ownsQ = false; }, true);
})();
