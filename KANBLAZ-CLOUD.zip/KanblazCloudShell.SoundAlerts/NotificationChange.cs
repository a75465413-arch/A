namespace KanblazCloudShell.SoundAlerts;

internal enum NotificationChange
{
	Ignored,
	Updated,
	Added
}
