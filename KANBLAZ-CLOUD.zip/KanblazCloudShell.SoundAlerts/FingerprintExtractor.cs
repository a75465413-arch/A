using System;
using System.Collections.Generic;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class FingerprintExtractor
{
	internal const int Rate = 16000;

	internal const int Size = 1024;

	internal const int Hop = 256;

	private readonly double[] real = new double[1024];

	private readonly double[] imaginary = new double[1024];

	private readonly double[] window = new double[1024];

	private readonly double[] previous = new double[33];

	private readonly int[] edges = new int[34];

	private bool hasPrevious;

	internal FingerprintExtractor()
	{
		for (int i = 0; i < 1024; i++)
		{
			window[i] = 0.5 - 0.5 * Math.Cos(Math.PI * 2.0 * (double)i / 1023.0);
		}
		for (int j = 0; j < edges.Length; j++)
		{
			edges[j] = Math.Max((j == 0) ? 1 : (edges[j - 1] + 1), (int)Math.Round(100.0 * Math.Pow(70.0, (double)j / 33.0) * 1024.0 / 16000.0));
		}
	}

	internal void Reset()
	{
		hasPrevious = false;
		Array.Clear(previous, 0, previous.Length);
	}

	internal AudioPrint Extract(short[] samples)
	{
		double num = 0.0;
		for (int i = 0; i < 1024; i++)
		{
			double num2 = (double)samples[i] / 32768.0;
			real[i] = num2 * window[i];
			imaginary[i] = 0.0;
			num += num2 * num2;
		}
		Transform(real, imaginary);
		double[] array = new double[33];
		for (int j = 0; j < array.Length; j++)
		{
			double num3 = 0.0;
			for (int k = edges[j]; k < edges[j + 1]; k++)
			{
				num3 += real[k] * real[k] + imaginary[k] * imaginary[k];
			}
			array[j] = Math.Log(1E-12 + num3 / (double)(edges[j + 1] - edges[j]));
		}
		uint num4 = 0u;
		uint num5 = 0u;
		for (int l = 0; l < 32; l++)
		{
			double num6 = array[l] - array[l + 1];
			if (num6 > 0.0)
			{
				num4 |= (uint)(1 << l);
			}
			if (hasPrevious && num6 > previous[l] - previous[l + 1])
			{
				num5 |= (uint)(1 << l);
			}
		}
		Array.Copy(array, previous, 33);
		bool audible = hasPrevious && num / 1024.0 > 2.5E-07;
		hasPrevious = true;
		return new AudioPrint
		{
			Spectrum = num4,
			Change = num5,
			Audible = audible
		};
	}

	private static void Transform(double[] r, double[] im)
	{
		int num = r.Length;
		int i = 1;
		int num2 = 0;
		for (; i < num; i++)
		{
			int num3 = num >> 1;
			while ((num2 & num3) != 0)
			{
				num2 ^= num3;
				num3 >>= 1;
			}
			num2 ^= num3;
			if (i < num2)
			{
				double num4 = r[i];
				r[i] = r[num2];
				r[num2] = num4;
			}
		}
		for (int num5 = 2; num5 <= num; num5 <<= 1)
		{
			double num6 = Math.PI * -2.0 / (double)num5;
			double num7 = Math.Cos(num6);
			double num8 = Math.Sin(num6);
			for (int j = 0; j < num; j += num5)
			{
				double num9 = 1.0;
				double num10 = 0.0;
				for (int k = 0; k < num5 / 2; k++)
				{
					int num11 = j + k;
					int num12 = num11 + num5 / 2;
					double num13 = r[num12] * num9 - im[num12] * num10;
					double num14 = r[num12] * num10 + im[num12] * num9;
					r[num12] = r[num11] - num13;
					im[num12] = im[num11] - num14;
					r[num11] += num13;
					im[num11] += num14;
					double num15 = num9 * num7 - num10 * num8;
					num10 = num9 * num8 + num10 * num7;
					num9 = num15;
				}
			}
		}
	}

	internal static AudioPrint[] Fingerprint(short[] pcm)
	{
		FingerprintExtractor fingerprintExtractor = new FingerprintExtractor();
		short[] array = new short[1024];
		List<AudioPrint> list = new List<AudioPrint>();
		for (int i = 0; i + 1024 <= pcm.Length; i += 256)
		{
			Array.Copy(pcm, i, array, 0, 1024);
			list.Add(fingerprintExtractor.Extract(array));
		}
		return list.ToArray();
	}
}
