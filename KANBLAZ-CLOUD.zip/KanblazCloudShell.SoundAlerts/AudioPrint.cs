namespace KanblazCloudShell.SoundAlerts;

internal struct AudioPrint
{
	internal uint Spectrum;

	internal uint Change;

	internal bool Audible;
}
