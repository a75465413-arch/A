using System;
using System.Collections.Generic;
using System.Linq;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class SoundDetector
{
	internal const int MatchFrames = 32;

	internal const double MinimumScore = 0.78;

	private static readonly uint VoiceMask = CreateVoiceMask();

	private readonly SoundReference[] references;

	private readonly FingerprintExtractor extractor = new FingerprintExtractor();

	private readonly short[] pcm = new short[1024];

	private readonly AudioPrint[] recent = new AudioPrint[32];

	private int filled;

	private int frames;

	private int cursor;

	private int candidate = -1;

	private int confirmations;

	internal double BestObservedScore { get; private set; }

	internal event Action<SoundMatch> Detected;

	private static uint CreateVoiceMask()
	{
		uint num = 0u;
		for (int i = 0; i < 32; i++)
		{
			if (100.0 * Math.Pow(70.0, (double)i / 33.0) >= 300.0 && 100.0 * Math.Pow(70.0, (double)(i + 2) / 33.0) <= 4000.0)
			{
				num |= (uint)(1 << i);
			}
		}
		return num;
	}

	internal SoundDetector(SoundReference[] references)
	{
		this.references = references;
	}

	internal void Reset()
	{
		filled = (frames = (cursor = (confirmations = 0)));
		candidate = -1;
		extractor.Reset();
		Array.Clear(pcm, 0, pcm.Length);
		Array.Clear(recent, 0, recent.Length);
	}

	internal void Append(short[] samples, int count)
	{
		if (count < 0 || count > samples.Length)
		{
			throw new ArgumentOutOfRangeException("count");
		}
		int num = 0;
		while (num < count)
		{
			int num2 = Math.Min(pcm.Length - filled, count - num);
			Array.Copy(samples, num, pcm, filled, num2);
			num += num2;
			filled += num2;
			if (filled == pcm.Length)
			{
				recent[cursor] = extractor.Extract(pcm);
				cursor = (cursor + 1) % 32;
				frames++;
				if (frames >= 32 && frames % 4 == 0)
				{
					Match();
				}
				Array.Copy(pcm, 256, pcm, 0, pcm.Length - 256);
				filled -= 256;
			}
		}
	}

	private void Match()
	{
		if ((double)recent.Count((AudioPrint audioPrint3) => audioPrint3.Audible) < 27.2)
		{
			confirmations = 0;
			candidate = -1;
			return;
		}
		int winner = -1;
		double num = 0.0;
		double num2 = 0.0;
		Dictionary<string, double> dictionary = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
		for (int num3 = 0; num3 < references.Length; num3++)
		{
			double num4 = 0.0;
			AudioPrint[] array = references[num3].Frames;
			for (int num5 = 1; num5 + 32 <= array.Length; num5++)
			{
				int num6 = 0;
				int num7 = 0;
				for (int num8 = 0; num8 < 32; num8++)
				{
					AudioPrint audioPrint = recent[(cursor + num8) % 32];
					AudioPrint audioPrint2 = array[num5 + num8];
					num6 += PopCount(audioPrint.Spectrum ^ audioPrint2.Spectrum) + 2 * PopCount(audioPrint.Change ^ audioPrint2.Change);
					num7 += PopCount((audioPrint.Spectrum ^ audioPrint2.Spectrum) & VoiceMask) + 2 * PopCount((audioPrint.Change ^ audioPrint2.Change) & VoiceMask);
				}
				double num9 = 1.0 - (double)num6 / 3072.0;
				double num10 = 1.0 - (double)num7 / (96.0 * (double)PopCount(VoiceMask));
				double val = ((num9 >= 0.65) ? Math.Max(num9, num10 - 0.06) : num9);
				num4 = Math.Max(num4, val);
			}
			if (!dictionary.TryGetValue(references[num3].Name, out var value) || num4 > value)
			{
				dictionary[references[num3].Name] = num4;
			}
			if (num4 > num)
			{
				num = num4;
				winner = num3;
			}
		}
		if (winner >= 0)
		{
			num2 = (from p in dictionary
				where !string.Equals(p.Key, references[winner].Name, StringComparison.OrdinalIgnoreCase)
				select p.Value).DefaultIfEmpty(0.0).Max();
		}
		BestObservedScore = Math.Max(BestObservedScore, num);
		if (winner < 0 || num < 0.78 || num - num2 < 0.035)
		{
			confirmations = 0;
			candidate = -1;
			return;
		}
		confirmations = ((candidate < 0 || !(references[winner].Name == references[candidate].Name)) ? 1 : (confirmations + 1));
		candidate = winner;
		if (confirmations == 2)
		{
			Detected?.Invoke(new SoundMatch
			{
				Name = references[winner].Name,
				Score = num
			});
		}
	}

	private static int PopCount(uint value)
	{
		value -= (value >> 1) & 0x55555555;
		value = (value & 0x33333333) + ((value >> 2) & 0x33333333);
		value = (value + (value >> 4)) & 0xF0F0F0F;
		return (int)(value * 16843009 >> 24);
	}
}
