using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class ProcessAudioMonitor : IDisposable
{
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate void Samples(IntPtr data, int count, int flags);

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	private struct OsVersion
	{
		internal int Size;

		internal int Major;

		internal int Minor;

		internal int Build;

		internal int Platform;

		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
		internal string ServicePack;
	}

	private readonly uint processId;

	private readonly ManualResetEvent stop = new ManualResetEvent(initialState: false);

	private readonly SoundDetector detector;

	private readonly int referenceCount;

	private readonly Samples callback;

	private readonly Thread thread;

	private readonly Stopwatch clock = Stopwatch.StartNew();

	private readonly object lifetime = new object();

	private short[] samples = new short[2048];

	private volatile bool disposed;

	private bool finished;

	private double lastPacket;

	internal static bool Supported
	{
		get
		{
			OsVersion version = new OsVersion
			{
				Size = Marshal.SizeOf(typeof(OsVersion))
			};
			if (RtlGetVersion(ref version) == 0 && version.Major >= 10)
			{
				return version.Build >= 20348;
			}
			return false;
		}
	}

	internal event Action<SoundMatch> Detected;

	internal event Action<string> StatusChanged;

	[DllImport("Kanblaz.ProcessAudio.dll", CallingConvention = CallingConvention.StdCall)]
	private static extern int KanblazCaptureRun(uint processId, IntPtr stop, Samples callback);

	[DllImport("ntdll.dll", CharSet = CharSet.Unicode)]
	private static extern int RtlGetVersion(ref OsVersion version);

	internal ProcessAudioMonitor(uint processId, SoundReference[] references)
	{
		if (processId == 0 || processId == (uint)Process.GetCurrentProcess().Id)
		{
			throw new ArgumentException("An isolated browser process is required.");
		}
		this.processId = processId;
		detector = new SoundDetector(references);
		referenceCount = references.Length;
		detector.Detected += (SoundMatch match) =>
		{
			Action<SoundMatch> action = Detected;
			if (!disposed)
			{
				action?.Invoke(match);
			}
		};
		callback = Receive;
		thread = new Thread(Run)
		{
			IsBackground = true,
			Name = "Kanblaz sound detector"
		};
		thread.SetApartmentState(ApartmentState.MTA);
	}

	internal void Start()
	{
		thread.Start();
	}

	private void Publish(string value)
	{
		Action<string> action = StatusChanged;
		if (!disposed)
		{
			action?.Invoke(value);
		}
	}

	private void Run()
	{
		try
		{
			if (!Supported)
			{
				Publish("Detector unavailable: requires Windows 11 or build 20348+.");
			}
			else if (!disposed)
			{
				int num = KanblazCaptureRun(processId, stop.SafeWaitHandle.DangerousGetHandle(), callback);
				if (num < 0)
				{
					Publish("Detector unavailable (audio 0x" + num.ToString("X8") + "). System-wide audio is not captured.");
				}
			}
		}
		catch (DllNotFoundException)
		{
			Publish("Detector unavailable: Kanblaz.ProcessAudio.dll is missing.");
		}
		catch (Exception)
		{
			Publish("Detector stopped: this session's audio could not be isolated.");
		}
		finally
		{
			GC.KeepAlive(callback);
			lock (lifetime)
			{
				finished = true;
				stop.Dispose();
			}
			Array.Clear(samples, 0, samples.Length);
			detector.Reset();
		}
	}

	private void Receive(IntPtr data, int count, int flags)
	{
		if (disposed)
		{
			return;
		}
		try
		{
			if (flags == 2)
			{
				Publish("Detector active · " + referenceCount + " sounds · local analysis");
				return;
			}
			if (count <= 0 || count > 16000)
			{
				detector.Reset();
				return;
			}
			double totalSeconds = clock.Elapsed.TotalSeconds;
			if (flags == 1 || totalSeconds - lastPacket > 0.4)
			{
				detector.Reset();
			}
			lastPacket = totalSeconds;
			if (samples.Length < count)
			{
				samples = new short[count];
			}
			if (data == IntPtr.Zero)
			{
				Array.Clear(samples, 0, count);
			}
			else
			{
				Marshal.Copy(data, samples, 0, count);
			}
			detector.Append(samples, count);
		}
		catch
		{
			Publish("Detector stopped because of an audio analysis error.");
			Dispose();
		}
	}

	public void Dispose()
	{
		lock (lifetime)
		{
			if (!disposed)
			{
				disposed = true;
				if (!finished)
				{
					stop.Set();
				}
			}
		}
	}
}
