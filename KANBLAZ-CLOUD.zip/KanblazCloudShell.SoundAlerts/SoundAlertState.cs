using System;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class SoundAlertState
{
	internal const int DurationSeconds = 32;

	private double end = double.NegativeInfinity;

	private double nextAllowed = double.NegativeInfinity;

	internal string SoundName { get; private set; }

	internal bool Trigger(string sound, double now)
	{
		if (string.IsNullOrEmpty(sound) || now < nextAllowed)
		{
			return false;
		}
		SoundName = sound;
		end = now + 32.0;
		nextAllowed = end + 2.0;
		return true;
	}

	internal int Remaining(double now)
	{
		if (!(now >= end))
		{
			return Math.Max(0, (int)Math.Ceiling(Math.Min(32.0, end - now)));
		}
		return 0;
	}

	internal void Clear()
	{
		end = (nextAllowed = double.NegativeInfinity);
		SoundName = null;
	}
}
