using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class SoundAlertOverlay : Form
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	private struct BlendFunction
	{
		internal byte Operation;

		internal byte Flags;

		internal byte Alpha;

		internal byte Format;
	}

	private readonly Control surface;

	private readonly ExternalAlertTarget clickTarget;

	private string caption = string.Empty;

	private string soundName = string.Empty;

	private int secondsLeft;

	private bool requested;

	private bool synchronizing;

	private bool artworkDirty = true;

	private bool visualNotice;

	private bool borderOnly;

	private bool compactMode;

	private NotificationEvent[] groupEvents;

	private NotificationEvent[] sessionEvents;

	private static readonly List<SoundAlertOverlay> Active = new List<SoundAlertOverlay>();

	protected override bool ShowWithoutActivation => true;

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 134742184;
			createParams.Style |= 134217728;
			return createParams;
		}
	}

	[DllImport("user32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr destinationDc, ref Point position, ref Size size, IntPtr sourceDc, ref Point source, uint key, ref BlendFunction blend, uint flags);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern IntPtr CreateCompatibleDC(IntPtr dc);

	[DllImport("gdi32.dll")]
	private static extern bool DeleteDC(IntPtr dc);

	[DllImport("gdi32.dll")]
	private static extern IntPtr SelectObject(IntPtr dc, IntPtr value);

	[DllImport("gdi32.dll")]
	private static extern bool DeleteObject(IntPtr value);

	[DllImport("user32.dll")]
	private static extern bool ShowWindow(IntPtr window, int command);

	[DllImport("user32.dll")]
	private static extern bool SetForegroundWindow(IntPtr window);

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);

	internal SoundAlertOverlay(Control surface)
	{
		if (surface == null)
		{
			throw new ArgumentNullException("surface");
		}
		this.surface = surface;
		clickTarget = new ExternalAlertTarget(ReturnToGame);
		SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		SetStyle(ControlStyles.Selectable, value: false);
		FormBorderStyle = FormBorderStyle.None;
		StartPosition = FormStartPosition.Manual;
		ShowInTaskbar = false;
		TopMost = true;
		Enabled = false;
		AutoScaleMode = AutoScaleMode.None;
		MinimizeBox = (MaximizeBox = (ControlBox = false));
		TabStop = false;
		Visible = false;
		AccessibleName = "Sound alert";
		surface.Disposed += SurfaceDisposed;
	}

	protected override void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		artworkDirty = true;
	}

	protected override void WndProc(ref Message message)
	{
		if (message.Msg == 132)
		{
			message.Result = new IntPtr(-1);
		}
		else if (message.Msg == 33)
		{
			message.Result = new IntPtr(3);
		}
		else
		{
			base.WndProc(ref message);
		}
	}

	internal void ShowAlert(string sound, int seconds, bool visual = false)
	{
		visualNotice = visual;
		if (!IsDisposed)
		{
			soundName = sound ?? string.Empty;
			secondsLeft = Math.Max(0, Math.Min(32, seconds));
			caption = soundName + "  ·  " + secondsLeft + " s";
			Text = "KANBLAZ · " + caption;
			AccessibleDescription = caption;
			requested = true;
			if (!Active.Contains(this))
			{
				Active.Add(this);
			}
			artworkDirty = true;
			Synchronize();
		}
	}

	internal void ShowGroup(NotificationEvent[] events, int seconds)
	{
		sessionEvents = null;
		groupEvents = events;
		borderOnly = false;
		ShowAlert("Notifications", seconds);
	}

	internal void ShowBorder(string sound, int seconds, bool visual)
	{
		sessionEvents = null;
		groupEvents = null;
		borderOnly = true;
		ShowAlert(sound, seconds, visual);
	}

	internal void ShowSession(NotificationEvent[] events, int seconds)
	{
		NotificationEvent notificationEvent = events[0];
		if (requested && sessionEvents != null && soundName == notificationEvent.Caption && secondsLeft == seconds)
		{
			Synchronize();
			return;
		}
		sessionEvents = events;
		groupEvents = null;
		borderOnly = false;
		ShowAlert(notificationEvent.Caption, seconds, notificationEvent.Visual);
	}

	internal static bool NeedsFloating(Control surface)
	{
		Form form = surface.TopLevelControl as Form;
		if (surface.IsDisposed || form == null || form.IsDisposed || form.WindowState == FormWindowState.Minimized || !form.Visible || !surface.Visible)
		{
			return true;
		}
		IntPtr foregroundWindow = GetForegroundWindow();
		GetWindowThreadProcessId(foregroundWindow, out var process);
		return ExternalApplicationActive(foregroundWindow != IntPtr.Zero, process, (uint)Process.GetCurrentProcess().Id);
	}

	internal static bool ExternalApplicationActive(bool hasForeground, uint foregroundPid, uint ownPid)
	{
		if (hasForeground && foregroundPid != 0)
		{
			return foregroundPid != ownPid;
		}
		return false;
	}

	internal void Synchronize()
	{
		if (IsDisposed || synchronizing)
		{
			return;
		}
		synchronizing = true;
		try
		{
			Form form = surface.TopLevelControl as Form;
			if (!requested || surface.IsDisposed || !surface.IsHandleCreated || form == null || form.IsDisposed || !form.IsHandleCreated)
			{
				clickTarget.Hide();
				if (Visible)
				{
					Hide();
				}
				return;
			}
			bool flag = NeedsFloating(surface);
			if (compactMode != flag)
			{
				compactMode = flag;
				artworkDirty = true;
			}
			if (borderOnly & flag)
			{
				clickTarget.Hide();
				if (Visible)
				{
					Hide();
				}
				return;
			}
			if (!flag)
			{
				clickTarget.Hide();
			}
			Rectangle rectangle;
			if (groupEvents != null)
			{
				Rectangle workingArea = Screen.FromControl(form).WorkingArea;
				int num = Math.Min(760, Math.Max(1, workingArea.Width - 24));
				int num2 = Math.Min(140 * groupEvents.Length, Math.Max(1, workingArea.Height - 24));
				rectangle = new Rectangle(workingArea.Right - num - 12, workingArea.Top + 12, num, num2);
			}
			else if (flag)
			{
				Rectangle workingArea2 = Screen.FromControl(form).WorkingArea;
				int num3 = 0;
				foreach (SoundAlertOverlay item in Active)
				{
					if (item == this)
					{
						break;
					}
					if (!item.IsDisposed && NeedsFloating(item.surface))
					{
						num3++;
					}
				}
				rectangle = BackgroundBounds(workingArea2, num3);
			}
			else
			{
				rectangle = surface.RectangleToScreen(surface.ClientRectangle);
				for (Control control = surface.Parent; control != null; control = control.Parent)
				{
					rectangle.Intersect(control.RectangleToScreen(control.ClientRectangle));
				}
			}
			if (rectangle.Width <= 0 || rectangle.Height <= 0)
			{
				clickTarget.Hide();
				if (Visible)
				{
					Hide();
				}
				return;
			}
			if (Bounds != rectangle)
			{
				Bounds = rectangle;
			}
			if (artworkDirty || !IsHandleCreated)
			{
				RenderLayer();
			}
			if (!Visible)
			{
				Show();
			}
			if (flag && !borderOnly)
			{
				Rectangle bounds = CompactClickBounds(ClientSize);
				bounds.Offset(Location);
				clickTarget.ShowAt(bounds, caption);
			}
		}
		finally
		{
			synchronizing = false;
		}
	}

	internal void HideAlert()
	{
		clickTarget.Hide();
		Active.Remove(this);
		requested = false;
		if (!IsDisposed)
		{
			Hide();
		}
		caption = string.Empty;
		AccessibleDescription = string.Empty;
	}

	internal static Rectangle CompactClickBounds(Size size)
	{
		float num = Math.Max(0f, Math.Min(1f, (float)(size.Width - 16) / 680f));
		return Rectangle.Intersect(new Rectangle(Point.Empty, size), new Rectangle(8 + (int)(4f * num), 8 + (int)(20f * num), Math.Max(1, (int)(672f * num)), Math.Max(1, (int)(96f * num))));
	}

	private void ReturnToGame()
	{
		if (!IsDisposed && requested && compactMode && secondsLeft > 0 && !surface.IsDisposed && surface.TopLevelControl is Form { IsDisposed: false, IsHandleCreated: not false } form)
		{
			clickTarget.Hide();
			if (form.WindowState == FormWindowState.Minimized)
			{
				ShowWindow(form.Handle, 9);
			}
			if (!form.Visible)
			{
				form.Show();
			}
			form.Activate();
			SetForegroundWindow(form.Handle);
			if (surface is CloudSessionForm cloudSessionForm)
			{
				cloudSessionForm.FocusFromNotification();
			}
			else
			{
				surface.Select();
			}
			Synchronize();
		}
	}

	internal static Rectangle BackgroundBounds(Rectangle area, int slot)
	{
		int num = Math.Min(696, Math.Max(1, area.Width - 24));
		int num2 = Math.Min(140, Math.Max(1, area.Height - 24));
		int num3 = Math.Max(1, (area.Height - 12) / (num2 + 12));
		int num4 = Math.Max(1, (area.Width - 12) / (num + 12));
		int num5 = Math.Max(0, slot) % (num3 * num4);
		return new Rectangle(area.Right - num - 12 - num5 / num3 * (num + 12), area.Top + 12 + num5 % num3 * (num2 + 12), num, num2);
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		base.OnSizeChanged(e);
		artworkDirty = true;
	}

	private void RenderLayer()
	{
		Region region = new Region(ClientRectangle);
		int num = Math.Min(135, Math.Min(ClientSize.Width, ClientSize.Height) / 4);
		if (groupEvents == null && ClientSize.Width > 2 * num && ClientSize.Height > 160 + num)
		{
			region.Exclude(new Rectangle(num, 160, ClientSize.Width - 2 * num, ClientSize.Height - 160 - num));
		}
		Region region2 = Region;
		Region = region;
		region2?.Dispose();
		using Bitmap bitmap = (compactMode ? SoundAlertArtwork.RenderCompact(ClientSize, soundName, secondsLeft, visualNotice, (sessionEvents != null) ? sessionEvents[0].Label : null) : ((sessionEvents != null) ? SoundAlertArtwork.RenderSession(ClientSize, sessionEvents, secondsLeft) : ((groupEvents != null) ? SoundAlertArtwork.RenderGroup(ClientSize, groupEvents, secondsLeft) : SoundAlertArtwork.Render(ClientSize, soundName, secondsLeft, visualNotice))));
		IntPtr intPtr = IntPtr.Zero;
		IntPtr intPtr2 = IntPtr.Zero;
		IntPtr intPtr3 = IntPtr.Zero;
		try
		{
			intPtr = CreateCompatibleDC(IntPtr.Zero);
			if (intPtr == IntPtr.Zero)
			{
				throw new Win32Exception(Marshal.GetLastWin32Error());
			}
			intPtr2 = bitmap.GetHbitmap(Color.FromArgb(0));
			intPtr3 = SelectObject(intPtr, intPtr2);
			if (intPtr3 == IntPtr.Zero || intPtr3 == new IntPtr(-1))
			{
				throw new Win32Exception("The alert graphic could not be prepared.");
			}
			Point position = Location;
			Size size = bitmap.Size;
			Point source = Point.Empty;
			BlendFunction blend = new BlendFunction
			{
				Alpha = byte.MaxValue,
				Format = 1
			};
			if (!UpdateLayeredWindow(Handle, IntPtr.Zero, ref position, ref size, intPtr, ref source, 0u, ref blend, 2u))
			{
				throw new Win32Exception(Marshal.GetLastWin32Error());
			}
			artworkDirty = false;
		}
		finally
		{
			if (intPtr3 != IntPtr.Zero && intPtr3 != new IntPtr(-1))
			{
				SelectObject(intPtr, intPtr3);
			}
			if (intPtr2 != IntPtr.Zero)
			{
				DeleteObject(intPtr2);
			}
			if (intPtr != IntPtr.Zero)
			{
				DeleteDC(intPtr);
			}
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
	}

	private void SurfaceDisposed(object sender, EventArgs e)
	{
		Dispose();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && !IsDisposed)
		{
			Active.Remove(this);
			clickTarget.Dispose();
			surface.Disposed -= SurfaceDisposed;
		}
		base.Dispose(disposing);
	}
}
