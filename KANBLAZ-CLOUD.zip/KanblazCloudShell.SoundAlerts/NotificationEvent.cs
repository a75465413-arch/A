namespace KanblazCloudShell.SoundAlerts;

internal sealed class NotificationEvent
{
	internal string Id;

	internal string Profile;

	internal string Label;

	internal string Caption;

	internal string Name;

	internal bool Visual;

	internal bool BellRequested;

	internal double Created;

	internal bool SpokenName;

	internal bool BrainrotVisual;

	internal bool NameConflict;

	internal string AudioName;

	internal string OcrName;

	internal string BaseCaption;

	internal float NameConfidence;
}
