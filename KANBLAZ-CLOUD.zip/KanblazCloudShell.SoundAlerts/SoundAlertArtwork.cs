using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;

namespace KanblazCloudShell.SoundAlerts;

internal static class SoundAlertArtwork
{
	private static readonly Lazy<Bitmap> SpriteIcon = new Lazy<Bitmap>(() =>
	{
		string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "sprite-notice.png");
		if (!File.Exists(text))
		{
			return (Bitmap)null;
		}
		using Image original = Image.FromFile(text);
		return new Bitmap(original);
	});

	private static readonly Lazy<Bitmap> SecretBoxIcon = new Lazy<Bitmap>(() =>
	{
		string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "grande-secret-box.png");
		if (!File.Exists(text))
		{
			return (Bitmap)null;
		}
		using Image original = Image.FromFile(text);
		return new Bitmap(original);
	});

	private static readonly Lazy<Bitmap> LuckyIcon = new Lazy<Bitmap>(() =>
	{
		string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "grande-lucky-rot.png");
		if (!File.Exists(text))
		{
			return (Bitmap)null;
		}
		using Image original = Image.FromFile(text);
		return new Bitmap(original);
	});

	internal static string DisplayCaption(string caption)
	{
		if (string.IsNullOrEmpty(caption))
		{
			return string.Empty;
		}
		string[] array = caption.Split(new string[1] { " — " }, StringSplitOptions.None);
		if (!array[0].EndsWith(" Brainrot Spawned!", StringComparison.Ordinal))
		{
			return caption;
		}
		string text = array[0].Substring(0, array[0].Length - " Brainrot Spawned!".Length);
		string text2 = null;
		if (array.Length > 1 && array[1].StartsWith("Rarity: ", StringComparison.Ordinal))
		{
			text2 = array[1].Substring(8);
		}
		string text3 = text2 ?? text;
		if (text == "Uncollected" && text2 == "Secret")
		{
			text3 = "Uncollected / Secret";
		}
		string text4 = text3;
		for (int i = 1; i < array.Length; i++)
		{
			if (!array[i].StartsWith("Rarity: ", StringComparison.Ordinal))
			{
				text4 = text4 + " — " + array[i];
			}
		}
		return text4;
	}

	internal static Color CompactColor(string name, bool visual)
	{
		if (SoundReferences.IsLuckyRot(name))
		{
			return Color.Gold;
		}
		if (IsSprite(name))
		{
			return Color.FromArgb(207, 126, 255);
		}
		if (HasVisualRarity(name, "Eternal") || (!visual && SoundReferences.IsEternal(name)))
		{
			return Color.FromArgb(255, 68, 82);
		}
		if (HasVisualRarity(name, "Absolute") || (!visual && SoundReferences.IsAbsolute(name)))
		{
			return Color.FromArgb(0, 205, 38);
		}
		if (HasVisualRarity(name, "GOAT") || (!visual && SoundReferences.IsGoat(name)))
		{
			return Color.FromArgb(55, 135, 255);
		}
		if (HasVisualRarity(name, "Secret") || IsGrandeSecretBox(name))
		{
			return Color.FromArgb(155, 80, 255);
		}
		return Color.FromArgb(68, 230, 255);
	}

	internal static Bitmap RenderCompact(Size size, string name, int seconds, bool visual, string label = null)
	{
		Bitmap bitmap = new Bitmap(Math.Max(1, size.Width), Math.Max(1, size.Height), PixelFormat.Format32bppArgb);
		using Graphics graphics = Graphics.FromImage(bitmap);
		graphics.Clear(Color.Transparent);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		float num = Math.Min(1f, (float)(size.Width - 16) / 680f);
		graphics.TranslateTransform(8f, 8f);
		graphics.ScaleTransform(num, num);
		Color color = CompactColor(name, visual);
		using (SolidBrush brush = new SolidBrush(Color.FromArgb(240, 8, 13, 20)))
		{
			graphics.FillRectangle(brush, 4, 20, 672, 96);
		}
		using (Pen pen = new Pen(color, 3f))
		{
			graphics.DrawRectangle(pen, 4, 20, 672, 96);
		}
		using (SolidBrush brush2 = new SolidBrush(HasVisualRarity(name, "Secret") ? Color.Black : color))
		{
			graphics.FillRectangle(brush2, 10, 26, 10, 84);
		}
		int num2 = (name ?? "").LastIndexOf(" — ", StringComparison.Ordinal);
		string s = ((num2 >= 0) ? name.Substring(num2 + 3) : "KANBLAZ CLOUD");
		if (!string.IsNullOrWhiteSpace(label))
		{
			s = label;
		}
		string s2 = DisplayCaption((num2 >= 0) ? name.Substring(0, num2) : name);
		using Font font = new Font("Segoe UI", 15f, FontStyle.Bold);
		using Font font2 = new Font("Segoe UI", 12f);
		using SolidBrush brush3 = new SolidBrush(color);
		using StringFormat format = new StringFormat
		{
			Trimming = StringTrimming.EllipsisCharacter,
			FormatFlags = StringFormatFlags.NoWrap
		};
		graphics.DrawString(s, font, Brushes.White, new RectangleF(34f, 30f, 530f, 28f), format);
		graphics.DrawString(s2, font2, brush3, new RectangleF(34f, 68f, 530f, 28f), format);
		graphics.DrawString(Math.Max(0, seconds) + " s", font, brush3, new RectangleF(582f, 49f, 86f, 32f), format);
		return bitmap;
	}

	internal static Bitmap RenderSession(Size size, NotificationEvent[] events, int seconds)
	{
		NotificationEvent notificationEvent = events[events.Length - 1];
		Bitmap bitmap = Render(size, notificationEvent.Caption, seconds, notificationEvent.Visual);
		if (events.Length > 1 && size.Width >= 240 && size.Height >= 180)
		{
			int num = 24;
			int num2 = Math.Min(140 * events.Length, Math.Max(1, size.Height / 2));
			using Bitmap image = RenderGroup(new Size(760, 140 * events.Length), events, seconds);
			using Graphics graphics = Graphics.FromImage(bitmap);
			graphics.CompositingMode = CompositingMode.SourceCopy;
			using (SolidBrush brush = new SolidBrush(Color.Transparent))
			{
				graphics.FillRectangle(brush, num, num, size.Width - 2 * num, Math.Max(140, num2));
			}
			graphics.DrawImage(image, new Rectangle(num, num, size.Width - 2 * num, num2));
		}
		return bitmap;
	}

	internal static Bitmap RenderGroup(Size size, NotificationEvent[] events, int seconds)
	{
		Bitmap bitmap = new Bitmap(Math.Max(1, size.Width), Math.Max(1, size.Height), PixelFormat.Format32bppArgb);
		using Graphics graphics = Graphics.FromImage(bitmap);
		graphics.Clear(Color.Transparent);
		int num = Math.Min(3, events.Length);
		for (int i = 0; i < num; i++)
		{
			int num2 = i * size.Height / num;
			int num3 = (i + 1) * size.Height / num;
			using (Bitmap image = Render(new Size(size.Width, Math.Max(140, num3 - num2)), events[i].Caption, seconds, events[i].Visual))
			{
				graphics.DrawImage(image, new Rectangle(0, num2, size.Width, num3 - num2));
			}
			if (!events[i].Visual)
			{
				using Font font = new Font("Segoe UI", 10f, FontStyle.Bold);
				graphics.DrawString(events[i].Label ?? "", font, Brushes.White, new RectangleF(SoundReferences.IsLuckyRot(events[i].Caption) ? 200 : 72, Math.Max(num2, num3 - 24), Math.Max(1, size.Width - 220), 20f));
			}
		}
		return bitmap;
	}

	internal static bool HasVisualRarity(string name, string rarity)
	{
		if (name == null)
		{
			return false;
		}
		if (!name.Contains(" — Rarity: "))
		{
			if (!name.StartsWith(rarity + " Brainrot", StringComparison.Ordinal) && !name.StartsWith("Insane " + rarity + " Box Spawned!", StringComparison.Ordinal))
			{
				return name.StartsWith("Grande " + rarity + " Box Spawned!", StringComparison.Ordinal);
			}
			return true;
		}
		return name.Contains(" — Rarity: " + rarity + " — ");
	}

	internal static bool IsGrandeSecretBox(string name)
	{
		if (!(name == "Grande Secret Box Spawned!"))
		{
			return name?.StartsWith("Grande Secret Box Spawned! — ", StringComparison.Ordinal) ?? false;
		}
		return true;
	}

	internal static bool IsSprite(string name)
	{
		if (!(name == "SPRITE SPAWNED!"))
		{
			return name?.StartsWith("SPRITE SPAWNED! — ", StringComparison.Ordinal) ?? false;
		}
		return true;
	}

	private static void DrawLucky(Graphics g, Size size, string name, int seconds, bool visual)
	{
		float num = Math.Min(680, Math.Max(1, size.Width - 16));
		float num2 = num / 680f;
		float dx = ((float)size.Width - num) / 2f;
		float dy = 8f;
		GraphicsState gstate = g.Save();
		g.TranslateTransform(dx, dy);
		g.ScaleTransform(num2, num2);
		using (GraphicsPath graphicsPath = new GraphicsPath())
		{
			graphicsPath.AddPolygon(new PointF[5]
			{
				new PointF(45f, 25f),
				new PointF(650f, 25f),
				new PointF(675f, 54f),
				new PointF(659f, 117f),
				new PointF(45f, 117f)
			});
			using (LinearGradientBrush brush = new LinearGradientBrush(new Rectangle(40, 25, 635, 92), Color.FromArgb(245, 32, 25, 9), Color.FromArgb(240, 7, 9, 12), 90f))
			{
				g.FillPath(brush, graphicsPath);
			}
			using (Pen pen = new Pen(Color.FromArgb(55, 255, 199, 25), 12f))
			{
				g.DrawPath(pen, graphicsPath);
			}
			using (Pen pen2 = new Pen(Color.FromArgb(255, 206, 37), 4f))
			{
				g.DrawPath(pen2, graphicsPath);
			}
			using Pen pen3 = new Pen(Color.FromArgb(255, 244, 173), 1f);
			g.DrawLine(pen3, 155, 30, 645, 30);
		}
		if (LuckyIcon.Value != null)
		{
			g.DrawImage(LuckyIcon.Value, new RectangleF(0f, 0f, 150f, 135f));
		}
		using (Font font = new Font("Segoe UI", 27f, FontStyle.Bold, GraphicsUnit.Pixel))
		{
			using Font font2 = new Font("Segoe UI", 15f, FontStyle.Regular, GraphicsUnit.Pixel);
			using SolidBrush brush2 = new SolidBrush(Color.FromArgb(255, 221, 86));
			using SolidBrush brush3 = new SolidBrush(Color.FromArgb(240, 244, 247));
			using StringFormat format = new StringFormat
			{
				FormatFlags = StringFormatFlags.NoWrap,
				Trimming = StringTrimming.EllipsisCharacter
			};
			g.DrawString("GRANDE LUCKY ROT", font, brush2, new RectangleF(150f, 39f, 495f, 38f), format);
			string text = ((name.Length > "Grande Lucky Rot".Length) ? name.Substring("Grande Lucky Rot".Length) : "");
			g.DrawString((visual ? "SCREEN NOTICE" : "SOUND DETECTED") + text + "  ·  " + Math.Max(0, Math.Min(32, seconds)) + " s", font2, brush3, new RectangleF(152f, 81f, 485f, 25f), format);
		}
		g.Restore(gstate);
	}

	internal static Bitmap Render(Size size, string name, int seconds, bool visual = false)
	{
		if (size.Width < 1 || size.Height < 1)
		{
			throw new ArgumentOutOfRangeException("size");
		}
		Bitmap bitmap = new Bitmap(size.Width, size.Height, PixelFormat.Format32bppPArgb);
		try
		{
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.Clear(Color.Transparent);
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
				if (SoundReferences.IsLuckyRot(name))
				{
					DrawLucky(graphics, size, name, seconds, visual);
					return bitmap;
				}
				float num = Math.Min(1.4f, Math.Max(1f, (float)size.Width / 1000f));
				int num2 = 24;
				int num3 = Math.Max(num2 + 1, Math.Min(num2 + 12, Math.Min(size.Width, size.Height) / 4));
				int num4 = Math.Min(size.Height, (int)(88f * num));
				int num5 = Math.Min(Math.Max(0, size.Height - num4), (int)(16f * num));
				bool flag = string.Equals(name, "Special alert", StringComparison.Ordinal);
				bool flag2 = (!visual && SoundReferences.IsEternal(name)) || (visual && HasVisualRarity(name, "Eternal"));
				bool flag3 = visual && HasVisualRarity(name, "Secret");
				bool flag4 = (visual && HasVisualRarity(name, "Absolute")) || (!visual && SoundReferences.IsAbsolute(name));
				bool flag5 = (visual && HasVisualRarity(name, "GOAT")) || (!visual && SoundReferences.IsGoat(name));
				bool flag6 = flag | flag2 | flag4;
				Color color;
				if (flag2)
				{
					color = Color.FromArgb(255, 68, 82);
				}
				else
				{
					color = (flag ? Color.FromArgb(255, 242, 48) : Color.FromArgb(68, 230, 255));
				}
				Color color2;
				if (flag2)
				{
					color2 = Color.FromArgb(255, 30, 48);
				}
				else
				{
					color2 = (flag ? Color.FromArgb(255, 42, 62) : Color.FromArgb(48, 136, 250));
				}
				Color baseColor = (flag6 ? Color.FromArgb(32, 6, 8) : Color.FromArgb(5, 13, 27));
				Color baseColor2;
				if (flag2)
				{
					baseColor2 = Color.FromArgb(51, 10, 18);
				}
				else
				{
					baseColor2 = (flag ? Color.FromArgb(51, 14, 10) : Color.FromArgb(12, 30, 48));
				}
				if (flag4)
				{
					color = Color.FromArgb(0, 205, 38);
					color2 = Color.FromArgb(0, 120, 5);
					baseColor = Color.FromArgb(0, 12, 2);
					baseColor2 = Color.FromArgb(0, 30, 5);
				}
				if (flag3)
				{
					color = Color.Cyan;
					color2 = Color.FromArgb(155, 80, 255);
					baseColor = Color.Black;
					baseColor2 = Color.FromArgb(8, 8, 12);
				}
				if (flag5)
				{
					color = Color.FromArgb(55, 135, 255);
					color2 = Color.FromArgb(25, 65, 210);
					baseColor = Color.FromArgb(3, 9, 30);
					baseColor2 = Color.FromArgb(8, 25, 65);
					flag6 = true;
				}
				bool flag7 = visual && IsSprite(name);
				if (flag7)
				{
					color = Color.FromArgb(207, 126, 255);
					color2 = Color.FromArgb(120, 65, 190);
					baseColor = Color.FromArgb(18, 6, 28);
					baseColor2 = Color.FromArgb(35, 15, 55);
					flag6 = true;
				}
				using (LinearGradientBrush brush = new LinearGradientBrush(new Rectangle(0, 0, size.Width, Math.Max(1, num4)), Color.FromArgb(244, baseColor), Color.FromArgb(210, baseColor2), 90f))
				{
					graphics.FillRectangle(brush, 0, 0, size.Width, num4);
				}
				using (LinearGradientBrush brush2 = new LinearGradientBrush(new Rectangle(0, 0, size.Width, Math.Max(1, num4)), flag6 ? Color.FromArgb(50, color) : Color.FromArgb(36, 0, 229, 255), flag6 ? Color.FromArgb(42, color2) : Color.FromArgb(22, 104, 95, 255), 0f))
				{
					graphics.FillRectangle(brush2, 0, 0, size.Width, num4);
				}
				if (num5 > 0)
				{
					using LinearGradientBrush brush3 = new LinearGradientBrush(new Rectangle(0, num4, size.Width, num5), Color.FromArgb(210, baseColor2), Color.FromArgb(0, baseColor2), 90f);
					graphics.FillRectangle(brush3, 0, num4, size.Width, num5);
				}
				for (int i = num2; i < num3 && size.Width > i * 2 && size.Height > i * 2; i++)
				{
					int alpha = (int)(190.0 * Math.Pow(1.0 - (double)(i - num2) / (double)(num3 - num2), 2.0));
					if (flag6)
					{
						using LinearGradientBrush brush4 = new LinearGradientBrush(new Rectangle(0, 0, size.Width, size.Height), Color.FromArgb(alpha, color), Color.FromArgb(alpha, color2), 90f);
						using Pen pen = new Pen(brush4, 1f);
						graphics.DrawRectangle(pen, i, i, size.Width - i * 2 - 1, size.Height - i * 2 - 1);
					}
					else
					{
						using Pen pen2 = new Pen(Color.FromArgb(alpha, color), 1f);
						graphics.DrawRectangle(pen2, i, i, size.Width - i * 2 - 1, size.Height - i * 2 - 1);
					}
				}
				using (LinearGradientBrush brush5 = new LinearGradientBrush(new Rectangle(0, 0, size.Width, size.Height), color, color2, 90f))
				{
					using Pen pen3 = new Pen(brush5, num2)
					{
						Alignment = PenAlignment.Inset
					};
					graphics.DrawRectangle(pen3, 0, 0, size.Width - 1, size.Height - 1);
				}
				if (flag3)
				{
					using Pen pen4 = new Pen(Color.Black, Math.Max(2, num2 / 3));
					graphics.DrawRectangle(pen4, num2 / 2, num2 / 2, size.Width - num2 - 1, size.Height - num2 - 1);
				}
				if (size.Width < 240 || size.Height < 120)
				{
					return bitmap;
				}
				float num6 = 34f * num;
				float num7 = 96f * num;
				float num8 = (float)size.Width - num6 - num7;
				Color color3;
				if (flag2)
				{
					color3 = Color.FromArgb(130, 255, 193, 204);
				}
				else
				{
					color3 = (flag ? Color.FromArgb(130, 255, 247, 193) : Color.FromArgb(130, 213, 254, 255));
				}
				using (Pen pen5 = new Pen(color3, 1f))
				{
					graphics.DrawLine(pen5, num6, 24f * num, (float)size.Width - num6, 24f * num);
				}
				bool flag8 = visual && IsGrandeSecretBox(name) && size.Width >= 600 && SecretBoxIcon.Value != null;
				bool flag9 = flag7 && size.Width >= 360 && SpriteIcon.Value != null;
				if (flag9)
				{
					graphics.DrawImage(SpriteIcon.Value, new RectangleF(num6 - 6f * num, 25f * num, 62f * num, 55f * num));
				}
				else if (flag8)
				{
					graphics.DrawImage(SecretBoxIcon.Value, new RectangleF(num6 - 6f * num, 25f * num, 62f * num, 55f * num));
				}
				else
				{
					using Pen pen6 = new Pen(color, 2f * num);
					for (int j = 0; j < 5; j++)
					{
						float num9 = (float)((j == 2) ? 22 : ((j % 2 == 0) ? 8 : 15)) * num;
						float num10 = num6 + (float)(j * 5) * num;
						graphics.DrawLine(pen6, num10, 55f * num - num9 / 2f, num10, 55f * num + num9 / 2f);
					}
				}
				float num11 = num6 + (float)((flag8 | flag9) ? 66 : 38) * num;
				float width = Math.Max(1f, num8 - num11 - 15f * num);
				using (Font font = new Font("Segoe UI", 9f * num, FontStyle.Bold, GraphicsUnit.Pixel))
				{
					using Font font2 = new Font("Segoe UI", 20f * num, FontStyle.Bold, GraphicsUnit.Pixel);
					using Font font3 = new Font("Consolas", 28f * num, FontStyle.Bold, GraphicsUnit.Pixel);
					Color color4;
					if (flag4)
					{
						color4 = color;
					}
					else if (flag2)
					{
						color4 = Color.FromArgb(195, 255, 178, 190);
					}
					else
					{
						color4 = (flag ? Color.FromArgb(195, 255, 226, 157) : Color.FromArgb(195, 171, 237, 251));
					}
					using SolidBrush brush6 = new SolidBrush(color4);
					Color color5;
					if (flag2)
					{
						color5 = Color.FromArgb(250, 255, 236, 239);
					}
					else
					{
						color5 = (flag ? Color.FromArgb(250, 255, 249, 227) : Color.FromArgb(250, 241, 253, 255));
					}
					using SolidBrush brush7 = new SolidBrush(color5);
					using SolidBrush brush8 = new SolidBrush(color);
					using StringFormat stringFormat = new StringFormat
					{
						FormatFlags = StringFormatFlags.NoWrap,
						Trimming = StringTrimming.EllipsisCharacter
					};
					string s;
					if (flag4)
					{
						s = "ABSOLUTE";
					}
					else if (visual)
					{
						s = "SCREEN NOTICE";
					}
					else if (flag2)
					{
						s = "ETERNAL";
					}
					else
					{
						s = (flag5 ? "GOAT" : "SOUND DETECTED");
					}
					string text = ((!visual & flag5) ? "Skibidi Toilet" : (name ?? string.Empty));
					if (flag7)
					{
						text = "SPRITE SPAWNED!";
						string[] array = name.Split(new string[1] { " — " }, StringSplitOptions.None);
						s = ((array.Length > 1) ? array[array.Length - 1] : "SCREEN NOTICE");
					}
					if (visual && text.Contains("Brainrot Spawned!"))
					{
						string text2 = DisplayCaption(text);
						int num12 = text2.IndexOf(" — ", StringComparison.Ordinal);
						s = ((num12 < 0) ? text2 : text2.Substring(0, num12));
						text = ((num12 < 0) ? text2 : text2.Substring(num12 + 3));
					}
					graphics.DrawString(s, font, brush6, new RectangleF(num11, 32f * num, width, 13f * num), stringFormat);
					graphics.DrawString(text, font2, brush7, new RectangleF(num11 - 1f, 46f * num, width, 30f * num), stringFormat);
					using (SolidBrush brush9 = new SolidBrush(flag6 ? Color.FromArgb(90, 36, 8, 9) : Color.FromArgb(90, 6, 18, 36)))
					{
						graphics.FillRectangle(brush9, num8, 29f * num, num7, 46f * num);
					}
					using (Pen pen7 = new Pen(Color.FromArgb(110, color), 1f))
					{
						graphics.DrawLine(pen7, num8, 33f * num, num8, 72f * num);
					}
					stringFormat.Alignment = StringAlignment.Center;
					graphics.DrawString("ALERT", font, brush6, new RectangleF(num8, 30f * num, num7, 12f * num), stringFormat);
					graphics.DrawString("00:" + Math.Max(0, Math.Min(32, seconds)).ToString("00"), font3, brush8, new RectangleF(num8, 40f * num, num7, 36f * num), stringFormat);
				}
				float num13 = 82f * num;
				using (Pen pen8 = new Pen(Color.FromArgb(65, color), 2f * num))
				{
					graphics.DrawLine(pen8, num6, num13, (float)size.Width - num6, num13);
				}
				using (Pen pen9 = new Pen(color, 2f * num))
				{
					graphics.DrawLine(pen9, num6, num13, num6 + ((float)size.Width - num6 * 2f) * (float)Math.Max(0, Math.Min(32, seconds)) / 32f, num13);
				}
				Color color6;
				if (flag2)
				{
					color6 = Color.FromArgb(225, 255, 213, 222);
				}
				else
				{
					color6 = (flag ? Color.FromArgb(225, 255, 253, 208) : Color.FromArgb(225, 219, 254, 255));
				}
				using Pen pen10 = new Pen(color6, 2f * num);
				float num14 = 4f * num;
				float num15 = 25f * num;
				graphics.DrawLines(pen10, new PointF[3]
				{
					new PointF(num14, num14 + num15),
					new PointF(num14, num14),
					new PointF(num14 + num15, num14)
				});
				graphics.DrawLines(pen10, new PointF[3]
				{
					new PointF((float)size.Width - num14 - num15, num14),
					new PointF((float)size.Width - num14, num14),
					new PointF((float)size.Width - num14, num14 + num15)
				});
				graphics.DrawLines(pen10, new PointF[3]
				{
					new PointF(num14, (float)size.Height - num14 - num15),
					new PointF(num14, (float)size.Height - num14),
					new PointF(num14 + num15, (float)size.Height - num14)
				});
				graphics.DrawLines(pen10, new PointF[3]
				{
					new PointF((float)size.Width - num14 - num15, (float)size.Height - num14),
					new PointF((float)size.Width - num14, (float)size.Height - num14),
					new PointF((float)size.Width - num14, (float)size.Height - num14 - num15)
				});
			}
			return bitmap;
		}
		catch
		{
			bitmap.Dispose();
			throw;
		}
	}
}
