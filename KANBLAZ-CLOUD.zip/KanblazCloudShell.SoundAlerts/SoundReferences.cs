using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace KanblazCloudShell.SoundAlerts;

internal static class SoundReferences
{
	internal static readonly string[] EternalNameFiles = "arcangelo-mantisio|bullzilla|burguro-dan-fryuro|buzz-buzzini-guardini|cannone-maledettone|carouselino|celesto-tortello|din-doni-gongoni|el-cranchador|fishini-mechinini|fumino-gearzino|galaxio-astro|garbagzilla|gattino-e-mortosso|ghostero-cavallero|gigalitraktos-spidorobos|giraffzilla|guro-guro|harpanzee (1)|iceberry-mammoth|il-maledettones|jetzilla|kango-puncho|kitsunaura|krabaracade|lady-pegasina|magico-moonman|marionarch|mecha-traladone|necromano|pavonaccio|salsicino-furiosino|scorpidusa-spiderusa|sunculus-ferris|tiramisubmarini|turbino-supremo|vulkarion|vulturino-skeletono|wreckzilla".Split('|');

	internal static readonly string[] NewNameFiles = "Arcangelo Martisio|Buzz Buzzini Guardini|Cannone Maledettone|Carouselino|celesto tortello|Din Doni Gongoni|El crunchador|Fishini Mechinini|Fumino Gearzino|Galaxio Astro|Garbagzilla|Ghostero Cavallero|Gigalitraktos Spidorobos|Giraffzilla|Guro Guro|kango puncho|Kitsunaura|krabarcade|La crazy combinacion|Lady Pegasina|Mecha Traladone|pavonaccio|Salsicion Furiosino|Sunculus Ferris|Vulkarion|Vulturino Skeletono|Wreckzilla".Split('|');

	internal const string NeonAlertFileName = "Special_alert";

	internal const string NeonAlertName = "Special alert";

	internal const string VideoProject13FileName = "Video_Project_13";

	internal const string VideoProject13Name = "Video Project 13";

	internal const string HarpanzeeName = "Harpanzee";

	internal const string LuckyRotName = "Grande Lucky Rot";

	internal static readonly string[] FileNames = new string[13]
	{
		"skibidi-toilet", "Il_Maledettones", "El_Toro_Pistoloro", "Cerberwolf", "Mobytron", "Din_Don_Skeleton", "Hydragoni_Skeletoni", "DiggoBlock", "Special_alert", "Video_Project_13",
		"Harpanzee", "Ghostero_Cavallero", "Grande_Lucky_Rot"
	};

	private const int MatchFramesForName = 40;

	internal static string DisplayName(string file)
	{
		string text = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(file.Replace(" (1)", "").Replace('-', ' '));
		return NameKey(text) switch
		{
			"arcangelomantisio" => "Arcangelo Martisio", 
			"elcranchador" => "El Crunchador", 
			"krabaracade" => "Krabarcade", 
			"salsicinofuriosino" => "Salsicion Furiosino", 
			_ => text, 
		};
	}

	internal static string MatchEternalName(string text)
	{
		string key = NameKey(DisplayName(text ?? ""));
		return EternalNameFiles.Concat(NewNameFiles).Select(DisplayName).FirstOrDefault((string n) => NameKey(n) == key);
	}

	private static string NameKey(string text)
	{
		return new string((text ?? "").Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());
	}

	internal static bool IsSpokenEternal(string name)
	{
		if (MatchEternalName(name) == null)
		{
			return name == "DiggoBlock";
		}
		return true;
	}

	internal static double NameScoreRequired(string name)
	{
		switch (name)
		{
		default:
			return 0.82;
		case "Il Maledettones":
		case "DiggoBlock":
		case "Harpanzee":
		case "Ghostero Cavallero":
			return 0.78;
		}
	}

	internal static bool IsLuckyRot(string name)
	{
		if (!(name == "Grande Lucky Rot"))
		{
			return name?.StartsWith("Grande Lucky Rot — ", StringComparison.Ordinal) ?? false;
		}
		return true;
	}

	internal static bool IsAbsolute(string name)
	{
		switch (name)
		{
		default:
			return name == "Hydragoni Skeletoni";
		case "El Toro Pistoloro":
		case "Cerberwolf":
		case "Mobytron":
		case "Din Don Skeleton":
			return true;
		}
	}

	internal static bool IsEternal(string name)
	{
		if (NameKey(name) == "lacrazycombinacion")
		{
			return false;
		}
		if (!IsSpokenEternal(name))
		{
			switch (name)
			{
			default:
				return name == "Video Project 13";
			case "Il Maledettones":
			case "DiggoBlock":
			case "Harpanzee":
			case "Ghostero Cavallero":
				break;
			}
		}
		return true;
	}

	internal static bool IsGoat(string name)
	{
		if (!string.Equals(name, "skibidi-toilet", StringComparison.OrdinalIgnoreCase))
		{
			return string.Equals(name, "Skibidi Toilet", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	internal static SoundReference[] Load(string directory)
	{
		SoundReference[] source = FileNames.Select((string name) => new SoundReference(name.Replace('_', ' '), ReadPcm(Path.Combine(directory, name + ".wav")))).ToArray();
		if (source.Any((SoundReference reference) => reference.Frames.Length < 40))
		{
			throw new InvalidDataException("A sound reference is too short.");
		}
		List<SoundReference> list = source.ToList();
		string[] eternalNameFiles = EternalNameFiles;
		foreach (string text in eternalNameFiles)
		{
			string path = Path.Combine(directory, "eternal-names", text + ".wav");
			try
			{
				if (File.Exists(path))
				{
					SoundReference sample = new SoundReference(DisplayName(text), ReadPcm(path));
					if (sample.Frames.Length >= 40 && !list.Any((SoundReference r) => r.Name == sample.Name && r.Frames.Select((AudioPrint f) => f.Spectrum).SequenceEqual(sample.Frames.Select((AudioPrint f) => f.Spectrum))))
					{
						list.Add(sample);
					}
				}
			}
			catch (IOException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
		List<SoundReference> primary = new List<SoundReference>();
		eternalNameFiles = NewNameFiles;
		foreach (string text2 in eternalNameFiles)
		{
			string path2 = Path.Combine(directory, "new-name-samples", text2 + ".wav");
			try
			{
				if (File.Exists(path2))
				{
					SoundReference sample2 = new SoundReference(DisplayName(text2), ReadPcm(path2));
					if (sample2.Frames.Length >= 40 && !primary.Any((SoundReference r) => r.Name == sample2.Name && r.Frames.Select((AudioPrint f) => f.Spectrum).SequenceEqual(sample2.Frames.Select((AudioPrint f) => f.Spectrum))))
					{
						primary.Add(sample2);
					}
				}
			}
			catch (IOException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
		primary.AddRange(list.Where((SoundReference old) => !primary.Any((SoundReference n) => n.Name == old.Name && n.Frames.Select((AudioPrint f) => f.Spectrum).SequenceEqual(old.Frames.Select((AudioPrint f) => f.Spectrum)))));
		return primary.ToArray();
	}

	internal static short[] ReadPcm(string path)
	{
		using BinaryReader binaryReader = new BinaryReader(File.OpenRead(path));
		if (binaryReader.BaseStream.Length > 4000000 || new string(binaryReader.ReadChars(4)) != "RIFF")
		{
			throw new InvalidDataException("Invalid WAV.");
		}
		binaryReader.ReadUInt32();
		if (new string(binaryReader.ReadChars(4)) != "WAVE")
		{
			throw new InvalidDataException("Invalid WAV.");
		}
		bool flag = false;
		while (binaryReader.BaseStream.Position + 8 <= binaryReader.BaseStream.Length)
		{
			string text = new string(binaryReader.ReadChars(4));
			uint num = binaryReader.ReadUInt32();
			long num2 = binaryReader.BaseStream.Position + num;
			if (num2 > binaryReader.BaseStream.Length)
			{
				throw new InvalidDataException("Truncated WAV.");
			}
			if (text == "fmt ")
			{
				if (num < 16)
				{
					throw new InvalidDataException("Invalid WAV format.");
				}
				ushort num3 = binaryReader.ReadUInt16();
				ushort num4 = binaryReader.ReadUInt16();
				uint num5 = binaryReader.ReadUInt32();
				binaryReader.ReadUInt32();
				ushort num6 = binaryReader.ReadUInt16();
				ushort num7 = binaryReader.ReadUInt16();
				flag = num3 == 1 && num4 == 1 && num5 == 16000 && num6 == 2 && num7 == 16;
			}
			else if (text == "data")
			{
				if (!flag || num % 2 != 0)
				{
					throw new InvalidDataException("Mono 16 kHz/16-bit PCM WAV is required.");
				}
				short[] array = new short[num / 2];
				for (int i = 0; i < array.Length; i++)
				{
					array[i] = binaryReader.ReadInt16();
				}
				return array;
			}
			binaryReader.BaseStream.Position = num2 + (num & 1);
		}
		throw new InvalidDataException("WAV contains no audio.");
	}
}
