using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using KanblazCloudShell.VisualAlerts;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class SessionSoundAlerts : IDisposable
{
	private static readonly Lazy<SoundReference[]> References = new Lazy<SoundReference[]>(() => SoundReferences.Load(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "sounds")));

	private readonly Control surface;

	private readonly SoundAlertOverlay overlay;

	private readonly string notificationProfile = Guid.NewGuid().ToString("N");

	private readonly string profileLabel;

	private readonly Action<string> status;

	private readonly Action collision;

	private ProcessAudioMonitor monitor;

	private uint registeredPid;

	private int generation;

	private bool disposed;

	internal SoundAlertOverlay Overlay => overlay;

	internal SessionSoundAlerts(Control surface, Action<string> status, string profileLabel = "")
	{
		SessionSoundAlerts sessionSoundAlerts = this;
		this.surface = surface;
		this.status = status;
		this.profileLabel = profileLabel;
		overlay = new SoundAlertOverlay(surface);
		NotificationCoordinator.Register(notificationProfile, surface, overlay);
		collision = () =>
		{
			int failedGeneration = ++sessionSoundAlerts.generation;
			if (sessionSoundAlerts.monitor != null)
			{
				sessionSoundAlerts.monitor.Dispose();
				sessionSoundAlerts.monitor = null;
			}
			sessionSoundAlerts.Post(() =>
			{
				if (failedGeneration == sessionSoundAlerts.generation)
				{
					NotificationCoordinator.Remove(sessionSoundAlerts.notificationProfile, false);
					status("Detector disabled: two windows share an audio process.");
				}
			});
		};
	}

	internal async void Start(uint browserProcessId)
	{
		Stop(clearVisual: false);
		if (disposed)
		{
			return;
		}
		int request = generation;
		if (!ProcessAudioMonitor.Supported)
		{
			status("Detector unavailable: requires Windows 11 or build 20348+.");
			return;
		}
		SoundReference[] references;
		try
		{
			references = await Task.Run(() => References.Value);
		}
		catch
		{
			if (!disposed && request == generation)
			{
				status("Detector unavailable: sound references are missing.");
			}
			return;
		}
		if (disposed || request != generation)
		{
			return;
		}
		registeredPid = browserProcessId;
		if (!AudioProcessOwnership.Register(browserProcessId, collision))
		{
			return;
		}
		try
		{
			monitor = new ProcessAudioMonitor(browserProcessId, references);
			monitor.Detected += (SoundMatch match) =>
			{
				Post(() =>
				{
					if (request == generation)
					{
						bool flag = SoundReferences.IsSpokenEternal(match.Name);
						if (!flag || !(match.Score < SoundReferences.NameScoreRequired(match.Name)))
						{
							NotificationEvent notificationEvent = new NotificationEvent
							{
								Id = Guid.NewGuid().ToString("N"),
								Profile = notificationProfile,
								Label = profileLabel,
								Caption = match.Name,
								Name = match.Name,
								SpokenName = flag,
								AudioName = (flag ? match.Name : null),
								NameConfidence = (float)match.Score
							};
							if (NotificationCoordinator.Publish(notificationEvent) == NotificationChange.Added)
							{
								status("Sound detected: " + match.Name + " · alert for " + 32 + " seconds");
								try
								{
									if (SoundReferences.IsEternal(match.Name) && NotificationCoordinator.RequestBell(notificationProfile, notificationEvent.Id))
									{
										EternalBell.PlayForSound(match.Name, EternalBell.Play);
									}
								}
								catch
								{
									status("Eternal detected; notification sound could not play.");
								}
							}
						}
					}
				});
			};
			monitor.StatusChanged += (string value) =>
			{
				Post(() =>
				{
					if (request == generation)
					{
						status(value);
					}
				});
			};
			monitor.Start();
		}
		catch
		{
			status("Detector unavailable: isolated capture could not start.");
			Stop(clearVisual: false);
		}
	}

	private void Post(Action action)
	{
		if (disposed || surface.IsDisposed || !surface.IsHandleCreated)
		{
			return;
		}
		try
		{
			surface.BeginInvoke((Action)(() =>
			{
				if (!disposed && !surface.IsDisposed)
				{
					action();
				}
			}));
		}
		catch (InvalidOperationException)
		{
		}
	}

	internal NotificationChange ShowVisualAlert(BrainrotDetection notice)
	{
		if (disposed || notice == null)
		{
			return NotificationChange.Ignored;
		}
		string text = notice.Callout(profileLabel);
		bool brainrotVisual = notice.Notice != SpawnNotice.Sprite && notice.Notice != SpawnNotice.Box && notice.Notice != SpawnNotice.LuckyRot && notice.Notice != SpawnNotice.None;
		string ocrName = ((notice.NameConfidence >= 0.82f && notice.Name != "Unknown") ? notice.Name : "");
		NotificationChange notificationChange = NotificationCoordinator.Publish(new NotificationEvent
		{
			Id = notice.EventId,
			Profile = notificationProfile,
			Label = profileLabel,
			Caption = text,
			Name = notice.Name,
			Visual = true,
			BrainrotVisual = brainrotVisual,
			OcrName = ocrName,
			BaseCaption = notice.Callout(profileLabel, includeName: false),
			NameConfidence = notice.NameConfidence
		});
		if (notificationChange != NotificationChange.Ignored)
		{
			status("On-screen notice: " + text);
		}
		if (notificationChange != NotificationChange.Ignored && (SpawnNotices.UsesBell(notice.AlertNotice) || notice.Notice == SpawnNotice.Box || notice.Notice == SpawnNotice.LuckyRot) && NotificationCoordinator.RequestBell(notificationProfile, notice.EventId))
		{
			try
			{
				EternalBell.Play();
			}
			catch
			{
				status("Detected; notification sound could not play.");
			}
		}
		return notificationChange;
	}

	internal void ClearVisualAlert()
	{
		NotificationCoordinator.Remove(notificationProfile, true);
	}

	internal void Stop(bool clearVisual = true)
	{
		generation++;
		if (monitor != null)
		{
			monitor.Dispose();
			monitor = null;
		}
		if (registeredPid != 0)
		{
			AudioProcessOwnership.Unregister(registeredPid, collision);
		}
		registeredPid = 0u;
		NotificationCoordinator.Remove(notificationProfile, clearVisual ? ((bool?)null) : new bool?(false));
	}

	public void Dispose()
	{
		if (!disposed)
		{
			Stop();
			disposed = true;
			NotificationCoordinator.Unregister(notificationProfile);
			overlay.Dispose();
		}
	}
}
