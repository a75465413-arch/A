using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class ExternalAlertTarget : Form
{
	private readonly Action clicked;

	protected override bool ShowWithoutActivation => true;

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 134217856;
			return createParams;
		}
	}

	[DllImport("user32.dll")]
	private static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int cx, int cy, uint flags);

	internal ExternalAlertTarget(Action clicked)
	{
		this.clicked = clicked;
		FormBorderStyle = FormBorderStyle.None;
		ShowInTaskbar = false;
		StartPosition = FormStartPosition.Manual;
		AutoScaleMode = AutoScaleMode.None;
		TopMost = true;
		TabStop = false;
		Cursor = Cursors.Hand;
		BackColor = Color.Black;
		Opacity = 0.01;
		AccessibleName = "Open game window";
		AccessibleRole = AccessibleRole.PushButton;
	}

	protected override void WndProc(ref Message m)
	{
		if (m.Msg == 33)
		{
			m.Result = new IntPtr(3);
		}
		else
		{
			base.WndProc(ref m);
		}
	}

	internal void ShowAt(Rectangle bounds, string description)
	{
		if (!IsDisposed && bounds.Width > 0 && bounds.Height > 0)
		{
			if (Bounds != bounds)
			{
				Bounds = bounds;
			}
			AccessibleDescription = description;
			if (!Visible)
			{
				Show();
			}
			SetWindowPos(Handle, new IntPtr(-1), 0, 0, 0, 0, 19u);
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		if (e.Button != MouseButtons.Left || !ClientRectangle.Contains(e.Location))
		{
			return;
		}
		BeginInvoke((Action)(() =>
		{
			if (!IsDisposed && Visible)
			{
				clicked();
			}
		}));
	}
}
