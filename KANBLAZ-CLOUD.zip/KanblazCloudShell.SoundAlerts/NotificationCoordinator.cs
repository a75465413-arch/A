using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;

namespace KanblazCloudShell.SoundAlerts;

internal static class NotificationCoordinator
{
	private sealed class Client
	{
		internal Control Surface;

		internal SoundAlertOverlay Border;
	}

	private static readonly Dictionary<string, Client> Clients;

	private static readonly NotificationQueue Queue;

	private static readonly Stopwatch Clock;

	private static readonly Timer Timer;

	private static SoundAlertOverlay group;

	private static string anchor;

	private static int rendered;

	private static string floatingStamp;

	static NotificationCoordinator()
	{
		Clients = new Dictionary<string, Client>();
		Queue = new NotificationQueue(individual: true);
		Clock = Stopwatch.StartNew();
		Timer = new Timer
		{
			Interval = 100
		};
		rendered = -1;
		floatingStamp = "";
		Timer.Tick += (object s, EventArgs e) =>
		{
			Refresh(changed: false);
		};
	}

	internal static void Register(string profile, Control surface, SoundAlertOverlay border)
	{
		Clients.Add(profile, new Client
		{
			Surface = surface,
			Border = border
		});
	}

	internal static NotificationChange Publish(NotificationEvent value)
	{
		NotificationChange notificationChange = Queue.Publish(value, Clock.Elapsed.TotalSeconds);
		if (notificationChange != NotificationChange.Ignored)
		{
			Timer.Start();
			Refresh(changed: true);
		}
		return notificationChange;
	}

	internal static void Remove(string profile, bool? visual = null)
	{
		Queue.Remove(profile, visual);
		Refresh(changed: true);
	}

	internal static bool RequestBell(string profile, string id)
	{
		return Queue.RequestBell(profile, id);
	}

	internal static void Unregister(string profile)
	{
		if (Clients.TryGetValue(profile, out var value))
		{
			value.Border.HideAlert();
		}
		Queue.Remove(profile);
		Clients.Remove(profile);
		if (anchor == profile)
		{
			if (group != null)
			{
				group.Dispose();
			}
			group = null;
			anchor = null;
		}
		Refresh(changed: true);
	}

	private static void Refresh(bool changed)
	{
		int num = Queue.Remaining(Clock.Elapsed.TotalSeconds);
		NotificationEvent[] items = Queue.Items;
		if (num == 0 || Clients.Count == 0)
		{
			Timer.Stop();
			if (group != null)
			{
				group.HideAlert();
			}
			foreach (Client value in Clients.Values)
			{
				value.Border.HideAlert();
			}
			rendered = -1;
			return;
		}
		foreach (KeyValuePair<string, Client> pair in Clients)
		{
			NotificationEvent[] array = items.Where((NotificationEvent e) => e.Profile == pair.Key).ToArray();
			if (array.Length == 0)
			{
				pair.Value.Border.HideAlert();
				continue;
			}
			pair.Value.Border.ShowSession(array, Queue.RemainingFor(pair.Key, Clock.Elapsed.TotalSeconds));
			pair.Value.Border.Synchronize();
		}
		rendered = num;
	}
}
