using System;
using System.Collections.Generic;

namespace KanblazCloudShell.SoundAlerts;

internal static class AudioProcessOwnership
{
	private static readonly object Sync = new object();

	private static readonly Dictionary<uint, HashSet<Action>> Owners = new Dictionary<uint, HashSet<Action>>();

	internal static bool Register(uint pid, Action collision)
	{
		Action[] array = null;
		lock (Sync)
		{
			if (!Owners.TryGetValue(pid, out var value))
			{
				value = (Owners[pid] = new HashSet<Action>());
			}
			value.Add(collision);
			if (value.Count > 1)
			{
				array = new Action[value.Count];
				value.CopyTo(array);
			}
		}
		if (array == null)
		{
			return true;
		}
		Action[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			array2[i]();
		}
		return false;
	}

	internal static void Unregister(uint pid, Action collision)
	{
		lock (Sync)
		{
			if (Owners.TryGetValue(pid, out var value))
			{
				value.Remove(collision);
				if (value.Count == 0)
				{
					Owners.Remove(pid);
				}
			}
		}
	}
}
