namespace KanblazCloudShell.SoundAlerts;

internal sealed class SoundReference
{
	internal readonly string Name;

	internal readonly AudioPrint[] Frames;

	internal SoundReference(string name, short[] pcm)
	{
		Name = name;
		Frames = FingerprintExtractor.Fingerprint(pcm);
	}
}
