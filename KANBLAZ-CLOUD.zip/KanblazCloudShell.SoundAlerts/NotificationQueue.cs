using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace KanblazCloudShell.SoundAlerts;

internal sealed class NotificationQueue
{
	private readonly List<NotificationEvent> items = new List<NotificationEvent>();

	private readonly Dictionary<string, string> visualIds = new Dictionary<string, string>();

	private readonly Dictionary<string, double> audioSeen = new Dictionary<string, double>();

	private double deadline = double.NegativeInfinity;

	private readonly bool individual;

	private readonly Dictionary<string, double> deadlines = new Dictionary<string, double>();

	private readonly Dictionary<string, double> shownAt = new Dictionary<string, double>();

	internal NotificationEvent[] Items
	{
		get
		{
			if (!individual)
			{
				return items.ToArray();
			}
			return (from e in items
				group e by e.Profile into g
				select g.First()).ToArray();
		}
	}

	private static void MergeEvidence(NotificationEvent target, NotificationEvent incoming)
	{
		if (incoming.Visual)
		{
			target.Id = incoming.Id;
			target.Visual = true;
			target.BrainrotVisual = true;
			target.BaseCaption = incoming.BaseCaption;
			target.OcrName = incoming.OcrName;
			target.Label = incoming.Label;
		}
		else
		{
			target.AudioName = incoming.Name;
			target.SpokenName = true;
		}
		string text = Identity(target.AudioName);
		string text2 = Identity(target.OcrName);
		target.NameConflict |= text.Length > 0 && text2.Length > 0 && text != text2;
		ref string name = ref target.Name;
		string text3;
		if (target.NameConflict)
		{
			text3 = "";
		}
		else
		{
			text3 = ((text2.Length > 0) ? target.OcrName : (target.AudioName ?? ""));
		}
		name = text3;
		ref float nameConfidence = ref target.NameConfidence;
		float num;
		if (target.NameConflict)
		{
			num = 0f;
		}
		else
		{
			num = ((text.Length > 0 && text2.Length > 0) ? 0.99f : Math.Max(target.NameConfidence, incoming.NameConfidence));
		}
		nameConfidence = num;
		if (target.Visual)
		{
			target.Caption = target.BaseCaption + (string.IsNullOrEmpty(target.Name) ? "" : (" — " + target.Name));
		}
	}

	internal NotificationQueue(bool individual = false)
	{
		this.individual = individual;
	}

	internal int RemainingFor(string profile, double now)
	{
		Remaining(now);
		if (!deadlines.TryGetValue(profile, out var value))
		{
			return 0;
		}
		return Math.Max(0, (int)Math.Ceiling(value - now));
	}

	private static string Identity(string text)
	{
		if (!string.IsNullOrWhiteSpace(text) && !(text == "Unknown"))
		{
			return Regex.Replace((SoundReferences.MatchEternalName(text) ?? text).ToLowerInvariant(), "[^a-z0-9]", "");
		}
		return "";
	}

	internal int Remaining(double now)
	{
		if (individual)
		{
			string[] array = deadlines.Keys.ToArray();
			foreach (string profile in array)
			{
				NotificationEvent notificationEvent = items.FirstOrDefault((NotificationEvent e) => e.Profile == profile);
				items.RemoveAll((NotificationEvent e) => e.Profile == profile && now >= e.Created + 32.0);
				NotificationEvent notificationEvent2 = items.FirstOrDefault((NotificationEvent e) => e.Profile == profile);
				if (notificationEvent2 != null && notificationEvent2 == notificationEvent && items.Count((NotificationEvent e) => e.Profile == profile) > 1 && now >= shownAt[profile] + 10.0)
				{
					items.Remove(notificationEvent2);
					notificationEvent2 = items.FirstOrDefault((NotificationEvent e) => e.Profile == profile);
				}
				if (notificationEvent2 == null)
				{
					deadlines.Remove(profile);
					shownAt.Remove(profile);
					continue;
				}
				if (notificationEvent2 != notificationEvent)
				{
					shownAt[profile] = now;
				}
				deadlines[profile] = notificationEvent2.Created + 32.0;
			}
			if (deadlines.Count != 0)
			{
				return (int)Math.Ceiling(deadlines.Values.Max() - now);
			}
			return 0;
		}
		if (now >= deadline)
		{
			items.Clear();
			return 0;
		}
		if (items.Count != 0)
		{
			return (int)Math.Ceiling(Math.Min(32.0, deadline - now));
		}
		return 0;
	}

	internal NotificationChange Publish(NotificationEvent value, double now)
	{
		Remaining(now);
		if (value == null || string.IsNullOrWhiteSpace(value.Id) || string.IsNullOrWhiteSpace(value.Profile) || string.IsNullOrWhiteSpace(value.Caption))
		{
			return NotificationChange.Ignored;
		}
		if (value.Visual)
		{
			if (visualIds.TryGetValue(value.Profile, out var value2) && value2 == value.Id)
			{
				NotificationEvent notificationEvent = items.FirstOrDefault((NotificationEvent e) => e.Profile == value.Profile && e.Id == value.Id);
				if (notificationEvent == null)
				{
					return NotificationChange.Ignored;
				}
				if (notificationEvent.SpokenName && value.BrainrotVisual)
				{
					MergeEvidence(notificationEvent, value);
					return NotificationChange.Updated;
				}
				if (notificationEvent.Caption == value.Caption)
				{
					return NotificationChange.Ignored;
				}
				notificationEvent.Caption = value.Caption;
				notificationEvent.Name = value.Name;
				notificationEvent.Label = value.Label;
				notificationEvent.OcrName = value.OcrName;
				notificationEvent.BaseCaption = value.BaseCaption;
				notificationEvent.NameConfidence = value.NameConfidence;
				return NotificationChange.Updated;
			}
			visualIds[value.Profile] = value.Id;
		}
		else
		{
			string key = value.Profile + "\0" + Identity(value.Name);
			bool flag = audioSeen.TryGetValue(key, out var value3) && now - value3 < 2.0;
			audioSeen[key] = now;
			string[] array = (from k in audioSeen
				where now - k.Value > 10.0
				select k.Key).ToArray();
			foreach (string key2 in array)
			{
				audioSeen.Remove(key2);
			}
			if (flag)
			{
				return NotificationChange.Ignored;
			}
		}
		string identity = Identity(value.Name);
		if (value.SpokenName || value.BrainrotVisual)
		{
			NotificationEvent[] array2 = items.Where((NotificationEvent e) =>
			{
				if (e.Profile == value.Profile && now - e.Created <= 2.0)
				{
					if (!value.Visual)
					{
						if (e.Visual && e.BrainrotVisual)
						{
							return !e.SpokenName;
						}
						return false;
					}
					if (!e.Visual)
					{
						return e.SpokenName;
					}
					return false;
				}
				return false;
			}).ToArray();
			if (array2.Length == 1)
			{
				MergeEvidence(array2[0], value);
				return NotificationChange.Updated;
			}
		}
		NotificationEvent notificationEvent2 = items.LastOrDefault((NotificationEvent e) => identity.Length > 0 && e.Profile == value.Profile && e.Visual != value.Visual && Identity(e.Name) == identity && now - e.Created <= 3.0);
		if (notificationEvent2 != null)
		{
			if (!value.Visual)
			{
				return NotificationChange.Ignored;
			}
			notificationEvent2.Id = value.Id;
			notificationEvent2.Caption = value.Caption;
			notificationEvent2.Name = value.Name;
			notificationEvent2.Visual = true;
			notificationEvent2.Label = value.Label;
			return NotificationChange.Updated;
		}
		value.Created = now;
		items.Add(value);
		if (individual)
		{
			if (!deadlines.ContainsKey(value.Profile))
			{
				deadlines[value.Profile] = now + 32.0;
				shownAt[value.Profile] = now;
			}
		}
		else if (items.Count > 3)
		{
			items.RemoveAt(0);
		}
		deadline = now + 32.0;
		return NotificationChange.Added;
	}

	internal void Remove(string profile, bool? visual = null)
	{
		items.RemoveAll((NotificationEvent e) => e.Profile == profile && (!visual.HasValue || e.Visual == visual.Value));
		if (!items.Any((NotificationEvent e) => e.Profile == profile))
		{
			deadlines.Remove(profile);
			shownAt.Remove(profile);
		}
		if (!visual.HasValue)
		{
			visualIds.Remove(profile);
			string[] array = audioSeen.Keys.Where((string k) => k.StartsWith(profile + "\0", StringComparison.Ordinal)).ToArray();
			foreach (string key in array)
			{
				audioSeen.Remove(key);
			}
		}
	}

	internal bool RequestBell(string profile, string id)
	{
		NotificationEvent notificationEvent = items.FirstOrDefault((NotificationEvent e) => e.Profile == profile && e.Id == id);
		if (notificationEvent == null || notificationEvent.BellRequested)
		{
			return false;
		}
		notificationEvent.BellRequested = true;
		return true;
	}
}
