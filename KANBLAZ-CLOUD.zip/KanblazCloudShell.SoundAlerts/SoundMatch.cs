namespace KanblazCloudShell.SoundAlerts;

internal sealed class SoundMatch
{
	internal string Name;

	internal double Score;
}
