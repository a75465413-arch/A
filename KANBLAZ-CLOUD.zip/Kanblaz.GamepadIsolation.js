// Registered BEFORE the audio adjustment in the SAME document script.
// Per-page controller routing and explicitly enabled virtual-joystick macro.
// No OS device changes, drivers, keyboard replay or pointer/fullscreen changes.
(() => {
  'use strict';
  const inScope = () => location.protocol === 'https:' && (
    ((location.hostname === 'www.xbox.com' || location.hostname === 'xbox.com') &&
      /^\/(?:[a-z]{2}-[a-z]{2}\/)?play(?:\/|$)/i.test(location.pathname)) ||
    location.hostname === 'play.xbox.com' || location.hostname === 'play.geforcenow.com' ||
    (location.hostname === 'luna.amazon.com' && !/^\/(?:ap|signin|login|auth)(?:\/|$)/i.test(location.pathname)));
  if (!inScope()) return;
  let shared = /*KANBLAZ_CONTROLLER_SHARED*/ false;
  let hostOwned = /*KANBLAZ_CONTROLLER_OWNED*/ null;
  let ownershipUntil = 0;
  let sharedUntil = 0, xinputUntil = 0, xinputPads = null;
  const xinputSlots = new Map();
  const sharing = () => shared && (hostOwned === null || Date.now() < sharedUntil);
  // A navigation can overlap registration replacement. Never wrap an already
  // wrapped API or capture the audio adjustment as if it were native focus.
  if (typeof window.__kanblazControllerSharedV1 === 'function') {
    window.__kanblazControllerSharedV1(shared); return;
  }
  const nativeFocus = Document.prototype.hasFocus;
  const nativeGetGamepads = navigator.getGamepads;
  if (typeof nativeFocus !== 'function' || typeof nativeGetGamepads !== 'function') return;
  const focused = () => {
    try { return inScope() && (hostOwned === null ? nativeFocus.call(document) : hostOwned && Date.now() < ownershipUntil); }
    catch (_) { return false; }
  };
  const editing = () => {
    const element = document.activeElement;
    return !!element && (element.isContentEditable || ['INPUT', 'TEXTAREA', 'SELECT'].includes(element.tagName));
  };
  let mode = 'keyboard', hadFocus = false, busy = false, suspended = false;
  let slots = new Map(), published = new Map(), previousButtons = new Map();
  let listLength = 0;
  let previousAxes = new Map();
  let virtualActive = false, virtualUntil = 0, virtualSlot = null;
  const now = () => typeof performance === 'object' ? performance.now() : Date.now();
  let squareUntil = 0;
  const virtualEngaged = () => ((virtualActive && now() < virtualUntil) || now() < squareUntil) && !suspended && inScope();
  const virtualEditing = () => {
    let target = document.activeElement;
    while (target && target.shadowRoot && target.shadowRoot.activeElement) target = target.shadowRoot.activeElement;
    return !!(target && (target.isContentEditable || ['INPUT','TEXTAREA','SELECT','IFRAME'].includes(target.tagName) ||
      (target.closest && target.closest('form')) ||
      (target.getAttribute && ['textbox','searchbox','combobox'].includes(target.getAttribute('role'))))) ||
      !!(document.querySelector && document.querySelector('dialog[open],[role=dialog][aria-modal=true]'));
  };
  const virtualAllowed = () => virtualEngaged() && !virtualEditing();
  const ownEvents = new WeakSet();
  const enabled = () => !virtualEngaged() && !suspended && inScope() && (sharing() || (!shared && mode === 'gamepad' && focused() && !editing()));
  const pressed = button => !!button && (button.pressed || button.value >= 0.5);
  const inputFor = slot => (slot.isVirtual ? virtualAllowed() : enabled()) && slot.raw && slot.raw.connected &&
    (!slot.raw.kanblazXInput || (sharing() && Date.now() < xinputUntil)) ? slot.raw : null;
  const mergeXInput = native => {
    if (!shared || xinputPads === null) return native;
    // Replace browser XInput duplicates; keep PS4/HID controllers on their existing route.
    const list = native.map(pad => pad && /xinput|xbox|045e/i.test(pad.id) ? null : pad);
    if (Date.now() >= xinputUntil) return list;
    xinputPads.forEach((pad, user) => {
      if (!pad) return;
      let index = xinputSlots.get(user);
      if (index === undefined || list[index]) {
        index = 0; while (list[index]) index++;
        xinputSlots.set(user, index);
      }
      list[index] = { id: 'Xbox Controller (XInput ' + user + ')', index, mapping: 'standard', connected: true,
        kanblazXInput: true, timestamp: pad.timestamp, axes: pad.axes,
        buttons: pad.buttons.map(value => ({ value, pressed: value > 0.5, touched: value > 0 })) };
    });
    return list;
  };
  const actuatorView = (slot, select) => {
    const initial = select(slot.raw);
    if (!initial) return initial;
    const view = Object.create(Object.getPrototypeOf(initial));
    for (const key of ['type', 'effects']) if (key in initial)
      Object.defineProperty(view, key, { enumerable: true, get: () => (select(slot.raw) || initial)[key] });
    for (const key of ['playEffect', 'reset', 'pulse']) if (typeof initial[key] === 'function')
      Object.defineProperty(view, key, { value: (...args) => {
        const raw = inputFor(slot), actuator = raw && select(raw);
        return actuator && typeof actuator[key] === 'function' ? actuator[key](...args)
          : Promise.resolve(key === 'pulse' ? false : 'preempted');
      } });
    return Object.freeze(view);
  };
  const createSlot = raw => {
    const slot = { raw, lastRaw: raw, view: null };
    const view = Object.create(Object.getPrototypeOf(raw));
    const axes = Array.from(raw.axes, () => 0);
    for (let index = 0; index < axes.length; index++)
      Object.defineProperty(axes, index, { enumerable: true, get: () => {
        const current = inputFor(slot); return current && (!slot.isVirtual || (virtualActive && now() < virtualUntil)) ? current.axes[index] : 0;
      } });
    const buttons = Array.from(raw.buttons, (initial, index) => {
      const button = Object.create(Object.getPrototypeOf(initial));
      for (const key of ['pressed', 'touched', 'value'])
        Object.defineProperty(button, key, { enumerable: true, get: () => {
          const current = inputFor(slot);
          if (slot.isVirtual && index === 2) return key === 'value' ? (current && now() < squareUntil ? 1 : 0) : !!(current && now() < squareUntil);
          return current ? current.buttons[index][key] : key === 'value' ? 0 : false;
        } });
      return Object.freeze(button);
    });
    for (const key of ['id', 'index', 'mapping'])
      Object.defineProperty(view, key, { enumerable: true, value: raw[key] });
    Object.defineProperties(view, {
      connected: { enumerable: true, get: () => !!inputFor(slot) },
      timestamp: { enumerable: true, get: () => { const current = inputFor(slot); return current ? current.timestamp : 0; } },
      axes: { enumerable: true, value: Object.freeze(axes) },
      buttons: { enumerable: true, value: Object.freeze(buttons) },
      vibrationActuator: { enumerable: true, value: actuatorView(slot, value => value && value.vibrationActuator) }
    });
    if ('hapticActuators' in raw)
      Object.defineProperty(view, 'hapticActuators', { value: Object.freeze(Array.from(raw.hapticActuators,
        (_, index) => actuatorView(slot, value => value && value.hapticActuators && value.hapticActuators[index]))) });
    slot.view = Object.freeze(view);
    return slot;
  };
  const announce = (type, slot) => {
    // Logical connection notifications only, never button/key/click events.
    // These events are untrusted; they do not impersonate physical browser events.
    try {
      let event;
      try { event = new GamepadEvent(type, { gamepad: slot.raw || slot.lastRaw }); }
      catch (_) { event = new Event(type); }
      Object.defineProperty(event, 'gamepad', { value: slot.view });
      ownEvents.add(event);
      window.dispatchEvent(event);
    } catch (_) { /* Polling still exposes the selected input mode. */ }
  };
  // Independent samples preserve direction/button changes for GeForce clients
  // that compare the previous poll with the current poll.
  const geforceSnapshots = location.hostname === 'play.geforcenow.com';
  const snapshot = view => {
    if (!view || !view.connected) return null;
    return Object.freeze({ id:view.id, index:view.index, mapping:view.mapping,
      connected:true, timestamp:view.timestamp, axes:Object.freeze(Array.from(view.axes)),
      buttons:Object.freeze(Array.from(view.buttons,b=>Object.freeze({pressed:b.pressed,touched:b.touched,value:b.value}))),
      vibrationActuator:view.vibrationActuator });
  };
  const synchronize = () => {
    const desired = virtualAllowed() && virtualSlot ? new Map([[0, virtualSlot]]) :
      enabled() ? new Map(Array.from(slots).filter(([, slot]) => slot.raw && slot.raw.connected)) : new Map();
    const old = published;
    published = desired; // Reentrant listeners must see the new connection state.
    for (const [index, slot] of old) if (desired.get(index) !== slot) announce('gamepaddisconnected', slot);
    for (const [index, slot] of desired) if (old.get(index) !== slot) announce('gamepadconnected', slot);
  };
  const sample = (baseline = false) => {
    if (busy) return;
    busy = true;
    try {
      if (virtualActive && !virtualEngaged()) {
        virtualActive = false;
        mode = 'keyboard'; hadFocus = false; previousButtons.clear();
      }
      if (virtualEngaged()) { synchronize(); return; }
      if (suspended || !inScope() || (shared ? !sharing() : !focused())) {
        mode = 'keyboard'; hadFocus = false; previousButtons.clear();
        if (inScope()) synchronize(); else published.clear();
        return; // Individual mode never polls hardware from background windows.
      }
      const entering = !hadFocus;
      hadFocus = true;
      let native;
      try { native = Array.from(nativeGetGamepads.call(navigator)); }
      catch (_) { if (!sharing() || xinputPads === null) throw _; native = []; }
      const list = mergeXInput(native);
      listLength = list.length;
      const next = new Map(), buttons = new Map(), axes = new Map();
      let freshPress = false;
      for (let index = 0; index < list.length; index++) {
        const raw = list[index];
        if (!raw || !raw.connected) continue;
        const previous = slots.get(index);
        const same = previous && previous.raw && previous.raw.id === raw.id && previous.raw.mapping === raw.mapping &&
          previous.raw.axes.length === raw.axes.length && previous.raw.buttons.length === raw.buttons.length;
        const slot = same ? previous : createSlot(raw);
        slot.raw = slot.lastRaw = raw; next.set(index, slot);
        const down = Array.from(raw.buttons, pressed);
        const before = previousButtons.get(index);
        // A NEW press, not a held button, timestamp change, touch or stick drift.
        if (!baseline && !entering && down.some((value, button) => value && !(before && before[button]))) freshPress = true;
        const values = Array.from(raw.axes);
        const beforeAxes = previousAxes.get(index);
        // Light deliberate movement can select controller mode. Do not amplify
        // the actual axes, react to tiny drift, or activate on a focus baseline.
        if (!baseline && !entering && same && beforeAxes && values.some((value, axis) =>
            Math.abs(value) > .12 && (Math.abs(beforeAxes[axis] || 0) <= .12 ||
            Math.abs(value - (beforeAxes[axis] || 0)) >= .08))) freshPress = true;
        axes.set(index, values);
        buttons.set(index, down);
      }
      for (const [index, slot] of slots) if (next.get(index) !== slot) slot.raw = null;
      slots = next; previousButtons = buttons; previousAxes = axes;
      if (!shared) {
        if (editing() || next.size === 0) mode = 'keyboard';
        else if (freshPress) mode = 'gamepad';
      }
      synchronize();
    } catch (_) {
      // Neither mode may retain a pressed button after a failed hardware read.
      for (const slot of slots.values()) slot.raw = null;
      slots.clear();
      mode = 'keyboard'; hadFocus = false; previousButtons.clear(); synchronize();
    } finally { busy = false; }
  };
  const preferKeyboard = event => {
    if (shared || !event.isTrusted || !focused()) return;
    if (event.type !== 'keydown' && (event.button !== 0 || (event.pointerType && event.pointerType !== 'mouse'))) return;
    mode = 'keyboard';
    sample(true); // A held button cannot immediately undo the user's choice.
    // Do not cancel, stop, replay or synthesize the user's input.
  };
  // Native host supplies only this boolean; no profile, device ID or auth data.
  // Retain the same wrappers so already-cached gamepads obey mode changes too.
  Object.defineProperty(window, '__kanblazControllerSharedV1', { value: value => {
    if (typeof value !== 'boolean' || value === shared) return;
    shared = value;
    mode = 'keyboard'; hadFocus = false; previousButtons.clear();
    sample(true); // Individual resumes safely: release, then press a button.
  } });
  // Production uses a short native-Windows ownership lease, not page-reported
  // focus. Focus emulation/background audio must never enable another controller.
  Object.defineProperty(window, '__kanblazControllerStateV2', { value: (value, owned) => {
    if (typeof value !== 'boolean' || typeof owned !== 'boolean') return false;
    const changed = shared !== value || hostOwned !== owned;
    shared = value; hostOwned = owned; ownershipUntil = owned ? Date.now() + 400 : 0;
    sharedUntil = value ? Date.now() + 400 : 0;
    if (!value) { xinputPads = null; xinputUntil = 0; xinputSlots.clear(); }
    if (changed) {
      mode = 'keyboard'; hadFocus = false; previousButtons.clear(); sample(true);
    }
    return true;
  } });
  // Host-only transport carries bounded numeric state, never device identifiers or profile data.
  // The same cached Gamepad views, macro priority and connection events serve PS4 and Xbox.
  Object.defineProperty(window, '__kanblazXInputV1', { value: pads => {
    if (pads !== null && (!Array.isArray(pads) || pads.length !== 4 || pads.some(pad => pad !== null &&
      (!pad || !Array.isArray(pad.axes) || pad.axes.length !== 4 ||
       !Array.isArray(pad.buttons) || pad.buttons.length !== 17 ||
       pad.axes.some(value => !Number.isFinite(value) || Math.abs(value) > 1) ||
       pad.buttons.some(value => !Number.isFinite(value) || value < 0 || value > 1))))) {
      xinputUntil = 0; sample(); return false;
    }
    xinputPads = pads && pads.map(pad => pad && ({ axes: pad.axes.slice(), buttons: pad.buttons.slice(), timestamp: now() }));
    xinputUntil = sharing() && pads !== null ? Date.now() + 250 : 0;
    sample(); return true;
  } });
  // Explicit app usage: bounded numeric stick positions, never arbitrary
  // commands. Neutral by default; expires closed if refresh/Stop fails.
  const ensureVirtualSlot = () => {
    if (virtualSlot) return;
    const raw = { id: 'KANBLAZ CLOUD Virtual Joystick', index: 0, mapping: 'standard', connected: true,
      timestamp: now(), axes: [0,0,0,0], buttons: Array.from({length:17}, () => ({pressed:false,touched:false,value:0})) };
    virtualSlot = createSlot(raw); virtualSlot.isVirtual = true;
  };
  Object.defineProperty(window, '__kanblazSquareV1', { value: active => {
    if (typeof active !== 'boolean') return false;
    if (active && (!inScope() || suspended || virtualEditing())) return false;
    if (active) ensureVirtualSlot();
    squareUntil = active ? now() + 600 : 0;
    if (virtualSlot) virtualSlot.raw.timestamp = now();
    sample(true); return true;
  } });
  Object.defineProperty(window, '__kanblazVirtualJoystickV1', { value: (active, x, y) => {
    if (typeof active !== 'boolean' || !Number.isFinite(x) || !Number.isFinite(y) ||
        Math.abs(x) > 1 || Math.abs(y) > 1 || x*x + y*y > 1.000001) return false;
    if (active && (!inScope() || suspended || (virtualEditing() && (x !== 0 || y !== 0)))) return false;
    const changed = virtualActive !== active;
    if (active) ensureVirtualSlot();
    if (virtualSlot) {
      virtualSlot.raw.axes[0] = active ? x : 0; virtualSlot.raw.axes[1] = active ? y : 0;
      virtualSlot.raw.timestamp = now();
    }
    virtualActive = active; virtualUntil = active ? now() + 600 : 0;
    if (changed) { mode = 'keyboard'; hadFocus = false; previousButtons.clear(); }
    sample(true);
    return true;
  } });
  Object.defineProperty(navigator, 'getGamepads', {
    configurable: true,
    value: function getGamepads() {
      if (!inScope()) return nativeGetGamepads.call(navigator);
      sample();
      const result = virtualEngaged() ? Array.from({length:Math.max(4,listLength)}, (_, index) =>
        index === 0 && virtualAllowed() ? virtualSlot.view : null) :
        Array.from({ length: listLength }, (_, index) => enabled() && slots.has(index) ? slots.get(index).view : null);
      return geforceSnapshots ? result.map(snapshot) : result;
    }
  });
  for (const type of ['pointerdown', 'mousedown', 'keydown']) window.addEventListener(type, preferKeyboard, true);
  window.addEventListener('focus', () => sample(true), true);
  window.addEventListener('blur', event => {
    if (event.target !== window || shared) return;
    mode = 'keyboard'; hadFocus = false; previousButtons.clear(); synchronize();
  }, true);
  for (const type of ['gamepadconnected', 'gamepaddisconnected'])
    window.addEventListener(type, event => {
      if (!inScope() || ownEvents.has(event)) return;
      event.stopImmediatePropagation(); // Announce logical availability exactly once.
      if (event.isTrusted) sample();
    }, true);
  window.addEventListener('pagehide', () => {
    virtualActive = false; virtualUntil = 0; squareUntil = 0;
    sharedUntil = 0; xinputUntil = 0;
    suspended = true; mode = 'keyboard'; hadFocus = false; previousButtons.clear();
    if (inScope()) synchronize();
  }, true);
  window.addEventListener('pageshow', () => { suspended = false; sample(true); }, true);
  sample(true);
  // Still detects a real button press if the page stops polling after disconnection.
  // Individual polls only the focused window; Shared exposes what the browser allows.
  // No keystrokes or device IDs are persisted. Virtual input exists only while
  // explicitly refreshed by the per-window macro and expires after 600 ms.
  setInterval(sample, 50);
})();
