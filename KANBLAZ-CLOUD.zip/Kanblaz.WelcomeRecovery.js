// Detect only the static confirmation-button label. Never read account headings,
// emails, input values, cookies, storage, URL parameters or tokens; never click it.
(() => {
  'use strict';
  const hosts = new Set(['xbox.com', 'www.xbox.com', 'play.xbox.com',
    'account.xbox.com', 'sisu.xboxlive.com', 'login.live.com']);
  if (location.protocol !== 'https:' || (location.port && location.port !== '443') ||
      !hosts.has(location.hostname) || !window.chrome?.webview) return;
  const labels = new Set(["let's go", 'lets go', 'vamos', '¡vamos!', 'vamos alla', '¡vamos alla!']);
  const normalize = text => (text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[’‘]/g, "'").trim().toLowerCase();
  const visible = node => {
    const rect = node.getBoundingClientRect(), style = getComputedStyle(node);
    return node.isConnected && rect.width > 0 && rect.height > 0 && rect.bottom > 0 && rect.right > 0 &&
      rect.top < innerHeight && rect.left < innerWidth && style.display !== 'none' &&
      style.visibility !== 'hidden' && style.opacity !== '0';
  };
  let since = null, lastSample = null, sent = false;
  const sample = () => {
    const now = performance.now();
    if (lastSample !== null && now - lastSample > 10000) since = null;
    lastSample = now;
    // A live video or a visible editable field means this is not the target screen.
    const playing = Array.from(document.querySelectorAll('video')).some(v => !v.paused && v.readyState >= 2);
    const editing = Array.from(document.querySelectorAll('input:not([type=hidden]),textarea,[contenteditable=true]')).some(visible);
    const blocked = !playing && !editing && Array.from(document.querySelectorAll('button,[role=button]'))
      .some(button => visible(button) && labels.has(normalize(button.textContent)));
    if (!blocked) { since = null; sent = false; return; }
    if (since === null) since = now;
    if (!sent && now - since >= 5000) {
      sent = true;
      window.chrome.webview.postMessage('kanblaz.welcome.blocked.v1');
    }
  };
  setInterval(sample, 500);
})();
