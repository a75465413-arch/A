// Kanblaz experimental compatibility adjustment. Original implementation.
// No timers, synthetic input, media autoplay, credential access or network requests.
(() => {
  'use strict';

  const host = location.hostname.toLowerCase();
  const supportedGamePage = location.protocol === 'https:' && (
    ((host === 'www.xbox.com' || host === 'xbox.com') &&
      /^\/(?:[a-z]{2}-[a-z]{2}\/)?play(?:\/|$)/i.test(location.pathname)) ||
    host === 'play.xbox.com' || host === 'play.geforcenow.com' ||
    (host === 'luna.amazon.com' && !/^\/(?:ap|signin|login|auth)(?:\/|$)/i.test(location.pathname))
  );
  if (!supportedGamePage) return;

  const prototype = Document.prototype;
  const replace = (name, descriptor) => {
    try {
      const original = Object.getOwnPropertyDescriptor(prototype, name);
      Object.defineProperty(prototype, name, {
        configurable: true,
        enumerable: original ? original.enumerable : false,
        ...descriptor
      });
    } catch (_) { /* Unsupported properties leave their native behavior intact. */ }
  };

  replace('hidden', { get: () => false });
  replace('visibilityState', { get: () => 'visible' });
  if ('webkitHidden' in document) replace('webkitHidden', { get: () => false });
  if ('webkitVisibilityState' in document) replace('webkitVisibilityState', { get: () => 'visible' });
  replace('hasFocus', { value: function hasFocus() { return true; }, writable: true });

  const blockPageVisibility = event => {
    if (event.target === document || event.target === window) event.stopImmediatePropagation();
  };
  window.addEventListener('visibilitychange', blockPageVisibility, true);
  window.addEventListener('webkitvisibilitychange', blockPageVisibility, true);
  // Only the window-level blur is filtered. Inputs retain their normal blur/focusout
  // events; keyboard, mouse, pointer-lock and fullscreen events are never intercepted.
  window.addEventListener('blur', event => {
    if (event.target === window) event.stopImmediatePropagation();
  }, true);
})();
