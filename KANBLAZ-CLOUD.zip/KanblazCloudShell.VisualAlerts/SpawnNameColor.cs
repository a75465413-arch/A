using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace KanblazCloudShell.VisualAlerts;

internal static class SpawnNameColor
{
	private sealed class Letter
	{
		internal int Color;

		internal int Area;

		internal Rectangle Bounds;
	}

	internal static string Detect(Bitmap image, Rectangle region)
	{
		region = Rectangle.Intersect(new Rectangle(Point.Empty, image.Size), region);
		if (region.Width < 12 || region.Height < 6)
		{
			return "unknown";
		}
		int width = region.Width;
		int height = region.Height;
		Color[] array = new Color[width * height];
		int[] array2 = new int[width * height];
		bool[] array3 = new bool[width * height];
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				array2[i * width + j] = Kind(array[i * width + j] = image.GetPixel(region.X + j, region.Y + i));
			}
		}
		List<Letter> list = new List<Letter>();
		int[] array4 = new int[4]
		{
			-1,
			1,
			-width,
			width
		};
		for (int k = 0; k < array2.Length; k++)
		{
			int num = array2[k];
			if (num == 0 || array3[k])
			{
				continue;
			}
			Queue<int> queue = new Queue<int>();
			queue.Enqueue(k);
			array3[k] = true;
			int num2 = width;
			int num3 = 0;
			int num4 = height;
			int num5 = 0;
			int num6 = 0;
			int num7 = 0;
			int num8 = 0;
			int num9 = 0;
			while (queue.Count > 0)
			{
				int num10 = queue.Dequeue();
				int num11 = num10 % width;
				int val = num10 / width;
				num6++;
				num2 = Math.Min(num2, num11);
				num3 = Math.Max(num3, num11);
				num4 = Math.Min(num4, val);
				num5 = Math.Max(num5, val);
				int[] array5 = array4;
				foreach (int num12 in array5)
				{
					int num13 = num10 + num12;
					if (num13 < 0 || num13 >= array2.Length || (num12 == -1 && num11 == 0) || (num12 == 1 && num11 == width - 1))
					{
						continue;
					}
					if (array2[num13] == num)
					{
						if (!array3[num13])
						{
							array3[num13] = true;
							queue.Enqueue(num13);
						}
						continue;
					}
					num7++;
					Color color = array[num13];
					if ((num == 4) ? (Math.Min(color.R, Math.Min(color.G, color.B)) > 150) : (Math.Max(color.R, Math.Max(color.G, color.B)) < 110))
					{
						num8++;
					}
					if ((array2[num13] >= 1 && array2[num13] <= 3) || array2[num13] >= 5)
					{
						num9++;
					}
				}
			}
			int num14 = num5 - num4 + 1;
			int num15 = num3 - num2 + 1;
			if (num6 >= 4 && num14 >= 3 && !((double)num14 > (double)height * 0.9) && num15 <= num14 * 4 && num2 != 0 && num3 != width - 1 && num4 != 0 && num5 != height - 1 && num7 != 0 && !((double)num8 < ((num == 4) ? 0.18 : 0.15) * (double)num7) && (num != 4 || !((double)num9 > (double)num7 * 0.06)))
			{
				list.Add(new Letter
				{
					Color = num,
					Area = num6,
					Bounds = new Rectangle(num2, num4, num15, num14)
				});
			}
		}
		int[] scores = new int[8];
		foreach (Letter seed in list)
		{
			Letter[] array6 = list.Where((Letter letter) => letter.Color == seed.Color && (double)Math.Abs(letter.Bounds.Bottom - seed.Bounds.Bottom) <= Math.Max(2.0, (double)seed.Bounds.Height * 0.3) && (double)letter.Bounds.Height >= (double)seed.Bounds.Height * 0.45 && (double)letter.Bounds.Height <= (double)seed.Bounds.Height * 1.8).ToArray();
			if (array6.Length < 3)
			{
				continue;
			}
			int num16 = array6.Max((Letter letter) => letter.Bounds.Right) - array6.Min((Letter letter) => letter.Bounds.Left);
			if (num16 >= 12 && !((double)num16 > (double)width * 0.95))
			{
				scores[seed.Color] = Math.Max(scores[seed.Color], array6.Sum((Letter letter) => letter.Area));
			}
		}
		int[] source = new int[6] { 1, 2, 3, 5, 6, 7 };
		int best = source.OrderByDescending((int num17) => scores[num17]).First();
		if (scores[best] >= 12)
		{
			if ((double)source.Where((int num17) => num17 != best).Max((int num17) => scores[num17]) > (double)scores[best] * 0.45)
			{
				return "unknown";
			}
			return (new string[8] { "unknown", "red", "green", "blue", "black", "purple", "pink", "yellow" })[best];
		}
		if (scores[4] < 18)
		{
			return "unknown";
		}
		return "black";
	}

	private static int Kind(Color p)
	{
		float hue = p.GetHue();
		if (p.R > 120 && p.B > 65 && (double)(int)p.R > (double)(int)p.G * 1.3 && (double)(int)p.B > (double)(int)p.G * 1.2 && hue >= 290f && hue < 350f)
		{
			return 6;
		}
		if (p.R > 110 && p.G > 100 && (double)(int)p.B < (double)(int)Math.Min(p.R, p.G) * 0.6 && hue >= 35f && hue <= 70f)
		{
			return 7;
		}
		if (p.B > 55 && p.R > 35 && (double)(int)p.B > (double)(int)p.G * 1.3 && (double)(int)p.R > (double)(int)p.G * 1.3 && p.GetHue() > 250f && p.GetHue() < 330f)
		{
			return 5;
		}
		if (p.R > 100 && (double)(int)p.R > (double)(int)p.G * 1.5 && (double)(int)p.R > (double)(int)p.B * 1.4)
		{
			return 1;
		}
		if (p.G > 75 && (double)(int)p.G > (double)(int)p.R * 1.3 && (double)(int)p.G > (double)(int)p.B * 1.15)
		{
			return 2;
		}
		if (p.B > 100 && (double)(int)p.B > (double)(int)p.R * 1.4 && (double)(int)p.B > (double)(int)p.G * 1.15 && p.GetHue() <= 250f)
		{
			return 3;
		}
		if (Math.Max(p.R, Math.Max(p.G, p.B)) >= 80)
		{
			return 0;
		}
		return 4;
	}
}
