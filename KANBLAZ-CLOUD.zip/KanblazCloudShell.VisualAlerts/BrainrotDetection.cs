using System;
using System.Drawing;

namespace KanblazCloudShell.VisualAlerts;

internal sealed class BrainrotDetection
{
	internal SpawnNotice Notice;

	internal string Name = "Unknown";

	internal string Method = "none";

	internal string NameColor = "unknown";

	internal float TriggerConfidence;

	internal float NameConfidence;

	internal float NameAttemptConfidence;

	internal bool NameFromCatalog;

	internal double TemplateScore;

	internal Rectangle TriggerRegion;

	internal Rectangle NameRegion;

	internal SpawnNotice Rarity;

	internal string SpriteCategory = "";

	internal string RaritySource = "none";

	internal readonly string EventId = Guid.NewGuid().ToString("N");

	internal SpawnNotice AlertNotice
	{
		get
		{
			if (Notice == SpawnNotice.None || Notice == SpawnNotice.Box || Notice == SpawnNotice.LuckyRot || Rarity == SpawnNotice.None)
			{
				return Notice;
			}
			return Rarity;
		}
	}

	internal string Callout(string profile, bool includeName = true)
	{
		string text = ((!includeName || string.IsNullOrWhiteSpace(Name) || string.Equals(Name, "Unknown", StringComparison.OrdinalIgnoreCase)) ? "" : Name);
		string text2;
		if (Notice != SpawnNotice.LuckyRot)
		{
			if (Notice == SpawnNotice.Box)
			{
				text2 = ((text.Length > 0) ? (text + " ") : "") + "Box Spawned!";
			}
			else
			{
				text2 = ((Notice == SpawnNotice.Sprite) ? "SPRITE SPAWNED!" : (SpawnNotices.Caption(Notice) + ((Rarity != SpawnNotice.None) ? (" — Rarity: " + Rarity) : "") + ((text.Length > 0) ? (" — " + text) : "")));
			}
		}
		else
		{
			text2 = ((text.Length > 0) ? text : "Grande Lucky Rot");
		}
		return text2 + " — " + profile;
	}

	internal static SpawnNotice RarityForColor(string color)
	{
		switch (color)
		{
		default:
			return SpawnNotice.None;
		case "purple":
		case "pink":
		case "yellow":
			return SpawnNotice.Others;
		case "blue":
			return SpawnNotice.GOAT;
		case "green":
			return SpawnNotice.Absolute;
		case "black":
			return SpawnNotice.Secret;
		case "red":
			return SpawnNotice.Eternal;
		}
	}
}
