using System;
using System.Text;

namespace KanblazCloudShell.VisualAlerts;

internal sealed class OcrTrace
{
	internal readonly string Id = Guid.NewGuid().ToString("N");

	private readonly string profile;

	private readonly StringBuilder rows = new StringBuilder();

	internal OcrTrace(string profile)
	{
		this.profile = profile;
	}

	internal static string Clean(string value)
	{
		value = (value ?? "").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
		if (value.Length <= 400)
		{
			return value;
		}
		return value.Substring(0, 400);
	}

	internal void Add(string stage, string detail)
	{
		if (rows.Length < 28000)
		{
			rows.Append(DateTime.UtcNow.ToString("o")).Append('\t').Append(Id)
				.Append('\t')
				.Append(Clean(profile))
				.Append('\t')
				.Append(Clean(stage))
				.Append('\t')
				.Append(Clean(detail))
				.AppendLine();
		}
	}

	internal void Finish()
	{
		OcrTraceLog.Enqueue(rows.ToString());
	}

	internal static void Outcome(string profile, string eventId, string outcome)
	{
		OcrTrace ocrTrace = new OcrTrace(profile);
		ocrTrace.Add("notification-result", eventId + " " + outcome);
		ocrTrace.Finish();
	}
}
