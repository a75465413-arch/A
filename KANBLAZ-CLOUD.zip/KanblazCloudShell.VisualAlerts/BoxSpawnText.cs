using System.Text.RegularExpressions;

namespace KanblazCloudShell.VisualAlerts;

internal static class BoxSpawnText
{
	internal static string Extract(string text, float confidence)
	{
		if (string.IsNullOrWhiteSpace(text) || text.Length > 180 || confidence < 0.6f)
		{
			return null;
		}
		Match match = Regex.Match(text.Trim(), "^(?<name>[\\p{L}\\p{N}][\\p{L}\\p{N} '\\-]{0,79}?)\\s+Box\\s+Spawned\\s*(?:![^\\p{L}]*|[.,]*)$", RegexOptions.IgnoreCase);
		if (!match.Success)
		{
			return null;
		}
		return Regex.Replace(match.Groups["name"].Value.Trim(), "\\s+", " ");
	}
}
