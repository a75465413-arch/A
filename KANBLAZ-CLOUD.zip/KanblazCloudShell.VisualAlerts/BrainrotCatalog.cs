using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text.RegularExpressions;

namespace KanblazCloudShell.VisualAlerts;

[DataContract]
internal sealed class BrainrotCatalog
{
	[DataMember(Name = "version")]
	public int Version;

	[DataMember(Name = "entries")]
	public CatalogEntry[] Entries;

	internal static BrainrotCatalog Load(string path)
	{
		try
		{
			if (!File.Exists(path) || new FileInfo(path).Length > 1048576)
			{
				return Empty();
			}
			using FileStream stream = File.OpenRead(path);
			BrainrotCatalog brainrotCatalog = (BrainrotCatalog)new DataContractJsonSerializer(typeof(BrainrotCatalog)).ReadObject(stream);
			return (brainrotCatalog != null && brainrotCatalog.Version == 1 && brainrotCatalog.Entries != null) ? brainrotCatalog : Empty();
		}
		catch (IOException)
		{
			return Empty();
		}
		catch (UnauthorizedAccessException)
		{
			return Empty();
		}
		catch (SerializationException)
		{
			return Empty();
		}
	}

	private static BrainrotCatalog Empty()
	{
		return new BrainrotCatalog
		{
			Version = 1,
			Entries = new CatalogEntry[0]
		};
	}

	private static string Key(string value)
	{
		return Regex.Replace(value ?? "", "[^a-z0-9]", "", RegexOptions.IgnoreCase).ToLowerInvariant();
	}

	internal CatalogEntry Match(string text, float confidence)
	{
		if (confidence < 0.6f)
		{
			return null;
		}
		string key = Key(text);
		bool flag = Regex.IsMatch(key, "^\\d+$");
		if (flag && (confidence < 0.85f || !string.Equals((text ?? "").Trim(), key, StringComparison.Ordinal)))
		{
			return null;
		}
		if (key.Length < (flag ? 2 : 3))
		{
			return null;
		}
		CatalogEntry[] array = (Entries ?? new CatalogEntry[0]).Where((CatalogEntry e) => e != null && e.Notice != SpawnNotice.None && !string.IsNullOrWhiteSpace(e.Name) && (Key(e.Name) == key || (e.Aliases ?? new string[0]).Any((string a) => Key(a) == key))).ToArray();
		if (array.Length != 1)
		{
			return null;
		}
		return array[0];
	}
}
