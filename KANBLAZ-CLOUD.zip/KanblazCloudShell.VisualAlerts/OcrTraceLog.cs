using System;
using System.Collections.Concurrent;
using System.IO;
using System.Text;
using System.Threading;

namespace KanblazCloudShell.VisualAlerts;

internal static class OcrTraceLog
{
	private static readonly ConcurrentQueue<string> Queue = new ConcurrentQueue<string>();

	private static int count;

	private static int writing;

	internal static readonly string DirectoryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "ocr-private-trace");

	private static readonly string FilePath = Path.Combine(DirectoryPath, "trace-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N") + ".tsv");

	private static readonly Timer FlushTimer = new Timer((object _) =>
	{
		Flush();
	}, null, 1000, 1000);

	internal static void Enqueue(string value)
	{
		if (Interlocked.Increment(ref count) > 128)
		{
			Interlocked.Decrement(ref count);
		}
		else
		{
			Queue.Enqueue(value);
		}
	}

	internal static void Flush()
	{
		if (Interlocked.Exchange(ref writing, 1) != 0)
		{
			return;
		}
		try
		{
			StringBuilder stringBuilder = new StringBuilder();
			string result;
			while (Queue.TryDequeue(out result))
			{
				Interlocked.Decrement(ref count);
				stringBuilder.Append(result);
				if (stringBuilder.Length >= 262144)
				{
					break;
				}
			}
			if (stringBuilder.Length == 0)
			{
				return;
			}
			Directory.CreateDirectory(DirectoryPath);
			long num = 0L;
			FileInfo[] files = new DirectoryInfo(DirectoryPath).GetFiles("trace-*.tsv");
			foreach (FileInfo fileInfo in files)
			{
				num += fileInfo.Length;
			}
			if (num + stringBuilder.Length * 4 <= 20971520)
			{
				if (!File.Exists(FilePath))
				{
					File.AppendAllText(FilePath, "utc\tscan\tprofile\tstage\tdetail\r\n", Encoding.UTF8);
				}
				File.AppendAllText(FilePath, stringBuilder.ToString(), Encoding.UTF8);
			}
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		finally
		{
			Interlocked.Exchange(ref writing, 0);
		}
	}
}
