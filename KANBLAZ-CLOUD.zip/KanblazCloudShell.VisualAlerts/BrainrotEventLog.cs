using System;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;

namespace KanblazCloudShell.VisualAlerts;

internal static class BrainrotEventLog
{
	private static readonly object Gate = new object();

	internal static string DirectoryPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "detection-events");

	internal static void Write(string profile, BrainrotDetection result, string outcome)
	{
		WriteToDirectory(DirectoryPath, profile, result, outcome);
	}

	internal static void WriteToDirectory(string directory, string profile, BrainrotDetection result, string outcome)
	{
		string text = Regex.Replace(profile ?? "", "[\\r\\n\\t|]", " ");
		string contents = DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt", CultureInfo.InvariantCulture) + " | " + result.Notice.ToString() + " | " + result.Name + " | " + text + " | trigger=" + result.Method + "; confidence=" + result.TriggerConfidence.ToString("F2", CultureInfo.InvariantCulture) + "; name=" + ((result.Name == "Unknown") ? "unreadable" : "ocr") + "; nameConfidence=" + result.NameConfidence.ToString("F2", CultureInfo.InvariantCulture) + "; nameAttemptConfidence=" + result.NameAttemptConfidence.ToString("F2", CultureInfo.InvariantCulture) + "; color=" + result.NameColor + "; rarity=" + result.Rarity.ToString() + "; raritySource=" + result.RaritySource + "; alert=" + result.AlertNotice.ToString() + "; template=" + result.TemplateScore.ToString("F2", CultureInfo.InvariantCulture) + "; " + outcome + Environment.NewLine;
		lock (Gate)
		{
			Directory.CreateDirectory(directory);
			string text2 = Path.Combine(directory, "events-" + DateTime.Now.ToString("yyyy-MM-dd") + ".log");
			if (File.Exists(text2) && new FileInfo(text2).Length > 5242880)
			{
				throw new IOException("Daily detection log is full.");
			}
			File.AppendAllText(text2, contents);
		}
	}
}
