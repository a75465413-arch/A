namespace KanblazCloudShell.VisualAlerts;

internal enum SpawnNotice
{
	None,
	Uncollected,
	Eternal,
	Secret,
	Absolute,
	Box,
	LuckyRot,
	GOAT,
	Sprite,
	Brainrot,
	Others
}
