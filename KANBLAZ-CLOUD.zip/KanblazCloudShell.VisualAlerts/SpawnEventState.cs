using System;

namespace KanblazCloudShell.VisualAlerts;

internal sealed class SpawnEventState
{
	private BrainrotDetection current;

	private string pending;

	private int votes;

	private int missing;

	private double missingSince;

	internal string LastDecision { get; private set; }

	private static bool Known(string name)
	{
		if (!string.IsNullOrWhiteSpace(name))
		{
			return name != "Unknown";
		}
		return false;
	}

	internal BrainrotDetection Observe(BrainrotDetection sample, double now)
	{
		LastDecision = "accepted";
		if (sample == null || sample.Notice == SpawnNotice.None)
		{
			LastDecision = "no-trigger";
			if (missing++ == 0)
			{
				missingSince = now;
			}
			if (missing >= 2 && now - missingSince >= 1.0)
			{
				current = null;
				pending = null;
				votes = 0;
			}
			return null;
		}
		missing = 0;
		int num;
		int num2;
		if (current != null && sample.Notice == current.Notice)
		{
			num = ((sample.SpriteCategory == current.SpriteCategory) ? 1 : 0);
			if (num != 0 && Known(current.Name) && Known(sample.Name))
			{
				num2 = ((!string.Equals(current.Name, sample.Name, StringComparison.OrdinalIgnoreCase)) ? 1 : 0);
				goto IL_00eb;
			}
		}
		else
		{
			num = 0;
		}
		num2 = 0;
		goto IL_00eb;
		IL_00eb:
		bool flag = (byte)num2 != 0;
		if (num != 0 && !flag)
		{
			pending = null;
			votes = 0;
			if ((Known(current.Name) || !Known(sample.Name)) && (current.Rarity != SpawnNotice.None || sample.Rarity == SpawnNotice.None) && (!(current.RaritySource == "catalog") || !(sample.RaritySource == "color")))
			{
				LastDecision = "duplicate-current-event";
				return null;
			}
			LastDecision = "enriched-current-event";
			if (!Known(current.Name))
			{
				current.Name = sample.Name;
				current.NameConfidence = sample.NameConfidence;
			}
			if (current.Rarity == SpawnNotice.None || (current.RaritySource == "catalog" && sample.RaritySource == "color"))
			{
				current.Rarity = sample.Rarity;
				current.NameColor = sample.NameColor;
				current.RaritySource = sample.RaritySource;
			}
			return current;
		}
		string text = sample.Notice.ToString() + ":" + sample.SpriteCategory + ":" + sample.Name;
		if (text == pending)
		{
			votes++;
		}
		else
		{
			pending = text;
			votes = 1;
		}
		bool flag2 = sample.Notice == SpawnNotice.Sprite || sample.Notice == SpawnNotice.Box || sample.Notice == SpawnNotice.LuckyRot;
		bool flag3 = sample.NameFromCatalog && sample.NameConfidence >= 0.8f && sample.TriggerConfidence >= 0.85f;
		if (((flag && !flag3) || (flag2 && sample.TriggerConfidence < 0.85f)) && votes < 2)
		{
			LastDecision = "waiting-second-observation";
			return null;
		}
		current = sample;
		pending = null;
		votes = 0;
		return current;
	}

	internal void Reset()
	{
		current = null;
		pending = null;
		votes = (missing = 0);
		missingSince = 0.0;
	}
}
