using System.Text.RegularExpressions;

namespace KanblazCloudShell.VisualAlerts;

internal static class SpawnNotices
{
	internal static string Caption(SpawnNotice notice)
	{
		return notice switch
		{
			SpawnNotice.Others => "Others Brainrot Spawned!", 
			SpawnNotice.Brainrot => "Brainrot Spawned!", 
			SpawnNotice.Absolute => "Absolute Brainrot Spawned!", 
			SpawnNotice.GOAT => "GOAT Brainrot Spawned!", 
			SpawnNotice.Secret => "Secret Brainrot Spawned!", 
			SpawnNotice.Uncollected => "Uncollected Brainrot Spawned!", 
			SpawnNotice.Eternal => "Eternal Brainrot Spawned!", 
			_ => string.Empty, 
		};
	}

	internal static bool UsesBell(SpawnNotice notice)
	{
		return notice == SpawnNotice.Eternal;
	}

	internal static SpawnNotice Match(string text, float confidence)
	{
		if (string.IsNullOrEmpty(text) || text.Length > 4096 || confidence < 0.35f)
		{
			return SpawnNotice.None;
		}
		text = Regex.Replace(text, "\\buncoliec\\s+ed(?=\\s+brainrot\\s+spawned\\b)", "uncollected", RegexOptions.IgnoreCase);
		MatchCollection matchCollection = Regex.Matches(text.ToLowerInvariant(), "[a-z]+");
		for (int i = 0; i + 2 < matchCollection.Count; i++)
		{
			string value = matchCollection[i + 1].Value;
			string value2 = matchCollection[i + 2].Value;
			if ((!(value != "brainrot") || !(value != "bralnrot") || !(value != "grainrot") || !(value != "gralnrot") || !(value != "brainsot")) && (!(value2 != "spawned") || !(value2 != "spawnedt") || !(value2 != "spavrned")))
			{
				switch (matchCollection[i].Value)
				{
				case "common":
				case "rare":
				case "epic":
				case "legendary":
				case "mythic":
					return SpawnNotice.Brainrot;
				case "secret":
					return SpawnNotice.Secret;
				case "goat":
					return SpawnNotice.GOAT;
				case "absolute":
				case "absoiute":
					return SpawnNotice.Absolute;
				case "eternal":
				case "bhernal":
				case "eternai":
				case "etemal":
					return SpawnNotice.Eternal;
				case "uncollect":
				case "uncollected":
				case "uncoilected":
				case "uncoliected":
				case "uncoiiected":
				case "uncallected":
				case "uncoltected":
				case "uncolfected":
					return SpawnNotice.Uncollected;
				}
			}
		}
		return SpawnNotice.None;
	}
}
