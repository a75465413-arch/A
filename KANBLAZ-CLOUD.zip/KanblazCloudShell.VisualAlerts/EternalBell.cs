using System;
using System.Diagnostics;
using System.IO;
using System.Media;
using System.Text;
using KanblazCloudShell.SoundAlerts;

namespace KanblazCloudShell.VisualAlerts;

internal static class EternalBell
{
	private static readonly Stopwatch Clock = Stopwatch.StartNew();

	private static readonly MemoryStream Wave = new MemoryStream(CreateWave());

	private static readonly SoundPlayer Player = new SoundPlayer(Wave);

	private static double nextAllowed = double.NegativeInfinity;

	internal static bool PlayForSound(string name, Action play)
	{
		if (!SoundReferences.IsEternal(name))
		{
			return false;
		}
		play();
		return true;
	}

	internal static void Play()
	{
		double totalSeconds = Clock.Elapsed.TotalSeconds;
		if (!(totalSeconds < nextAllowed))
		{
			nextAllowed = totalSeconds + 1.0;
			Player.Play();
		}
	}

	internal static byte[] CreateWave()
	{
		using MemoryStream memoryStream = new MemoryStream();
		using BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write(Encoding.ASCII.GetBytes("RIFF"));
		binaryWriter.Write(39726);
		binaryWriter.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
		binaryWriter.Write(16);
		binaryWriter.Write((short)1);
		binaryWriter.Write((short)1);
		binaryWriter.Write(22050);
		binaryWriter.Write(44100);
		binaryWriter.Write((short)2);
		binaryWriter.Write((short)16);
		binaryWriter.Write(Encoding.ASCII.GetBytes("data"));
		binaryWriter.Write(39690);
		for (int i = 0; i < 19845; i++)
		{
			double num = (double)i / 22050.0;
			double num2 = Math.Min(1.0, num / 0.008) * Math.Min(1.0, (double)(19844 - i) / 1102.5);
			double num3 = 0.65 * Math.Sin(Math.PI * 2093.0 * num) * Math.Exp(-5.0 * num) + 0.23 * Math.Sin(Math.PI * 5768.0 * num) * Math.Exp(-8.0 * num) + 0.12 * Math.Sin(Math.PI * 11302.0 * num) * Math.Exp(-11.0 * num);
			binaryWriter.Write((short)(7208.74 * num2 * num3));
		}
		return memoryStream.ToArray();
	}
}
