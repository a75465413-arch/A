using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace KanblazCloudShell.VisualAlerts;

internal sealed class SessionVisualAlerts : IDisposable
{
	internal const string StreamVisibleScript = "(() => {\n          if (document.querySelector('input[type=password],input[autocomplete=one-time-code]')) return false;\n          return Array.from(document.querySelectorAll('video')).some(v => {\n            const r = v.getBoundingClientRect(), s = getComputedStyle(v);\n            return !v.paused && !v.ended && v.readyState >= 2 && v.videoWidth >= 300 &&\n              r.width >= innerWidth * .6 && r.height >= innerHeight * .5 &&\n              r.right > 0 && r.bottom > 0 && r.left < innerWidth && r.top < innerHeight &&\n              s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0';\n          });\n        })()";

	private readonly WebView2 browser;

	private readonly Func<string, bool> allowedPage;

	private readonly Action<BrainrotDetection> notify;

	private readonly Action<string> status;

	private readonly SpawnEventState events = new SpawnEventState();

	private bool active;

	private bool disposed;

	private bool scanning;

	private bool faulted;

	private bool announced;

	private int generation;

	private double nextScan;

	private double nextDiagnostic;

	private readonly string traceProfile;

	private double nextEligibilityTrace;

	internal SessionVisualAlerts(WebView2 browser, Func<string, bool> allowedPage, Action<BrainrotDetection> notify, Action<string> status, string traceProfile = "session")
	{
		this.browser = browser;
		this.allowedPage = allowedPage;
		this.notify = notify;
		this.status = status;
		this.traceProfile = traceProfile;
	}

	internal void Start()
	{
		if (!disposed && !active)
		{
			active = true;
			faulted = false;
			announced = false;
			nextScan = 0.0;
			VisualAlertScheduler.Add(this);
		}
	}

	internal void Stop()
	{
		active = false;
		generation++;
		events.Reset();
		VisualAlertScheduler.Remove(this);
	}

	internal bool Ready(double now)
	{
		if (!active || disposed || faulted || scanning || now < nextScan || browser.IsDisposed)
		{
			return false;
		}
		try
		{
			Form form = browser.TopLevelControl as Form;
			bool flag = browser.IsHandleCreated && browser.Visible && browser.Width >= 240 && browser.Height >= 120 && form != null && form.Visible && form.WindowState != FormWindowState.Minimized && browser.CoreWebView2 != null && allowedPage(browser.CoreWebView2.Source);
			if (!flag && now >= nextEligibilityTrace)
			{
				nextEligibilityTrace = now + 10.0;
				OcrTrace ocrTrace = new OcrTrace(traceProfile);
				ocrTrace.Add("not-ready", "handle=" + browser.IsHandleCreated + "; visible=" + browser.Visible + "; size=" + browser.Width + "x" + browser.Height + "; host=" + ((form == null) ? "none" : form.WindowState.ToString()) + "; hostVisible=" + (form?.Visible ?? false) + "; core=" + (browser.CoreWebView2 != null));
				ocrTrace.Finish();
			}
			return flag;
		}
		catch (InvalidOperationException)
		{
			return false;
		}
		catch (COMException)
		{
			return false;
		}
	}

	private bool Current(int request, CoreWebView2 core, string address)
	{
		if (active && !disposed && request == generation && !browser.IsDisposed && browser.CoreWebView2 == core && core.Source == address)
		{
			return allowedPage(core.Source);
		}
		return false;
	}

	internal async Task ScanAsync()
	{
		if (!Ready(VisualAlertScheduler.Now))
		{
			return;
		}
		scanning = true;
		int request = generation;
		CoreWebView2 core = browser.CoreWebView2;
		string address = core.Source;
		string stage = "playback-check";
		OcrTrace trace = new OcrTrace(traceProfile);
		trace.Add("scan-start", "generation=" + request + "; browser=" + browser.Width + "x" + browser.Height);
		try
		{
			string text = await core.ExecuteScriptAsync("(() => {\n          if (document.querySelector('input[type=password],input[autocomplete=one-time-code]')) return false;\n          return Array.from(document.querySelectorAll('video')).some(v => {\n            const r = v.getBoundingClientRect(), s = getComputedStyle(v);\n            return !v.paused && !v.ended && v.readyState >= 2 && v.videoWidth >= 300 &&\n              r.width >= innerWidth * .6 && r.height >= innerHeight * .5 &&\n              r.right > 0 && r.bottom > 0 && r.left < innerWidth && r.top < innerHeight &&\n              s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0';\n          });\n        })()");
			if (!Current(request, core, address))
			{
				trace.Add("rejected", "document changed before capture");
				return;
			}
			if (text != "true")
			{
				trace.Add("rejected", "playback gate false");
				events.Observe(new BrainrotDetection(), VisualAlertScheduler.Now);
				return;
			}
			using MemoryStream memory = new MemoryStream();
			stage = "capture";
			double capturedAt = VisualAlertScheduler.Now;
			trace.Add("capture-start", "");
			await core.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png, memory);
			trace.Add("capture-end", "ms=" + ((VisualAlertScheduler.Now - capturedAt) * 1000.0).ToString("F1", CultureInfo.InvariantCulture));
			if (!Current(request, core, address))
			{
				trace.Add("rejected", "document changed after capture");
				return;
			}
			if (memory.Length == 0L || memory.Length > 33554432)
			{
				throw new InvalidDataException();
			}
			memory.Position = 0L;
			using Bitmap image = new Bitmap(memory);
			stage = "trigger-ocr";
			BrainrotDetection brainrotDetection = await VisualAlertScheduler.RecognizeAsync(image, capturedAt, trace);
			if (!Current(request, core, address))
			{
				trace.Add("rejected", "document changed after OCR");
				return;
			}
			if (brainrotDetection == null)
			{
				trace.Add("rejected", "OCR skipped; see queue stage");
				return;
			}
			string[] array = new string[10]
			{
				"event=",
				brainrotDetection.EventId,
				"; notice=",
				brainrotDetection.Notice.ToString(),
				"; confidence=",
				brainrotDetection.TriggerConfidence.ToString("F4", CultureInfo.InvariantCulture),
				"; method=",
				brainrotDetection.Method,
				"; region=",
				null
			};
			Rectangle triggerRegion = brainrotDetection.TriggerRegion;
			array[9] = triggerRegion.ToString();
			trace.Add("detection", string.Concat(array));
			if (VisualAlertScheduler.Now - capturedAt > 5.0)
			{
				trace.Add("rejected", "result age exceeds 5s");
				return;
			}
			if (!announced)
			{
				announced = true;
				status("Brainrot detector active · trigger / name / visual template · local event log");
			}
			BrainrotDetection brainrotDetection2 = events.Observe(brainrotDetection, VisualAlertScheduler.Now);
			trace.Add("state", events.LastDecision);
			if (brainrotDetection2 != null)
			{
				notify(brainrotDetection2);
			}
			else if (brainrotDetection.Notice == SpawnNotice.None && VisualAlertScheduler.Now >= nextDiagnostic)
			{
				nextDiagnostic = VisualAlertScheduler.Now + 60.0;
				status("Detection diagnostic: capture=ok; trigger=no-match; name=not-run; ui=not-requested; audio=not-requested");
			}
		}
		catch
		{
			trace.Add("error", stage);
			if (active && !disposed && request == generation)
			{
				faulted = true;
				status("Detection failed at " + stage + ". Keep all OCR files and the Visual C++ x64 runtime installed; toggle Text alerts to retry.");
			}
		}
		finally
		{
			scanning = false;
			nextScan = VisualAlertScheduler.Now + 0.35;
			trace.Add("scan-end", "");
			trace.Finish();
		}
	}

	public void Dispose()
	{
		if (!disposed)
		{
			Stop();
			disposed = true;
		}
	}
}
