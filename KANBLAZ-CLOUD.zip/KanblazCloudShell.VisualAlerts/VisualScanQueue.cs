using System;
using System.Collections.Generic;

namespace KanblazCloudShell.VisualAlerts;

internal sealed class VisualScanQueue<T> where T : class
{
	private readonly List<T> clients = new List<T>();

	private int cursor;

	internal int Count => clients.Count;

	internal void Add(T client)
	{
		if (!clients.Contains(client))
		{
			clients.Add(client);
		}
	}

	internal void Remove(T client)
	{
		int num = clients.IndexOf(client);
		if (num >= 0)
		{
			clients.RemoveAt(num);
			if (num < cursor)
			{
				cursor--;
			}
			if (cursor >= clients.Count)
			{
				cursor = 0;
			}
		}
	}

	internal T Next(Func<T, bool> ready)
	{
		for (int i = 0; i < clients.Count; i++)
		{
			T val = clients[cursor];
			cursor = (cursor + 1) % clients.Count;
			if (ready(val))
			{
				return val;
			}
		}
		return null;
	}
}
