using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using KanblazCloudShell.SoundAlerts;
using Tesseract;

namespace KanblazCloudShell.VisualAlerts;

internal sealed class SpawnTextRecognizer : IDisposable
{
	private readonly TesseractEngine engine;

	private readonly BrainrotCatalog catalog;

	[ThreadStatic]
	internal static Action<string, string> Trace;

	private readonly Dictionary<SpawnNotice, Bitmap> templates = new Dictionary<SpawnNotice, Bitmap>();

	private Rectangle lastTextBounds;

	internal SpawnTextRecognizer(string dataDirectory)
	{
		string path = Path.Combine(dataDirectory, "..", "catalogs");
		string text = Path.Combine(path, "brainrots.txt");
		catalog = BrainrotCatalog.Load(File.Exists(text) ? text : Path.Combine(path, "brainrots.json"));
		engine = new TesseractEngine(dataDirectory, "eng", EngineMode.LstmOnly);
		engine.SetVariable("debug_file", "NUL");
		engine.SetVariable("tessedit_write_images", "0");
	}

	internal static Rectangle NoticeRegion(Size size)
	{
		if (size.Width < 100 || size.Height < 80)
		{
			return Rectangle.Empty;
		}
		if (size.Height < 220 && size.Width > size.Height * 2)
		{
			return new Rectangle(Point.Empty, size);
		}
		return new Rectangle((int)((double)size.Width * 0.2), (int)((double)size.Height * 0.62), (int)((double)size.Width * 0.6), (int)((double)size.Height * 0.18));
	}

	internal SpawnNotice Recognize(Bitmap image)
	{
		Rectangle region = NoticeRegion(image.Size);
		if (region.IsEmpty)
		{
			return SpawnNotice.None;
		}
		SpawnNotice spawnNotice = RecognizeRegion(image, region, 150, PageSegMode.SparseText);
		if (spawnNotice != SpawnNotice.None)
		{
			return spawnNotice;
		}
		region = new Rectangle((int)((double)image.Width * 0.27), (int)((double)image.Height * 0.68), (int)((double)image.Width * 0.46), (int)((double)image.Height * 0.07));
		spawnNotice = RecognizeRegion(image, region, 150, PageSegMode.SingleLine);
		if (spawnNotice != SpawnNotice.None)
		{
			return spawnNotice;
		}
		return RecognizeAdaptive(image);
	}

	private SpawnNotice RecognizeAdaptive(Bitmap image)
	{
		if (image.Width > 1000)
		{
			using (Bitmap bitmap = new Bitmap(800, Math.Max(1, image.Height * 800 / image.Width), PixelFormat.Format24bppRgb))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap))
				{
					graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
					graphics.DrawImage(image, new Rectangle(Point.Empty, bitmap.Size));
				}
				return RecognizeAdaptive(bitmap);
			}
		}
		foreach (Rectangle item in FindNoticeBands(image))
		{
			int num = Math.Max(2, item.Height / 4);
			int[] array = new int[2] { 145, 210 };
			foreach (int threshold in array)
			{
				int[] array2 = new int[3]
				{
					0,
					-num,
					num
				};
				foreach (int num2 in array2)
				{
					int[] array3 = new int[2]
					{
						num,
						num * 2
					};
					foreach (int num3 in array3)
					{
						Rectangle band = Rectangle.Intersect(new Rectangle(0, 0, image.Width, image.Height), new Rectangle(item.X, item.Y + num2 - num3, item.Width, item.Height + num3 * 2));
						SpawnNotice spawnNotice = RecognizeEnlargedLine(image, band, threshold);
						if (spawnNotice != SpawnNotice.None)
						{
							return spawnNotice;
						}
					}
				}
			}
		}
		return SpawnNotice.None;
	}

	internal static Rectangle AdaptiveNoticeRegion(Size size)
	{
		if (size.Width >= 100 && size.Height >= 20 && size.Height < 220 && size.Width > size.Height * 2)
		{
			return new Rectangle(Point.Empty, size);
		}
		if (size.Width < 100 || size.Height < 80)
		{
			return Rectangle.Empty;
		}
		if (size.Height < 220 && size.Width > size.Height * 2)
		{
			return new Rectangle(Point.Empty, size);
		}
		return new Rectangle((int)((double)size.Width * 0.29), (int)((double)size.Height * 0.62), (int)((double)size.Width * 0.42), (int)((double)size.Height * 0.28));
	}

	internal static List<Rectangle> FindNoticeBands(Bitmap image)
	{
		List<Rectangle> list = new List<Rectangle>();
		Rectangle srcRect = AdaptiveNoticeRegion(image.Size);
		if (srcRect.IsEmpty)
		{
			return list;
		}
		int[] array = new int[srcRect.Height];
		using (Bitmap bitmap = new Bitmap(srcRect.Width, srcRect.Height, PixelFormat.Format24bppRgb))
		{
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.DrawImage(image, new Rectangle(Point.Empty, bitmap.Size), srcRect, GraphicsUnit.Pixel);
			}
			BitmapData bitmapData = bitmap.LockBits(new Rectangle(Point.Empty, bitmap.Size), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
			try
			{
				int num = Math.Abs(bitmapData.Stride);
				byte[] array2 = new byte[num * bitmap.Height];
				for (int i = 0; i < bitmap.Height; i++)
				{
					Marshal.Copy(IntPtr.Add(bitmapData.Scan0, i * bitmapData.Stride), array2, i * num, num);
				}
				for (int j = 2; j < bitmap.Height - 2; j++)
				{
					for (int k = 2; k < bitmap.Width - 2; k++)
					{
						int num2 = j * num + k * 3;
						int num3 = Math.Min(array2[num2], Math.Min(array2[num2 + 1], array2[num2 + 2]));
						int num4 = Math.Max(array2[num2], Math.Max(array2[num2 + 1], array2[num2 + 2]));
						if (num3 < 170 || num4 - num3 > 80)
						{
							continue;
						}
						bool flag = false;
						for (int l = -2; l <= 2; l++)
						{
							if (flag)
							{
								break;
							}
							for (int m = -2; m <= 2; m++)
							{
								int num5 = (j + l) * num + (k + m) * 3;
								if ((array2[num5] + array2[num5 + 1] + array2[num5 + 2]) / 3 < 105)
								{
									flag = true;
									break;
								}
							}
						}
						if (flag)
						{
							array[j]++;
						}
					}
				}
			}
			finally
			{
				bitmap.UnlockBits(bitmapData);
			}
		}
		int num6 = Math.Max(9, (int)Math.Round((double)image.Height * ((image.Height < 220) ? 0.22 : 0.025)));
		for (int n = 0; n < 2; n++)
		{
			int num7 = 0;
			int num8 = 0;
			for (int num9 = 0; num9 < array.Length - num6; num9++)
			{
				bool flag2 = false;
				foreach (Rectangle item in list)
				{
					if ((double)Math.Abs(item.Y - srcRect.Y - num9) < (double)num6 * 1.5)
					{
						flag2 = true;
					}
				}
				if (!flag2)
				{
					int num10 = 0;
					for (int num11 = 0; num11 < num6; num11++)
					{
						num10 += array[num9 + num11];
					}
					if (num10 > num7)
					{
						num7 = num10;
						num8 = num9;
					}
				}
			}
			if ((double)num7 < (double)srcRect.Width * ((image.Height < 220) ? 0.3 : 0.45))
			{
				break;
			}
			list.Add(new Rectangle(srcRect.X, srcRect.Y + num8, srcRect.Width, num6));
		}
		return list;
	}

	private SpawnNotice RecognizeEnlargedLine(Bitmap image, Rectangle band, int threshold)
	{
		using Bitmap bitmap = new Bitmap(band.Width * 4 + 24, band.Height * 4 + 24, PixelFormat.Format24bppRgb);
		using MemoryStream memoryStream = new MemoryStream();
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.Clear(Color.White);
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.DrawImage(image, new Rectangle(12, 12, band.Width * 4, band.Height * 4), band, GraphicsUnit.Pixel);
		}
		BitmapData bitmapData = bitmap.LockBits(new Rectangle(Point.Empty, bitmap.Size), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
		try
		{
			byte[] array = new byte[Math.Abs(bitmapData.Stride)];
			for (int i = 12; i < bitmap.Height - 12; i++)
			{
				IntPtr intPtr = IntPtr.Add(bitmapData.Scan0, i * bitmapData.Stride);
				Marshal.Copy(intPtr, array, 0, array.Length);
				for (int j = 12; j < bitmap.Width - 12; j++)
				{
					int num = j * 3;
					int num2 = Math.Min(array[num], Math.Min(array[num + 1], array[num + 2]));
					int num3 = Math.Max(array[num], Math.Max(array[num + 1], array[num + 2]));
					byte b = (byte)((num2 < threshold || num3 - num2 >= 80) ? byte.MaxValue : 0);
					array[num] = (array[num + 1] = (array[num + 2] = b));
				}
				Marshal.Copy(array, 0, intPtr, array.Length);
			}
		}
		finally
		{
			bitmap.UnlockBits(bitmapData);
		}
		bitmap.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
		using Pix image2 = Pix.LoadFromMemory(memoryStream.ToArray());
		using Page page = engine.Process(image2, PageSegMode.SingleLine);
		return SpawnNotices.Match(page.GetText(), page.GetMeanConfidence());
	}

	private SpawnNotice RecognizeRegion(Bitmap image, Rectangle region, int threshold, PageSegMode mode)
	{
		using Bitmap bitmap = new Bitmap(region.Width, region.Height, PixelFormat.Format24bppRgb);
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.DrawImage(image, new Rectangle(Point.Empty, bitmap.Size), region, GraphicsUnit.Pixel);
		}
		BitmapData bitmapData = bitmap.LockBits(new Rectangle(Point.Empty, bitmap.Size), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
		try
		{
			byte[] array = new byte[Math.Abs(bitmapData.Stride)];
			for (int i = 0; i < bitmap.Height; i++)
			{
				IntPtr intPtr = IntPtr.Add(bitmapData.Scan0, i * bitmapData.Stride);
				Marshal.Copy(intPtr, array, 0, array.Length);
				for (int j = 0; j < bitmap.Width; j++)
				{
					int num = j * 3;
					int num2 = Math.Min(array[num], Math.Min(array[num + 1], array[num + 2]));
					int num3 = Math.Max(array[num], Math.Max(array[num + 1], array[num + 2]));
					byte b = (byte)((num2 < threshold || num3 - num2 >= ((mode == PageSegMode.SingleLine) ? 80 : 65)) ? byte.MaxValue : 0);
					array[num] = (array[num + 1] = (array[num + 2] = b));
				}
				Marshal.Copy(array, 0, intPtr, array.Length);
			}
		}
		finally
		{
			bitmap.UnlockBits(bitmapData);
		}
		int num4 = ((mode == PageSegMode.SingleLine) ? Math.Min(1500, Math.Max(600, bitmap.Width * 3)) : 1080);
		int height = Math.Max(1, (int)Math.Round((double)(bitmap.Height * num4) / (double)bitmap.Width));
		using Bitmap bitmap2 = new Bitmap(num4, height, PixelFormat.Format24bppRgb);
		using MemoryStream memoryStream = new MemoryStream();
		using (Graphics graphics2 = Graphics.FromImage(bitmap2))
		{
			graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics2.DrawImage(bitmap, new Rectangle(Point.Empty, bitmap2.Size));
		}
		bitmap2.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
		using Pix image2 = Pix.LoadFromMemory(memoryStream.ToArray());
		using Page page = engine.Process(image2, mode);
		return SpawnNotices.Match(page.GetText(), page.GetMeanConfidence());
	}

	public void Dispose()
	{
		foreach (Bitmap value in templates.Values)
		{
			value.Dispose();
		}
		templates.Clear();
		engine.Dispose();
	}

	private BrainrotDetection FindBox(Bitmap image)
	{
		bool flag = image.Width > image.Height * 3;
		string[] array;
		if (flag)
		{
			array = new string[2] { "original", "white" };
			foreach (string mask in array)
			{
				string text = BoxSpawnText.Extract(ReadBand(image, new Rectangle(Point.Empty, image.Size), mask, out var confidence), confidence);
				if (text != null && confidence >= 0.75f)
				{
					return new BrainrotDetection
					{
						Notice = SpawnNotice.Box,
						Name = text,
						Method = "box-strip-ocr",
						TriggerConfidence = confidence,
						NameConfidence = confidence,
						TriggerRegion = new Rectangle(Point.Empty, image.Size),
						NameColor = "white"
					};
				}
			}
		}
		if (!flag)
		{
			foreach (Rectangle item in FindNoticeBands(image))
			{
				Rectangle rectangle = Rectangle.Intersect(new Rectangle(Point.Empty, image.Size), new Rectangle(item.X, item.Y - 8, item.Width, item.Height + 16));
				array = new string[2] { "white", "original" };
				foreach (string mask2 in array)
				{
					string text2 = BoxSpawnText.Extract(ReadBand(image, rectangle, mask2, out var confidence2), confidence2);
					if (text2 != null && confidence2 >= 0.75f)
					{
						return new BrainrotDetection
						{
							Notice = SpawnNotice.Box,
							Name = text2,
							Method = "box-band-ocr",
							TriggerConfidence = confidence2,
							NameConfidence = confidence2,
							TriggerRegion = rectangle,
							NameColor = "white"
						};
					}
				}
				Rectangle rectangle2 = Rectangle.Intersect(new Rectangle(Point.Empty, image.Size), new Rectangle(item.X, item.Y - 4, item.Width, item.Height + 8));
				if (rectangle2.Width <= rectangle2.Height * 3)
				{
					continue;
				}
				using Bitmap image2 = image.Clone(rectangle2, PixelFormat.Format24bppRgb);
				BrainrotDetection brainrotDetection = FindBox(image2);
				if (brainrotDetection != null && brainrotDetection.TriggerConfidence >= 0.9f)
				{
					brainrotDetection.TriggerRegion = rectangle2;
					return brainrotDetection;
				}
			}
		}
		if (flag && image.Width > 800)
		{
			using (Bitmap bitmap = new Bitmap(800, Math.Max(1, image.Height * 800 / image.Width)))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap))
				{
					graphics.DrawImage(image, 0, 0, bitmap.Width, bitmap.Height);
				}
				return FindBox(bitmap);
			}
		}
		Rectangle rectangle3 = (flag ? new Rectangle(Point.Empty, image.Size) : AdaptiveNoticeRegion(image.Size));
		if (flag)
		{
			int[] array2 = new int[image.Height];
			int num = 0;
			for (int j = 0; j < image.Height; j++)
			{
				for (int k = 0; k < image.Width; k++)
				{
					Color pixel = image.GetPixel(k, j);
					if (Math.Min(pixel.R, Math.Min(pixel.G, pixel.B)) > 190 && Math.Max(pixel.R, Math.Max(pixel.G, pixel.B)) - Math.Min(pixel.R, Math.Min(pixel.G, pixel.B)) < 45)
					{
						array2[j]++;
					}
				}
			}
			for (int l = 1; l < array2.Length; l++)
			{
				if (array2[l] > array2[num])
				{
					num = l;
				}
			}
			int num2 = num;
			int m = num;
			while (num2 > 0 && (double)array2[num2 - 1] > (double)array2[num] * 0.18)
			{
				num2--;
			}
			for (; m + 1 < array2.Length && (double)array2[m + 1] > (double)array2[num] * 0.18; m++)
			{
			}
			num2 = Math.Max(0, num2 - 4);
			m = Math.Min(image.Height - 1, m + 4);
			rectangle3 = new Rectangle(0, num2, image.Width, m - num2 + 1);
			int num3 = -1;
			int num4 = -1;
			int num5 = 0;
			int num6 = image.Width - 1;
			int num7 = 0;
			for (int n = 0; n <= image.Width; n++)
			{
				int num8 = 0;
				if (n < image.Width)
				{
					for (int num9 = num2; num9 <= m; num9++)
					{
						Color pixel2 = image.GetPixel(n, num9);
						if (Math.Min(pixel2.R, Math.Min(pixel2.G, pixel2.B)) > 190 && Math.Max(pixel2.R, Math.Max(pixel2.G, pixel2.B)) - Math.Min(pixel2.R, Math.Min(pixel2.G, pixel2.B)) < 45)
						{
							num8++;
						}
					}
				}
				if ((double)num8 > (double)rectangle3.Height * 0.18)
				{
					if (num3 < 0)
					{
						num3 = n;
					}
					num4 = n;
				}
				if (num3 >= 0 && (n == image.Width || (double)(n - num4) > (double)rectangle3.Height * 0.9))
				{
					if (num4 - num3 > num7)
					{
						num7 = num4 - num3;
						num5 = num3;
						num6 = num4;
					}
					num3 = -1;
				}
			}
			if ((double)num7 > (double)image.Width * 0.4)
			{
				int num10 = Math.Max(0, num5 - 3);
				rectangle3 = new Rectangle(num10, num2, Math.Min(image.Width, num6 + 4) - num10, m - num2 + 1);
			}
		}
		if (rectangle3.Width < 10 || rectangle3.Height < 5)
		{
			return null;
		}
		array = new string[2] { "white", "original" };
		foreach (string mask3 in array)
		{
			using Bitmap bitmap2 = MaskBand(image, rectangle3, mask3);
			using Bitmap bitmap3 = new Bitmap(bitmap2.Width * 3 + 24, bitmap2.Height * 3 + 24);
			using MemoryStream memoryStream = new MemoryStream();
			using (Graphics graphics2 = Graphics.FromImage(bitmap3))
			{
				graphics2.Clear(Color.White);
				graphics2.InterpolationMode = InterpolationMode.HighQualityBicubic;
				graphics2.DrawImage(bitmap2, 12, 12, bitmap3.Width - 24, bitmap3.Height - 24);
			}
			bitmap3.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
			using Pix image3 = Pix.LoadFromMemory(memoryStream.ToArray());
			using Page page = engine.Process(image3, flag ? PageSegMode.SingleLine : PageSegMode.SparseText);
			using ResultIterator resultIterator = page.GetIterator();
			resultIterator.Begin();
			do
			{
				float num11 = resultIterator.GetConfidence(PageIteratorLevel.TextLine) / 100f;
				string text3 = BoxSpawnText.Extract(resultIterator.GetText(PageIteratorLevel.TextLine), num11);
				if (num11 >= 0.8f && Regex.IsMatch(resultIterator.GetText(PageIteratorLevel.TextLine) ?? "", "^\\s*Grande\\s+Lucky\\s+Rot[!.]?\\s*$", RegexOptions.IgnoreCase))
				{
					return new BrainrotDetection
					{
						Notice = SpawnNotice.LuckyRot,
						Name = "Grande Lucky Rot",
						Method = "lucky-rot-ocr",
						TriggerConfidence = num11,
						NameConfidence = num11,
						TriggerRegion = rectangle3
					};
				}
				if (text3 != null && (flag || num11 >= 0.9f))
				{
					return new BrainrotDetection
					{
						Notice = SpawnNotice.Box,
						Name = text3,
						Method = "box-line-ocr",
						TriggerConfidence = num11,
						NameConfidence = num11,
						TriggerRegion = rectangle3,
						NameColor = "white"
					};
				}
			}
			while (resultIterator.Next(PageIteratorLevel.TextLine));
		}
		return null;
	}

	private BrainrotDetection FindTrigger(Bitmap image)
	{
		Rectangle region = AdaptiveNoticeRegion(image.Size);
		if (region.IsEmpty)
		{
			return null;
		}
		BrainrotDetection brainrotDetection = null;
		string[] array = new string[2] { "white", "original" };
		foreach (string text in array)
		{
			using Bitmap bitmap = MaskBand(image, region, text);
			using Bitmap bitmap2 = new Bitmap(bitmap.Width * 3, bitmap.Height * 3);
			using MemoryStream memoryStream = new MemoryStream();
			using (Graphics graphics = Graphics.FromImage(bitmap2))
			{
				graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
				graphics.DrawImage(bitmap, 0, 0, bitmap2.Width, bitmap2.Height);
			}
			bitmap2.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
			using (Pix image2 = Pix.LoadFromMemory(memoryStream.ToArray()))
			{
				using Page page = engine.Process(image2, PageSegMode.SparseText);
				using ResultIterator resultIterator = page.GetIterator();
				resultIterator.Begin();
				do
				{
					float num = resultIterator.GetConfidence(PageIteratorLevel.TextLine) / 100f;
					Match match = MatchSprite(resultIterator.GetText(PageIteratorLevel.TextLine));
					if (Trace != null)
					{
						Trace("ocr-line", text + "; confidence=" + num.ToString("F4", CultureInfo.InvariantCulture) + "; spriteMatch=" + match.Success + "; text=" + resultIterator.GetText(PageIteratorLevel.TextLine));
					}
					if (match.Success && num >= 0.6f && resultIterator.TryGetBoundingBox(PageIteratorLevel.TextLine, out var bounds))
					{
						return new BrainrotDetection
						{
							Notice = SpawnNotice.Sprite,
							SpriteCategory = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(match.Groups["category"].Value.ToLowerInvariant()),
							Method = "sprite-ocr",
							TriggerConfidence = num,
							TriggerRegion = new Rectangle(region.X + bounds.X1 / 3, region.Y + bounds.Y1 / 3, (bounds.Width + 2) / 3, (bounds.Height + 2) / 3)
						};
					}
					SpawnNotice spawnNotice = SpawnNotices.Match(resultIterator.GetText(PageIteratorLevel.TextLine), num);
					if (brainrotDetection == null && spawnNotice != SpawnNotice.None && resultIterator.TryGetBoundingBox(PageIteratorLevel.TextLine, out var bounds2))
					{
						brainrotDetection = new BrainrotDetection
						{
							Notice = spawnNotice,
							Method = "trigger-ocr",
							TriggerConfidence = num,
							TriggerRegion = new Rectangle(region.X + bounds2.X1 / 3, region.Y + bounds2.Y1 / 3, (bounds2.Width + 2) / 3, (bounds2.Height + 2) / 3)
						};
					}
				}
				while (resultIterator.Next(PageIteratorLevel.TextLine));
			}
			if (brainrotDetection != null && brainrotDetection.TriggerConfidence >= 0.75f)
			{
				return brainrotDetection;
			}
		}
		return brainrotDetection;
	}

	internal static Match MatchSprite(string text)
	{
		return Regex.Match((text ?? "").Trim(), "^(?:(?<category>Uncollected|Epic|Rare|Common|Legendary|Mythic)\\s+)?Sprite\\s+Spawned[!.]?\\s*$", RegexOptions.IgnoreCase);
	}

	internal void LoadTemplates(string folder)
	{
		if (!Directory.Exists(folder))
		{
			return;
		}
		string text = Path.Combine(folder, "GrandeLuckyRot-reference.jpg");
		if (File.Exists(text))
		{
			using Bitmap bitmap = new Bitmap(text);
			using Bitmap mask = OutlineMask(bitmap, new Rectangle(Point.Empty, bitmap.Size));
			templates[SpawnNotice.LuckyRot] = NormalizeOutline(mask);
		}
		foreach (SpawnNotice value in Enum.GetValues(typeof(SpawnNotice)))
		{
			string text2 = Path.Combine(folder, value.ToString() + ".png");
			if (value != SpawnNotice.None && File.Exists(text2))
			{
				templates[value] = new Bitmap(text2);
			}
		}
	}

	private string ReadBand(Bitmap image, Rectangle region, string mask, out float confidence)
	{
		using Bitmap bitmap = MaskBand(image, region, mask);
		using Bitmap bitmap2 = new Bitmap(bitmap.Width * 3 + 24, bitmap.Height * 3 + 24);
		using MemoryStream memoryStream = new MemoryStream();
		using (Graphics graphics = Graphics.FromImage(bitmap2))
		{
			graphics.Clear(Color.White);
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.DrawImage(bitmap, 12, 12, bitmap.Width * 3, bitmap.Height * 3);
		}
		bitmap2.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
		using Pix image2 = Pix.LoadFromMemory(memoryStream.ToArray());
		using Page page = engine.Process(image2, PageSegMode.SingleLine);
		confidence = page.GetMeanConfidence();
		lastTextBounds = region;
		using (ResultIterator resultIterator = page.GetIterator())
		{
			resultIterator.Begin();
			if (resultIterator.TryGetBoundingBox(PageIteratorLevel.TextLine, out var bounds))
			{
				lastTextBounds = Rectangle.Intersect(region, new Rectangle(region.X + (bounds.X1 - 12) / 3, region.Y + (bounds.Y1 - 12) / 3, Math.Max(1, (bounds.Width + 2) / 3), Math.Max(1, (bounds.Height + 2) / 3)));
			}
		}
		using (ResultIterator resultIterator2 = page.GetIterator())
		{
			resultIterator2.Begin();
			List<string> list = new List<string>();
			List<Rect> list2 = new List<Rect>();
			do
			{
				if (resultIterator2.TryGetBoundingBox(PageIteratorLevel.Word, out var bounds2))
				{
					list.Add(resultIterator2.GetText(PageIteratorLevel.Word) ?? "");
					list2.Add(bounds2);
				}
			}
			while (resultIterator2.Next(PageIteratorLevel.Word));
			for (int i = 0; i + 2 < list.Count; i++)
			{
				if (SpawnNotices.Match(string.Join(" ", list.Skip(i).Take(3)), 1f) != SpawnNotice.None)
				{
					int x = list2[i].X1;
					int num = list2.Skip(i).Take(3).Min((Rect b) => b.Y1);
					int x2 = list2[i + 2].X2;
					int num2 = list2.Skip(i).Take(3).Max((Rect b) => b.Y2);
					lastTextBounds = new Rectangle(region.X + (x - 12) / 3, region.Y + (num - 12) / 3, (x2 - x + 2) / 3, (num2 - num + 2) / 3);
					break;
				}
			}
		}
		string text = page.GetText().Trim();
		if (Trace != null)
		{
			Action<string, string> trace = Trace;
			string[] array = new string[7]
			{
				mask,
				"; confidence=",
				confidence.ToString("F4", CultureInfo.InvariantCulture),
				"; region=",
				null,
				null,
				null
			};
			Rectangle rectangle = region;
			array[4] = rectangle.ToString();
			array[5] = "; text=";
			array[6] = text;
			trace("ocr-band", string.Concat(array));
		}
		return text;
	}

	internal static Bitmap MaskBand(Bitmap image, Rectangle region, string mask)
	{
		bool flag = mask.EndsWith("-clean", StringComparison.Ordinal);
		mask = mask.Replace("-clean", "");
		Bitmap bitmap = new Bitmap(region.Width, region.Height, PixelFormat.Format24bppRgb);
		for (int i = 0; i < region.Height; i++)
		{
			for (int j = 0; j < region.Width; j++)
			{
				Color pixel = image.GetPixel(region.X + j, region.Y + i);
				int num = Math.Min(pixel.R, Math.Min(pixel.G, pixel.B));
				int num2 = Math.Max(pixel.R, Math.Max(pixel.G, pixel.B));
				bool flag2 = mask switch
				{
					"cyan" => pixel.G > 100 && pixel.B > 100 && (double)(int)pixel.R < (double)(int)Math.Min(pixel.G, pixel.B) * 0.7, 
					"blue" => pixel.B > 100 && (double)(int)pixel.B > (double)(int)pixel.R * 1.4, 
					"purple" => pixel.R > 55 && pixel.B > 65 && (double)(int)pixel.R > (double)(int)pixel.G * 1.3 && (double)(int)pixel.B > (double)(int)pixel.G * 1.3, 
					"green" => pixel.G > 75 && (double)(int)pixel.G > (double)(int)pixel.R * 1.3 && (double)(int)pixel.G > (double)(int)pixel.B * 1.15, 
					"red" => pixel.R > 100 && (double)(int)pixel.R > (double)(int)pixel.G * 1.5 && (double)(int)pixel.R > (double)(int)pixel.B * 1.4, 
					"black" => num2 < 90, 
					"white" => num >= 170 && num2 - num < 75, 
					_ => false, 
				};
				if (mask == "original")
				{
					bitmap.SetPixel(j, i, pixel);
				}
				else
				{
					bitmap.SetPixel(j, i, flag2 ? Color.Black : Color.White);
				}
			}
		}
		if (mask != "white" && mask != "original")
		{
			Queue<Point> queue = new Queue<Point>();
			for (int k = 0; k < bitmap.Width; k++)
			{
				queue.Enqueue(new Point(k, 0));
				queue.Enqueue(new Point(k, bitmap.Height - 1));
			}
			for (int l = 0; l < bitmap.Height; l++)
			{
				queue.Enqueue(new Point(0, l));
				queue.Enqueue(new Point(bitmap.Width - 1, l));
			}
			while (queue.Count > 0)
			{
				Point point = queue.Dequeue();
				if (point.X >= 0 && point.Y >= 0 && point.X < bitmap.Width && point.Y < bitmap.Height && bitmap.GetPixel(point.X, point.Y).R <= 128)
				{
					bitmap.SetPixel(point.X, point.Y, Color.White);
					queue.Enqueue(new Point(point.X - 1, point.Y));
					queue.Enqueue(new Point(point.X + 1, point.Y));
					queue.Enqueue(new Point(point.X, point.Y - 1));
					queue.Enqueue(new Point(point.X, point.Y + 1));
				}
			}
			if (flag)
			{
				bool[,] array = new bool[bitmap.Width, bitmap.Height];
				for (int m = 0; m < bitmap.Height; m++)
				{
					for (int n = 0; n < bitmap.Width; n++)
					{
						if (array[n, m] || bitmap.GetPixel(n, m).R > 128)
						{
							continue;
						}
						List<Point> list = new List<Point>();
						queue.Enqueue(new Point(n, m));
						int num3 = m;
						int num4 = m;
						while (queue.Count > 0)
						{
							Point item = queue.Dequeue();
							if (item.X >= 0 && item.Y >= 0 && item.X < bitmap.Width && item.Y < bitmap.Height && !array[item.X, item.Y] && bitmap.GetPixel(item.X, item.Y).R <= 128)
							{
								array[item.X, item.Y] = true;
								list.Add(item);
								num3 = Math.Min(num3, item.Y);
								num4 = Math.Max(num4, item.Y);
								queue.Enqueue(new Point(item.X - 1, item.Y));
								queue.Enqueue(new Point(item.X + 1, item.Y));
								queue.Enqueue(new Point(item.X, item.Y - 1));
								queue.Enqueue(new Point(item.X, item.Y + 1));
							}
						}
						if (list.Count >= 5 && !((double)(num4 - num3) < (double)region.Height * 0.3))
						{
							continue;
						}
						foreach (Point item2 in list)
						{
							bitmap.SetPixel(item2.X, item2.Y, Color.White);
						}
					}
				}
			}
		}
		return bitmap;
	}

	internal static Rectangle InkBounds(Bitmap mask)
	{
		int num = mask.Width;
		int num2 = mask.Height;
		int num3 = -1;
		int num4 = -1;
		for (int i = 0; i < mask.Height; i++)
		{
			for (int j = 0; j < mask.Width; j++)
			{
				if (mask.GetPixel(j, i).R < 128)
				{
					num = Math.Min(num, j);
					num3 = Math.Max(num3, j);
					num2 = Math.Min(num2, i);
					num4 = Math.Max(num4, i);
				}
			}
		}
		if (num3 >= num)
		{
			return Rectangle.FromLTRB(num, num2, num3 + 1, num4 + 1);
		}
		return Rectangle.Empty;
	}

	internal static Bitmap Template(Bitmap image, Rectangle band)
	{
		using Bitmap bitmap = MaskBand(image, band, "white");
		Rectangle srcRect = InkBounds(bitmap);
		if (srcRect.IsEmpty)
		{
			return null;
		}
		Bitmap bitmap2 = new Bitmap(512, 40);
		using (Graphics graphics = Graphics.FromImage(bitmap2))
		{
			graphics.Clear(Color.White);
			graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
			graphics.DrawImage(bitmap, new Rectangle(0, 0, 512, 40), srcRect, GraphicsUnit.Pixel);
		}
		return bitmap2;
	}

	private SpawnNotice MatchTemplate(Bitmap image, Rectangle band, out double best)
	{
		best = 0.0;
		SpawnNotice result = SpawnNotice.None;
		using (Bitmap bitmap = Template(image, band))
		{
			if (bitmap == null)
			{
				return result;
			}
			foreach (KeyValuePair<SpawnNotice, Bitmap> template in templates)
			{
				if (template.Value.Size != bitmap.Size)
				{
					continue;
				}
				int num = 0;
				int num2 = 0;
				for (int i = 0; i < 40; i++)
				{
					for (int j = 0; j < 512; j++)
					{
						bool flag = bitmap.GetPixel(j, i).R < 128;
						bool flag2 = template.Value.GetPixel(j, i).R < 128;
						if (flag)
						{
							num2++;
						}
						if (flag2)
						{
							num2++;
						}
						if (flag & flag2)
						{
							num++;
						}
					}
				}
				double num3 = ((num2 == 0) ? 0.0 : (2.0 * (double)num / (double)num2));
				if (num3 > best)
				{
					best = num3;
					result = template.Key;
				}
			}
		}
		if (!(best >= 0.88))
		{
			return SpawnNotice.None;
		}
		return result;
	}

	internal BrainrotDetection RecognizeDetailed(Bitmap image)
	{
		BrainrotDetection direct = FindTrigger(image) ?? FindWhiteAnnouncement(image);
		if (direct != null)
		{
			EnrichWithoutLosingSpawn(direct, () =>
			{
				ReadSpawnColor(image, direct);
			});
			return direct;
		}
		BrainrotDetection brainrotDetection = FindLuckyRot(image);
		if (brainrotDetection != null)
		{
			return brainrotDetection;
		}
		BrainrotDetection brainrotDetection2 = FindBox(image);
		if (brainrotDetection2 != null)
		{
			return brainrotDetection2;
		}
		BrainrotDetection result = new BrainrotDetection();
		foreach (Rectangle item in FindNoticeBands(image))
		{
			int num = 1;
			Rectangle region = Rectangle.Intersect(new Rectangle(Point.Empty, image.Size), new Rectangle(item.X, item.Y - num, item.Width, item.Height + num * 2));
			SpawnNotice spawnNotice = SpawnNotices.Match(ReadBand(image, region, "white", out var confidence), confidence);
			int num2 = Math.Min(image.Width, item.Height * 16 + 2);
			Rectangle band = Rectangle.Intersect(new Rectangle(Point.Empty, image.Size), new Rectangle(image.Width / 2 - num2 / 2, region.Y, num2, region.Height));
			SpawnNotice spawnNotice2 = MatchTemplate(image, band, out var best);
			result.TemplateScore = Math.Max(result.TemplateScore, best);
			if (spawnNotice != SpawnNotice.None || spawnNotice2 != SpawnNotice.None)
			{
				result.Notice = ((spawnNotice != SpawnNotice.None) ? spawnNotice : spawnNotice2);
				result.Method = ((spawnNotice != SpawnNotice.None) ? "trigger-ocr" : "trigger-template");
				result.TriggerConfidence = confidence;
				result.TriggerRegion = new Rectangle((spawnNotice == SpawnNotice.None) ? band.X : lastTextBounds.X, item.Y, (spawnNotice == SpawnNotice.None) ? band.Width : lastTextBounds.Width, item.Height);
				EnrichWithoutLosingSpawn(result, () =>
				{
					ReadSpawnColor(image, result);
				});
				return result;
			}
		}
		return result;
	}

	private BrainrotDetection FindWhiteAnnouncement(Bitmap image)
	{
		foreach (Rectangle item in FindNoticeBands(image))
		{
			int num = Math.Max(2, item.Height / 3);
			Rectangle region = Rectangle.Intersect(new Rectangle(Point.Empty, image.Size), new Rectangle(item.X, item.Y - num, item.Width, item.Height + 2 * num));
			string text = ReadBand(image, region, "white", out var confidence);
			Match match = MatchSprite(text);
			SpawnNotice spawnNotice = ((match.Success && confidence >= 0.6f) ? SpawnNotice.Sprite : SpawnNotices.Match(text, confidence));
			if (spawnNotice != SpawnNotice.None)
			{
				return new BrainrotDetection
				{
					Notice = spawnNotice,
					TriggerConfidence = confidence,
					TriggerRegion = lastTextBounds,
					Method = "white-row-ocr",
					SpriteCategory = (match.Success ? match.Groups["category"].Value : "")
				};
			}
		}
		return null;
	}

	private BrainrotDetection FindLuckyRot(Bitmap image)
	{
		foreach (Rectangle item in (image.Width > image.Height * 3) ? new List<Rectangle>
		{
			new Rectangle(Point.Empty, image.Size)
		} : FindNoticeBands(image))
		{
			using Bitmap bitmap = new Bitmap(item.Width, item.Height);
			for (int i = 0; i < bitmap.Height; i++)
			{
				for (int j = 0; j < bitmap.Width; j++)
				{
					Color pixel = image.GetPixel(item.X + j, item.Y + i);
					bitmap.SetPixel(j, i, (Math.Max(pixel.R, Math.Max(pixel.G, pixel.B)) < 130) ? Color.Black : Color.White);
				}
			}
			if (templates.TryGetValue(SpawnNotice.LuckyRot, out var value))
			{
				using Bitmap bitmap2 = NormalizeOutline(bitmap);
				if (bitmap2 != null)
				{
					int num = 0;
					int num2 = 0;
					for (int k = 0; k < 64; k++)
					{
						for (int l = 0; l < 512; l++)
						{
							bool flag = bitmap2.GetPixel(l, k).R < 128;
							bool flag2 = value.GetPixel(l, k).R < 128;
							if (flag)
							{
								num2++;
							}
							if (flag2)
							{
								num2++;
							}
							if (flag & flag2)
							{
								num++;
							}
						}
					}
					double num3 = ((num2 == 0) ? 0.0 : (2.0 * (double)num / (double)num2));
					if (num3 >= 0.92)
					{
						return new BrainrotDetection
						{
							Notice = SpawnNotice.LuckyRot,
							Name = "Grande Lucky Rot",
							Method = "lucky-outline-template",
							TemplateScore = num3,
							TriggerRegion = item
						};
					}
				}
			}
			bool[,] array = new bool[bitmap.Width, bitmap.Height];
			Queue<Point> queue = new Queue<Point>();
			for (int m = 0; m < bitmap.Width; m++)
			{
				queue.Enqueue(new Point(m, 0));
				queue.Enqueue(new Point(m, bitmap.Height - 1));
			}
			for (int n = 0; n < bitmap.Height; n++)
			{
				queue.Enqueue(new Point(0, n));
				queue.Enqueue(new Point(bitmap.Width - 1, n));
			}
			while (queue.Count > 0)
			{
				Point point = queue.Dequeue();
				if (point.X >= 0 && point.Y >= 0 && point.X < bitmap.Width && point.Y < bitmap.Height && !array[point.X, point.Y] && bitmap.GetPixel(point.X, point.Y).R != 0)
				{
					array[point.X, point.Y] = true;
					queue.Enqueue(new Point(point.X - 1, point.Y));
					queue.Enqueue(new Point(point.X + 1, point.Y));
					queue.Enqueue(new Point(point.X, point.Y - 1));
					queue.Enqueue(new Point(point.X, point.Y + 1));
				}
			}
			for (int num4 = 0; num4 < bitmap.Height; num4++)
			{
				for (int num5 = 0; num5 < bitmap.Width; num5++)
				{
					if (!array[num5, num4])
					{
						bitmap.SetPixel(num5, num4, Color.Black);
					}
				}
			}
			using MemoryStream memoryStream = new MemoryStream();
			Rectangle srcRect = InkBounds(bitmap);
			if (srcRect.IsEmpty)
			{
				continue;
			}
			using (Bitmap bitmap3 = new Bitmap(Math.Max(1, srcRect.Width * 36 / srcRect.Height) + 20, 56))
			{
				using (Graphics graphics = Graphics.FromImage(bitmap3))
				{
					graphics.Clear(Color.White);
					graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
					graphics.DrawImage(bitmap, new Rectangle(10, 10, bitmap3.Width - 20, 36), srcRect, GraphicsUnit.Pixel);
				}
				bitmap3.Save(memoryStream, System.Drawing.Imaging.ImageFormat.Png);
			}
			using Pix image2 = Pix.LoadFromMemory(memoryStream.ToArray());
			using Page page = engine.Process(image2, PageSegMode.SingleLine);
			if (page.GetMeanConfidence() >= 0.75f && Regex.IsMatch(page.GetText(), "^\\s*Grande\\s+Lucky\\s+Rot[!.]?\\s*$", RegexOptions.IgnoreCase))
			{
				return new BrainrotDetection
				{
					Notice = SpawnNotice.LuckyRot,
					Name = "Grande Lucky Rot",
					Method = "outline-ocr",
					TriggerConfidence = page.GetMeanConfidence(),
					NameConfidence = page.GetMeanConfidence(),
					TriggerRegion = item
				};
			}
		}
		return null;
	}

	private static Bitmap OutlineMask(Bitmap image, Rectangle region)
	{
		Bitmap bitmap = new Bitmap(region.Width, region.Height);
		for (int i = 0; i < bitmap.Height; i++)
		{
			for (int j = 0; j < bitmap.Width; j++)
			{
				Color pixel = image.GetPixel(region.X + j, region.Y + i);
				bitmap.SetPixel(j, i, (Math.Max(pixel.R, Math.Max(pixel.G, pixel.B)) < 130) ? Color.Black : Color.White);
			}
		}
		return bitmap;
	}

	private static Bitmap NormalizeOutline(Bitmap mask)
	{
		Rectangle srcRect = InkBounds(mask);
		if (srcRect.IsEmpty)
		{
			return null;
		}
		Bitmap bitmap = new Bitmap(512, 64);
		using Graphics graphics = Graphics.FromImage(bitmap);
		graphics.Clear(Color.White);
		graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
		graphics.DrawImage(mask, new Rectangle(0, 0, 512, 64), srcRect, GraphicsUnit.Pixel);
		return bitmap;
	}

	internal static void EnrichWithoutLosingSpawn(BrainrotDetection result, Action enrich)
	{
		try
		{
			enrich();
		}
		catch (TesseractException)
		{
			result.Name = "Unknown";
			result.NameConfidence = 0f;
			result.NameFromCatalog = false;
		}
		catch (ArgumentException)
		{
			result.Name = "Unknown";
			result.NameConfidence = 0f;
			result.NameFromCatalog = false;
		}
		catch (InvalidOperationException)
		{
			result.Name = "Unknown";
			result.NameConfidence = 0f;
			result.NameFromCatalog = false;
		}
	}

	private void ReadSpawnColor(Bitmap image, BrainrotDetection result)
	{
		if (result.Notice == SpawnNotice.Sprite)
		{
			return;
		}
		Rectangle triggerRegion = result.TriggerRegion;
		int num = Math.Max(12, triggerRegion.Height);
		int num2 = Math.Min(triggerRegion.Width, (int)((double)image.Width * 0.5));
		result.NameRegion = Rectangle.Intersect(new Rectangle(Point.Empty, image.Size), new Rectangle(Math.Max(0, triggerRegion.X + triggerRegion.Width / 2 - num2 / 2), triggerRegion.Bottom + Math.Max(2, (int)((double)num * 0.15)), num2, (int)((double)num * 1.6)));
		if (result.NameRegion.Width < 3 || result.NameRegion.Height < 3)
		{
			return;
		}
		string text = SpawnNameColor.Detect(image, result.NameRegion);
		ApplyIdentity(result, text, null);
		if (result.Notice == SpawnNotice.Eternal || result.Rarity == SpawnNotice.Eternal)
		{
			string text2 = ReadBand(image, result.NameRegion, (text == "unknown") ? "original" : text, out var confidence);
			result.NameAttemptConfidence = confidence;
			string text3 = ((confidence >= 0.82f) ? SoundReferences.MatchEternalName(text2) : null);
			if (text3 != null)
			{
				result.Name = text3;
				result.NameConfidence = confidence;
				result.NameFromCatalog = true;
			}
		}
	}

	internal static void ApplyIdentity(BrainrotDetection result, string measured, CatalogEntry match)
	{
		if (result.Notice != SpawnNotice.None && result.Notice != SpawnNotice.Sprite && result.Notice != SpawnNotice.Box && result.Notice != SpawnNotice.LuckyRot)
		{
			result.NameColor = measured;
			result.Rarity = BrainrotDetection.RarityForColor(measured);
			result.RaritySource = ((result.Rarity != SpawnNotice.None) ? "color" : "none");
			if (result.Rarity == SpawnNotice.None && match != null)
			{
				result.Rarity = match.Notice;
				result.RaritySource = "catalog";
			}
		}
	}

	internal static bool AcceptName(string name, CatalogEntry match)
	{
		if (!string.IsNullOrWhiteSpace(name) && name.Length <= 64 && name.Split(' ').Length <= 7 && !Regex.IsMatch(name, "spawn|brainrot|stealing|profile|event", RegexOptions.IgnoreCase))
		{
			if (match == null)
			{
				if (name.Length >= 3)
				{
					return name.Count(char.IsLetter) >= 3;
				}
				return false;
			}
			return true;
		}
		return false;
	}
}
