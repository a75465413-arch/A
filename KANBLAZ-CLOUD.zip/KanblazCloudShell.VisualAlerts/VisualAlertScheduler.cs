using System;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KanblazCloudShell.VisualAlerts;

internal static class VisualAlertScheduler
{
	private static readonly Stopwatch Clock;

	private static readonly Timer Timer;

	private static readonly VisualScanQueue<SessionVisualAlerts> Clients;

	private static readonly object OcrLock;

	private static SpawnTextRecognizer recognizer;

	private static bool busy;

	private static bool shuttingDown;

	private static int inFlight;

	internal static double Now => Clock.Elapsed.TotalSeconds;

	static VisualAlertScheduler()
	{
		Clock = Stopwatch.StartNew();
		Timer = new Timer
		{
			Interval = 100
		};
		Clients = new VisualScanQueue<SessionVisualAlerts>();
		OcrLock = new object();
		Timer.Tick += async delegate
		{
			if (!busy && inFlight < 2)
			{
				SessionVisualAlerts sessionVisualAlerts = Clients.Next((SessionVisualAlerts value) => value.Ready(Now));
				if (sessionVisualAlerts != null)
				{
					busy = true;
					try
					{
						Task operation = TrackScanAsync(sessionVisualAlerts);
						await Task.WhenAny(operation, Task.Delay(2500));
						if (operation.IsCompleted)
						{
							await operation;
						}
					}
					finally
					{
						busy = false;
					}
				}
			}
		};
		Application.ApplicationExit += delegate
		{
			shuttingDown = true;
			Timer.Stop();
			lock (OcrLock)
			{
				if (recognizer != null)
				{
					recognizer.Dispose();
					recognizer = null;
				}
			}
		};
	}

	private static async Task TrackScanAsync(SessionVisualAlerts client)
	{
		inFlight++;
		try
		{
			await client.ScanAsync();
		}
		finally
		{
			inFlight--;
		}
	}

	internal static void Add(SessionVisualAlerts client)
	{
		if (!shuttingDown)
		{
			Clients.Add(client);
			Timer.Start();
		}
	}

	internal static void Remove(SessionVisualAlerts client)
	{
		Clients.Remove(client);
		if (Clients.Count == 0)
		{
			Timer.Stop();
		}
	}

	internal static Task<BrainrotDetection> RecognizeAsync(Bitmap image, double capturedAt, OcrTrace trace)
	{
		trace.Add("ocr-queued", "image=" + image.Width + "x" + image.Height);
		return Task.Run(() =>
		{
			lock (OcrLock)
			{
				trace.Add("ocr-start", "captureAgeMs=" + ((Now - capturedAt) * 1000.0).ToString("F1", CultureInfo.InvariantCulture));
				if (!shuttingDown && !(Now - capturedAt > 2.5))
				{
					if (recognizer == null)
					{
						string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "ocr");
						recognizer = new SpawnTextRecognizer(text);
						recognizer.LoadTemplates(Path.Combine(text, "spawn-templates"));
					}
					Rectangle rectangle = GameViewport.Find(image);
					OcrTrace ocrTrace = trace;
					Rectangle rectangle2 = rectangle;
					ocrTrace.Add("geometry", "viewport=" + rectangle2.ToString() + "; roi=" + SpawnTextRecognizer.AdaptiveNoticeRegion(rectangle.Size).ToString());
					SpawnTextRecognizer.Trace = (string stage, string detail) =>
					{
						trace.Add(stage, detail);
					};
					try
					{
						if (!(rectangle == new Rectangle(Point.Empty, image.Size)))
						{
							using Bitmap image2 = image.Clone(rectangle, image.PixelFormat);
							return recognizer.RecognizeDetailed(image2);
						}
						return recognizer.RecognizeDetailed(image);
					}
					finally
					{
						SpawnTextRecognizer.Trace = null;
						trace.Add("ocr-end", "");
					}
				}
				trace.Add("queue-skip", shuttingDown ? "shutdown" : "capture age exceeds 2.5s");
				return (BrainrotDetection)null;
			}
		});
	}
}
