using System.Runtime.Serialization;

namespace KanblazCloudShell.VisualAlerts;

[DataContract]
internal sealed class CatalogEntry
{
	[DataMember(Name = "name")]
	public string Name;

	[DataMember(Name = "rarity")]
	public string Rarity;

	[DataMember(Name = "aliases")]
	public string[] Aliases;

	internal SpawnNotice Notice
	{
		get
		{
			if (!(Rarity == "Secret"))
			{
				if (!(Rarity == "Eternal"))
				{
					if (!(Rarity == "Absolute"))
					{
						if (!(Rarity == "GOAT"))
						{
							return SpawnNotice.None;
						}
						return SpawnNotice.GOAT;
					}
					return SpawnNotice.Absolute;
				}
				return SpawnNotice.Eternal;
			}
			return SpawnNotice.Secret;
		}
	}
}
