using System;
using System.Drawing;

namespace KanblazCloudShell.VisualAlerts;

internal static class GameViewport
{
	internal static Rectangle Find(Bitmap image)
	{
		Rectangle result = new Rectangle(Point.Empty, image.Size);
		if (image.Width < 240 || image.Height < 240 || (double)image.Width / (double)image.Height >= 1.65)
		{
			return result;
		}
		int num = Edge(image, reverse: false);
		int num2 = Edge(image, reverse: true);
		int num3 = num2 - num + 1;
		int num4 = image.Height - num2 - 1;
		if (num3 <= 0 || (double)num < (double)image.Height * 0.04 || (double)num4 < (double)image.Height * 0.04)
		{
			return result;
		}
		if ((double)Math.Abs(num - num4) > Math.Max(24.0, (double)image.Height * 0.04))
		{
			return result;
		}
		double num5 = (double)image.Width / (double)num3;
		if (num5 < 1.7 || num5 > 1.86)
		{
			return result;
		}
		return new Rectangle(0, num, image.Width, num3);
	}

	private static int Edge(Bitmap image, bool reverse)
	{
		int num = 0;
		int result = 0;
		for (int i = 0; i < image.Height; i += 2)
		{
			int num2 = (reverse ? (image.Height - 1 - i) : i);
			int num3 = 0;
			for (int j = 0; j < 24; j++)
			{
				int x = (int)((double)image.Width * (0.2 + 0.45 * (double)j / 23.0));
				Color pixel = image.GetPixel(x, num2);
				if (pixel.R > 22 || pixel.G > 22 || pixel.B > 22)
				{
					num3++;
				}
			}
			if (num3 >= 6)
			{
				if (num++ == 0)
				{
					result = num2;
				}
				if (num >= 3)
				{
					return result;
				}
			}
			else
			{
				num = 0;
			}
		}
		if (!reverse)
		{
			return 0;
		}
		return image.Height - 1;
	}
}
