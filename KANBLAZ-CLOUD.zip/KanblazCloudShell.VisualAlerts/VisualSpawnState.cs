namespace KanblazCloudShell.VisualAlerts;

internal sealed class VisualSpawnState
{
	private SpawnNotice visible;

	private int missing;

	private double missingSince;

	private readonly double[] nextAllowed = new double[11]
	{
		0.0,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity,
		double.NegativeInfinity
	};

	internal bool Observe(SpawnNotice notice, double now)
	{
		if (notice == SpawnNotice.None)
		{
			if (missing++ == 0)
			{
				missingSince = now;
			}
			if (missing >= 3 && now - missingSince >= 2.0)
			{
				visible = SpawnNotice.None;
			}
			return false;
		}
		missing = 0;
		if (visible == notice)
		{
			return false;
		}
		visible = notice;
		if (now < nextAllowed[(int)notice])
		{
			return false;
		}
		nextAllowed[(int)notice] = now + 34.0;
		return true;
	}

	internal void Reset()
	{
		visible = SpawnNotice.None;
		missing = 0;
		for (int i = 1; i < nextAllowed.Length; i++)
		{
			nextAllowed[i] = double.NegativeInfinity;
		}
	}
}
