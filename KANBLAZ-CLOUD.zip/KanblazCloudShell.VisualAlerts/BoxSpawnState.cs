using System;
using System.Collections.Generic;

namespace KanblazCloudShell.VisualAlerts;

internal sealed class BoxSpawnState
{
	private string visible;

	private double missingSince = -1.0;

	private int missing;

	private readonly Queue<string> recent = new Queue<string>();

	internal bool Observe(string name, double now)
	{
		recent.Enqueue(name);
		while (recent.Count > 4)
		{
			recent.Dequeue();
		}
		if (string.IsNullOrEmpty(name))
		{
			if (missing++ == 0)
			{
				missingSince = now;
			}
			if (missing >= 3 && now - missingSince >= 2.0)
			{
				visible = null;
				recent.Clear();
			}
			return false;
		}
		missing = 0;
		if (string.Equals(visible, name, StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		int num = 0;
		foreach (string item in recent)
		{
			if (string.Equals(item, name, StringComparison.OrdinalIgnoreCase))
			{
				num++;
			}
		}
		if (num < 2)
		{
			return false;
		}
		visible = name;
		return true;
	}

	internal void Reset()
	{
		visible = null;
		missing = 0;
		missingSince = -1.0;
		recent.Clear();
	}
}
