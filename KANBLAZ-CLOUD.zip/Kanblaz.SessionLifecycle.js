// Only inspect rendered service messages and video playback state. No account
// data, browser storage, network interception, screenshots or gameplay automation.
(() => {
  'use strict';
  if (window.top !== window) return;
  const inScope = () => location.protocol === 'https:' && (
    ((location.hostname === 'www.xbox.com' || location.hostname === 'xbox.com') &&
      /^\/(?:[a-z]{2}-[a-z]{2}\/)?play(?:\/|$)/i.test(location.pathname)) ||
    location.hostname === 'play.xbox.com' || location.hostname === 'play.geforcenow.com' ||
    (location.hostname === 'luna.amazon.com' && !/^\/(?:ap|signin|login|auth)(?:\/|$)/i.test(location.pathname)));
  if (!inScope() || !window.chrome?.webview) return;
  const normalize = value => (value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ').trim().toLowerCase();
  const terminalHeadings = new Set([
    'disconnected from game streaming session', 'you were inactive for too long.',
    'you were inactive for too long', 'your game streaming session has ended',
    'your session has ended', 'game session ended', 'session ended',
    'se ha desconectado de la sesion de streaming del juego',
    'te has desconectado de la sesion de streaming del juego',
    'desconectado de la sesion de streaming del juego',
    'has estado inactivo durante demasiado tiempo.',
    'la sesion de juego ha finalizado', 'tu sesion ha finalizado', 'sesion finalizada'
  ]);
  const quitLabels = new Set(['quit game', 'quit', 'salir', 'salir del juego', 'salir del juego ahora', 'end session', 'finalizar sesion']);
  const cancelLabels = new Set(['cancel', 'cancelar', 'keep playing', 'seguir jugando', 'continue playing']);
  const playLabels = new Set(['play', 'jugar', 'play again', 'volver a jugar', 'jugar de nuevo', 'start game', 'iniciar juego']);
  const readyButtons = new Set(['click to start playing', 'haz clic para empezar a jugar', 'haz clic para comenzar a jugar',
    'haz clic para jugar', 'clic para empezar a jugar', 'pulsa para empezar a jugar']);
  const readyHeadings = new Set(['ready to play?', 'your stream is ready', 'listo para jugar?', '¿listo para jugar?',
    'tu transmision esta lista', 'la transmision esta lista']);
  const queueHeadings = new Set(['launching with cloud gaming', 'warming things up for you',
    'loading your game', 'iniciando con cloud gaming', 'iniciando con juegos en la nube',
    'cargando tu juego', 'preparando todo para ti']);
  const blockedStreams = new WeakSet();
  let samples = new WeakMap();
  let queueSamples = 0, sawQueue = false;
  let lastSignal = '', endedScreen = false;
  const send = (signal, repeat = false) => {
    if (!repeat && lastSignal === signal) return;
    window.chrome.webview.postMessage('kanblaz.session.' + signal + '.v1');
    lastSignal = signal;
  };
  const visible = element => {
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return element.isConnected && rect.width > 0 && rect.height > 0 &&
      rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth &&
      style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0' &&
      (!element.checkVisibility || element.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true }));
  };
  const liveStream = video => {
    const stream = video.srcObject;
    return stream && typeof stream.getVideoTracks === 'function' && stream.active &&
      stream.getVideoTracks().some(track => track.readyState === 'live') ? stream : null;
  };
  const videos = () => Array.from(document.querySelectorAll('video'));
  const hasLiveStream = () => videos().some(video => !!liveStream(video));
  const serviceScreen = () => {
    const state = { terminal: false, queue: false, ready: false };
    const xbox = ['xbox.com','www.xbox.com','play.xbox.com'].includes(location.hostname);
    // Narrow text targets: never read input values, a whole document, or hidden text.
    for (const element of document.querySelectorAll('h1,h2,h3,[role="heading"],[role="alert"],p,div,span,button,[role="button"]')) {
      if ((element.tagName === 'DIV' || element.tagName === 'SPAN') && element.childElementCount > 0) continue;
      const value = element.textContent || '';
      if (value.length > 240) continue;
      const label = normalize(value), stageLabel = label.replace(/[.\u2026]+$/, '');
      const terminal = terminalHeadings.has(label);
      const queue = xbox && queueHeadings.has(stageLabel);
      const ready = xbox && (readyHeadings.has(stageLabel) || readyButtons.has(label));
      if (!(terminal || queue || ready) || !visible(element)) continue;
      state.terminal = state.terminal || terminal;
      state.queue = state.queue || queue;
      state.ready = state.ready || ready;
    }
    return state;
  };
  const poll = () => {
    if (!inScope()) {
      // Do not carry an incomplete loading sequence through account/other pages.
      queueSamples = 0; sawQueue = false; samples = new WeakMap();
      return;
    }
    const screen = serviceScreen();
    if (screen.terminal) {
      queueSamples = 0; sawQueue = false; samples = new WeakMap();
      for (const video of videos()) { const stream = liveStream(video); if (stream) blockedStreams.add(stream); }
      endedScreen = true; send('ended'); return;
    }
    if (screen.queue) {
      // Two observations of the actual service loading screen, not a generic
      // video pause. This evidence is ephemeral and never saved across reloads.
      if (++queueSamples >= 2) sawQueue = true;
      samples = new WeakMap();
      if (!hasLiveStream() && !endedScreen) send('idle', true); // Can confirm a preceding Quit, never ends a clock by itself.
      return;
    }
    queueSamples = 0;
    if (screen.ready) {
      // Xbox already has a live MediaStream behind "Ready to play?". Do not
      // count that preloaded video as accepted gameplay or reuse its samples.
      samples = new WeakMap();
      if (!hasLiveStream() && !endedScreen) send('idle', true);
      return;
    }
    const candidates = videos();
    let playing = false, live = false;
    const resumedStreams = [];
    for (const video of candidates) {
      const stream = liveStream(video);
      if (stream) live = true; // Paused/hidden streams must not confirm Quit.
      // A confirmed new loading sequence can reuse the same MediaStream object.
      // Merely dismissing the terminal screen still cannot unblock stale media.
      if (!stream || (blockedStreams.has(stream) && !sawQueue)) { samples.delete(video); continue; }
      const size = video.getBoundingClientRect();
      if (!visible(video) || size.width < 160 || size.height < 90 ||
          video.videoWidth < 160 || video.videoHeight < 90 || video.paused || video.ended || video.readyState < 2) {
        samples.delete(video); continue;
      }
      const previous = samples.get(video);
      const time = video.currentTime;
      samples.set(video, { stream, time });
      // Two advancing observations of live media exclude queue/trailer/loading video.
      if (previous && previous.stream === stream && time > previous.time) {
        playing = true; resumedStreams.push(stream);
      }
    }
    if (playing) {
      if (sawQueue) {
        for (const stream of resumedStreams) blockedStreams.delete(stream);
        // Loading -> actual advancing gameplay is a boundary even without any
        // observed button click. The host only re-arms an expired/ended clock.
        send('next-playing');
        lastSignal = 'playing'; // This signal also confirms playback; do not repeat it.
      } else send('playing');
      endedScreen = false; sawQueue = false;
    }
    else if (!live && !endedScreen) send('idle', true);
    // Pauses, stalled media and temporary network drops do not finish the session.
  };
  document.addEventListener('click', event => {
    if (!event.isTrusted || !inScope()) return;
    const button = event.target?.closest?.('button,[role="button"],a');
    if (!button || !visible(button)) return;
    const text = button.textContent || '';
    if (text.length > 100) return;
    const label = normalize(text.trim() || button.getAttribute('aria-label'));
    if (quitLabels.has(label)) { sawQueue = false; queueSamples = 0; send('quit', true); } // Intent only; confirmation may be cancelled.
    else if (cancelLabels.has(label)) { sawQueue = false; queueSamples = 0; send('cancel', true); }
    else if (readyButtons.has(label) && ['xbox.com','www.xbox.com','play.xbox.com'].includes(location.hostname)) {
      // A real acceptance after loading is a launch boundary even if Xbox
      // preloaded/reused a MediaStream. Ready alone (e.g. refocus/reload) is not.
      if (sawQueue || endedScreen) {
        for (const video of videos()) { const stream = liveStream(video); if (stream) blockedStreams.delete(stream); }
        samples = new WeakMap(); sawQueue = false; queueSamples = 0;
        endedScreen = false; send('launch', true);
      }
    }
    else if (playLabels.has(label) && !hasLiveStream()) {
      endedScreen = false; send('launch', true);
    }
  }, true);
  // Deliberately no unload/pagehide handler: reload/closing is NOT Quit Game.
  setInterval(poll, 1000);
})();
