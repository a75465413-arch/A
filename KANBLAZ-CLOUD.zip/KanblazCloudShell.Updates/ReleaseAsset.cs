using System.Runtime.Serialization;

namespace KanblazCloudShell.Updates;

[DataContract]
internal sealed class ReleaseAsset
{
	[DataMember(Name = "name")]
	public string Name;

	[DataMember(Name = "browser_download_url")]
	public string Url;

	[DataMember(Name = "digest")]
	public string Digest;

	[DataMember(Name = "state")]
	public string State;

	[DataMember(Name = "size")]
	public long Size;
}
