using System;
using System.Linq;
using System.Runtime.Serialization;

namespace KanblazCloudShell.Updates;

[DataContract]
internal sealed class ReleaseInfo
{
	[DataMember(Name = "tag_name")]
	public string Tag;

	[DataMember(Name = "body")]
	public string Notes;

	[DataMember(Name = "draft")]
	public bool Draft;

	[DataMember(Name = "prerelease")]
	public bool Prerelease;

	[DataMember(Name = "assets")]
	public ReleaseAsset[] Assets;

	internal Version Version => UpdateProtocol.ParseVersion(Tag);

	internal ReleaseAsset Package => (Assets ?? new ReleaseAsset[0]).SingleOrDefault((ReleaseAsset a) => a.Name == UpdateProtocol.AssetName);
}
