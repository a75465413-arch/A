using System.Runtime.Serialization;

namespace KanblazCloudShell.Updates;

[DataContract]
internal sealed class UpdateJob
{
	[DataMember]
	public string Destination;

	[DataMember]
	public string Archive;

	[DataMember]
	public string Digest;

	[DataMember]
	public string Version;

	[DataMember]
	public int ParentId;
}
