using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace KanblazCloudShell.Updates;

internal static class UpdateProtocol
{
	internal const string Repository = "kanblaz/KANBLAZ-CLOUD-Releases";

	internal const string Channel = "stable";

	internal const long MaxDownload = 536870912L;

	internal const long MaxExpanded = 1073741824L;

	internal static string Architecture
	{
		get
		{
			if (IntPtr.Size != 4)
			{
				return "x64";
			}
			return "x86";
		}
	}

	internal static string AssetName => "KANBLAZ-CLOUD-win-" + Architecture + ".zip";

	internal static string CacheRoot => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KanblazUpdates");

	internal static Version ParseVersion(string tag)
	{
		if (tag == null || !Regex.IsMatch(tag, "^v?\\d+\\.\\d+\\.\\d+(\\.\\d+)?$"))
		{
			throw new InvalidDataException("Unsupported release version.");
		}
		Version version = new Version(tag.TrimStart('v'));
		return new Version(version.Major, version.Minor, version.Build, Math.Max(0, version.Revision));
	}

	internal static bool IsNewStable(ReleaseInfo release, Version current)
	{
		if (release != null && !release.Draft && !release.Prerelease)
		{
			return release.Version > current;
		}
		return false;
	}

	internal static void ValidateAsset(ReleaseAsset asset)
	{
		if (asset == null || asset.State != "uploaded" || asset.Size <= 0 || asset.Size > 536870912 || !Regex.IsMatch(asset.Digest ?? "", "^sha256:[a-fA-F0-9]{64}$") || !Uri.TryCreate(asset.Url, UriKind.Absolute, out var result) || result.Scheme != "https" || result.Host != "github.com" || !result.IsDefaultPort || result.UserInfo != "" || !result.AbsolutePath.StartsWith("/kanblaz/KANBLAZ-CLOUD-Releases/releases/download/", StringComparison.Ordinal) || !result.AbsolutePath.EndsWith("/" + AssetName, StringComparison.Ordinal))
		{
			throw new InvalidDataException("Release needs the official Windows package and GitHub SHA-256 digest.");
		}
	}

	internal static async Task<byte[]> Fetch(string url, long maximum, CancellationToken cancel, Stream destination = null)
	{
		using HttpClientHandler handler = new HttpClientHandler
		{
			AllowAutoRedirect = false,
			UseCookies = false,
			UseDefaultCredentials = false
		};
		using HttpClient client = new HttpClient(handler)
		{
			Timeout = TimeSpan.FromMinutes(10.0)
		};
		client.DefaultRequestHeaders.UserAgent.ParseAdd("KanblazCloud-Updater/1.0");
		client.DefaultRequestHeaders.Accept.ParseAdd("application/vnd.github+json");
		for (int hop = 0; hop < 5; hop++)
		{
			Uri uri = new Uri(url);
			string host = uri.Host;
			if (!(uri.Scheme != "https") && uri.IsDefaultPort && !(uri.UserInfo != ""))
			{
				switch (host)
				{
				case "api.github.com":
				case "github.com":
				case "release-assets.githubusercontent.com":
				case "objects.githubusercontent.com":
				{
					using HttpResponseMessage response = await client.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, cancel);
					int statusCode = (int)response.StatusCode;
					if (statusCode >= 300 && statusCode < 400 && response.Headers.Location != null)
					{
						url = new Uri(uri, response.Headers.Location).AbsoluteUri;
						continue;
					}
					if (response.StatusCode == HttpStatusCode.NotFound)
					{
						throw new InvalidDataException("No public release is available yet.");
					}
					response.EnsureSuccessStatusCode();
					if (response.Content.Headers.ContentLength > maximum)
					{
						throw new InvalidDataException("Update exceeds size limit.");
					}
					using Stream input = await response.Content.ReadAsStreamAsync();
					using MemoryStream memory = new MemoryStream();
					Stream output = destination ?? memory;
					byte[] buffer = new byte[81920];
					long size = 0L;
					int num;
					while ((num = await input.ReadAsync(buffer, 0, buffer.Length, cancel)) > 0)
					{
						size += num;
						if (size > maximum)
						{
							throw new InvalidDataException("Update exceeds size limit.");
						}
						await output.WriteAsync(buffer, 0, num, cancel);
					}
					return (destination == null) ? memory.ToArray() : null;
				}
				}
			}
			throw new InvalidDataException("Untrusted update destination.");
		}
		throw new InvalidDataException("Too many update redirects.");
	}

	internal static async Task<ReleaseInfo> Check(CancellationToken cancel)
	{
		using MemoryStream stream = new MemoryStream(await Fetch("https://api.github.com/repos/kanblaz/KANBLAZ-CLOUD-Releases/releases/latest", 1048576L, cancel));
		return (ReleaseInfo)new DataContractJsonSerializer(typeof(ReleaseInfo)).ReadObject(stream);
	}

	internal static string Hash(string path)
	{
		using FileStream inputStream = File.OpenRead(path);
		using SHA256 sHA = SHA256.Create();
		return "sha256:" + BitConverter.ToString(sHA.ComputeHash(inputStream)).Replace("-", "").ToLowerInvariant();
	}

	internal static bool AllowedFile(string name)
	{
		if (string.IsNullOrEmpty(name) || name.Contains('\\') || name.StartsWith("/") || name.Contains(":") || name.Split('/').Any((string p) =>
		{
			switch (p)
			{
			default:
				if (!p.EndsWith(".") && !p.EndsWith(" ") && p.IndexOfAny(Path.GetInvalidFileNameChars()) < 0)
				{
					return Regex.IsMatch(p, "^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\\.|$)", RegexOptions.IgnoreCase);
				}
				break;
			case "":
			case ".":
			case "..":
				break;
			}
			return true;
		}))
		{
			return false;
		}
		if (name.StartsWith("assets/", StringComparison.Ordinal))
		{
			return new string[7] { ".png", ".jpg", ".ico", ".wav", ".traineddata", ".txt", ".md" }.Contains(Path.GetExtension(name).ToLowerInvariant());
		}
		if (name.StartsWith(Architecture + "/", StringComparison.Ordinal))
		{
			if (!(name == Architecture + "/leptonica-1.82.0.dll"))
			{
				return name == Architecture + "/tesseract50.dll";
			}
			return true;
		}
		return new string[15]
		{
			"KANBLAZ CLOUD.exe", "Kanblaz.UpdateHost.exe", "Kanblaz.ProcessAudio.dll", "Microsoft.Web.WebView2.Core.dll", "Microsoft.Web.WebView2.WinForms.dll", "Tesseract.dll", "WebView2Loader.dll", "README.html", "SOUND ALERTS.html", "COPYRIGHT.txt",
			"00 - INSTRUCTIONS.png", "02 - SUPPORTED SERVICES.png", "01 - CREATE DESKTOP SHORTCUT.bat", "Create desktop shortcut.bat", "Create desktop shortcut.ps1"
		}.Contains(name);
	}

	internal static void NoLinks(string path)
	{
		for (string text = Path.GetFullPath(path); text != null; text = Path.GetDirectoryName(text))
		{
			if ((File.Exists(text) || Directory.Exists(text)) && (File.GetAttributes(text) & FileAttributes.ReparsePoint) != 0)
			{
				throw new IOException("Update paths cannot contain links or junctions.");
			}
		}
	}

	internal static string Inside(string root, string relative)
	{
		if (!AllowedFile(relative))
		{
			throw new InvalidDataException("Package contains an unsupported file.");
		}
		string text = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
		string fullPath = Path.GetFullPath(Path.Combine(text, relative.Replace('/', Path.DirectorySeparatorChar)));
		if (!fullPath.StartsWith(text, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidDataException("Unsafe update path.");
		}
		NoLinks(fullPath);
		return fullPath;
	}

	internal static List<string> Extract(string archive, string digest, string output)
	{
		if (!string.Equals(Hash(archive), digest, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidDataException("Update SHA-256 mismatch.");
		}
		NoLinks(output);
		if (Directory.Exists(output))
		{
			throw new IOException("Staging folder already exists.");
		}
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		long num = 0L;
		using (ZipArchive zipArchive = ZipFile.OpenRead(archive))
		{
			if (zipArchive.Entries.Count > 2000)
			{
				throw new InvalidDataException("Too many package entries.");
			}
			foreach (ZipArchiveEntry entry in zipArchive.Entries)
			{
				if (!entry.FullName.EndsWith("/") || entry.Length != 0L)
				{
					Inside(output, entry.FullName);
					if (!hashSet.Add(entry.FullName) || ((entry.ExternalAttributes >> 16) & 0xF000) == 40960)
					{
						throw new InvalidDataException("Duplicate or linked package entry.");
					}
					num += entry.Length;
					if (num > 1073741824)
					{
						throw new InvalidDataException("Expanded package too large.");
					}
				}
			}
			string[] array = new string[10]
			{
				"KANBLAZ CLOUD.exe",
				"Kanblaz.UpdateHost.exe",
				"WebView2Loader.dll",
				"Microsoft.Web.WebView2.Core.dll",
				"Microsoft.Web.WebView2.WinForms.dll",
				"Tesseract.dll",
				"Kanblaz.ProcessAudio.dll",
				Architecture + "/leptonica-1.82.0.dll",
				Architecture + "/tesseract50.dll",
				"assets/ocr/eng.traineddata"
			};
			foreach (string text in array)
			{
				if (!hashSet.Contains(text))
				{
					throw new InvalidDataException("Incomplete update package: " + text);
				}
			}
			Directory.CreateDirectory(output);
			foreach (ZipArchiveEntry entry2 in zipArchive.Entries)
			{
				if (!hashSet.Contains(entry2.FullName))
				{
					continue;
				}
				string path = Inside(output, entry2.FullName);
				Directory.CreateDirectory(Path.GetDirectoryName(path));
				using Stream stream = entry2.Open();
				using FileStream destination = new FileStream(path, FileMode.CreateNew, FileAccess.Write);
				stream.CopyTo(destination);
			}
		}
		return hashSet.OrderBy((string n) => (n == "KANBLAZ CLOUD.exe") ? 1 : 0).ToList();
	}

	internal static void ValidateDestination(string directory)
	{
		NoLinks(directory);
		string text = Path.GetFullPath(directory).TrimEnd('\\') + "\\";
		string value = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz").TrimEnd('\\') + "\\";
		if (text.StartsWith(value, StringComparison.OrdinalIgnoreCase) || !File.Exists(Path.Combine(text, "KANBLAZ CLOUD.exe")))
		{
			throw new IOException("Unsupported installation location. Application data cannot be an update destination.");
		}
	}

	internal static void Install(string stage, string destination, string backup, IEnumerable<string> files, Action<string> beforeCopy = null)
	{
		ValidateDestination(destination);
		NoLinks(backup);
		Directory.CreateDirectory(backup);
		List<string> list = files.ToList();
		HashSet<string> hashSet = new HashSet<string>();
		List<string> list2 = new List<string>();
		foreach (string item2 in list)
		{
			string text = Inside(destination, item2);
			string text2 = Inside(backup, item2);
			if (File.Exists(text))
			{
				Directory.CreateDirectory(Path.GetDirectoryName(text2));
				File.Copy(text, text2, overwrite: false);
				hashSet.Add(item2);
			}
		}
		try
		{
			foreach (string item3 in list)
			{
				string text3 = Inside(destination, item3);
				beforeCopy?.Invoke(item3);
				Directory.CreateDirectory(Path.GetDirectoryName(text3));
				list2.Add(item3);
				File.Copy(Inside(stage, item3), text3, overwrite: true);
			}
		}
		catch (Exception ex)
		{
			List<Exception> list3 = new List<Exception> { ex };
			foreach (string item4 in list2.AsEnumerable().Reverse())
			{
				try
				{
					string text4 = Inside(destination, item4);
					if (hashSet.Contains(item4))
					{
						File.Copy(Inside(backup, item4), text4, overwrite: true);
					}
					else if (File.Exists(text4))
					{
						File.Delete(text4);
					}
				}
				catch (Exception item)
				{
					list3.Add(item);
				}
			}
			if (list3.Count > 1)
			{
				throw new AggregateException("Update failed; rollback needs manual attention. Backup retained.", list3);
			}
			throw new IOException("Update failed; previous application files restored.", ex);
		}
	}
}
