using System;
using System.Security.Cryptography;

namespace KanblazLicensing;

internal static class ActivationServiceConfig
{
	internal const string Endpoint = "https://kanblaz-licenses.kanblaz.workers.dev/v1/activate";

	internal const string ReceiptPublicKeyXml = "<RSAKeyValue><Modulus>z+0SswZHJ9ShjUuLF+ctkJyV3slNpbLAstAzP237QaYFuVi3r8TEX6a88rO7sFQ/TAwlR1zQr4Q4uOpuS6EvlHt5Xbx6mQU49lZk5PwEsnSroL4R6btiLBwGsi9dutqBzWKH9QKVNk9xFsen8rpkkVK987U9b5Klcza6YLwMwzjScqhHrZy1SBJk9xObrnjwa97O3Z91vejNJ0mZJna7jnS3mxRrHOsBrBLHT61+db7rIhy8S2q3yLwA7WdqfGWw0TVONMgvyCFMWKXmg0L3LTSXxJZPjsqKikedYVMJ8Vwe4LDeVXCf5lxoIE/K6uITwfzksx5Cl+EPk0L8PI3ZZQ==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

	internal static bool IsConfigured
	{
		get
		{
			if (!Uri.TryCreate("https://kanblaz-licenses.kanblaz.workers.dev/v1/activate", UriKind.Absolute, out var result) || result.Scheme != "https" || !string.IsNullOrEmpty(result.UserInfo) || result.AbsolutePath != "/v1/activate" || !string.IsNullOrEmpty(result.Query) || !string.IsNullOrEmpty(result.Fragment))
			{
				return false;
			}
			try
			{
				using RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider();
				rSACryptoServiceProvider.PersistKeyInCsp = false;
				rSACryptoServiceProvider.FromXmlString("<RSAKeyValue><Modulus>z+0SswZHJ9ShjUuLF+ctkJyV3slNpbLAstAzP237QaYFuVi3r8TEX6a88rO7sFQ/TAwlR1zQr4Q4uOpuS6EvlHt5Xbx6mQU49lZk5PwEsnSroL4R6btiLBwGsi9dutqBzWKH9QKVNk9xFsen8rpkkVK987U9b5Klcza6YLwMwzjScqhHrZy1SBJk9xObrnjwa97O3Z91vejNJ0mZJna7jnS3mxRrHOsBrBLHT61+db7rIhy8S2q3yLwA7WdqfGWw0TVONMgvyCFMWKXmg0L3LTSXxJZPjsqKikedYVMJ8Vwe4LDeVXCf5lxoIE/K6uITwfzksx5Cl+EPk0L8PI3ZZQ==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>");
				return rSACryptoServiceProvider.PublicOnly && rSACryptoServiceProvider.KeySize >= 2048;
			}
			catch
			{
				return false;
			}
		}
	}
}
