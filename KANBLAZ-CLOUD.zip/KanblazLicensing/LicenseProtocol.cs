using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace KanblazLicensing;

internal static class LicenseProtocol
{
	internal const string IssuerPublicKeyXml = "<RSAKeyValue><Modulus>uV/e4tsUMvzMBlhAzQ4gwaQw8QSgx0Wah5C0JQUSRgiLtO5Em4+GQooUJNh2CxXBuPwsxTHTPLwCJnodSYL/TlmpdpMRZDZUhQrDgbtbxncssTElv6bNHKZLb9QCvld4QFJeC1hHNrn/gxkWcB1aOKAMO/FS6fGjGGHzqf6puT0ABjHpZZPeZ2WP+fiCuGFCSIt6Cx8Iic0FMoRIo9XumRl/hge169iwpNtdFYh2VLoEn7fEvejkPpKviCJSc8mOn7iP/9NVbRD4pkPPu8nkjb25xoIbL5/5jURJjxnF4MeRkfkbOIe29f9bJDezu++JDX9u7yHALUSsV/MX9Hgo9Q==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";

	private static readonly Encoding StrictUtf8 = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);

	internal static string Normalize(string code)
	{
		if (code == null || code.Length > 8192)
		{
			return string.Empty;
		}
		return string.Concat(code.Where((char c) => !char.IsWhiteSpace(c)));
	}

	internal static string Encode(byte[] bytes)
	{
		return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-')
			.Replace('/', '_');
	}

	internal static byte[] Decode(string value)
	{
		if (string.IsNullOrEmpty(value) || value.Any((char c) => (!char.IsLetterOrDigit(c) || c >= '\u0080') && c != '-' && c != '_'))
		{
			throw new FormatException("Invalid encoding.");
		}
		string text = value.Replace('-', '+').Replace('_', '/');
		if (text.Length % 4 == 1)
		{
			throw new FormatException("Invalid encoding.");
		}
		return Convert.FromBase64String(text.PadRight((text.Length + 3) / 4 * 4, '='));
	}

	internal static string Sign(string payload, RSACryptoServiceProvider key)
	{
		byte[] bytes = StrictUtf8.GetBytes(payload);
		using SHA256 halg = SHA256.Create();
		return Encode(bytes) + "." + Encode(key.SignData(bytes, halg));
	}

	private static string Verify(string signed, string publicKey)
	{
		string[] array = Normalize(signed).Split('.');
		if (array.Length != 2)
		{
			throw new FormatException();
		}
		byte[] array2 = Decode(array[0]);
		byte[] signature = Decode(array[1]);
		using (RSACryptoServiceProvider rSACryptoServiceProvider = new RSACryptoServiceProvider())
		{
			using SHA256 halg = SHA256.Create();
			rSACryptoServiceProvider.PersistKeyInCsp = false;
			rSACryptoServiceProvider.FromXmlString(publicKey);
			if (!rSACryptoServiceProvider.VerifyData(array2, halg, signature))
			{
				throw new CryptographicException();
			}
		}
		return StrictUtf8.GetString(array2);
	}

	internal static string NewPayload(Guid id, string label)
	{
		if (id == Guid.Empty || label == null || label.Length > 120 || label.Any(char.IsControl))
		{
			throw new ArgumentException("Invalid license data.");
		}
		return "KANBLAZ2|" + id.ToString("N") + "|" + Convert.ToBase64String(StrictUtf8.GetBytes(label)) + "|2";
	}

	internal static bool TryLicense(string code, out LicenseData license, string publicKey = "<RSAKeyValue><Modulus>uV/e4tsUMvzMBlhAzQ4gwaQw8QSgx0Wah5C0JQUSRgiLtO5Em4+GQooUJNh2CxXBuPwsxTHTPLwCJnodSYL/TlmpdpMRZDZUhQrDgbtbxncssTElv6bNHKZLb9QCvld4QFJeC1hHNrn/gxkWcB1aOKAMO/FS6fGjGGHzqf6puT0ABjHpZZPeZ2WP+fiCuGFCSIt6Cx8Iic0FMoRIo9XumRl/hge169iwpNtdFYh2VLoEn7fEvejkPpKviCJSc8mOn7iP/9NVbRD4pkPPu8nkjb25xoIbL5/5jURJjxnF4MeRkfkbOIe29f9bJDezu++JDX9u7yHALUSsV/MX9Hgo9Q==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>")
	{
		license = null;
		try
		{
			string[] array = Verify(code, publicKey).Split('|');
			bool num = array.Length == 3 && array[0] == "KANBLAZ1";
			bool flag = array.Length == 4 && array[0] == "KANBLAZ2" && array[3] == "2";
			if ((!num && !flag) || !Guid.TryParseExact(array[1], "N", out var result) || result == Guid.Empty)
			{
				return false;
			}
			string text = StrictUtf8.GetString(Convert.FromBase64String(array[2]));
			if (text.Length > 120 || text.IndexOfAny(new char[3] { '\r', '\n', '\t' }) >= 0)
			{
				return false;
			}
			license = new LicenseData
			{
				Id = result.ToString("N"),
				Label = text,
				RequiresServer = flag
			};
			return true;
		}
		catch
		{
			return false;
		}
	}

	internal static bool TryReceipt(string receipt, string licenseId, string device, string publicKey)
	{
		try
		{
			return IsDevice(device) && Verify(receipt, publicKey) == "KANBLAZ-DEVICE1|" + licenseId + "|" + device + "|2";
		}
		catch
		{
			return false;
		}
	}

	internal static bool IsDevice(string value)
	{
		if (value != null && value.Length == 64)
		{
			return value.All((char c) => (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'));
		}
		return false;
	}

	internal static string DeviceHash(string windowsInstallationId, string licenseId)
	{
		if (!Guid.TryParse(windowsInstallationId, out var result) || result == Guid.Empty || !Guid.TryParseExact(licenseId, "N", out var result2) || result2 == Guid.Empty)
		{
			throw new InvalidOperationException("This Windows installation could not be identified.");
		}
		using SHA256 sHA = SHA256.Create();
		return BitConverter.ToString(sHA.ComputeHash(Encoding.UTF8.GetBytes("KANBLAZ-DEVICE1|" + result2.ToString("N") + "|" + result.ToString("N")))).Replace("-", "").ToLowerInvariant();
	}
}
