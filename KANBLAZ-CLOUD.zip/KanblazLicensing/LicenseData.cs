namespace KanblazLicensing;

internal sealed class LicenseData
{
	internal string Id;

	internal string Label;

	internal bool RequiresServer;
}
