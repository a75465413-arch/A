// Read only narrow rendered labels/media metadata. No account/storage/input data.
(() => {
  if(window.top!==window || location.protocol!=='https:' || (location.port&&location.port!=='443') ||
     !['xbox.com','www.xbox.com','play.xbox.com'].includes(location.hostname) ||
     !/^\/(?:[a-z]{2}-[a-z]{2}\/)?play\/(?:launch|games)\/fortnite\/[^/]+\/?$/i.test(location.pathname)) return 'unsupported';
  const visible=e=>{
    const r=e.getBoundingClientRect(),s=getComputedStyle(e);
    return e.isConnected&&r.width>0&&r.height>0&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth&&
      s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0'&&(!e.checkVisibility||e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}));
  };
  // Safety wins over recovery: even an ambiguous live stream prevents reload.
  const live=Array.from(document.querySelectorAll('video')).some(v=>{
    const stream=v.srcObject;
    return v.videoWidth>=160&&v.videoHeight>=90&&stream&&stream.active&&
      typeof stream.getVideoTracks==='function'&&stream.getVideoTracks().some(t=>t.readyState==='live');
  });
  if(live)return 'playing';
  const normalize=t=>(t||'').replace(/\s+/g,' ').trim().toLowerCase();
  const loading=new Set(['launching with cloud gaming','warming things up for you','loading your game','iniciando con cloud gaming','cargando tu juego']);
  let ended=false,queue=false,play=false;
  let disconnected=false,inactive=false,quit=false;
  for(const e of document.querySelectorAll('h1,h2,h3,[role=heading],[role=alert],p,span,div,button,[role=button]')){
    if(e.childElementCount>0&&['DIV','SPAN'].includes(e.tagName))continue;
    if(!visible(e))continue;
    const text=e.textContent||'';if(text.length>120)continue;
    const label=normalize(text);
    if(label==='how was your experience playing?')ended=true;
    if(label==='disconnected from game streaming session')disconnected=true;
    if(label==='you were inactive for too long.')inactive=true;
    if((e.tagName==='BUTTON'||e.getAttribute('role')==='button')&&label==='quit game')quit=true;
    if(loading.has(label.replace(/[.\u2026]+$/,'')))queue=true;
    if((e.tagName==='BUTTON'||e.getAttribute('role')==='button')&&['play','jugar','play again','volver a jugar','click to start playing'].includes(label))play=true;
  }
  // Confirm the specific idle-disconnect screen, not a generic network/loading
  // message. The host applies the same 3-second confirmation and retry budget.
  if(ended||(disconnected&&inactive&&quit))return 'ended';
  if(queue)return 'loading';
  if(play)return 'play';
  return 'unknown';
})()
