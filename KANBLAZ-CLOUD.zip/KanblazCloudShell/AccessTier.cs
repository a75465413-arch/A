namespace KanblazCloudShell;

internal enum AccessTier
{
	Free,
	Pro
}
