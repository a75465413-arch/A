using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceScrollPanel : Panel
{
	internal WorkspaceScrollPanel()
	{
		DoubleBuffered = true;
	}

	protected override void OnScroll(ScrollEventArgs e)
	{
		base.OnScroll(e);
		Invalidate(invalidateChildren: true);
	}

	protected override void OnMouseWheel(MouseEventArgs e)
	{
		base.OnMouseWheel(e);
		Invalidate(invalidateChildren: true);
	}
}
