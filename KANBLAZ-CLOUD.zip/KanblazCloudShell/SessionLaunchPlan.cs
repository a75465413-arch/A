using System;
using System.Collections.Generic;
using System.Linq;

namespace KanblazCloudShell;

internal static class SessionLaunchPlan
{
	internal static Guid[] NewKeys(IEnumerable<Guid> requested, IEnumerable<Guid> running)
	{
		HashSet<Guid> existing = new HashSet<Guid>(running);
		return requested.Where((Guid key) => existing.Add(key)).ToArray();
	}
}
