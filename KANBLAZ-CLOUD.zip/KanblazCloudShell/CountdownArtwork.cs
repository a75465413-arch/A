using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace KanblazCloudShell;

internal static class CountdownArtwork
{
	internal static readonly Size BadgeSize = new Size(90, 28);

	internal static readonly Size ResetSize = new Size(26, 28);

	internal static Rectangle BoundsFor(Rectangle cell)
	{
		if (cell.Width < BadgeSize.Width + 16 || cell.Height < BadgeSize.Height + 16)
		{
			return Rectangle.Empty;
		}
		return new Rectangle(cell.Left + 8, cell.Bottom - BadgeSize.Height - 8, BadgeSize.Width, BadgeSize.Height);
	}

	internal static Rectangle ResetBoundsFor(Rectangle cell)
	{
		Rectangle rectangle = BoundsFor(cell);
		if (rectangle.IsEmpty)
		{
			return Rectangle.Empty;
		}
		Rectangle result = new Rectangle(rectangle.Right + 4, rectangle.Top, ResetSize.Width, ResetSize.Height);
		if (result.Right > cell.Right - 8)
		{
			return Rectangle.Empty;
		}
		return result;
	}

	internal static void DrawReset(Graphics g, bool hovered)
	{
		g.Clear(hovered ? Color.FromArgb(29, 51, 65) : Color.FromArgb(13, 20, 29));
		g.SmoothingMode = SmoothingMode.AntiAlias;
		using Pen pen = new Pen(Color.FromArgb(66, 91, 110));
		using Pen pen2 = new Pen(Color.FromArgb(219, 240, 247), 1.6f);
		g.DrawRectangle(pen, 0, 0, ResetSize.Width - 1, ResetSize.Height - 1);
		g.DrawArc(pen2, 6, 7, 13, 13, 40, 290);
		g.DrawLines(pen2, new Point[3]
		{
			new Point(14, 9),
			new Point(20, 10),
			new Point(20, 4)
		});
	}

	internal static void Draw(Graphics g, int seconds, string label = null)
	{
		g.Clear(Color.FromArgb(13, 20, 29));
		g.SmoothingMode = SmoothingMode.AntiAlias;
		g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
		Color color = ((seconds == 0) ? Color.FromArgb(255, 195, 100) : Color.FromArgb(219, 240, 247));
		using Pen pen = new Pen(Color.FromArgb(66, 91, 110));
		using Pen pen2 = new Pen(color, 1.3f);
		using SolidBrush brush = new SolidBrush(color);
		using Font font = new Font("Consolas", 14f, FontStyle.Bold, GraphicsUnit.Pixel);
		using StringFormat format = new StringFormat
		{
			LineAlignment = StringAlignment.Center
		};
		g.DrawRectangle(pen, 0, 0, BadgeSize.Width - 1, BadgeSize.Height - 1);
		g.DrawEllipse(pen2, 8, 8, 12, 12);
		g.DrawLine(pen2, 14, 10, 14, 14);
		g.DrawLine(pen2, 14, 14, 17, 15);
		g.DrawString(label ?? SessionCountdownState.Format(seconds), font, brush, new RectangleF(27f, 2f, 60f, 24f), format);
	}
}
