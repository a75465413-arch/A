using System;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class AccountForm : Form
{
	private readonly TextBox email = new TextBox();

	private readonly Label feedback = new Label();

	private readonly Label planBadge = new Label();

	private AccessPolicy access;

	private readonly CancellationTokenSource loginCancellation = new CancellationTokenSource();

	private Button googleButton;

	private Button signOutButton;

	private Button adminButton;

	private string verifiedAccountEmail;

	internal bool AccessChanged { get; private set; }

	internal AccountForm(AccessPolicy access, Icon appIcon)
	{
		this.access = access;
		Text = "KANBLAZ CLOUD";
		Icon = appIcon;
		StartPosition = FormStartPosition.CenterParent;
		ClientSize = new Size(760, 730);
		MinimumSize = new Size(720, 650);
		FormBorderStyle = FormBorderStyle.FixedDialog;
		MaximizeBox = false;
		MinimizeBox = false;
		ShowInTaskbar = false;
		BackColor = Color.FromArgb(9, 13, 18);
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 10f);
		BuildInterface();
		RefreshPlan();
		FormClosed += delegate
		{
			loginCancellation.Cancel();
		};
		Shown += async delegate
		{
			_ = 1;
			try
			{
				GoogleAccountLogin.Reply reply = await GoogleAccountLogin.Current(loginCancellation.Token);
				if (!IsDisposed && reply != null)
				{
					ShowAccount(reply.Email, reply.Admin);
					await RefreshAccountAccess();
				}
			}
			catch
			{
				if (!IsDisposed)
				{
					feedback.Text = "Sign in with Google to verify your account. Your existing license is unchanged.";
				}
			}
		};
	}

	private void BuildInterface()
	{
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			AutoScroll = true,
			ColumnCount = 1,
			RowCount = 5,
			Padding = new Padding(30),
			BackColor = BackColor
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		Controls.Add(tableLayoutPanel);
		TableLayoutPanel tableLayoutPanel2 = new TableLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			ColumnCount = 2
		};
		tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false
		};
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "ACCOUNT & ACCESS",
			AutoSize = true,
			ForeColor = Color.FromArgb(145, 166, 182),
			Font = new Font("Segoe UI Semibold", 9f)
		});
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Manage your KANBLAZ CLOUD plan",
			AutoSize = true,
			ForeColor = Color.White,
			Font = new Font("Segoe UI Semibold", 21f),
			Margin = new Padding(0, 4, 0, 18)
		});
		tableLayoutPanel2.Controls.Add(flowLayoutPanel, 0, 0);
		planBadge.AutoSize = true;
		planBadge.Font = new Font("Segoe UI Semibold", 10f);
		planBadge.Padding = new Padding(12, 7, 12, 7);
		planBadge.Margin = new Padding(0, 6, 0, 0);
		tableLayoutPanel2.Controls.Add(planBadge, 1, 0);
		tableLayoutPanel.Controls.Add(tableLayoutPanel2, 0, 0);
		TableLayoutPanel tableLayoutPanel3 = new TableLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			Padding = new Padding(20),
			BackColor = Color.FromArgb(17, 24, 32),
			Margin = new Padding(0, 0, 0, 14)
		};
		tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
		tableLayoutPanel3.Controls.Add(new Label
		{
			Text = "GOOGLE ACCOUNT / CUENTA DE GOOGLE",
			AutoSize = true,
			ForeColor = Color.FromArgb(177, 196, 210),
			Font = new Font("Segoe UI Semibold", 9f),
			Margin = new Padding(0, 0, 0, 7)
		}, 0, 0);
		tableLayoutPanel3.SetColumnSpan(tableLayoutPanel3.GetControlFromPosition(0, 0), 2);
		email.Dock = DockStyle.Fill;
		email.Font = new Font("Segoe UI", 11f);
		email.BackColor = Color.FromArgb(10, 16, 22);
		email.ForeColor = Color.White;
		email.BorderStyle = BorderStyle.FixedSingle;
		email.Margin = new Padding(0, 0, 10, 0);
		email.AccessibleName = "Email address";
		googleButton = CreateButton("Sign in with Google", GoogleSignIn, primary: true);
		tableLayoutPanel3.Controls.Add(googleButton, 0, 1);
		signOutButton = CreateButton("Sign out", GoogleSignOut, primary: false);
		signOutButton.Enabled = false;
		tableLayoutPanel3.Controls.Add(signOutButton, 1, 1);
		feedback.AutoSize = true;
		feedback.MaximumSize = new Size(650, 0);
		feedback.ForeColor = Color.FromArgb(153, 181, 202);
		feedback.Margin = new Padding(0, 10, 0, 0);
		feedback.Text = "Your browser will open Google. This connects your account, not your gaming sessions or license. / Google se abrirá en tu navegador.";
		tableLayoutPanel3.Controls.Add(feedback, 0, 2);
		tableLayoutPanel3.SetColumnSpan(feedback, 2);
		tableLayoutPanel.Controls.Add(tableLayoutPanel3, 0, 1);
		TableLayoutPanel tableLayoutPanel4 = new TableLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			Margin = new Padding(0, 0, 0, 14)
		};
		tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
		tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
		tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.34f));
		tableLayoutPanel4.Controls.Add(Feature("FREE", "2 profiles", "2 simultaneous sessions"), 0, 0);
		tableLayoutPanel4.Controls.Add(Feature("PRO", "Unlimited profiles", "Practical capacity depends on the PC and service"), 1, 0);
		tableLayoutPanel4.Controls.Add(Feature("PRO TOOLS", "Layouts and themes", "Folders, group launch and customization"), 2, 0);
		tableLayoutPanel.Controls.Add(tableLayoutPanel4, 0, 2);
		TableLayoutPanel tableLayoutPanel5 = new TableLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			Padding = new Padding(20),
			BackColor = Color.FromArgb(29, 28, 19)
		};
		tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
		FlowLayoutPanel flowLayoutPanel2 = new FlowLayoutPanel
		{
			AutoSize = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false
		};
		flowLayoutPanel2.Controls.Add(new Label
		{
			Text = "PRO MEMBERSHIPS",
			AutoSize = true,
			ForeColor = Color.FromArgb(255, 211, 109),
			Font = new Font("Segoe UI Semibold", 13f)
		});
		flowLayoutPanel2.Controls.Add(new Label
		{
			Text = "USD 5 / month · USD 20 / 6 months · USD 30 / year\nManage subscriptions with your Google account.",
			AutoSize = true,
			MaximumSize = new Size(430, 0),
			ForeColor = Color.FromArgb(192, 190, 165),
			Margin = new Padding(0, 5, 0, 0)
		});
		tableLayoutPanel5.Controls.Add(flowLayoutPanel2, 0, 0);
		Button control = CreateButton("Memberships", OpenMemberships, primary: false);
		tableLayoutPanel5.Controls.Add(control, 1, 0);
		Label control2 = new Label
		{
			AutoSize = true,
			MaximumSize = new Size(650, 0),
			ForeColor = Color.FromArgb(192, 190, 165),
			Margin = new Padding(0, 14, 0, 0),
			Text = "Existing lifetime licenses remain valid. You can continue using your activation code."
		};
		tableLayoutPanel5.Controls.Add(control2, 0, 1);
		tableLayoutPanel5.SetColumnSpan(control2, 2);
		tableLayoutPanel.Controls.Add(tableLayoutPanel5, 0, 3);
		FlowLayoutPanel flowLayoutPanel3 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.RightToLeft,
			Padding = new Padding(0, 14, 0, 0)
		};
		flowLayoutPanel3.Controls.Add(CreateButton("Close", delegate
		{
			Close();
		}, primary: false));
		flowLayoutPanel3.Controls.Add(CreateButton("Use activation code", ActivateExistingCode, primary: false));
		flowLayoutPanel3.Controls.Add(CreateButton("Refresh access / Actualizar", async delegate
		{
			await RefreshAccountAccess();
		}, primary: false));
		adminButton = CreateButton("Admin", OpenAdmin, primary: false);
		adminButton.Visible = false;
		flowLayoutPanel3.Controls.Add(adminButton);
		tableLayoutPanel.Controls.Add(flowLayoutPanel3, 0, 4);
	}

	private static Control Feature(string label, string title, string detail)
	{
		return new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Padding = new Padding(16),
			Margin = new Padding(0, 0, 10, 0),
			BackColor = Color.FromArgb(17, 24, 32),
			Controls = 
			{
				(Control)new Label
				{
					Text = label,
					AutoSize = true,
					ForeColor = Color.FromArgb(145, 166, 182),
					Font = new Font("Segoe UI Semibold", 8.5f)
				},
				(Control)new Label
				{
					Text = title,
					AutoSize = true,
					ForeColor = Color.White,
					Font = new Font("Segoe UI Semibold", 12f),
					Margin = new Padding(0, 8, 0, 2)
				},
				(Control)new Label
				{
					Text = detail,
					AutoSize = true,
					MaximumSize = new Size(190, 0),
					ForeColor = Color.FromArgb(153, 173, 188)
				}
			}
		};
	}

	private static Button CreateButton(string text, EventHandler action, bool primary)
	{
		Button button = new Button();
		button.Text = text;
		button.AutoSize = true;
		button.FlatStyle = FlatStyle.Flat;
		button.Padding = new Padding(12, 7, 12, 7);
		button.BackColor = (primary ? Color.FromArgb(220, 239, 252) : Color.FromArgb(35, 44, 54));
		button.ForeColor = (primary ? Color.FromArgb(7, 19, 29) : Color.White);
		button.Margin = new Padding(8, 0, 0, 0);
		button.FlatAppearance.BorderColor = (primary ? Color.FromArgb(220, 239, 252) : Color.FromArgb(72, 88, 102));
		button.Click += action;
		return button;
	}

	private void RefreshPlan()
	{
		bool flag = access.Tier == AccessTier.Pro;
		Label label = planBadge;
		string text;
		if (access.AccessName.Contains("OG"))
		{
			text = "PRO · OG";
		}
		else
		{
			text = (flag ? "PRO" : "FREE");
		}
		label.Text = text;
		planBadge.BackColor = (flag ? Color.FromArgb(74, 57, 22) : Color.FromArgb(38, 52, 64));
		planBadge.ForeColor = (flag ? Color.FromArgb(255, 211, 109) : Color.FromArgb(206, 222, 233));
	}

	private void ShowAccount(string verifiedEmail, bool admin = false)
	{
		verifiedAccountEmail = verifiedEmail;
		feedback.ForeColor = Color.FromArgb(153, 220, 180);
		feedback.Text = "Signed in / Sesión iniciada: " + verifiedEmail + "\nYour existing license is unchanged.";
		signOutButton.Enabled = true;
		adminButton.Visible = admin;
	}

	private async void OpenAdmin(object sender, EventArgs args)
	{
		adminButton.Enabled = false;
		try
		{
			await GoogleAccountLogin.OpenAdmin(loginCancellation.Token);
		}
		catch
		{
			if (!IsDisposed)
			{
				feedback.Text = "Admin unavailable. Verify your account and permissions. / Admin no disponible.";
			}
		}
		finally
		{
			if (!IsDisposed)
			{
				adminButton.Enabled = true;
			}
		}
	}

	private async Task RefreshAccountAccess()
	{
		try
		{
			GoogleAccountLogin.Reply reply = await GoogleAccountLogin.RefreshAccess(loginCancellation.Token);
			if (!IsDisposed)
			{
				access = AccessPolicy.ForCurrentUser();
				AccessChanged = true;
				RefreshPlan();
				if (reply != null)
				{
					feedback.Text = "Account / Cuenta: " + verifiedAccountEmail + "\n" + access.AccessName + "\n" + ((reply.AccessMode == "test") ? ("TEST — " + reply.AccessSource + ". No Pro activation / Sin activar Pro.") : "Online access verified / Acceso online verificado") + ((reply.AccessUntil.HasValue && reply.AccessPro) ? ("\nExpires / Vence: " + DateTimeOffset.FromUnixTimeSeconds(reply.AccessUntil.Value).ToLocalTime().ToString("g")) : "");
				}
			}
		}
		catch
		{
			if (!IsDisposed)
			{
				access = AccessPolicy.ForCurrentUser();
				AccessChanged = true;
				RefreshPlan();
				feedback.Text = "Could not verify online access. Existing activation codes are unchanged. / No se pudo verificar el acceso online.";
			}
		}
	}

	private async void GoogleSignIn(object sender, EventArgs args)
	{
		googleButton.Enabled = false;
		signOutButton.Enabled = false;
		feedback.Text = "Complete sign-in in your browser. / Completa el acceso en tu navegador.";
		try
		{
			GoogleAccountLogin.Reply reply = await GoogleAccountLogin.SignIn(loginCancellation.Token);
			if (!IsDisposed)
			{
				ShowAccount(reply.Email);
			}
			GoogleAccountLogin.Reply reply2 = await GoogleAccountLogin.Current(loginCancellation.Token);
			if (!IsDisposed && reply2 != null)
			{
				ShowAccount(reply2.Email, reply2.Admin);
				await RefreshAccountAccess();
			}
		}
		catch (OperationCanceledException)
		{
			if (!IsDisposed)
			{
				feedback.Text = "Sign-in canceled or timed out. / Acceso cancelado o tiempo agotado.";
			}
		}
		catch (Exception ex2)
		{
			if (!IsDisposed)
			{
				feedback.ForeColor = Color.FromArgb(255, 211, 109);
				feedback.Text = ((ex2 is InvalidOperationException) ? ex2.Message : "Unable to sign in. Check your connection and try again. / No se pudo iniciar sesión.");
			}
		}
		finally
		{
			if (!IsDisposed)
			{
				googleButton.Enabled = true;
			}
		}
	}

	private async void GoogleSignOut(object sender, EventArgs args)
	{
		adminButton.Visible = false;
		googleButton.Enabled = false;
		signOutButton.Enabled = false;
		try
		{
			await GoogleAccountLogin.SignOut(loginCancellation.Token);
			if (!IsDisposed)
			{
				feedback.Text = "Signed out. Your profiles and existing license are unchanged. / Sesión cerrada.";
			}
		}
		catch
		{
			if (!IsDisposed)
			{
				feedback.Text = "Signed out locally; server revocation could not be confirmed. / Sesión local cerrada.";
			}
		}
		finally
		{
			if (!IsDisposed)
			{
				googleButton.Enabled = true;
				access = AccessPolicy.ForCurrentUser();
				AccessChanged = true;
				RefreshPlan();
			}
		}
	}

	private void RequestSignIn(object sender, EventArgs args)
	{
		string text = AccountAccess.NormalizeEmail(email.Text);
		if (text.Length == 0)
		{
			feedback.ForeColor = Color.FromArgb(255, 145, 145);
			feedback.Text = "Enter a valid email address.";
		}
		else
		{
			feedback.ForeColor = Color.FromArgb(255, 211, 109);
			feedback.Text = (AccountAccess.AccountServiceConfigured ? "Check your email to continue signing in." : ("The secure account server is not connected yet. No access was changed for " + text + "."));
		}
	}

	private async void OpenMemberships(object sender, EventArgs args)
	{
		try
		{
			using (MembershipForm membershipForm = new MembershipForm(Icon))
			{
				membershipForm.ShowDialog(this);
			}
			await RefreshAccountAccess();
		}
		catch
		{
			if (!IsDisposed)
			{
				feedback.Text = "Sign in with Google to manage memberships. / Inicia sesión con Google para gestionar membresías.";
			}
		}
	}

	private void ActivateExistingCode(object sender, EventArgs args)
	{
		using (ActivationForm activationForm = new ActivationForm())
		{
			if (activationForm.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
		}
		access = AccessPolicy.ForCurrentUser();
		AccessChanged = true;
		RefreshPlan();
		feedback.ForeColor = Color.FromArgb(112, 231, 165);
		feedback.Text = "Pro activation verified on this Windows account.";
	}
}
