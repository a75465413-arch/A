using System;

namespace KanblazCloudShell;

internal sealed class Profile
{
	internal Guid StorageKey { get; set; }

	internal Guid BrowserKey { get; set; }

	internal string BrowserStore { get; set; }

	internal string ServiceId { get; set; }

	internal string Label { get; set; }

	internal string UrlOverride { get; set; }

	internal string LaunchContext { get; set; }

	internal Guid GroupId { get; set; }

	internal CloudService Service => CloudService.FromId(ServiceId) ?? CloudService.Xbox;

	internal string LaunchUrl
	{
		get
		{
			if (!string.IsNullOrWhiteSpace(UrlOverride))
			{
				return UrlOverride;
			}
			return Service.LaunchUrl;
		}
	}

	public override string ToString()
	{
		return $"{Label}  ·  {Service.Name}";
	}
}
