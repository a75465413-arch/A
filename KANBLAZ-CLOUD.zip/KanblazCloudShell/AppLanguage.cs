namespace KanblazCloudShell;

internal enum AppLanguage
{
	English,
	Spanish,
	System
}
