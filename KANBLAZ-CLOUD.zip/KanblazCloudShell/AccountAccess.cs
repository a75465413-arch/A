using System;
using System.Net.Mail;

namespace KanblazCloudShell;

internal static class AccountAccess
{
	internal const string PricingUrl = "https://kanblaz-cloud.kanblaz.chatgpt.site/#pricing";

	internal static bool AccountServiceConfigured => false;

	internal static string NormalizeEmail(string value)
	{
		string text = (value ?? string.Empty).Trim();
		if (text.Length == 0 || text.Length > 254 || text.IndexOfAny(new char[3] { '\r', '\n', '\t' }) >= 0)
		{
			return string.Empty;
		}
		try
		{
			MailAddress mailAddress = new MailAddress(text);
			return string.Equals(mailAddress.Address, text, StringComparison.OrdinalIgnoreCase) ? mailAddress.Address.ToLowerInvariant() : string.Empty;
		}
		catch (FormatException)
		{
			return string.Empty;
		}
	}
}
