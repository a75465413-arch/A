using System;
using System.IO;

namespace KanblazCloudShell;

internal sealed class ThemePreferences
{
	private readonly string path;

	internal ThemePreferences(string path)
	{
		this.path = Path.GetFullPath(path);
	}

	internal static ThemePreferences ForCurrentUser()
	{
		return new ThemePreferences(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "color-theme.txt"));
	}

	internal AppThemeKind Load()
	{
		try
		{
			if (!File.Exists(path) || new FileInfo(path).Length > 64)
			{
				return AppThemeKind.Obsidian;
			}
			AppThemeKind result;
			return (Enum.TryParse<AppThemeKind>(File.ReadAllText(path).Trim(), ignoreCase: true, out result) && result == AppThemeKind.Ice) ? AppThemeKind.Ice : AppThemeKind.Obsidian;
		}
		catch
		{
			return AppThemeKind.Obsidian;
		}
	}

	internal void Save(AppThemeKind value)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		File.WriteAllText(path, value.ToString());
	}
}
