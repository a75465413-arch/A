using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Xml;

namespace KanblazCloudShell;

internal sealed class FolderReferences
{
	[DataContract]
	internal sealed class Entry
	{
		[DataMember]
		public Guid Profile;

		[DataMember]
		public Guid Game;

		[DataMember]
		public List<Guid> Folders = new List<Guid>();
	}

	[DataContract]
	private sealed class State
	{
		[DataMember]
		public int Version = 1;

		[DataMember]
		public List<Entry> Entries = new List<Entry>();

		[DataMember]
		public Guid LastGame;

		[DataMember]
		public Guid? LastFolder;
	}

	private readonly string path;

	private State state = new State();

	internal bool Writable { get; private set; } = true;

	internal Guid LastGame => state.LastGame;

	internal Guid? LastFolder => state.LastFolder;

	internal FolderReferences(string path)
	{
		this.path = path;
		try
		{
			if (File.Exists(path))
			{
				if (new FileInfo(path).Length > 4194304)
				{
					throw new InvalidDataException();
				}
				using (FileStream stream = File.OpenRead(path))
				{
					state = (State)new DataContractJsonSerializer(typeof(State)).ReadObject(stream);
				}
				if (state == null || state.Version != 1 || state.Entries == null || state.Entries.Any((Entry e) => e == null || e.Profile == Guid.Empty || e.Game == Guid.Empty || e.Folders == null) || (from e in state.Entries
					group e by Tuple.Create(e.Profile, e.Game)).Any((IGrouping<Tuple<Guid, Guid>, Entry> g) => g.Count() > 1))
				{
					throw new InvalidDataException();
				}
			}
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is SerializationException || ex is XmlException)
		{
			state = new State();
			Writable = false;
		}
	}

	internal bool Has(Guid profile, Guid game)
	{
		return state.Entries.Any((Entry e) => e.Profile == profile && e.Game == game);
	}

	internal Guid[] Folders(Guid profile, Guid game, Guid? original, IEnumerable<Guid> validFolders)
	{
		Entry entry = state.Entries.FirstOrDefault((Entry e) => e.Profile == profile && e.Game == game);
		HashSet<Guid> hashSet = new HashSet<Guid>(validFolders);
		hashSet.Add(Guid.Empty);
		Guid[] array;
		if (entry != null)
		{
			array = entry.Folders.ToArray();
		}
		else
		{
			array = ((!original.HasValue) ? new Guid[0] : new Guid[1] { original.Value });
		}
		Guid[] array2 = array.Where(hashSet.Contains).Distinct().ToArray();
		if (array2.Length != 0 || array.Length == 0)
		{
			return array2;
		}
		return new Guid[1] { Guid.Empty };
	}

	internal void Set(IEnumerable<Entry> entries)
	{
		State state = Clone();
		foreach (Entry e in entries)
		{
			if (e.Profile == Guid.Empty || e.Game == Guid.Empty)
			{
				throw new ArgumentException("Invalid profile reference.");
			}
			state.Entries.RemoveAll((Entry v) => v.Profile == e.Profile && v.Game == e.Game);
			state.Entries.Add(new Entry
			{
				Profile = e.Profile,
				Game = e.Game,
				Folders = e.Folders.Distinct().ToList()
			});
		}
		Commit(state);
	}

	internal void Remember(Guid game, Guid? folder)
	{
		State state = Clone();
		state.LastGame = game;
		state.LastFolder = folder;
		Commit(state);
	}

	private State Clone()
	{
		return new State
		{
			LastGame = state.LastGame,
			LastFolder = state.LastFolder,
			Entries = state.Entries.Select((Entry e) => new Entry
			{
				Profile = e.Profile,
				Game = e.Game,
				Folders = e.Folders.ToList()
			}).ToList()
		};
	}

	private void Commit(State next)
	{
		if (!Writable)
		{
			throw new IOException("Folder metadata could not be read; original file preserved.");
		}
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string sourceFileName = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			using (FileStream fileStream = new FileStream(sourceFileName, FileMode.CreateNew, FileAccess.Write, FileShare.None))
			{
				new DataContractJsonSerializer(typeof(State)).WriteObject(fileStream, next);
				fileStream.Flush(flushToDisk: true);
			}
			if (File.Exists(path))
			{
				File.Replace(sourceFileName, path, path + ".bak", ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(sourceFileName, path);
			}
			state = next;
		}
		finally
		{
			if (File.Exists(sourceFileName))
			{
				File.Delete(sourceFileName);
			}
		}
	}
}
