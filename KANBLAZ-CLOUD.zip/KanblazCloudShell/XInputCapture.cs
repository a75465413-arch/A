using System;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal sealed class XInputCapture
{
	internal struct Pad
	{
		internal ushort Buttons;

		internal byte LeftTrigger;

		internal byte RightTrigger;

		internal short LX;

		internal short LY;

		internal short RX;

		internal short RY;
	}

	internal struct State
	{
		internal uint Packet;

		internal Pad Gamepad;
	}

	internal delegate uint Reader(uint index, out State state);

	private Reader reader;

	[DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")]
	[DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
	private static extern uint Read14(uint index, out State state);

	[DllImport("xinput9_1_0.dll", EntryPoint = "XInputGetState")]
	[DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
	private static extern uint Read910(uint index, out State state);

	internal XInputCapture(Reader reader = null)
	{
		this.reader = reader ?? new Reader(Read14);
	}

	internal static double Axis(short value)
	{
		if (value >= 0)
		{
			return (double)value / 32767.0;
		}
		return (double)value / 32768.0;
	}

	internal static double[] Axes(Pad pad)
	{
		return new double[4]
		{
			Axis(pad.LX),
			0.0 - Axis(pad.LY),
			Axis(pad.RX),
			0.0 - Axis(pad.RY)
		};
	}

	internal static double[] Buttons(Pad pad)
	{
		double[] array = new int[17]
		{
			4096, 8192, 16384, 32768, 256, 512, 0, 0, 32, 16,
			64, 128, 1, 2, 4, 8, 0
		}.Select((int mask) => ((pad.Buttons & mask) == 0) ? 0.0 : 1.0).ToArray();
		array[6] = (double)(int)pad.LeftTrigger / 255.0;
		array[7] = (double)(int)pad.RightTrigger / 255.0;
		return array;
	}

	private static string Numbers(double[] values)
	{
		return "[" + string.Join(",", values.Select((double value) => value.ToString("R", CultureInfo.InvariantCulture))) + "]";
	}

	internal string ReadJson()
	{
		if (reader == null)
		{
			return "null";
		}
		string[] array = new string[4];
		for (uint num = 0u; num < 4; num++)
		{
			uint num2;
			State state;
			try
			{
				num2 = reader(num, out state);
			}
			catch (DllNotFoundException)
			{
				return Fallback();
			}
			catch (EntryPointNotFoundException)
			{
				return Fallback();
			}
			array[num] = ((num2 == 0) ? ("{\"axes\":" + Numbers(Axes(state.Gamepad)) + ",\"buttons\":" + Numbers(Buttons(state.Gamepad)) + "}") : "null");
		}
		return "[" + string.Join(",", array) + "]";
	}

	private string Fallback()
	{
		if (reader == new Reader(Read910))
		{
			reader = null;
			return "null";
		}
		reader = Read910;
		return ReadJson();
	}
}
