using System;
using System.IO;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal static class BrowserProfileDeletion
{
	internal static async Task DeleteAsync(string productRoot, string folder, string expectedParent, Guid browserKey, Action<string> deleteDirectory = null, Func<int, Task> delay = null)
	{
		productRoot = Path.GetFullPath(productRoot).TrimEnd(Path.DirectorySeparatorChar);
		folder = Path.GetFullPath(folder);
		expectedParent = Path.GetFullPath(expectedParent);
		if (browserKey == Guid.Empty || !folder.StartsWith(productRoot + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || !string.Equals(Path.GetDirectoryName(folder), expectedParent, StringComparison.OrdinalIgnoreCase) || Path.GetFileName(folder) != browserKey.ToString("N"))
		{
			throw new InvalidDataException("The profile folder is invalid.");
		}
		Action<string> remove = deleteDirectory ?? ((Action<string>)((string path) =>
		{
			Directory.Delete(path, recursive: true);
		}));
		Func<int, Task> wait = delay ?? ((Func<int, Task>)((int milliseconds) => Task.Delay(milliseconds)));
		for (int attempt = 0; attempt < 8; attempt++)
		{
			try
			{
				await Task.Run(() =>
				{
					if (!IsMissing(folder))
					{
						RejectRedirectedDirectories(productRoot, folder);
						remove(folder);
						if (!IsMissing(folder))
						{
							throw new IOException("The folder is still in use.", -2147024751);
						}
					}
				}).ConfigureAwait(continueOnCapturedContext: false);
				break;
			}
			catch (IOException ex) when (IsTransient(ex))
			{
				if (IsMissing(folder))
				{
					break;
				}
				if (attempt == 7)
				{
					throw new IOException("WebView2 has not released the profile folder yet. Close other windows or versions using it and try again.", ex);
				}
				await wait(150 * (attempt + 1)).ConfigureAwait(continueOnCapturedContext: false);
			}
		}
	}

	private static bool IsMissing(string path)
	{
		try
		{
			File.GetAttributes(path);
			return false;
		}
		catch (FileNotFoundException)
		{
			return true;
		}
		catch (DirectoryNotFoundException)
		{
			return true;
		}
	}

	private static bool IsTransient(IOException error)
	{
		int num = error.HResult & 0xFFFF;
		if (!(error is FileNotFoundException) && !(error is DirectoryNotFoundException) && num != 32 && num != 33)
		{
			return num == 145;
		}
		return true;
	}

	private static void RejectRedirectedDirectories(string productRoot, string folder)
	{
		string text = folder;
		while (true)
		{
			FileAttributes attributes = File.GetAttributes(text);
			if ((attributes & FileAttributes.ReparsePoint) != 0 || (attributes & FileAttributes.Directory) == 0)
			{
				throw new InvalidDataException("Cannot delete a profile whose folder or location is a link.");
			}
			if (!string.Equals(text, productRoot, StringComparison.OrdinalIgnoreCase))
			{
				text = Path.GetDirectoryName(text);
				continue;
			}
			break;
		}
	}
}
