using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace KanblazCloudShell;

internal sealed class ProfileRepository
{
	[DataContract]
	private sealed class ProfileCatalog
	{
		[DataMember]
		public int Version = 2;

		[DataMember]
		public List<StoredProfile> Profiles = new List<StoredProfile>();

		[DataMember]
		public List<string> Imported = new List<string>();

		[DataMember]
		public List<StoredGroup> Groups = new List<StoredGroup>();
	}

	[DataContract]
	private sealed class StoredProfile
	{
		[DataMember]
		public Guid Id;

		[DataMember]
		public Guid BrowserKey;

		[DataMember]
		public string Store;

		[DataMember]
		public string Service;

		[DataMember]
		public string Label;

		[DataMember]
		public string Url;

		[DataMember]
		public Guid GroupId;

		[DataMember]
		public bool Pending;
	}

	[DataContract]
	private sealed class StoredGroup
	{
		[DataMember]
		public Guid Id;

		[DataMember]
		public string Name;
	}

	private readonly string productRoot;

	private ProfileCatalog catalog;

	private bool recoveringCatalog;

	private static readonly string[] LegacyStores = new string[4] { "audio-test", "v2", "mosaic", "prototype" };

	internal string RegistryPath => Path.Combine(productRoot, "Cloud Shell", "profiles.json");

	internal string BackupPath => RegistryPath + ".bak";

	internal bool RecoveredBackup { get; private set; }

	internal List<Profile> PendingProfiles
	{
		get
		{
			LoadProfiles();
			return catalog.Profiles.Where((StoredProfile p) => p.Pending).Select(ToProfile).ToList();
		}
	}

	internal ProfileRepository(string productRoot)
	{
		this.productRoot = Path.GetFullPath(productRoot);
	}

	internal static string StoreFolder(string store)
	{
		return (store ?? "current") switch
		{
			"current" => "Cloud Shell", 
			"audio-test" => "Cloud Shell Audio Test", 
			"v2" => "Cloud Shell V2", 
			"mosaic" => "Cloud Shell Mosaic Host Test", 
			"prototype" => "Cloud Shell Prototype", 
			_ => throw new InvalidDataException("Unrecognized profile source."), 
		};
	}

	internal string BrowserDataFolder(Profile profile)
	{
		if (profile == null || profile.StorageKey == Guid.Empty)
		{
			throw new InvalidDataException("Profile has no valid identity.");
		}
		Guid guid = ((profile.BrowserKey == Guid.Empty) ? profile.StorageKey : profile.BrowserKey);
		return Path.Combine(productRoot, StoreFolder(profile.BrowserStore), "browser-data", guid.ToString("N"));
	}

	internal List<Profile> LoadProfiles()
	{
		if (catalog == null)
		{
			catalog = LoadCatalog();
			ImportLegacyMetadata();
		}
		return catalog.Profiles.Where((StoredProfile p) => !p.Pending).Select(ToProfile).ToList();
	}

	internal List<ProfileGroup> LoadGroups()
	{
		LoadProfiles();
		return catalog.Groups.Select((StoredGroup group) => new ProfileGroup
		{
			Id = group.Id,
			Name = group.Name
		}).ToList();
	}

	private ProfileCatalog LoadCatalog()
	{
		if (!File.Exists(RegistryPath) && !File.Exists(BackupPath))
		{
			return new ProfileCatalog();
		}
		try
		{
			return ReadCatalog(RegistryPath);
		}
		catch (Exception ex) when (ex is SerializationException || ex is InvalidDataException || ex is XmlException || ex is FileNotFoundException)
		{
			if (!File.Exists(BackupPath))
			{
				throw new InvalidDataException("The profile registry could not be read. The original file was preserved.", ex);
			}
			ProfileCatalog result = ReadCatalog(BackupPath);
			RecoveredBackup = true;
			recoveringCatalog = true;
			return result;
		}
	}

	private static ProfileCatalog ReadCatalog(string path)
	{
		ProfileCatalog profileCatalog;
		using (FileStream stream = File.OpenRead(path))
		{
			profileCatalog = (ProfileCatalog)new DataContractJsonSerializer(typeof(ProfileCatalog)).ReadObject(stream);
		}
		if (profileCatalog != null && profileCatalog.Version > 2)
		{
			throw new NotSupportedException("This registry requires a newer version of KANBLAZ CLOUD.");
		}
		if (profileCatalog != null && profileCatalog.Version == 1)
		{
			profileCatalog.Version = 2;
			profileCatalog.Groups = new List<StoredGroup>();
		}
		Validate(profileCatalog);
		return profileCatalog;
	}

	private static void Validate(ProfileCatalog value)
	{
		if (value == null || value.Version != 2 || value.Profiles == null || value.Imported == null || value.Groups == null || value.Profiles.Any((StoredProfile p) => p == null) || value.Groups.Any((StoredGroup group) => group == null))
		{
			throw new InvalidDataException("Invalid profile registry.");
		}
		HashSet<Guid> hashSet = new HashSet<Guid>();
		HashSet<string> hashSet2 = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		foreach (StoredGroup group in value.Groups)
		{
			string text;
			try
			{
				text = SafeGroupName(group.Name);
			}
			catch (ArgumentException innerException)
			{
				throw new InvalidDataException("Invalid profile group.", innerException);
			}
			if (group.Id == Guid.Empty || !string.Equals(group.Name, text, StringComparison.Ordinal) || !hashSet.Add(group.Id) || !hashSet2.Add(text))
			{
				throw new InvalidDataException("Invalid profile group.");
			}
		}
		HashSet<Guid> hashSet3 = new HashSet<Guid>();
		HashSet<string> hashSet4 = new HashSet<string>();
		foreach (StoredProfile profile in value.Profiles)
		{
			if (profile.Store == null || profile.Id == Guid.Empty || profile.BrowserKey == Guid.Empty || !hashSet3.Add(profile.Id) || CloudService.FromId(profile.Service) == null || (profile.GroupId != Guid.Empty && !hashSet.Contains(profile.GroupId)))
			{
				throw new InvalidDataException("Invalid saved profile.");
			}
			StoreFolder(profile.Store);
			string store = profile.Store;
			Guid browserKey = profile.BrowserKey;
			if (!hashSet4.Add(store + "/" + browserKey.ToString()))
			{
				throw new InvalidDataException("Duplicate browser profile.");
			}
		}
	}

	private void ImportLegacyMetadata()
	{
		ProfileCatalog profileCatalog = Clone(catalog);
		HashSet<string> hashSet = new HashSet<string>(profileCatalog.Imported);
		bool flag = RecoveredBackup;
		string[] legacyStores = LegacyStores;
		foreach (string text in legacyStores)
		{
			string path = Path.Combine(productRoot, StoreFolder(text), "profiles.tsv");
			if (!File.Exists(path))
			{
				continue;
			}
			string[] array = File.ReadAllLines(path);
			foreach (string obj in array)
			{
				string[] array2 = obj.Split('\t');
				if ((array2.Length != 3 && array2.Length != 4) || !Guid.TryParse(array2[0], out var originalKey) || originalKey == Guid.Empty || CloudService.FromId(array2[1]) == null)
				{
					continue;
				}
				string item = text + "/" + originalKey.ToString("N");
				if (hashSet.Add(item))
				{
					Guid id = (profileCatalog.Profiles.Any((StoredProfile p) => p.Id == originalKey) ? Guid.NewGuid() : originalKey);
					profileCatalog.Profiles.Add(new StoredProfile
					{
						Id = id,
						BrowserKey = originalKey,
						Store = text,
						Service = array2[1],
						Label = ShellStorage.SafeLabel(array2[2]),
						Url = ((array2.Length == 4) ? ShellStorage.SafeUrl(array2[3]) : ""),
						Pending = false
					});
					profileCatalog.Imported.Add(item);
					flag = true;
				}
			}
		}
		if (flag)
		{
			Commit(profileCatalog);
		}
	}

	internal void SaveProfiles(IEnumerable<Profile> profiles)
	{
		LoadProfiles();
		List<Profile> source = profiles.ToList();
		ProfileCatalog profileCatalog = Clone(catalog);
		profileCatalog.Profiles = profileCatalog.Profiles.Where((StoredProfile p) => p.Pending).Concat(source.Select((Profile p) => new StoredProfile
		{
			Id = p.StorageKey,
			BrowserKey = ((p.BrowserKey == Guid.Empty) ? p.StorageKey : p.BrowserKey),
			Store = (p.BrowserStore ?? "current"),
			Service = p.ServiceId,
			Label = ShellStorage.SafeLabel(p.Label),
			Url = ShellStorage.SafeUrl(p.UrlOverride),
			GroupId = p.GroupId,
			Pending = false
		})).ToList();
		Commit(profileCatalog);
	}

	internal ProfileGroup CreateGroup(string name)
	{
		LoadProfiles();
		string safe = SafeGroupName(name);
		if (catalog.Groups.Any((StoredGroup group) => string.Equals(group.Name, safe, StringComparison.OrdinalIgnoreCase)))
		{
			throw new InvalidOperationException("A group with that name already exists.");
		}
		ProfileCatalog profileCatalog = Clone(catalog);
		StoredGroup storedGroup = new StoredGroup
		{
			Id = Guid.NewGuid(),
			Name = safe
		};
		profileCatalog.Groups.Add(storedGroup);
		Commit(profileCatalog);
		return new ProfileGroup
		{
			Id = storedGroup.Id,
			Name = storedGroup.Name
		};
	}

	internal void RenameGroup(Guid id, string name)
	{
		LoadProfiles();
		string safe = SafeGroupName(name);
		if (catalog.Groups.Any((StoredGroup group) => group.Id != id && string.Equals(group.Name, safe, StringComparison.OrdinalIgnoreCase)))
		{
			throw new InvalidOperationException("A group with that name already exists.");
		}
		ProfileCatalog profileCatalog = Clone(catalog);
		(profileCatalog.Groups.SingleOrDefault((StoredGroup value) => value.Id == id) ?? throw new InvalidOperationException("That group no longer exists.")).Name = safe;
		Commit(profileCatalog);
	}

	internal void DeleteGroup(Guid id)
	{
		LoadProfiles();
		ProfileCatalog profileCatalog = Clone(catalog);
		if (profileCatalog.Groups.RemoveAll((StoredGroup group) => group.Id == id) == 0)
		{
			throw new InvalidOperationException("That group no longer exists.");
		}
		foreach (StoredProfile item in profileCatalog.Profiles.Where((StoredProfile profile) => profile.GroupId == id))
		{
			item.GroupId = Guid.Empty;
		}
		Commit(profileCatalog);
	}

	internal static string SafeGroupName(string value)
	{
		string text = (value ?? string.Empty).Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ')
			.Trim();
		if (text.Length == 0)
		{
			throw new ArgumentException("Enter a group name.");
		}
		if (text.Length > 60)
		{
			text = text.Substring(0, 60).Trim();
		}
		if (text.Length == 0 || text.Any(char.IsControl))
		{
			throw new ArgumentException("Enter a valid group name.");
		}
		return text;
	}

	internal void RestoreProfiles(IEnumerable<Guid> ids)
	{
		LoadProfiles();
		HashSet<Guid> requested = new HashSet<Guid>(ids);
		ProfileCatalog profileCatalog = Clone(catalog);
		foreach (StoredProfile item in profileCatalog.Profiles.Where((StoredProfile p) => p.Pending && requested.Contains(p.Id)).ToList())
		{
			item.Pending = false;
		}
		Commit(profileCatalog);
	}

	internal void ArchiveProfile(Guid id)
	{
		LoadProfiles();
		ProfileCatalog profileCatalog = Clone(catalog);
		profileCatalog.Profiles.Single((StoredProfile p) => p.Id == id).Pending = true;
		Commit(profileCatalog);
	}

	internal void RemoveSavedProfile(Guid id)
	{
		RemoveSavedProfileAsync(id).GetAwaiter().GetResult();
	}

	internal Task RemoveSavedProfileAsync(Guid id)
	{
		return RemoveProfileAsync(id, pending: true);
	}

	internal Task RemoveActiveProfileAsync(Guid id)
	{
		return RemoveProfileAsync(id, pending: false);
	}

	private async Task RemoveProfileAsync(Guid id, bool pending)
	{
		LoadProfiles();
		StoredProfile storedProfile = catalog.Profiles.SingleOrDefault((StoredProfile p) => p.Id == id && p.Pending == pending);
		if (storedProfile == null)
		{
			throw new InvalidOperationException("That profile is no longer in the selected list.");
		}
		string fullPath = Path.GetFullPath(BrowserDataFolder(ToProfile(storedProfile)));
		string fullPath2 = Path.GetFullPath(Path.Combine(productRoot, StoreFolder(storedProfile.Store), "browser-data"));
		await BrowserProfileDeletion.DeleteAsync(productRoot, fullPath, fullPath2, storedProfile.BrowserKey);
		ProfileCatalog profileCatalog = Clone(catalog);
		profileCatalog.Profiles.RemoveAll((StoredProfile p) => p.Id == id);
		Commit(profileCatalog);
	}

	private void Commit(ProfileCatalog next)
	{
		Validate(next);
		string directoryName = Path.GetDirectoryName(RegistryPath);
		Directory.CreateDirectory(directoryName);
		string text = Path.Combine(directoryName, "profiles-" + Guid.NewGuid().ToString("N") + ".tmp");
		try
		{
			using (FileStream fileStream = new FileStream(text, FileMode.CreateNew, FileAccess.Write, FileShare.None))
			{
				new DataContractJsonSerializer(typeof(ProfileCatalog)).WriteObject(fileStream, next);
				fileStream.Flush(flushToDisk: true);
			}
			if (File.Exists(RegistryPath))
			{
				File.Replace(text, RegistryPath, recoveringCatalog ? (RegistryPath + ".corrupt-" + Guid.NewGuid().ToString("N")) : BackupPath, ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(text, RegistryPath);
			}
			catalog = next;
			recoveringCatalog = false;
		}
		finally
		{
			if (File.Exists(text))
			{
				File.Delete(text);
			}
		}
	}

	private static Profile ToProfile(StoredProfile p)
	{
		string text = p.Label;
		if (text != null && Regex.IsMatch(text, "\\APerfil [0-9]+\\z"))
		{
			text = "Profile " + text.Substring("Perfil ".Length);
		}
		return new Profile
		{
			StorageKey = p.Id,
			BrowserKey = p.BrowserKey,
			BrowserStore = p.Store,
			ServiceId = p.Service,
			Label = text,
			UrlOverride = p.Url,
			GroupId = p.GroupId
		};
	}

	private static ProfileCatalog Clone(ProfileCatalog value)
	{
		return new ProfileCatalog
		{
			Imported = value.Imported.ToList(),
			Groups = value.Groups.Select((StoredGroup group) => new StoredGroup
			{
				Id = group.Id,
				Name = group.Name
			}).ToList(),
			Profiles = value.Profiles.Select((StoredProfile p) => new StoredProfile
			{
				Id = p.Id,
				BrowserKey = p.BrowserKey,
				Store = p.Store,
				Service = p.Service,
				Label = p.Label,
				Url = p.Url,
				GroupId = p.GroupId,
				Pending = p.Pending
			}).ToList()
		};
	}
}
