using System.Drawing;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceBrandTitle : Control
{
	internal Color Accent = Color.Cyan;

	internal WorkspaceBrandTitle()
	{
		DoubleBuffered = true;
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		BackColor = Color.Transparent;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		using Font font = new Font("Segoe UI Semibold", 21f);
		Size size = TextRenderer.MeasureText("KANBLAZ ", font, Size.Empty, TextFormatFlags.NoPadding);
		TextRenderer.DrawText(e.Graphics, "KANBLAZ ", font, new Point(0, 0), ForeColor, TextFormatFlags.NoPadding);
		TextRenderer.DrawText(e.Graphics, "CLOUD", font, new Point(size.Width, 0), Accent, TextFormatFlags.NoPadding);
	}
}
