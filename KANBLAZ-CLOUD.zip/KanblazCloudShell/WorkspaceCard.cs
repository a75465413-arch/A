using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceCard : Panel
{
	internal AppTheme Palette;

	internal WorkspaceCard()
	{
		DoubleBuffered = true;
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		if (PerformanceMode.Enabled)
		{
			AppTheme appTheme = Palette ?? AppTheme.Matte(187, 70);
			e.Graphics.Clear(appTheme.Surface);
			using Pen pen = new Pen(appTheme.Border);
			using GraphicsPath path = WorkspaceDrawing.Round(new Rectangle(1, 1, Math.Max(1, Width - 3), Math.Max(1, Height - 3)), 8);
			e.Graphics.DrawPath(pen, path);
			return;
		}
		base.OnPaintBackground(e);
		if (Width < 4 || Height < 4)
		{
			return;
		}
		AppTheme appTheme2 = Palette ?? AppTheme.Matte(187, 70);
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		using GraphicsPath path2 = WorkspaceDrawing.Round(new Rectangle(4, 4, Width - 8, Height - 8), 20);
		using LinearGradientBrush brush = new LinearGradientBrush(ClientRectangle, Color.FromArgb(35, appTheme2.SurfaceRaised), Color.FromArgb(55, appTheme2.Surface), 80f);
		using Pen pen2 = new Pen(appTheme2.Border);
		e.Graphics.FillPath(brush, path2);
		if (appTheme2.Glow)
		{
			for (int num = 8; num >= 2; num -= 2)
			{
				using Pen pen3 = new Pen(Color.FromArgb(Math.Max(2, appTheme2.GlowAlpha / 4), appTheme2.ActiveBorder), num);
				e.Graphics.DrawPath(pen3, path2);
			}
		}
		e.Graphics.DrawPath(pen2, path2);
	}
}
