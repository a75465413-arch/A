using System;
using System.IO;

namespace KanblazCloudShell;

internal static class PerformanceMode
{
	private static readonly string SettingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "shell-performance-default-v1.txt");

	internal static bool Enabled = Load();

	private static bool Load()
	{
		try
		{
			return !File.Exists(SettingsPath) || File.ReadAllText(SettingsPath).Trim() != "0";
		}
		catch (IOException)
		{
			return true;
		}
		catch (UnauthorizedAccessException)
		{
			return true;
		}
	}

	internal static void Save(bool enabled)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath));
		File.WriteAllText(SettingsPath, enabled ? "1" : "0");
		Enabled = enabled;
	}
}
