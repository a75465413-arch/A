using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace KanblazCloudShell;

internal static class StartupTiming
{
	private static readonly Stopwatch Clock = Stopwatch.StartNew();

	private static readonly List<string> Stages = new List<string>();

	internal static void Mark(string stage)
	{
		Stages.Add(stage + "=" + Clock.ElapsedMilliseconds + " ms");
	}

	internal static void Save()
	{
		try
		{
			File.WriteAllLines(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "startup-timing.txt"), Stages);
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
	}
}
