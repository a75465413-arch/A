using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceComboBox : ComboBox
{
	internal AppTheme Palette;

	internal WorkspaceComboBox()
	{
		DropDownStyle = ComboBoxStyle.DropDownList;
		DrawMode = DrawMode.OwnerDrawFixed;
		ItemHeight = 26;
		FlatStyle = FlatStyle.Flat;
	}

	protected override void OnSelectedIndexChanged(EventArgs e)
	{
		base.OnSelectedIndexChanged(e);
		Invalidate();
	}

	protected override void OnDrawItem(DrawItemEventArgs e)
	{
		if (e.Index >= 0)
		{
			AppTheme appTheme = Palette ?? AppTheme.Matte(187, 70);
			using (SolidBrush brush = new SolidBrush(((e.State & DrawItemState.Selected) != 0) ? appTheme.Selection : appTheme.Surface))
			{
				e.Graphics.FillRectangle(brush, e.Bounds);
			}
			TextRenderer.DrawText(e.Graphics, GetItemText(Items[e.Index]), Font, new Rectangle(e.Bounds.X + 10, e.Bounds.Y, e.Bounds.Width - 16, e.Bounds.Height), ForeColor, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
			e.DrawFocusRectangle();
		}
	}

	protected override void WndProc(ref Message m)
	{
		base.WndProc(ref m);
		if (Width < 4 || Height < 4)
		{
			return;
		}
		if (m.Msg == 15)
		{
			using (Graphics graphics = Graphics.FromHwnd(Handle))
			{
				DrawFace(graphics);
				return;
			}
		}
		if ((m.Msg != 791 && m.Msg != 792) || !(m.WParam != IntPtr.Zero))
		{
			return;
		}
		using Graphics graphics2 = Graphics.FromHdc(m.WParam);
		DrawFace(graphics2);
	}

	private void DrawFace(Graphics graphics)
	{
		AppTheme appTheme = Palette ?? AppTheme.Matte(187, 70);
		WorkspaceBackdrop.PaintBehind(this, graphics, ClientRectangle, 0);
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		using (GraphicsPath path = WorkspaceDrawing.Round(new Rectangle(2, 2, Width - 4, Height - 4), 12))
		{
			using LinearGradientBrush brush = new LinearGradientBrush(ClientRectangle, appTheme.SurfaceRaised, appTheme.Window, 90f);
			using Pen pen = new Pen(Focused ? appTheme.ActiveBorder : appTheme.Border);
			graphics.FillPath(brush, path);
			graphics.DrawPath(pen, path);
		}
		TextRenderer.DrawText(graphics, (SelectedIndex < 0) ? "Choose…" : GetItemText(SelectedItem), Font, new Rectangle(12, 0, Math.Max(1, Width - 40), Height), Enabled ? appTheme.Text : appTheme.Muted, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
		using Pen pen2 = new Pen(appTheme.Muted, 1.5f);
		graphics.DrawLines(pen2, new Point[3]
		{
			new Point(Width - 24, Height / 2 - 2),
			new Point(Width - 19, Height / 2 + 3),
			new Point(Width - 14, Height / 2 - 2)
		});
	}
}
