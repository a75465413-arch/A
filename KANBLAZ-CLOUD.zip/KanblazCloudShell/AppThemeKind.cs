namespace KanblazCloudShell;

internal enum AppThemeKind
{
	Obsidian,
	MidnightBlue,
	Emerald,
	Crimson,
	Violet,
	Ice,
	Holiday,
	Caramel,
	Hearts
}
