using System;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal static class NativeInputOwnership
{
	private struct Rect
	{
		internal int Left;

		internal int Top;

		internal int Right;

		internal int Bottom;
	}

	private struct GuiThreadInfo
	{
		internal int Size;

		internal int Flags;

		internal IntPtr Active;

		internal IntPtr Focus;

		internal IntPtr Capture;

		internal IntPtr MenuOwner;

		internal IntPtr MoveSize;

		internal IntPtr Caret;

		internal Rect CaretRect;
	}

	internal static IntPtr ForegroundWindow => GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern bool GetGUIThreadInfo(uint thread, ref GuiThreadInfo info);

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern bool IsChild(IntPtr parent, IntPtr child);

	[DllImport("user32.dll")]
	private static extern IntPtr GetAncestor(IntPtr window, uint flags);

	[DllImport("user32.dll")]
	private static extern IntPtr SetFocus(IntPtr window);

	[DllImport("kernel32.dll")]
	private static extern uint GetCurrentThreadId();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);

	[DllImport("user32.dll")]
	private static extern bool AttachThreadInput(uint from, uint to, bool attach);

	internal static bool FocusReleaseTarget(IntPtr target)
	{
		if (target == IntPtr.Zero || GetAncestor(target, 2u) != GetForegroundWindow())
		{
			return false;
		}
		GuiThreadInfo info = new GuiThreadInfo
		{
			Size = Marshal.SizeOf(typeof(GuiThreadInfo))
		};
		uint num = ((GetGUIThreadInfo(0u, ref info) && info.Focus != IntPtr.Zero) ? GetWindowThreadProcessId(info.Focus, out var _) : 0u);
		uint currentThreadId = GetCurrentThreadId();
		bool flag = false;
		try
		{
			if (num != 0 && num != currentThreadId)
			{
				flag = AttachThreadInput(currentThreadId, num, attach: true);
			}
			SetFocus(target);
			return OwnsKeyboard(target);
		}
		finally
		{
			if (flag)
			{
				AttachThreadInput(currentThreadId, num, attach: false);
			}
		}
	}

	internal static bool OwnsKeyboard(IntPtr window)
	{
		if (window == IntPtr.Zero || GetAncestor(window, 2u) != GetForegroundWindow())
		{
			return false;
		}
		GuiThreadInfo info = new GuiThreadInfo
		{
			Size = Marshal.SizeOf(typeof(GuiThreadInfo))
		};
		if (GetGUIThreadInfo(0u, ref info) && info.Focus != IntPtr.Zero)
		{
			if (!(info.Focus == window))
			{
				return IsChild(window, info.Focus);
			}
			return true;
		}
		return false;
	}
}
