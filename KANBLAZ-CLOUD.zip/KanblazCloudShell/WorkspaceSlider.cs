using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceSlider : TrackBar
{
	internal Color Accent = Color.Cyan;

	private bool dragging;

	private Bitmap hueRamp;

	protected override void Dispose(bool disposing)
	{
		if (disposing && hueRamp != null)
		{
			hueRamp.Dispose();
			hueRamp = null;
		}
		base.Dispose(disposing);
	}

	private void SetPointerValue(int x)
	{
		double num = Math.Max(0.0, Math.Min(1.0, ((double)x - 12.0) / (double)Math.Max(1, Width - 24)));
		Value = Minimum + (int)Math.Round(num * (double)(Maximum - Minimum));
	}

	protected override void OnValueChanged(EventArgs e)
	{
		base.OnValueChanged(e);
		Invalidate();
	}

	protected override void WndProc(ref Message m)
	{
		if (m.Msg == 513 && Enabled)
		{
			Focus();
			dragging = true;
			Capture = true;
			SetPointerValue((short)(m.LParam.ToInt64() & 0xFFFF));
			return;
		}
		if (m.Msg == 512 && dragging)
		{
			SetPointerValue((short)(m.LParam.ToInt64() & 0xFFFF));
			return;
		}
		if (m.Msg == 514 && dragging)
		{
			SetPointerValue((short)(m.LParam.ToInt64() & 0xFFFF));
			dragging = false;
			Capture = false;
			return;
		}
		if (m.Msg == 533)
		{
			dragging = false;
		}
		base.WndProc(ref m);
		if (Width < 30 || Height < 10)
		{
			return;
		}
		if (m.Msg == 15)
		{
			using (Graphics g = Graphics.FromHwnd(Handle))
			{
				DrawTrack(g);
				return;
			}
		}
		if ((m.Msg != 791 && m.Msg != 792) || !(m.WParam != IntPtr.Zero))
		{
			return;
		}
		using Graphics g2 = Graphics.FromHdc(m.WParam);
		DrawTrack(g2);
	}

	private void DrawTrack(Graphics g)
	{
		WorkspaceBackdrop.PaintBehind(this, g, ClientRectangle, 0);
		g.SmoothingMode = SmoothingMode.AntiAlias;
		int num = Width - 24;
		int num2 = Height / 2;
		using (Pen pen = new Pen(Color.FromArgb(63, 75, 87), 5f)
		{
			StartCap = LineCap.Round,
			EndCap = LineCap.Round
		})
		{
			g.DrawLine(pen, 12, num2, Width - 12, num2);
		}
		if (Convert.ToString(Tag) == "hue-slider")
		{
			if (hueRamp == null || hueRamp.Width != num)
			{
				if (hueRamp != null)
				{
					hueRamp.Dispose();
				}
				hueRamp = new Bitmap(num, 6);
				using Graphics graphics = Graphics.FromImage(hueRamp);
				for (int i = 0; i < num; i++)
				{
					using Pen pen2 = new Pen(AppTheme.Hsl((double)i * 360.0 / (double)num, 0.9, 0.6));
					graphics.DrawLine(pen2, i, 0, i, 5);
				}
			}
			g.DrawImageUnscaled(hueRamp, 12, num2 - 3);
		}
		int num3 = 12 + (int)((double)(Value - Minimum) * (double)num / (double)Math.Max(1, Maximum - Minimum));
		if (Convert.ToString(Tag) != "hue-slider")
		{
			using Pen pen3 = new Pen(Accent, 5f)
			{
				StartCap = LineCap.Round,
				EndCap = LineCap.Round
			};
			g.DrawLine(pen3, 12, num2, num3, num2);
		}
		using (SolidBrush brush = new SolidBrush(Accent))
		{
			g.FillEllipse(brush, num3 - 7, num2 - 7, 14, 14);
		}
		using Pen pen4 = new Pen(Color.FromArgb(226, 241, 247), 2f);
		g.DrawEllipse(pen4, num3 - 7, num2 - 7, 14, 14);
	}
}
