using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class KeyboardReleaseMonitor : IDisposable
{
	private struct Registration
	{
		internal ushort Page;

		internal ushort Usage;

		internal uint Flags;

		internal IntPtr Target;
	}

	private bool registered;

	[DllImport("user32.dll")]
	private static extern bool RegisterRawInputDevices(Registration[] devices, uint count, uint size);

	[DllImport("user32.dll")]
	private static extern uint GetRawInputData(IntPtr input, uint command, IntPtr data, ref uint size, uint headerSize);

	internal bool Start(IntPtr target)
	{
		return registered = RegisterRawInputDevices(new Registration[1]
		{
			new Registration
			{
				Page = 1,
				Usage = 6,
				Flags = 256u,
				Target = target
			}
		}, 1u, (uint)Marshal.SizeOf(typeof(Registration)));
	}

	internal bool IsRelease(IntPtr input, Keys key)
	{
		return IsEdge(input, key, released: true);
	}

	internal bool IsPress(IntPtr input, Keys key)
	{
		return IsEdge(input, key, released: false);
	}

	private bool IsEdge(IntPtr input, Keys key, bool released)
	{
		uint num = (uint)(8 + 2 * IntPtr.Size);
		uint size = 0u;
		if (GetRawInputData(input, 268435459u, IntPtr.Zero, ref size, num) == uint.MaxValue || size < num + 16 || size > 1024)
		{
			return false;
		}
		IntPtr intPtr = Marshal.AllocHGlobal((int)size);
		try
		{
			if (GetRawInputData(input, 268435459u, intPtr, ref size, num) != size || Marshal.ReadInt32(intPtr) != 1)
			{
				return false;
			}
			return (Marshal.ReadInt16(intPtr, (int)(num + 2)) & 1) != 0 == released && (Keys)Marshal.ReadInt16(intPtr, (int)(num + 6)) == key;
		}
		finally
		{
			Marshal.FreeHGlobal(intPtr);
		}
	}

	public void Dispose()
	{
		if (registered)
		{
			RegisterRawInputDevices(new Registration[1]
			{
				new Registration
				{
					Page = 1,
					Usage = 6,
					Flags = 1u
				}
			}, 1u, (uint)Marshal.SizeOf(typeof(Registration)));
		}
		registered = false;
	}
}
