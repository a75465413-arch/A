using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class PhysicalInputHook : IDisposable
{
	private delegate IntPtr Hook(int code, IntPtr message, IntPtr data);

	private struct Keyboard
	{
		internal uint Key;

		internal uint Scan;

		internal uint Flags;

		internal uint Time;

		internal IntPtr Extra;
	}

	private readonly Hook callback;

	private IntPtr handle;

	private readonly Func<Keys, bool, bool> edge;

	[DllImport("user32.dll", SetLastError = true)]
	private static extern IntPtr SetWindowsHookEx(int id, Hook hook, IntPtr module, uint thread);

	[DllImport("user32.dll")]
	private static extern bool UnhookWindowsHookEx(IntPtr hook);

	[DllImport("user32.dll")]
	private static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr message, IntPtr data);

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
	private static extern IntPtr GetModuleHandle(string name);

	internal PhysicalInputHook(Func<Keys, bool, bool> edge)
	{
		this.edge = edge;
		callback = Read;
	}

	internal bool Start()
	{
		handle = SetWindowsHookEx(13, callback, GetModuleHandle(null), 0u);
		return handle != IntPtr.Zero;
	}

	private IntPtr Read(int code, IntPtr message, IntPtr data)
	{
		if (code >= 0)
		{
			Keyboard keyboard = (Keyboard)Marshal.PtrToStructure(data, typeof(Keyboard));
			int num = message.ToInt32();
			if ((keyboard.Flags & 0x12) == 0 && (num == 256 || num == 260 || num == 257 || num == 261))
			{
				try
				{
					if (edge((Keys)keyboard.Key, num == 256 || num == 260))
					{
						return new IntPtr(1);
					}
				}
				catch
				{
				}
			}
		}
		return CallNextHookEx(handle, code, message, data);
	}

	public void Dispose()
	{
		if (handle != IntPtr.Zero)
		{
			UnhookWindowsHookEx(handle);
		}
		handle = IntPtr.Zero;
	}
}
