using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using KanblazLicensing;

namespace KanblazCloudShell;

internal sealed class ActivationServer : IActivationServer
{
	[DataContract]
	private sealed class RequestData
	{
		[DataMember(Name = "code")]
		public string Code;

		[DataMember(Name = "device")]
		public string Device;
	}

	[DataContract]
	private sealed class ResponseData
	{
		[DataMember(Name = "receipt")]
		public string Receipt { get; set; }
	}

	private static readonly HttpClient Client = new HttpClient(new HttpClientHandler
	{
		AllowAutoRedirect = false
	})
	{
		Timeout = TimeSpan.FromSeconds(15.0)
	};

	public async Task<string> ActivateAsync(string code, string device)
	{
		if (!ActivationServiceConfig.IsConfigured)
		{
			throw new InvalidOperationException("The two-device activation service is not configured yet. Contact Kanblaz.");
		}
		using CancellationTokenSource cancellation = new CancellationTokenSource(TimeSpan.FromSeconds(15.0));
		using MemoryStream memory = new MemoryStream();
		new DataContractJsonSerializer(typeof(RequestData)).WriteObject(memory, new RequestData
		{
			Code = code,
			Device = device
		});
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://kanblaz-licenses.kanblaz.workers.dev/v1/activate");
		request.Content = new StringContent(Encoding.UTF8.GetString(memory.ToArray()), Encoding.UTF8, "application/json");
		using HttpResponseMessage response = await Client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellation.Token).ConfigureAwait(continueOnCapturedContext: false);
		if (response.StatusCode == HttpStatusCode.Conflict)
		{
			throw new InvalidOperationException("This code is already activated on two devices. Contact Kanblaz if you need help.");
		}
		if (response.StatusCode == HttpStatusCode.Forbidden)
		{
			throw new InvalidOperationException("The server does not recognize this activation code.");
		}
		if (response.StatusCode != HttpStatusCode.OK)
		{
			throw new InvalidOperationException("The activation service is unavailable. Try again later.");
		}
		using Stream stream = await response.Content.ReadAsStreamAsync().ConfigureAwait(continueOnCapturedContext: false);
		using MemoryStream buffer = new MemoryStream();
		byte[] bytes = new byte[1024];
		int num;
		while ((num = await stream.ReadAsync(bytes, 0, bytes.Length, cancellation.Token).ConfigureAwait(continueOnCapturedContext: false)) > 0)
		{
			if (buffer.Length + num > 8192)
			{
				throw new InvalidDataException("Invalid activation response.");
			}
			buffer.Write(bytes, 0, num);
		}
		buffer.Position = 0L;
		return ((ResponseData)new DataContractJsonSerializer(typeof(ResponseData)).ReadObject(buffer))?.Receipt;
	}
}
