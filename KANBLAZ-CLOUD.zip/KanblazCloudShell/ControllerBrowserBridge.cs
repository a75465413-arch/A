using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace KanblazCloudShell;

internal sealed class ControllerBrowserBridge : IDisposable
{
	private readonly CoreWebView2 browser;

	private readonly HashSet<CoreWebView2Frame> frames = new HashSet<CoreWebView2Frame>();

	private readonly ControllerRouting routing;

	private bool shared;

	private bool owned;

	private bool disposed;

	internal ControllerBrowserBridge(CoreWebView2 browser, bool backgroundAudio)
	{
		ControllerBrowserBridge controllerBrowserBridge = this;
		this.browser = browser;
		browser.FrameCreated += FrameCreated;
		routing = new ControllerRouting((bool value) => GamepadIsolation.InstallAsync(browser, backgroundAudio, value, hostManaged: true), browser.RemoveScriptToExecuteOnDocumentCreated, (bool ignored) => controllerBrowserBridge.ApplyAllAsync());
	}

	internal Task SetSharedAsync(bool value)
	{
		shared = value;
		owned = false;
		return routing.SetAsync(value);
	}

	internal Task SetOwnedAsync(bool value)
	{
		owned = value;
		return routing.SetAsync(shared);
	}

	internal async Task SetBroadcastFrameAsync(bool selected, string pads)
	{
		if (!disposed)
		{
			shared = selected;
			owned = false;
			string script = GamepadIsolation.StateScript(selected, owned: false) + ";(() => { const set = window.__kanblazXInputV1; return typeof set === 'function' ? set(" + (selected ? pads : "null") + ") : false; })()";
			await Task.WhenAll(new Task<string>[1] { browser.ExecuteScriptAsync(script) }.Concat(from frame in frames.ToArray()
				select ApplyFrameAsync(frame, script)));
		}
	}

	internal async Task SetJoystickAsync(bool active, double x, double y)
	{
		if (disposed)
		{
			if (active)
			{
				throw new ObjectDisposedException("ControllerBrowserBridge");
			}
			return;
		}
		string script = GamepadIsolation.JoystickScript(active, x, y);
		Task<string> root = browser.ExecuteScriptAsync(script);
		await Task.WhenAll(new Task<string>[1] { root }.Concat(from frame in frames.ToArray()
			select ApplyFrameAsync(frame, script)));
		bool flag = active;
		if (flag)
		{
			flag = await root != "true";
		}
		if (!flag)
		{
			return;
		}
		throw new InvalidOperationException("Virtual joystick is not available in this game document.");
	}

	internal async Task SetSquareAsync(bool active)
	{
		if (disposed)
		{
			if (active)
			{
				throw new ObjectDisposedException("ControllerBrowserBridge");
			}
			return;
		}
		string script = "(() => {const set=window.__kanblazSquareV1;return typeof set==='function'?set(" + (active ? "true" : "false") + "):false;})()";
		Task<string> root = browser.ExecuteScriptAsync(script);
		await Task.WhenAll(new Task<string>[1] { root }.Concat(from frame in frames.ToArray()
			select ApplyFrameAsync(frame, script)));
		bool flag = active;
		if (flag)
		{
			flag = await root != "true";
		}
		if (!flag)
		{
			return;
		}
		throw new InvalidOperationException("Controller button unavailable in this session.");
	}

	private async Task ApplyAllAsync()
	{
		if (!disposed)
		{
			string script = GamepadIsolation.StateScript(shared, owned);
			await Task.WhenAll(new Task<string>[1] { browser.ExecuteScriptAsync(script) }.Concat(from frame in frames.ToArray()
				select ApplyFrameAsync(frame, script)));
		}
	}

	private async Task<string> ApplyFrameAsync(CoreWebView2Frame frame, string script)
	{
		if (disposed || !frames.Contains(frame))
		{
			return "false";
		}
		try
		{
			return await frame.ExecuteScriptAsync(script);
		}
		catch
		{
			if (disposed || !frames.Contains(frame) || frame.IsDestroyed() != 0)
			{
				return "false";
			}
			throw;
		}
	}

	private void FrameCreated(object sender, CoreWebView2FrameCreatedEventArgs args)
	{
		if (!disposed && frames.Add(args.Frame))
		{
			args.Frame.FrameCreated += FrameCreated;
			args.Frame.Destroyed += FrameDestroyed;
			args.Frame.DOMContentLoaded += FrameReady;
		}
	}

	private async void FrameReady(object sender, CoreWebView2DOMContentLoadedEventArgs args)
	{
		if (disposed)
		{
			return;
		}
		try
		{
			await routing.SetAsync(shared);
		}
		catch
		{
		}
	}

	private void FrameDestroyed(object sender, object args)
	{
		if (sender is CoreWebView2Frame item)
		{
			frames.Remove(item);
		}
	}

	public void Dispose()
	{
		disposed = true;
		browser.FrameCreated -= FrameCreated;
		frames.Clear();
	}
}
