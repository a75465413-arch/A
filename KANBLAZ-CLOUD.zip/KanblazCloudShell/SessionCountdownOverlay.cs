using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class SessionCountdownOverlay : Form
{
	private readonly Control surface;

	private readonly SessionCountdownState state;

	private readonly ToolTip hudHint = new ToolTip();

	private readonly HudPreferences hud = HudPreferences.Current;

	private Rectangle usableCell;

	private Point dragStart;

	private Point dragOrigin;

	private bool dragging;

	private bool moved;

	private readonly Timer tick = new Timer
	{
		Interval = 100
	};

	private int displayed = -1;

	private string displayedLabel;

	private bool watching;

	private readonly VerifiedSessionWarning serviceWarning = new VerifiedSessionWarning();

	private readonly Stopwatch warningClock = Stopwatch.StartNew();

	private bool warningLit;

	private string lastWarning;

	private bool synchronizing;

	private bool confirmingReset;

	private SessionVolume volume;

	internal bool Running
	{
		get
		{
			if (!IsDisposed)
			{
				return state.Started;
			}
			return false;
		}
	}

	internal int RemainingSeconds => state.RemainingSeconds;

	protected override bool ShowWithoutActivation => true;

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 134742144;
			return createParams;
		}
	}

	internal event Action<string> PersistenceWarning;

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);

	[DllImport("user32.dll")]
	private static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);

	[DllImport("user32.dll")]
	private static extern uint GetDpiForWindow(IntPtr window);

	internal void ObserveVerifiedRemainingTime(int? seconds, bool verified)
	{
		serviceWarning.Observe(seconds, verified, warningClock.Elapsed.TotalSeconds);
	}

	internal void SetVolume(SessionVolume value)
	{
		volume = value;
		volume.Changed += RefreshVolume;
		RefreshVolume();
	}

	private void RefreshVolume()
	{
		AccessibleDescription = state.Label + " · " + volume.Status;
		Invalidate();
	}

	private void OpenVolume()
	{
		if (volume != null)
		{
			volume.ShowMenu(this, ConfirmManualReset);
		}
	}

	internal SessionCountdownOverlay(Control surface, SessionCountdownState state = null)
	{
		if (surface == null)
		{
			throw new ArgumentNullException("surface");
		}
		this.surface = surface;
		this.state = state ?? new SessionCountdownState();
		Text = "KANBLAZ CLOUD";
		AccessibleName = "Local session timer (not verified service time)";
		FormBorderStyle = FormBorderStyle.None;
		StartPosition = FormStartPosition.Manual;
		AutoScaleMode = AutoScaleMode.None;
		ShowInTaskbar = false;
		ControlBox = (MinimizeBox = (MaximizeBox = (TabStop = false)));
		ClientSize = CountdownArtwork.BadgeSize;
		BackColor = Color.FromArgb(1, 2, 3);
		TransparencyKey = BackColor;
		ResizeRedraw = true;
		DoubleBuffered = true;
		tick.Tick += Tick;
		surface.Disposed += SurfaceDisposed;
		hud.Changed += HudChanged;
		hudHint.SetToolTip(this, "Local timer, not verified Xbox remaining time · Drag to move · Speaker: volume · Right-click: reset · Arrow: hide/show");
	}

	internal void StartCountdown()
	{
		if (!IsDisposed)
		{
			state.Start();
			StartWatching();
		}
	}

	internal void StartWatching()
	{
		if (!IsDisposed)
		{
			watching = true;
			RefreshCountdown();
			tick.Start();
		}
	}

	internal void Observe(string signal)
	{
		if (!IsDisposed)
		{
			state.Observe(signal);
			RefreshCountdown();
		}
	}

	private void ConfirmManualReset()
	{
		if (IsDisposed || confirmingReset || !(surface.TopLevelControl is Form { IsDisposed: false } form))
		{
			return;
		}
		confirmingReset = true;
		try
		{
			if (MessageBox.Show(form, "Reset only this window's timer to 59:00?\n\nThis does not reload the game or extend the time granted by Xbox or GeForce.", "KANBLAZ CLOUD", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes && !IsDisposed)
			{
				if (!state.RestartManually())
				{
					MessageBox.Show(form, state.PersistenceError, "KANBLAZ CLOUD", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				}
				RefreshCountdown();
			}
		}
		finally
		{
			confirmingReset = false;
		}
	}

	internal void RefreshCountdown()
	{
		if (!IsDisposed && watching)
		{
			int remainingSeconds = state.RemainingSeconds;
			if (remainingSeconds != displayed || displayedLabel != state.Label)
			{
				displayed = remainingSeconds;
				displayedLabel = state.Label;
				AccessibleDescription = displayedLabel + ((displayedLabel == "--:--" || displayedLabel == "00:00") ? " · Waiting for a new session" : "");
				Invalidate();
			}
			if (state.PersistenceError != null && state.PersistenceError != lastWarning)
			{
				lastWarning = state.PersistenceError;
				PersistenceWarning?.Invoke(lastWarning);
			}
			Synchronize();
		}
	}

	private void Tick(object sender, EventArgs e)
	{
		bool flag = serviceWarning.Lit(warningClock.Elapsed.TotalSeconds);
		if (flag != warningLit)
		{
			warningLit = flag;
			Invalidate();
		}
		RefreshCountdown();
	}

	protected override void WndProc(ref Message message)
	{
		if (message.Msg == 33)
		{
			message.Result = new IntPtr(3);
		}
		else
		{
			base.WndProc(ref message);
		}
	}

	private void Synchronize()
	{
		if (synchronizing || IsDisposed)
		{
			return;
		}
		synchronizing = true;
		try
		{
			Form form = surface.TopLevelControl as Form;
			if (!watching || surface.IsDisposed || !surface.IsHandleCreated || !surface.Visible || form == null || form.IsDisposed || !form.IsHandleCreated || !form.Visible || form.WindowState == FormWindowState.Minimized || GetAncestor(GetForegroundWindow(), 3u) != GetAncestor(form.Handle, 3u))
			{
				HideOverlays();
				return;
			}
			Rectangle cell = surface.RectangleToScreen(surface.ClientRectangle);
			for (Control control = surface.Parent; control != null; control = control.Parent)
			{
				cell.Intersect(control.RectangleToScreen(control.ClientRectangle));
			}
			cell.Intersect(Screen.FromControl(surface).WorkingArea);
			usableCell = cell;
			float dpi = 96f;
			try
			{
				dpi = GetDpiForWindow(form.Handle);
			}
			catch (EntryPointNotFoundException)
			{
			}
			Rectangle rectangle = hud.BoundsFor(cell, dpi);
			if (rectangle.IsEmpty)
			{
				HideOverlays();
				return;
			}
			if (Owner != form)
			{
				Hide();
				Owner = form;
			}
			if (Bounds != rectangle)
			{
				Bounds = rectangle;
			}
			if (!Visible)
			{
				Show(form);
			}
			SetWindowPos(Handle, IntPtr.Zero, 0, 0, 0, 0, 19u);
		}
		finally
		{
			synchronizing = false;
		}
	}

	private void HideOverlays()
	{
		if (Visible)
		{
			Hide();
		}
	}

	private void HudChanged()
	{
		if (!IsDisposed)
		{
			Synchronize();
			Invalidate();
		}
	}

	private void SaveHud()
	{
		try
		{
			hud.Apply();
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			PersistenceWarning?.Invoke("HUD changed; could not save: " + ex.Message);
		}
	}

	protected override void OnMouseDown(MouseEventArgs e)
	{
		base.OnMouseDown(e);
		if (e.Button == MouseButtons.Left)
		{
			dragging = true;
			moved = false;
			dragStart = Cursor.Position;
			dragOrigin = Location;
			Capture = true;
		}
	}

	protected override void OnMouseMove(MouseEventArgs e)
	{
		base.OnMouseMove(e);
		if (dragging)
		{
			Point position = Cursor.Position;
			int num = position.X - dragStart.X;
			int num2 = position.Y - dragStart.Y;
			if (Math.Abs(num) + Math.Abs(num2) > 4)
			{
				moved = true;
			}
			if (moved)
			{
				hud.MoveTo(usableCell, Size, new Point(dragOrigin.X + num, dragOrigin.Y + num2));
				Synchronize();
			}
		}
	}

	protected override void OnMouseUp(MouseEventArgs e)
	{
		base.OnMouseUp(e);
		if (e.Button == MouseButtons.Right)
		{
			ConfirmManualReset();
		}
		else
		{
			if (e.Button != MouseButtons.Left || !dragging)
			{
				return;
			}
			dragging = false;
			Capture = false;
			if (moved)
			{
				SaveHud();
				return;
			}
			float num = (float)e.X / (float)Math.Max(1, Width) * (float)(hud.Hidden ? 20 : 120);
			if (hud.Hidden || num >= 100f)
			{
				hud.Hidden = !hud.Hidden;
				SaveHud();
			}
			else if (num >= 76f)
			{
				OpenVolume();
			}
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		e.Graphics.Clear(BackColor);
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
		float sx = (float)Width / (float)(hud.Hidden ? 20 : 120);
		float sy = (float)Height / 26f;
		e.Graphics.ScaleTransform(sx, sy);
		if (warningLit)
		{
			using SolidBrush brush = new SolidBrush(Color.OrangeRed);
			e.Graphics.FillEllipse(brush, hud.Hidden ? 14 : 114, 1, 5, 5);
		}
		Color color = Color.FromArgb(255, (hud.Foreground >> 16) & 0xFF, (hud.Foreground >> 8) & 0xFF, hud.Foreground & 0xFF);
		if (color.ToArgb() == BackColor.ToArgb())
		{
			color = Color.FromArgb(2, 3, 4);
		}
		using SolidBrush brush2 = new SolidBrush(color);
		using SolidBrush brush3 = new SolidBrush((color.GetBrightness() < 0.35f) ? Color.White : Color.Black);
		using Font font = new Font("Consolas", 14f, FontStyle.Bold, GraphicsUnit.Pixel);
		using Pen pen = new Pen(color, 1.6f);
		if (!hud.Hidden)
		{
			e.Graphics.DrawString(displayedLabel ?? "--:--", font, brush3, 20f, 8f);
			e.Graphics.DrawString(displayedLabel ?? "--:--", font, brush2, 19f, 7f);
			e.Graphics.DrawEllipse(pen, 4, 8, 11, 11);
			e.Graphics.DrawLine(pen, 9.5f, 10f, 9.5f, 14f);
			e.Graphics.DrawLine(pen, 9.5f, 14f, 12f, 15f);
			PointF[] points = new PointF[6]
			{
				new PointF(78f, 11f),
				new PointF(82f, 11f),
				new PointF(87f, 7f),
				new PointF(87f, 20f),
				new PointF(82f, 16f),
				new PointF(78f, 16f)
			};
			e.Graphics.FillPolygon(brush2, points);
			if (volume != null && volume.Level == 0)
			{
				e.Graphics.DrawLine(pen, 90, 10, 96, 17);
				e.Graphics.DrawLine(pen, 96, 10, 90, 17);
			}
			else
			{
				e.Graphics.DrawArc(pen, 86, 8, 10, 11, -65, 130);
			}
		}
		float num = (hud.Hidden ? 6 : 106);
		if (hud.Hidden)
		{
			e.Graphics.DrawLine(pen, num, 8f, num + 6f, 13f);
			e.Graphics.DrawLine(pen, num + 6f, 13f, num, 18f);
		}
		else
		{
			e.Graphics.DrawLine(pen, num + 6f, 8f, num, 13f);
			e.Graphics.DrawLine(pen, num, 13f, num + 6f, 18f);
		}
	}

	private void SurfaceDisposed(object sender, EventArgs e)
	{
		Dispose();
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && !IsDisposed)
		{
			tick.Stop();
			tick.Tick -= Tick;
			tick.Dispose();
			watching = false;
			surface.Disposed -= SurfaceDisposed;
			hud.Changed -= HudChanged;
			hudHint.Dispose();
			if (volume != null)
			{
				volume.Changed -= RefreshVolume;
				volume.Dispose();
			}
		}
		base.Dispose(disposing);
	}
}
