using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class ThemeBanner : Control
{
	private Image artwork;

	private AppThemeKind kind;

	internal ThemeBanner()
	{
		DoubleBuffered = true;
	}

	internal void SetTheme(AppThemeKind value)
	{
		if (artwork != null)
		{
			artwork.Dispose();
			artwork = null;
		}
		kind = value;
		string text = AppTheme.Artwork(value);
		if (text != null && File.Exists(text))
		{
			using Image original = Image.FromFile(text);
			artwork = new Bitmap(original);
		}
		Invalidate();
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		AppTheme appTheme = AppTheme.For(kind);
		e.Graphics.Clear(appTheme.SurfaceRaised);
		if (artwork != null)
		{
			float num = Math.Max((float)Width / (float)artwork.Width, (float)Height / (float)artwork.Height);
			float num2 = (float)Width / num;
			float num3 = (float)Height / num;
			e.Graphics.DrawImage(artwork, ClientRectangle, new RectangleF(((float)artwork.Width - num2) / 2f, ((float)artwork.Height - num3) / 2f, num2, num3), GraphicsUnit.Pixel);
			using LinearGradientBrush brush = new LinearGradientBrush(ClientRectangle, Color.FromArgb(235, appTheme.Window), Color.FromArgb(40, appTheme.Window), 0f);
			e.Graphics.FillRectangle(brush, ClientRectangle);
		}
		using (SolidBrush brush2 = new SolidBrush(appTheme.Accent))
		{
			e.Graphics.FillRectangle(brush2, 0, 0, 4, Height);
		}
		using Font font = new Font("Segoe UI Semibold", 13f);
		TextRenderer.DrawText(e.Graphics, AppTheme.Name(kind), font, new Rectangle(18, 0, Width - 36, Height), Color.White, TextFormatFlags.VerticalCenter);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && artwork != null)
		{
			artwork.Dispose();
		}
		base.Dispose(disposing);
	}
}
