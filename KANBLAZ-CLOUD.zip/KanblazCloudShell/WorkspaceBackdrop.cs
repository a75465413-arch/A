using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceBackdrop : TableLayoutPanel
{
	internal AppTheme Palette;

	private Bitmap backdrop;

	private AppTheme renderedPalette;

	private int backgroundId;

	private Image backgroundImage;

	private readonly Dictionary<int, Image> sourceImages = new Dictionary<int, Image>();

	private bool renderedLight;

	internal static string BackgroundPath(int id)
	{
		string[] array = new string[3] { "", "orbit-dark.png", "orbit-light.png" };
		if (id >= 1 && id <= 2)
		{
			return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", array[id]);
		}
		return null;
	}

	internal static Image LoadBackground(int id)
	{
		string text = BackgroundPath(id);
		if (text == null || !File.Exists(text))
		{
			return null;
		}
		try
		{
			using Image original = Image.FromFile(text);
			return new Bitmap(original);
		}
		catch (ArgumentException)
		{
			return null;
		}
		catch (IOException)
		{
			return null;
		}
	}

	internal void SetBackground(int id)
	{
		if (PerformanceMode.Enabled)
		{
			id = 0;
		}
		if (backgroundId != id)
		{
			backgroundId = id;
			if (!sourceImages.TryGetValue(id, out backgroundImage))
			{
				backgroundImage = LoadBackground(id);
				sourceImages[id] = backgroundImage;
			}
			if (backdrop != null)
			{
				backdrop.Dispose();
				backdrop = null;
			}
		}
	}

	internal WorkspaceBackdrop()
	{
		DoubleBuffered = true;
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		if (PerformanceMode.Enabled)
		{
			e.Graphics.Clear((Palette ?? AppTheme.Matte(187, 70)).Window);
			return;
		}
		EnsureBackdrop();
		if (backdrop != null)
		{
			e.Graphics.DrawImageUnscaled(backdrop, 0, 0);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			if (backdrop != null)
			{
				backdrop.Dispose();
			}
			foreach (Image value in sourceImages.Values)
			{
				value?.Dispose();
			}
			sourceImages.Clear();
		}
		base.Dispose(disposing);
	}

	private void EnsureBackdrop()
	{
		if (Width < 1 || Height < 1)
		{
			return;
		}
		bool flag = Palette != null && Palette.Window.R > 128;
		if (backdrop != null && backdrop.Size == ClientSize && renderedLight == flag && (backgroundImage != null || renderedPalette == Palette))
		{
			return;
		}
		if (backdrop != null)
		{
			backdrop.Dispose();
		}
		backdrop = new Bitmap(Width, Height);
		renderedPalette = Palette;
		renderedLight = flag;
		using Graphics graphics = Graphics.FromImage(backdrop);
		DrawBackdrop(new PaintEventArgs(graphics, ClientRectangle));
	}

	internal static void PaintBehind(Control control, Graphics graphics, Rectangle bounds, int shade)
	{
		Control control2 = control;
		while (control2 != null && !(control2 is WorkspaceBackdrop))
		{
			control2 = control2.Parent;
		}
		WorkspaceBackdrop workspaceBackdrop = control2 as WorkspaceBackdrop;
		if (PerformanceMode.Enabled)
		{
			using (SolidBrush brush = new SolidBrush((workspaceBackdrop != null && workspaceBackdrop.Palette != null) ? workspaceBackdrop.Palette.Surface : Color.FromArgb(14, 20, 25)))
			{
				graphics.FillRectangle(brush, bounds);
				return;
			}
		}
		if (workspaceBackdrop == null)
		{
			using (SolidBrush brush2 = new SolidBrush(control.BackColor))
			{
				graphics.FillRectangle(brush2, bounds);
				return;
			}
		}
		workspaceBackdrop.EnsureBackdrop();
		if (workspaceBackdrop.backdrop == null)
		{
			return;
		}
		Point point = workspaceBackdrop.PointToClient(control.PointToScreen(Point.Empty));
		graphics.DrawImage(workspaceBackdrop.backdrop, bounds, new Rectangle(point.X + bounds.X, point.Y + bounds.Y, bounds.Width, bounds.Height), GraphicsUnit.Pixel);
		if (shade <= 0)
		{
			return;
		}
		using SolidBrush brush3 = new SolidBrush(Color.FromArgb(shade, (workspaceBackdrop.Palette ?? AppTheme.Nexus(Color.FromArgb(7, 89, 133), light: false, glow: true, 70)).Surface));
		graphics.FillRectangle(brush3, bounds);
	}

	private void DrawBackdrop(PaintEventArgs e)
	{
		AppTheme appTheme = Palette ?? AppTheme.Nexus(Color.FromArgb(7, 89, 133), light: false, glow: true, 70);
		e.Graphics.Clear((appTheme.Window.R > 128) ? appTheme.Window : Color.FromArgb(1, 4, 9));
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		bool flag = appTheme.Window.R > 128;
		if (backgroundImage != null)
		{
			float num = Math.Max((float)Width / (float)backgroundImage.Width, (float)Height / (float)backgroundImage.Height);
			float num2 = (float)Width / num;
			float num3 = (float)Height / num;
			e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			e.Graphics.DrawImage(backgroundImage, ClientRectangle, new RectangleF(((float)backgroundImage.Width - num2) / 2f, ((float)backgroundImage.Height - num3) / 2f, num2, num3), GraphicsUnit.Pixel);
			if (!flag)
			{
				using (SolidBrush brush = new SolidBrush(Color.FromArgb(24, Color.Black)))
				{
					e.Graphics.FillRectangle(brush, ClientRectangle);
					return;
				}
			}
			return;
		}
		using (GraphicsPath graphicsPath = new GraphicsPath())
		{
			graphicsPath.AddBezier(0f, (float)Height * 0.88f, (float)Width * 0.35f, (float)Height * 0.98f, (float)Width * 0.72f, (float)(-Height) * 0.2f, Width, (float)Height * 0.12f);
			for (int num4 = 220; num4 >= 10; num4 -= 15)
			{
				using Pen pen = new Pen(Color.FromArgb(flag ? 3 : 9, appTheme.ActiveBorder), num4);
				e.Graphics.DrawPath(pen, graphicsPath);
			}
			using Pen pen2 = new Pen(Color.FromArgb(flag ? 35 : 100, appTheme.ActiveBorder), 2f);
			e.Graphics.DrawPath(pen2, graphicsPath);
		}
		Random random = new Random(519);
		for (int i = 0; i < 100; i++)
		{
			int num5 = random.Next(Math.Max(1, Width));
			int num6 = random.Next(Math.Max(1, Height));
			using SolidBrush brush2 = new SolidBrush(Color.FromArgb(flag ? 35 : random.Next(35, 115), appTheme.ActiveBorder));
			e.Graphics.FillEllipse(brush2, num5, num6, (i % 7 != 0) ? 1 : 3, (i % 7 != 0) ? 1 : 3);
		}
		int num7 = Math.Max(80, Width / 7);
		using GraphicsPath graphicsPath2 = new GraphicsPath();
		graphicsPath2.AddEllipse((float)Width * 0.11f, (float)(-num7) * 0.58f, num7, num7);
		using PathGradientBrush pathGradientBrush = new PathGradientBrush(graphicsPath2);
		pathGradientBrush.CenterColor = Color.FromArgb(flag ? 18 : 75, appTheme.Accent);
		pathGradientBrush.SurroundColors = new Color[1] { Color.Transparent };
		e.Graphics.FillPath(pathGradientBrush, graphicsPath2);
	}
}
