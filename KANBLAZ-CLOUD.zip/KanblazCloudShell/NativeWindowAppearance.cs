using System;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal static class NativeWindowAppearance
{
	private const int DwmaBorderColor = 34;

	private const int DwmColorNone = -2;

	[DllImport("dwmapi.dll")]
	private static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int valueSize);

	internal static void HideResizeBorder(IntPtr window)
	{
		try
		{
			int value = -2;
			DwmSetWindowAttribute(window, 34, ref value, 4);
		}
		catch
		{
		}
	}
}
