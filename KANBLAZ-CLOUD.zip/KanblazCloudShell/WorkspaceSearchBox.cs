using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceSearchBox : TextBox
{
	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern IntPtr SendMessage(IntPtr window, int message, IntPtr parameter, string text);

	protected override void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		SendMessage(Handle, 5377, new IntPtr(1), "Search profiles…  Ctrl+K");
	}
}
