using System;
using System.IO;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class InputPreferences
{
	internal Keys Release = Keys.F1;

	internal Keys AlternateRelease;

	internal Keys BroadcastKey;

	internal bool BroadcastEnabled;

	internal bool Highlight;

	internal CursorStyle CursorStyle;

	internal int CursorSize = 32;

	internal int CursorColor = 6750003;

	internal int GlowColor = 16724000;

	internal int Glow = 60;

	internal bool TintCursor;

	internal static InputPreferences Current = new InputPreferences();

	internal static string DefaultPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "input-settings.txt");

	internal static bool Allowed(Keys key)
	{
		if (Enum.IsDefined(typeof(Keys), key) && key >= Keys.Back && key <= Keys.OemClear && key != Keys.ShiftKey && key != Keys.ControlKey && key != Keys.Menu && key != Keys.LShiftKey && key != Keys.RShiftKey && key != Keys.LControlKey && key != Keys.RControlKey && key != Keys.LMenu && key != Keys.RMenu && key != Keys.LWin)
		{
			return key != Keys.RWin;
		}
		return false;
	}

	internal string Validate()
	{
		if (!Allowed(Release) || (BroadcastKey != Keys.None && !Allowed(BroadcastKey)))
		{
			return "Press a single keyboard key, not a modifier.";
		}
		if (BroadcastEnabled && BroadcastKey == Keys.None)
		{
			return "Press a key in the empty field before enabling hold.";
		}
		if (BroadcastKey == Release)
		{
			return "Each function needs a different key.";
		}
		if (Release == Keys.F2 || BroadcastKey == Keys.F2)
		{
			return "F2 is reserved for Movement.";
		}
		if (!Enum.IsDefined(typeof(CursorStyle), CursorStyle))
		{
			return "Unknown cursor style.";
		}
		if (CursorSize < 16 || CursorSize > 96 || Glow < 0 || Glow > 100 || CursorColor < 0 || CursorColor > 16777215 || GlowColor < 0 || GlowColor > 16777215)
		{
			return "Invalid cursor settings.";
		}
		return null;
	}

	internal bool IsRelease(Keys key)
	{
		return key == Release;
	}

	internal static InputPreferences Load(string path)
	{
		try
		{
			if (!File.Exists(path) || new FileInfo(path).Length > 256)
			{
				return new InputPreferences();
			}
			string[] array = File.ReadAllText(path).Split('|');
			bool flag = array.Length == 7 && array[0] == "1";
			if (!flag && (array.Length != 13 || (array[0] != "2" && array[0] != "3")))
			{
				return new InputPreferences();
			}
			InputPreferences inputPreferences = new InputPreferences
			{
				Release = (Keys)int.Parse(array[1]),
				AlternateRelease = (Keys)int.Parse(array[2]),
				BroadcastKey = (Keys)int.Parse(array[3]),
				BroadcastEnabled = bool.Parse(array[4]),
				CursorStyle = (CursorStyle)int.Parse(array[5]),
				Highlight = bool.Parse(array[6])
			};
			if (flag)
			{
				inputPreferences.CursorStyle = CursorStyle.Windows;
			}
			else
			{
				inputPreferences.CursorSize = int.Parse(array[7]);
				inputPreferences.CursorColor = int.Parse(array[8]);
				inputPreferences.GlowColor = int.Parse(array[9]);
				inputPreferences.Glow = int.Parse(array[10]);
				inputPreferences.TintCursor = bool.Parse(array[11]);
				if (array[12] != "native")
				{
					return new InputPreferences();
				}
			}
			inputPreferences.AlternateRelease = Keys.None;
			if (array[0] != "3")
			{
				inputPreferences.BroadcastKey = Keys.None;
				inputPreferences.BroadcastEnabled = false;
			}
			return (inputPreferences.Validate() == null) ? inputPreferences : new InputPreferences();
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is FormatException || ex is OverflowException)
		{
			return new InputPreferences();
		}
	}

	internal void Save(string path)
	{
		string text = Validate();
		if (text != null)
		{
			throw new InvalidOperationException(text);
		}
		Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
		string text2 = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			File.WriteAllText(text2, string.Join("|", "3", (int)Release, (int)AlternateRelease, (int)BroadcastKey, BroadcastEnabled, (int)CursorStyle, Highlight, CursorSize, CursorColor, GlowColor, Glow, TintCursor, "native"));
			if (File.Exists(path))
			{
				File.Replace(text2, path, null);
			}
			else
			{
				File.Move(text2, path);
			}
		}
		finally
		{
			if (File.Exists(text2))
			{
				File.Delete(text2);
			}
		}
	}
}
