using System;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace KanblazCloudShell;

internal static class LaptopMouseShortcut
{
	internal static bool IsGameAddress(string address)
	{
		if (!Uri.TryCreate(address, UriKind.Absolute, out var result) || result.Scheme != "https")
		{
			return false;
		}
		string text = result.DnsSafeHost.ToLowerInvariant();
		if ((!(text == "xbox.com") && !(text == "www.xbox.com")) || !Regex.IsMatch(result.AbsolutePath, "^/(?:[a-z]{2}-[a-z]{2}/)?play(?:/|$)", RegexOptions.IgnoreCase))
		{
			switch (text)
			{
			case "luna.amazon.com":
				return !Regex.IsMatch(result.AbsolutePath, "^/(?:ap|signin|login|auth)(?:/|$)", RegexOptions.IgnoreCase);
			default:
				return false;
			case "play.xbox.com":
			case "play.geforcenow.com":
				break;
			}
		}
		return true;
	}

	internal static Task<string> InstallAsync(CoreWebView2 browser)
	{
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Kanblaz.LaptopMouseShortcut.js");
		if (stream == null)
		{
			throw new InvalidOperationException("The laptop Q shortcut component is missing.");
		}
		using StreamReader streamReader = new StreamReader(stream);
		return browser.AddScriptToExecuteOnDocumentCreatedAsync(streamReader.ReadToEnd());
	}
}
