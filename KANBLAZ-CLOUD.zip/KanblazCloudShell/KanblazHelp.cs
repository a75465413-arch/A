using System.Globalization;
using System.Text;

namespace KanblazCloudShell;

internal static class KanblazHelp
{
	private static string Normalize(string value)
	{
		StringBuilder stringBuilder = new StringBuilder();
		string text = (value ?? "").ToLowerInvariant().Normalize(NormalizationForm.FormD);
		foreach (char c in text)
		{
			if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
			{
				stringBuilder.Append(c);
			}
		}
		return stringBuilder.ToString();
	}

	internal static string Answer(string query, bool es, string modeKey, string releaseKey, string buttonKey)
	{
		string text = Normalize(query);
		if (text.Trim().Length == 0)
		{
			if (!es)
			{
				return "Choose a topic or ask about Kanblaz. Answers are local guides; this panel does not change settings or execute actions.";
			}
			return "Elige un tema o escribe tu pregunta sobre Kanblaz. Las respuestas son guías locales; este panel no cambia tus ajustes ni ejecuta acciones.";
		}
		if (Has(text, "perfil", "profile", "carpeta", "folder", "copiar", "pegar", "delete", "eliminar"))
		{
			if (!es)
			{
				return "PROFILES AND FOLDERS\n\nChoose a folder, then Add Profile. Each new profile has its own identity. Click a row to select; Launch Selected opens only your selection.\n\nAll Profiles shows each profile once. Choose a real folder to create or permanently delete profiles.\n\nRight-click → Copy; right-click the destination folder → Paste. This shares the same profile and saved sign-in. Remove from this folder keeps the profile; its last reference returns to Main Profiles. Delete everywhere requires confirmation and also deletes saved sign-in.";
			}
			return "PERFILES Y CARPETAS\n\nElige una carpeta y pulsa Añadir perfil. Cada perfil nuevo tiene su propia identidad. Haz clic en la fila para seleccionar; Abrir seleccionados abre solo la selección.\n\nTodos los perfiles reúne cada perfil una sola vez. Para crear o eliminar definitivamente, abre una carpeta real.\n\nClic derecho → Copiar; clic derecho en la carpeta destino → Pegar. Se comparte el mismo perfil y acceso guardado. Quitar de esta carpeta conserva el perfil; la última referencia vuelve a Main Profiles. Eliminar de todas partes pide confirmación y borra también el acceso guardado.";
		}
		if (Has(text, "movimiento", "movement", "f2"))
		{
			if (!es)
			{
				return "MOVEMENT\n\nF2 or the Movement button starts/stops movement in open sessions. While active, the button reads Deactivate Movement (F2). Open a game window first. This does not change Individual/Shared mode.";
			}
			return "MOVIMIENTO\n\nF2 o el botón de Movimiento inicia/detiene la función en las sesiones abiertas. Mientras está activa, el botón dice Desactivar movimiento (F2). Primero abre una ventana de juego. No cambia el modo Individual/Shared.";
		}
		if (Has(text, "controller button", "boton del control", "f3"))
		{
			if (!es)
			{
				return "CONTROLLER BUTTON\n\nCurrent key: " + Key(buttonKey, es) + ". Open Settings → Controller Button to review the action and change its binding. It is separate from Individual/Shared and mouse release. Shortcuts are disabled while typing in text fields.";
			}
			return "BOTÓN DEL CONTROL\n\nSu tecla actual es " + Key(buttonKey, es) + ". Abre Ajustes → Botón del control para revisar la acción y cambiar la asignación. Es independiente de Individual/Shared y de liberar el mouse. Los atajos se deshabilitan al escribir en campos de texto.";
		}
		if (Has(text, "control", "shared", "individual", "mando"))
		{
			if (!es)
			{
				return "CONTROLLER\n\nIndividual directs controller input to the focused game window. Shared shares it with supported open windows.\n\nCurrent toggle key: " + Key(modeKey, es) + ". Change it in Settings → Controller; the heading shows the selected mode. X is not mandatory: use your assigned key. Shortcuts are disabled while typing.";
			}
			return "CONTROL\n\nIndividual dirige el control a la ventana de juego enfocada. Shared comparte el control con las ventanas compatibles abiertas.\n\nLa tecla actual para alternar es " + Key(modeKey, es) + ". Se cambia en Ajustes → Control; el encabezado muestra el modo seleccionado. No asumas que X es obligatorio: usa la tecla que tengas asignada. Los atajos se deshabilitan al escribir.";
		}
		if (Has(text, "input", "liberar", "release", "f1", "tecla"))
		{
			if (!es)
			{
				return "INPUT\n\nConfigured mouse-release key: " + Key(releaseKey, es) + ". Change it in Settings → Input. Releasing the mouse lets you use the interface again. Manual key hold is a separate function with its own binding. Avoid conflicting assignments.";
			}
			return "INPUT\n\nLa tecla configurada para liberar el mouse es " + Key(releaseKey, es) + ". Abre Ajustes → Input para cambiarla. Liberar el mouse permite volver a manejar la interfaz. La tecla manual mantenida es otra función: revisa su propia asignación. Evita asignaciones en conflicto.";
		}
		if (Has(text, "mouse", "cursor", "raton"))
		{
			if (!es)
			{
				return "MOUSE\n\nSettings → Mouse contains cursor style, size, color and glow. Cursor glow intensity is separate from the interface's Nexus glow. Use Input to change the mouse-release key.";
			}
			return "MOUSE\n\nAjustes → Mouse contiene el estilo de cursor, tamaño, color y brillo. La intensidad del brillo del cursor es independiente del brillo Nexus de la interfaz. Para cambiar la tecla que libera el mouse, usa Input.";
		}
		if (Has(text, "hud", "timer", "tiempo", "volumen", "volume", "temporizador"))
		{
			if (!es)
			{
				return "TIMER AND VOLUME\n\nExtras lets you change HUD size/color and reset its position. Drag the clock to move the widget; right-click resets the timer. Its small icon hides/shows it.\n\nThe timer is local; it does not represent official Xbox time remaining.";
			}
			return "TIEMPO Y VOLUMEN\n\nEn Extras puedes ajustar el tamaño y color del HUD y restablecer su posición. Arrastra el reloj para mover el conjunto; clic derecho reinicia el tiempo. Su icono pequeño permite ocultar/mostrar.\n\nEl temporizador es local: no representa el tiempo restante oficial de Xbox.";
		}
		if (Has(text, "recuper", "recovery", "f5", "inactiv", "desconect"))
		{
			if (!es)
			{
				return "XBOX RECOVERY\n\nExtras → Auto recovery · Xbox turns recovery of recognized ended sessions on/off. Only the affected window is targeted. It cannot guarantee recovery from account, network or service-limit issues, and it does not detect Xbox time remaining.";
			}
			return "RECUPERACIÓN XBOX\n\nExtras → Recuperación auto. · Xbox permite activar o desactivar la recuperación de sesiones terminadas reconocidas. Solo se intenta recuperar la ventana afectada. No garantiza resolver problemas de cuenta, red o límites del servicio. No equivale a detectar tiempo restante de Xbox.";
		}
		if (Has(text, "notific", "ocr", "audio", "sonido", "sprite", "brainrot", "box"))
		{
			if (!es)
			{
				return "NOTIFICATIONS\n\nOpen Extras → Notifications to review available detectors. Alerts identify the detected profile. OCR depends on readable announcements in the captured image; audio depends on the available signal. Detection can fail: confirm events in the game. This panel only explains these functions.";
			}
			return "NOTIFICACIONES\n\nAbre Extras → Notifications para revisar los detectores disponibles. Las alertas identifican el perfil detectado. El OCR depende de que el anuncio sea legible en la captura; el audio depende de la señal disponible. Una detección puede fallar: confirma el evento en el juego. Este panel solo explica estas funciones.";
		}
		if (!es)
		{
			return "I do not have a local answer for that question yet. Try profiles, controller, movement, Input, Mouse, HUD, recovery or notifications. No AI model is connected.";
		}
		return "Todavía no tengo una respuesta local para esa pregunta. Prueba un tema: perfiles, control, movimiento, Input, Mouse, HUD, recuperación o notificaciones. No hay un modelo de IA conectado.";
	}

	private static bool Has(string query, params string[] terms)
	{
		foreach (string value in terms)
		{
			if (query.Contains(value))
			{
				return true;
			}
		}
		return false;
	}

	private static string Key(string key, bool es)
	{
		if (!string.IsNullOrEmpty(key) && !(key == "None"))
		{
			return key;
		}
		if (!es)
		{
			return "unassigned";
		}
		return "sin asignar";
	}
}
