using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class RecordedKey
{
	internal Keys Key;

	internal bool Down;

	internal int Delay;

	internal RecordedKey(Keys key, bool down, int delay)
	{
		Key = key;
		Down = down;
		Delay = delay;
	}
}
