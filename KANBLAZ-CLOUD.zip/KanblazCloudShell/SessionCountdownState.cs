using System;
using System.Diagnostics;
using System.Globalization;

namespace KanblazCloudShell;

internal sealed class SessionCountdownState
{
	internal const int DurationSeconds = 3540;

	private readonly Func<double> now;

	private readonly SessionClockStore store;

	private double deadline;

	private bool ended;

	private double quitUntil;

	private double idleSince = -1.0;

	private bool loadFailed;

	internal bool Started { get; private set; }

	internal string PersistenceError { get; private set; }

	internal string Label
	{
		get
		{
			if (!loadFailed && (Started || ended))
			{
				return Format(RemainingSeconds);
			}
			return "--:--";
		}
	}

	internal int RemainingSeconds
	{
		get
		{
			if (Started)
			{
				return (int)Math.Ceiling(Math.Max(0.0, Math.Min(3540.0, deadline - now())));
			}
			return 0;
		}
	}

	internal SessionCountdownState(Func<double> now = null, SessionClockStore store = null)
	{
		DateTime epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		double origin = (DateTime.UtcNow - epoch).TotalSeconds;
		Stopwatch elapsed = Stopwatch.StartNew();
		double latest = origin;
		this.now = now ?? ((Func<double>)(() => latest = Math.Max(latest, Math.Max((DateTime.UtcNow - epoch).TotalSeconds, origin + elapsed.Elapsed.TotalSeconds))));
		this.store = store;
		try
		{
			SessionClockRecord sessionClockRecord = ((store == null) ? new SessionClockRecord() : store.Load());
			Started = sessionClockRecord.Started;
			deadline = sessionClockRecord.Deadline;
			ended = sessionClockRecord.Ended;
		}
		catch
		{
			loadFailed = true;
			PersistenceError = "Saved time could not be read. The file was preserved; the timer will not restart automatically.";
		}
	}

	internal void Start()
	{
		if (!Started && !loadFailed)
		{
			deadline = now() + 3540.0;
			Started = true;
			ended = false;
			Save();
		}
	}

	internal bool RestartManually()
	{
		if (loadFailed)
		{
			return false;
		}
		Started = false;
		ended = false;
		deadline = 0.0;
		quitUntil = 0.0;
		idleSince = -1.0;
		Start();
		return true;
	}

	internal static string Format(int seconds)
	{
		seconds = Math.Max(0, Math.Min(3540, seconds));
		return string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}", seconds / 60, seconds % 60);
	}

	internal void Stop()
	{
		if (!loadFailed && !ended)
		{
			Started = false;
			deadline = 0.0;
			ended = true;
			quitUntil = 0.0;
			idleSince = -1.0;
			Save();
		}
	}

	internal void Observe(string signal)
	{
		double num = now();
		switch (signal)
		{
		case "ended":
			Stop();
			break;
		case "quit":
			quitUntil = num + 20.0;
			idleSince = -1.0;
			break;
		case "cancel":
			quitUntil = 0.0;
			idleSince = -1.0;
			break;
		case "next-playing":
			quitUntil = 0.0;
			idleSince = -1.0;
			if (Started && RemainingSeconds == 0)
			{
				Stop();
			}
			Start();
			break;
		case "launch":
			if (Started && RemainingSeconds == 0)
			{
				Stop();
			}
			break;
		case "idle":
			if (quitUntil > num)
			{
				if (idleSince < 0.0)
				{
					idleSince = num;
				}
				else if (num - idleSince >= 2.0)
				{
					Stop();
				}
			}
			break;
		case "playing":
			idleSince = -1.0;
			Start();
			break;
		}
	}

	private void Save()
	{
		if (store == null || loadFailed)
		{
			return;
		}
		try
		{
			store.Save(new SessionClockRecord
			{
				Started = Started,
				Deadline = deadline,
				Ended = ended
			});
			PersistenceError = null;
		}
		catch
		{
			PersistenceError = "Time could not be saved. The timer continues but might not be restored when reopened.";
		}
	}
}
