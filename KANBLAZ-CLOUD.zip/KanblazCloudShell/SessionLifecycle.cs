using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace KanblazCloudShell;

internal static class SessionLifecycle
{
	internal static string ReadScript()
	{
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Kanblaz.SessionLifecycle.js");
		if (stream == null)
		{
			throw new InvalidOperationException("The session lifecycle detector is missing.");
		}
		using StreamReader streamReader = new StreamReader(stream);
		return streamReader.ReadToEnd();
	}

	internal static Task<string> InstallAsync(CoreWebView2 browser)
	{
		return browser.AddScriptToExecuteOnDocumentCreatedAsync(ReadScript());
	}

	internal static bool TrySignal(string source, string currentSource, string json, out string signal)
	{
		signal = null;
		if (!LaptopMouseShortcut.IsGameAddress(source) || !string.Equals(source, currentSource, StringComparison.Ordinal))
		{
			return false;
		}
		switch (json)
		{
		case "\"kanblaz.session.playing.v1\"":
			signal = "playing";
			break;
		case "\"kanblaz.session.next-playing.v1\"":
			signal = "next-playing";
			break;
		case "\"kanblaz.session.ended.v1\"":
			signal = "ended";
			break;
		case "\"kanblaz.session.idle.v1\"":
			signal = "idle";
			break;
		case "\"kanblaz.session.quit.v1\"":
			signal = "quit";
			break;
		case "\"kanblaz.session.cancel.v1\"":
			signal = "cancel";
			break;
		case "\"kanblaz.session.launch.v1\"":
			signal = "launch";
			break;
		default:
			return false;
		}
		return true;
	}
}
