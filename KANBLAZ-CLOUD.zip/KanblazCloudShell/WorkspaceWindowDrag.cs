using System;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal static class WorkspaceWindowDrag
{
	[DllImport("user32.dll")]
	private static extern bool ReleaseCapture();

	[DllImport("user32.dll")]
	private static extern IntPtr SendMessage(IntPtr window, int message, IntPtr wparam, IntPtr lparam);

	internal static void Start(IntPtr handle)
	{
		ReleaseCapture();
		SendMessage(handle, 161, new IntPtr(2), IntPtr.Zero);
	}
}
