using System;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal sealed class MacroGlobalShortcut : IDisposable
{
	internal const int Id = 19250;

	internal const int Message = 786;

	internal const uint NoRepeat = 16384u;

	private IntPtr window;

	internal bool Registered => window != IntPtr.Zero;

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);

	[DllImport("user32.dll")]
	private static extern bool UnregisterHotKey(IntPtr window, int id);

	internal bool Register(IntPtr target)
	{
		if (Registered)
		{
			return true;
		}
		if (target == IntPtr.Zero)
		{
			return false;
		}
		if (!RegisterHotKey(target, 19250, 16384u, 113u))
		{
			return false;
		}
		window = target;
		return true;
	}

	public void Dispose()
	{
		if (Registered)
		{
			UnregisterHotKey(window, 19250);
			window = IntPtr.Zero;
		}
	}
}
