using System;
using System.Drawing;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class SessionCountdownResetButton : Form
{
	private readonly ToolTip hint = new ToolTip();

	private bool hovered;

	internal int Volume = 100;

	protected override bool ShowWithoutActivation => true;

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 134742144;
			return createParams;
		}
	}

	internal event Action ResetRequested;

	internal event Action TimerResetRequested;

	internal SessionCountdownResetButton()
	{
		Text = "KANBLAZ CLOUD";
		AccessibleName = "This window's game volume";
		AccessibleRole = AccessibleRole.PushButton;
		FormBorderStyle = FormBorderStyle.None;
		StartPosition = FormStartPosition.Manual;
		AutoScaleMode = AutoScaleMode.None;
		ShowInTaskbar = false;
		ControlBox = (MinimizeBox = (MaximizeBox = (TabStop = false)));
		ClientSize = CountdownArtwork.ResetSize;
		BackColor = Color.FromArgb(13, 20, 29);
		Cursor = Cursors.Hand;
		Opacity = 0.96;
		DoubleBuffered = true;
		hint.SetToolTip(this, "Game volume (0% = mute). Right-click to reset timer.");
	}

	protected override void WndProc(ref Message message)
	{
		if (message.Msg == 33)
		{
			message.Result = new IntPtr(3);
		}
		else
		{
			base.WndProc(ref message);
		}
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		hovered = true;
		Invalidate();
		base.OnMouseEnter(e);
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		hovered = false;
		Invalidate();
		base.OnMouseLeave(e);
	}

	protected override void OnMouseClick(MouseEventArgs e)
	{
		base.OnMouseClick(e);
		if (e.Button == MouseButtons.Left && ClientRectangle.Contains(e.Location))
		{
			ResetRequested?.Invoke();
		}
		if (e.Button == MouseButtons.Right && ClientRectangle.Contains(e.Location))
		{
			TimerResetRequested?.Invoke();
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.Clear(hovered ? Color.FromArgb(35, 55, 65) : BackColor);
		using Pen pen = new Pen((Volume == 0) ? Color.Gray : Color.FromArgb(100, 235, 255), 2f);
		graphics.DrawRectangle(pen, 5, 11, 4, 7);
		graphics.DrawLines(pen, new Point[4]
		{
			new Point(9, 11),
			new Point(15, 6),
			new Point(15, 23),
			new Point(9, 18)
		});
		if (Volume == 0)
		{
			graphics.DrawLine(pen, 19, 11, 25, 18);
			graphics.DrawLine(pen, 25, 11, 19, 18);
			return;
		}
		graphics.DrawArc(pen, 12, 8, 11, 13, -65, 130);
		if (Volume > 50)
		{
			graphics.DrawArc(pen, 13, 4, 16, 21, -65, 130);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && !IsDisposed)
		{
			hint.Dispose();
		}
		base.Dispose(disposing);
	}
}
