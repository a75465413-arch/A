namespace KanblazCloudShell;

internal struct TouchpadSample
{
	internal bool Down;

	internal bool Click;

	internal int X;

	internal int Y;

	internal int Contact;
}
