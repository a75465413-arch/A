using System;
using System.Text.RegularExpressions;

namespace KanblazCloudShell;

internal sealed class XboxRecoveryPolicy
{
	private double since = -1.0;

	private double lastSample = -1.0;

	private double lastReload = -1000.0;

	internal int Attempts { get; private set; }

	internal string Status { get; private set; }

	internal bool Awaiting { get; private set; }

	internal void Suspend()
	{
		since = -1.0;
		lastSample = -1.0;
		Awaiting = false;
	}

	internal void InvalidateEvidence()
	{
		since = -1.0;
		lastSample = -1.0;
	}

	internal bool Observe(string screen, double now, bool enabled)
	{
		if (!enabled)
		{
			Suspend();
			Status = "Auto Session Recovery off";
			return false;
		}
		if (lastSample >= 0.0 && (now - lastSample > 2.5 || now < lastSample))
		{
			since = -1.0;
		}
		lastSample = now;
		switch (screen)
		{
		case "playing":
			since = -1.0;
			Awaiting = false;
			Status = "Xbox gameplay active";
			return false;
		case "loading":
			since = -1.0;
			Awaiting = false;
			Status = "Xbox launch/loading flow detected";
			return false;
		case "play":
			since = -1.0;
			Awaiting = false;
			Status = "Xbox Play requires manual confirmation";
			return false;
		default:
			if (screen != "ended")
			{
				since = -1.0;
				if (Awaiting && now - lastReload >= 90.0)
				{
					Awaiting = false;
					Status = "Xbox flow not confirmed; review this window manually";
					return false;
				}
				Status = (Awaiting ? "Waiting for Xbox after refresh" : "No confirmed ended-session screen");
				return false;
			}
			if (since < 0.0)
			{
				since = now;
			}
			if (now - since < 3.0)
			{
				Status = "Confirming Xbox ended-session screen";
				return false;
			}
			if (now - lastReload < 30.0)
			{
				Status = "Xbox recovery retry cooldown";
				return false;
			}
			return Reload(now);
		}
	}

	private bool Reload(double now)
	{
		if (Attempts < int.MaxValue)
		{
			Attempts++;
		}
		lastReload = now;
		since = -1.0;
		Awaiting = true;
		Status = "Refreshing only this Xbox window (attempt " + Attempts + ")";
		return true;
	}

	internal static bool IsFortniteXbox(string address)
	{
		if (!Uri.TryCreate(address, UriKind.Absolute, out var result) || result.Scheme != "https" || !result.IsDefaultPort)
		{
			return false;
		}
		switch (result.DnsSafeHost.ToLowerInvariant())
		{
		case "xbox.com":
		case "www.xbox.com":
		case "play.xbox.com":
			return Regex.IsMatch(result.AbsolutePath, "^/(?:[a-z]{2}-[a-z]{2}/)?play/(?:launch|games)/fortnite/[^/]+/?$", RegexOptions.IgnoreCase);
		default:
			return false;
		}
	}
}
