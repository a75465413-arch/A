using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class ProfileSelectionCell : DataGridViewCheckBoxCell
{
	public ProfileSelectionCell()
		: base(threeState: false)
	{
		FlatStyle = FlatStyle.Flat;
	}

	protected override Rectangle GetContentBounds(Graphics graphics, DataGridViewCellStyle cellStyle, int rowIndex)
	{
		if (DataGridView == null || rowIndex < 0 || ColumnIndex < 0)
		{
			return Rectangle.Empty;
		}
		return new Rectangle(1, 1, Math.Max(0, OwningColumn.Width - 2), Math.Max(0, DataGridView.Rows[rowIndex].Height - 2));
	}

	internal static Rectangle GlyphBounds(Rectangle bounds, float dpi)
	{
		float num = Math.Max(1f, dpi / 96f);
		int num2 = Math.Max(1, Math.Min((int)Math.Round(26f * num), Math.Min(bounds.Width, bounds.Height) - (int)Math.Round(12f * num)));
		return new Rectangle(bounds.X + (bounds.Width - num2) / 2, bounds.Y + (bounds.Height - num2) / 2, num2, num2);
	}

	protected override void Paint(Graphics graphics, Rectangle clipBounds, Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle borderStyle, DataGridViewPaintParts paintParts)
	{
		base.Paint(graphics, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, cellStyle, borderStyle, paintParts & ~DataGridViewPaintParts.ContentForeground);
		if ((paintParts & DataGridViewPaintParts.ContentForeground) == 0)
		{
			return;
		}
		Rectangle bounds = GlyphBounds(cellBounds, graphics.DpiX);
		bool flag = (formattedValue is bool && (bool)formattedValue) || (formattedValue is CheckState && (CheckState)formattedValue == CheckState.Checked);
		bool flag2 = ReadOnly || DataGridView == null || !DataGridView.Enabled;
		AppTheme appTheme = ((DataGridView == null) ? null : (DataGridView.Tag as AppTheme));
		Color color;
		if (flag2)
		{
			color = Color.FromArgb(92, 106, 117);
		}
		else if (appTheme == null)
		{
			color = Color.FromArgb(168, 203, 228);
		}
		else
		{
			color = (flag ? appTheme.ActiveBorder : appTheme.Border);
		}
		Color color2;
		if (flag)
		{
			color2 = (flag2 ? Color.FromArgb(99, 118, 134) : (appTheme?.Accent ?? Color.FromArgb(221, 241, 255)));
		}
		else
		{
			color2 = appTheme?.Surface ?? Color.FromArgb(19, 29, 39);
		}
		GraphicsState gstate = graphics.Save();
		try
		{
			graphics.SetClip(clipBounds, CombineMode.Intersect);
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			using (GraphicsPath path = WorkspaceDrawing.Round(bounds, 5))
			{
				using SolidBrush brush = new SolidBrush(color2);
				graphics.FillPath(brush, path);
			}
			using (Pen pen = new Pen(color, Math.Max(1.5f, (float)bounds.Width / 13f)))
			{
				using GraphicsPath path2 = WorkspaceDrawing.Round(new Rectangle(bounds.X + 1, bounds.Y + 1, bounds.Width - 2, bounds.Height - 2), 4);
				graphics.DrawPath(pen, path2);
			}
			if (flag)
			{
				using (Pen pen2 = new Pen(Color.FromArgb(17, 39, 56), Math.Max(2f, (float)bounds.Width / 8f)))
				{
					LineCap startCap = (pen2.EndCap = LineCap.Round);
					pen2.StartCap = startCap;
					pen2.LineJoin = LineJoin.Round;
					graphics.DrawLines(pen2, new PointF[3]
					{
						new PointF((float)bounds.X + (float)bounds.Width * 0.23f, (float)bounds.Y + (float)bounds.Height * 0.51f),
						new PointF((float)bounds.X + (float)bounds.Width * 0.43f, (float)bounds.Y + (float)bounds.Height * 0.71f),
						new PointF((float)bounds.X + (float)bounds.Width * 0.78f, (float)bounds.Y + (float)bounds.Height * 0.29f)
					});
					return;
				}
			}
		}
		finally
		{
			graphics.Restore(gstate);
		}
	}
}
