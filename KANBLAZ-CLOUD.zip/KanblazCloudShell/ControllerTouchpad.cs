using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal sealed class ControllerTouchpad : IDisposable
{
	private struct Registration
	{
		internal ushort Page;

		internal ushort Usage;

		internal uint Flags;

		internal IntPtr Target;
	}

	private readonly Dictionary<IntPtr, TouchpadGesture> gestures = new Dictionary<IntPtr, TouchpadGesture>();

	private readonly Dictionary<IntPtr, int[]> devices = new Dictionary<IntPtr, int[]>();

	private bool registered;

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool RegisterRawInputDevices(Registration[] devices, uint count, uint size);

	[DllImport("user32.dll")]
	private static extern uint GetRawInputData(IntPtr input, uint command, IntPtr data, ref uint size, uint headerSize);

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern uint GetRawInputDeviceInfo(IntPtr device, uint command, IntPtr data, ref uint size);

	internal bool Register(IntPtr target)
	{
		registered = RegisterRawInputDevices(new Registration[2]
		{
			new Registration
			{
				Page = 1,
				Usage = 5,
				Flags = 8448u,
				Target = target
			},
			new Registration
			{
				Page = 1,
				Usage = 4,
				Flags = 8448u,
				Target = target
			}
		}, 2u, (uint)Marshal.SizeOf(typeof(Registration)));
		return registered;
	}

	internal void Reset()
	{
		gestures.Clear();
	}

	internal void Remove(IntPtr device)
	{
		gestures.Remove(device);
		devices.Remove(device);
	}

	internal bool Read(IntPtr input, out Point delta, out bool release, out bool mouseClick)
	{
		delta = Point.Empty;
		bool result = (release = (mouseClick = false));
		if (!registered)
		{
			return false;
		}
		uint num = (uint)(8 + 2 * IntPtr.Size);
		uint size = 0u;
		if (GetRawInputData(input, 268435459u, IntPtr.Zero, ref size, num) == uint.MaxValue || size < num + 8 || size > 65536)
		{
			return false;
		}
		IntPtr intPtr = Marshal.AllocHGlobal((int)size);
		try
		{
			if (GetRawInputData(input, 268435459u, intPtr, ref size, num) != size || Marshal.ReadInt32(intPtr) != 2)
			{
				result = false;
			}
			else
			{
				IntPtr intPtr2 = Marshal.ReadIntPtr(intPtr, 8);
				if (!devices.TryGetValue(intPtr2, out var value))
				{
					IntPtr intPtr3 = Marshal.AllocHGlobal(32);
					try
					{
						uint size2 = 32u;
						Marshal.WriteInt32(intPtr3, 32);
						if (GetRawInputDeviceInfo(intPtr2, 536870923u, intPtr3, ref size2) != uint.MaxValue)
						{
							value = new int[2]
							{
								Marshal.ReadInt32(intPtr3, 8),
								Marshal.ReadInt32(intPtr3, 12)
							};
							devices[intPtr2] = value;
							goto end_IL_009c;
						}
						result = false;
						goto end_IL_0057;
						end_IL_009c:;
					}
					finally
					{
						Marshal.FreeHGlobal(intPtr3);
					}
				}
				int num2 = Marshal.ReadInt32(intPtr, (int)num);
				int num3 = Marshal.ReadInt32(intPtr, (int)(num + 4));
				if (num2 < 1 || num2 > 1024 || num3 < 1 || num3 > 64 || (long)num2 * (long)num3 > size - num - 8)
				{
					result = false;
				}
				else
				{
					if (!gestures.TryGetValue(intPtr2, out var value2))
					{
						value2 = (gestures[intPtr2] = new TouchpadGesture());
					}
					bool flag = false;
					for (int i = 0; i < num3; i++)
					{
						byte[] array = new byte[num2];
						Marshal.Copy(IntPtr.Add(intPtr, (int)(num + 8) + i * num2), array, 0, num2);
						if (!ControllerTouchpadReport.TryRead(value[0], value[1], array, out var sample))
						{
							value2.Reset();
							continue;
						}
						Point p = value2.Update(sample, out var release2, out var mouseClick2);
						delta.Offset(p);
						release |= release2;
						mouseClick |= mouseClick2;
						flag = true;
					}
					result = flag;
				}
			}
			end_IL_0057:;
		}
		finally
		{
			Marshal.FreeHGlobal(intPtr);
		}
		return result;
	}

	public void Dispose()
	{
		if (registered)
		{
			RegisterRawInputDevices(new Registration[2]
			{
				new Registration
				{
					Page = 1,
					Usage = 5,
					Flags = 1u
				},
				new Registration
				{
					Page = 1,
					Usage = 4,
					Flags = 1u
				}
			}, 2u, (uint)Marshal.SizeOf(typeof(Registration)));
		}
		registered = false;
		gestures.Clear();
		devices.Clear();
	}
}
