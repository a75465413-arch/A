using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class VisualQuickGuide : Form
{
	internal const int PageCount = 10;

	private readonly bool spanish;

	private readonly string release;

	private readonly PictureBox picture = new PictureBox
	{
		Dock = DockStyle.Fill,
		SizeMode = PictureBoxSizeMode.Zoom
	};

	private readonly Button back = new WorkspaceButton
	{
		AutoSize = true
	};

	private readonly Button next = new WorkspaceButton
	{
		AutoSize = true
	};

	private readonly Button enlarge = new WorkspaceButton
	{
		AutoSize = true
	};

	private readonly Button video = new WorkspaceButton
	{
		AutoSize = true
	};

	private readonly Label counter = new Label
	{
		AutoSize = true,
		Margin = new Padding(12, 8, 12, 0)
	};

	internal int Page { get; private set; }

	internal bool CanGoBack => Page > 0;

	internal string NextCaption
	{
		get
		{
			if (Page != 9)
			{
				if (!spanish)
				{
					return "Next";
				}
				return "Siguiente";
			}
			if (!spanish)
			{
				return "Close";
			}
			return "Cerrar";
		}
	}

	internal static string Assets => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "guide");

	internal VisualQuickGuide(bool spanish, string release)
	{
		VisualQuickGuide visualQuickGuide = this;
		this.spanish = spanish;
		this.release = release;
		Text = "KANBLAZ CLOUD";
		ClientSize = new Size(1040, 730);
		MinimumSize = new Size(720, 510);
		StartPosition = FormStartPosition.CenterParent;
		ShowInTaskbar = false;
		MinimizeBox = false;
		BackColor = Color.FromArgb(5, 14, 23);
		ForeColor = Color.White;
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Bottom,
			Height = 54,
			Padding = new Padding(12, 6, 12, 6)
		};
		back.Text = (spanish ? "Atrás" : "Back");
		back.Click += delegate
		{
			visualQuickGuide.NavigatePage(-1);
		};
		next.Click += delegate
		{
			if (visualQuickGuide.Page == 9)
			{
				visualQuickGuide.Close();
			}
			else
			{
				visualQuickGuide.NavigatePage(1);
			}
		};
		enlarge.Text = (spanish ? "Ampliar imágenes" : "Enlarge images");
		enlarge.Click += delegate
		{
			visualQuickGuide.ShowImages();
		};
		video.Text = (spanish ? "▶ Ver video" : "▶ Watch video");
		video.Click += delegate
		{
			using GuideVideoForm guideVideoForm = new GuideVideoForm(spanish);
			guideVideoForm.ShowDialog(visualQuickGuide);
		};
		flowLayoutPanel.Controls.AddRange(new Control[5] { back, counter, next, enlarge, video });
		Controls.Add(picture);
		Controls.Add(flowLayoutPanel);
		AcceptButton = next;
		picture.Click += delegate
		{
			visualQuickGuide.ShowImages();
		};
		ShowPage();
	}

	internal void NavigatePage(int delta)
	{
		Page = Math.Max(0, Math.Min(9, Page + delta));
		ShowPage();
	}

	private void ShowPage()
	{
		Image image = picture.Image;
		picture.Image = Render(Page, spanish, release);
		image?.Dispose();
		back.Enabled = CanGoBack;
		next.Text = NextCaption;
		counter.Text = Page + 1 + " / " + 10;
		video.Visible = Page == 8;
		picture.AccessibleName = Title(Page, spanish) + ". " + Instruction(Page, spanish);
		enlarge.Enabled = Files(Page, spanish).Length != 0;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && picture.Image != null)
		{
			picture.Image.Dispose();
			picture.Image = null;
		}
		base.Dispose(disposing);
	}

	private void ShowImages()
	{
		string[] files = Files(Page, spanish);
		if (files.Length == 0)
		{
			return;
		}
		using Form form = new Form
		{
			Text = "KANBLAZ CLOUD",
			Size = new Size(1100, 800),
			MinimumSize = new Size(600, 450),
			StartPosition = FormStartPosition.CenterParent,
			BackColor = BackColor,
			ShowInTaskbar = false
		};
		PictureBox image = new PictureBox
		{
			Dock = DockStyle.Fill,
			SizeMode = PictureBoxSizeMode.Zoom
		};
		try
		{
			int index = 0;
			Action load = () =>
			{
				Image image2 = image.Image;
				image.Image = LoadImage(files[index]);
				image2?.Dispose();
			};
			FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
			{
				Dock = DockStyle.Bottom,
				Height = 45
			};
			WorkspaceButton workspaceButton = new WorkspaceButton
			{
				Text = (spanish ? "Anterior" : "Previous"),
				AutoSize = true
			};
			WorkspaceButton workspaceButton2 = new WorkspaceButton
			{
				Text = (spanish ? "Siguiente" : "Next"),
				AutoSize = true
			};
			workspaceButton.Click += delegate
			{
				index = (index + files.Length - 1) % files.Length;
				load();
			};
			workspaceButton2.Click += delegate
			{
				index = (index + 1) % files.Length;
				load();
			};
			bool visible = (workspaceButton2.Visible = files.Length > 1);
			workspaceButton.Visible = visible;
			flowLayoutPanel.Controls.AddRange(new Control[2] { workspaceButton, workspaceButton2 });
			form.Controls.Add(image);
			form.Controls.Add(flowLayoutPanel);
			load();
			form.ShowDialog(this);
			if (image.Image != null)
			{
				image.Image.Dispose();
				image.Image = null;
			}
		}
		finally
		{
			if (image != null)
			{
				((IDisposable)image).Dispose();
			}
		}
	}

	internal static string Title(int page, bool es)
	{
		return ((!es) ? new string[10] { "Verify your account", "Add a profile", "Select the service", "Sign in and open Fortnite", "Create your folders", "All Profiles", "Settings", "Kanblaz assistant", "Prepare in-game audio", "Recognize notifications" } : new string[10] { "Verifica tu cuenta", "Añade un perfil", "Selecciona el servicio", "Inicia sesión y abre Fortnite", "Crea tus carpetas", "Todos los perfiles", "Ajustes", "Asistente Kanblaz", "Prepara el audio del juego", "Reconoce las notificaciones" })[Math.Max(0, Math.Min(9, page))];
	}

	internal static string Instruction(int page, bool es)
	{
		string[] array = new string[10] { "Abre Cuenta e inicia sesión con Google para verificarla. El acceso Pro depende de tu membresía: un equipo activo a la vez. Para cambiar de equipo puede ser necesario cerrar el acceso anterior.", "Elige una carpeta real y pulsa + Añadir Profile. Cada perfil nuevo conserva su propia sesión. Free permite hasta 2 perfiles.", "En SERVICE elige Xbox Cloud Gaming, GeForce NOW o Amazon Luna para ese perfil.", "Abre el perfil e inicia sesión en el servicio elegido. Selecciona Fortnite; vincula tu cuenta de Epic Games o empieza con una nueva para progresar jugando.", "Pulsa + Nueva carpeta para organizar tus perfiles. Clic derecho permite copiar y pegar referencias del mismo perfil entre carpetas, sin duplicar su sesión.", "Todos los perfiles reúne cada perfil una sola vez. Haz clic en una fila para seleccionar y usa Abrir seleccionados. Crea o elimina definitivamente desde una carpeta real.", "Abre la categoría que necesites: Control, Movimiento, Input, Mouse, Botón del control, Layout, Apariencia o Extras. Personaliza tus teclas; no tienen que ser X, F1 o F3.", "Pulsa la estrella junto al buscador para consultar las funciones de Kanblaz. Actualmente ofrece ayuda local guiada; no hay un modelo de IA conectado.", "Volumen ON en cada ventana: no silencies ninguna. Apaga música y sonidos innecesarios, incluidos los del Index Book / Rots. Amplía las imágenes o mira el video de ejemplo.", "Consulta los colores y tipos de aviso de la imagen. Mantén el anuncio visible y legible. Audio y OCR pueden fallar: confirma el evento en el juego." };
		string[] array2 = new string[10] { "Open Account and sign in with Google to verify it. Pro access depends on your membership: one active computer at a time. Switching computers may require signing out of the previous device.", "Choose a real folder and click + Add Profile. Each new profile keeps its own session. Free supports up to 2 profiles.", "Under SERVICE, select Xbox Cloud Gaming, GeForce NOW or Amazon Luna for that profile.", "Launch the profile and sign in to the selected service. Choose Fortnite; link your Epic Games account or start with a new one and progress by playing.", "Click + New Folder to organize profiles. Right-click to copy and paste references to the same profile between folders, without duplicating its session.", "All Profiles shows each profile once. Click a row to select, then Launch Selected. Create or permanently delete profiles from a real folder.", "Open the category you need: Controller, Movement, Input, Mouse, Controller Button, Layout, Appearance or Extras. Customize your keys; X, F1 and F3 are not mandatory.", "Click the star beside profile search to ask about Kanblaz features. It currently provides local guided help; no AI model is connected.", "Volume ON in every window: do not mute any window. Turn off music and unnecessary sounds, including Index Book / Rots sounds. Enlarge the images or watch the example video.", "See the image for name colors and alert types. Keep the announcement visible and readable. Audio and OCR can miss events: confirm them in the game." };
		return (es ? array : array2)[Math.Max(0, Math.Min(9, page))];
	}

	internal static string[] Files(int page, bool es)
	{
		return page switch
		{
			0 => new string[1] { "account.png" }, 
			1 => new string[1] { "add-profile.png" }, 
			2 => new string[1] { "service.png" }, 
			3 => new string[2] { "nvidia-signin.png", "xbox-signin.png" }, 
			4 => new string[1] { "folders.png" }, 
			5 => new string[1] { "all-profiles.png" }, 
			6 => new string[1] { "settings.png" }, 
			7 => new string[1] { "assistant.png" }, 
			8 => new string[3] { "game-audio.png", "index-book.png", "index-sounds.png" }, 
			9 => new string[1] { es ? "notifications-es.png" : "notifications-en.png" }, 
			_ => new string[0], 
		};
	}

	private static Image LoadImage(string name)
	{
		string text = Path.Combine(Assets, name);
		if (!File.Exists(text))
		{
			return null;
		}
		try
		{
			using Image original = Image.FromFile(text);
			return new Bitmap(original);
		}
		catch (ArgumentException)
		{
			return null;
		}
		catch (IOException)
		{
			return null;
		}
	}

	internal static Bitmap Render(int page, bool es, string release)
	{
		page = Math.Max(0, Math.Min(9, page));
		Bitmap bitmap = new Bitmap(1200, 800);
		using Graphics graphics = Graphics.FromImage(bitmap);
		using Font font = new Font("Segoe UI", 29f, FontStyle.Bold);
		using Font font2 = new Font("Segoe UI", 16f);
		using Font font3 = new Font("Segoe UI", 11f);
		graphics.Clear(Color.FromArgb(5, 14, 23));
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
		using SolidBrush brush = new SolidBrush(Color.FromArgb(73, 212, 245));
		using SolidBrush brush2 = new SolidBrush(Color.White);
		using SolidBrush brush3 = new SolidBrush(Color.FromArgb(185, 212, 230));
		graphics.DrawString(es ? "KANBLAZ CLOUD · GUÍA RÁPIDA" : "KANBLAZ CLOUD · QUICK GUIDE", font3, brush, 30f, 20f);
		graphics.DrawString(page + 1 + ". " + Title(page, es), font, brush2, new RectangleF(30f, 52f, 1140f, 60f));
		graphics.DrawString(Instruction(page, es), font2, brush2, new RectangleF(30f, 122f, 1140f, 112f));
		string[] array = Files(page, es);
		int num = array.Length;
		int num2 = (1140 - (num - 1) * 18) / Math.Max(1, num);
		for (int i = 0; i < num; i++)
		{
			using Image image = LoadImage(array[i]);
			Rectangle rectangle = new Rectangle(30 + i * (num2 + 18), 242, num2, 490);
			if (image == null)
			{
				graphics.DrawString(es ? "Imagen no disponible" : "Image unavailable", font2, brush3, rectangle);
				continue;
			}
			float num3 = Math.Min((float)rectangle.Width / (float)image.Width, (float)rectangle.Height / (float)image.Height);
			int num4 = (int)((float)image.Width * num3);
			int num5 = (int)((float)image.Height * num3);
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.DrawImage(image, new Rectangle(rectangle.X + (rectangle.Width - num4) / 2, rectangle.Y + (rectangle.Height - num5) / 2, num4, num5));
		}
		string s;
		if (page != 9)
		{
			s = (es ? "Capturas originales de referencia · haz clic para ampliar" : "Original reference screenshots · click to enlarge");
		}
		else
		{
			s = (es ? "Imagen en español · haz clic para ampliar" : "English image · click to enlarge");
		}
		graphics.DrawString(s, font3, brush3, new RectangleF(30f, 756f, 1140f, 30f));
		return bitmap;
	}
}
