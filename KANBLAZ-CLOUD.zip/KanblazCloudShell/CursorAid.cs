using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class CursorAid : IDisposable
{
	private struct CursorInfo
	{
		internal int Size;

		internal int Flags;

		internal IntPtr Cursor;

		internal Point Position;
	}

	private struct IconInfo
	{
		[MarshalAs(UnmanagedType.Bool)]
		internal bool Icon;

		internal uint X;

		internal uint Y;

		internal IntPtr Mask;

		internal IntPtr Color;
	}

	private IntPtr native;

	private string fingerprint;

	private bool applied;

	private Cursor managed;

	private IntPtr retiringNative;

	private readonly Dictionary<Control, Cursor> originals = new Dictionary<Control, Cursor>();

	internal static string Stamp
	{
		get
		{
			InputPreferences current = InputPreferences.Current;
			return string.Join("|", current.CursorStyle, current.CursorSize, current.CursorColor, current.GlowColor, current.Glow, current.Highlight, current.TintCursor);
		}
	}

	internal bool Customized
	{
		get
		{
			InputPreferences current = InputPreferences.Current;
			if (current.CursorStyle == CursorStyle.Windows && current.CursorSize == 32 && !current.Highlight)
			{
				return current.TintCursor;
			}
			return true;
		}
	}

	[DllImport("user32.dll")]
	private static extern bool GetCursorInfo(ref CursorInfo info);

	[DllImport("user32.dll")]
	private static extern int ShowCursor(bool show);

	[DllImport("user32.dll")]
	private static extern IntPtr SetCursor(IntPtr cursor);

	[DllImport("user32.dll")]
	private static extern IntPtr CreateIconIndirect(ref IconInfo info);

	[DllImport("user32.dll")]
	private static extern bool DestroyCursor(IntPtr cursor);

	[DllImport("gdi32.dll")]
	private static extern bool DeleteObject(IntPtr bitmap);

	[DllImport("user32.dll")]
	private static extern bool GetIconInfo(IntPtr icon, out IconInfo info);

	internal static string CssCursor()
	{
		InputPreferences current = InputPreferences.Current;
		if (current.CursorStyle == CursorStyle.Windows && current.CursorSize == 32 && !current.Highlight && !current.TintCursor)
		{
			return "";
		}
		Point hotspot;
		using Bitmap bitmap = Render(current, out hotspot);
		using MemoryStream memoryStream = new MemoryStream();
		bitmap.Save(memoryStream, ImageFormat.Png);
		return "url(data:image/png;base64," + Convert.ToBase64String(memoryStream.ToArray()) + ") " + hotspot.X + " " + hotspot.Y + ", auto";
	}

	private void RestoreIfOwned()
	{
		CursorInfo info = new CursorInfo
		{
			Size = Marshal.SizeOf(typeof(CursorInfo))
		};
		if (applied && GetCursorInfo(ref info) && info.Cursor == native)
		{
			SetCursor(Cursors.Default.Handle);
		}
		applied = false;
	}

	internal static void Recover()
	{
		CursorInfo info = new CursorInfo
		{
			Size = Marshal.SizeOf(typeof(CursorInfo))
		};
		if (GetCursorInfo(ref info) && (info.Flags & 1) == 0)
		{
			for (int i = 0; i < 8; i++)
			{
				if (ShowCursor(show: true) >= 0)
				{
					break;
				}
			}
		}
		SetCursor(Cursors.Default.Handle);
	}

	internal static Bitmap Render(InputPreferences p, out Point hotspot)
	{
		int num = (p.Highlight ? 12 : 3);
		int cursorSize = p.CursorSize;
		Bitmap bitmap = new Bitmap(cursorSize + num * 2, cursorSize + num * 2, PixelFormat.Format32bppArgb);
		Color color = Color.FromArgb(-16777216 | p.CursorColor);
		Color baseColor = Color.FromArgb(-16777216 | p.GlowColor);
		hotspot = new Point(num, num);
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			if (p.CursorStyle == CursorStyle.NeonTarget)
			{
				float num2 = (float)bitmap.Width / 2f;
				float num3 = (float)cursorSize * 0.4f;
				hotspot = new Point((int)num2, (int)num2);
				if (p.Highlight && p.Glow > 0)
				{
					for (int num4 = 18; num4 >= 4; num4 -= 2)
					{
						using Pen pen = new Pen(Color.FromArgb(Math.Max(1, p.Glow / 6), baseColor), num4);
						graphics.DrawEllipse(pen, num2 - num3, num2 - num3, num3 * 2f, num3 * 2f);
					}
				}
				using (Pen pen2 = new Pen(color, Math.Max(1.5f, (float)cursorSize / 14f)))
				{
					graphics.DrawEllipse(pen2, num2 - num3, num2 - num3, num3 * 2f, num3 * 2f);
					int[] array = new int[2] { -1, 1 };
					foreach (int num5 in array)
					{
						graphics.DrawLine(pen2, num2 + (float)num5 * num3 * 0.6f, num2, num2 + (float)num5 * num3, num2);
						graphics.DrawLine(pen2, num2, num2 + (float)num5 * num3 * 0.6f, num2, num2 + (float)num5 * num3);
					}
				}
				using SolidBrush brush = new SolidBrush(color);
				graphics.FillEllipse(brush, num2 - 2f, num2 - 2f, 4f, 4f);
			}
			else
			{
				using Bitmap bitmap2 = new Bitmap(cursorSize, cursorSize, PixelFormat.Format32bppArgb);
				using (Graphics g = Graphics.FromImage(bitmap2))
				{
					Cursors.Default.DrawStretched(g, new Rectangle(0, 0, cursorSize, cursorSize));
				}
				if (GetIconInfo(Cursors.Default.Handle, out var info))
				{
					hotspot = new Point(num + (int)info.X * cursorSize / Cursors.Default.Size.Width, num + (int)info.Y * cursorSize / Cursors.Default.Size.Height);
					if (info.Mask != IntPtr.Zero)
					{
						DeleteObject(info.Mask);
					}
					if (info.Color != IntPtr.Zero)
					{
						DeleteObject(info.Color);
					}
				}
				using (Bitmap bitmap3 = new Bitmap(cursorSize, cursorSize, PixelFormat.Format32bppArgb))
				{
					for (int j = 0; j < cursorSize; j++)
					{
						for (int k = 0; k < cursorSize; k++)
						{
							Color pixel = bitmap2.GetPixel(k, j);
							bitmap3.SetPixel(k, j, Color.FromArgb(pixel.A * p.Glow / 700, baseColor));
							if (p.TintCursor && pixel.A > 0 && pixel.GetBrightness() > 0.3f)
							{
								bitmap2.SetPixel(k, j, Color.FromArgb(pixel.A, color));
							}
						}
					}
					if (p.Highlight)
					{
						for (int l = 0; l < 360; l += 30)
						{
							for (int m = 2; m <= 8; m += 2)
							{
								graphics.DrawImageUnscaled(bitmap3, num + (int)(Math.Cos((double)l * Math.PI / 180.0) * (double)m), num + (int)(Math.Sin((double)l * Math.PI / 180.0) * (double)m));
							}
						}
					}
				}
				graphics.DrawImageUnscaled(bitmap2, num, num);
			}
		}
		return bitmap;
	}

	internal static IntPtr CreateNative(InputPreferences p)
	{
		Point hotspot;
		using Bitmap bitmap = Render(p, out hotspot);
		using Bitmap bitmap2 = new Bitmap(bitmap.Width, bitmap.Height);
		IconInfo info = new IconInfo
		{
			Icon = false,
			X = (uint)hotspot.X,
			Y = (uint)hotspot.Y,
			Color = bitmap.GetHbitmap(Color.FromArgb(0)),
			Mask = bitmap2.GetHbitmap()
		};
		try
		{
			return CreateIconIndirect(ref info);
		}
		finally
		{
			DeleteObject(info.Color);
			DeleteObject(info.Mask);
		}
	}

	internal static void FreeNative(IntPtr handle)
	{
		if (handle != IntPtr.Zero)
		{
			DestroyCursor(handle);
		}
	}

	internal void ApplyTo(params Control[] roots)
	{
		InputPreferences current = InputPreferences.Current;
		string stamp = Stamp;
		IntPtr zero = IntPtr.Zero;
		Cursor cursor = null;
		if (fingerprint != stamp)
		{
			IntPtr intPtr = (Customized ? CreateNative(current) : IntPtr.Zero);
			if (Customized && intPtr == IntPtr.Zero)
			{
				return;
			}
			zero = native;
			cursor = managed;
			native = intPtr;
			managed = ((native == IntPtr.Zero) ? null : new Cursor(native));
			fingerprint = stamp;
		}
		retiringNative = zero;
		Control[] array = originals.Keys.Where((Control c) => c.IsDisposed).ToArray();
		foreach (Control key in array)
		{
			originals.Remove(key);
		}
		array = roots;
		foreach (Control control in array)
		{
			ApplyTree(control);
		}
		if (zero != IntPtr.Zero)
		{
			CursorInfo info = new CursorInfo
			{
				Size = Marshal.SizeOf(typeof(CursorInfo))
			};
			if (GetCursorInfo(ref info) && info.Cursor == zero)
			{
				SetCursor((native == IntPtr.Zero) ? Cursors.Default.Handle : native);
			}
			if (cursor != null)
			{
				cursor.Dispose();
			}
			DestroyCursor(zero);
		}
		retiringNative = IntPtr.Zero;
	}

	private void ApplyTree(Control control)
	{
		if (control == null || control.IsDisposed)
		{
			return;
		}
		if (!originals.ContainsKey(control))
		{
			originals[control] = ((control.Cursor.Handle == native || (retiringNative != IntPtr.Zero && control.Cursor.Handle == retiringNative)) ? Cursors.Default : control.Cursor);
		}
		control.Cursor = managed ?? originals[control];
		foreach (Control control2 in control.Controls)
		{
			ApplyTree(control2);
		}
	}

	public void Dispose()
	{
		foreach (KeyValuePair<Control, Cursor> original in originals)
		{
			if (!original.Key.IsDisposed)
			{
				original.Key.Cursor = original.Value;
			}
		}
		originals.Clear();
		applied = true;
		RestoreIfOwned();
		if (managed != null)
		{
			managed.Dispose();
		}
		if (native != IntPtr.Zero)
		{
			DestroyCursor(native);
		}
		native = IntPtr.Zero;
	}
}
