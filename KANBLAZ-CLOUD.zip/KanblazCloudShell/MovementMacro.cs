using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal sealed class MovementMacro
{
	internal const int CycleMilliseconds = 1500;

	internal const int RepeatIntervalMilliseconds = 180000;

	internal static readonly string[] Steps = new string[8] { "W", "WA", "A", "AS", "S", "SD", "D", "DW" };

	private readonly Func<Task<bool>> eligible;

	private readonly Func<char, bool, Task> send;

	private readonly Func<int, CancellationToken, Task> delay;

	private readonly Action<string> report;

	private readonly Func<Task> stopped;

	private readonly Func<long> milliseconds;

	private CancellationTokenSource cancellation;

	private Task running = Task.FromResult(0);

	internal const string EligibilityScript = "(() => {\n            const host = location.hostname;\n            if (location.protocol !== 'https:' || !(\n                ((host === 'www.xbox.com' || host === 'xbox.com') && /^\\/(?:[a-z]{2}-[a-z]{2}\\/)?play(?:\\/|$)/i.test(location.pathname)) ||\n                host === 'play.xbox.com' || host === 'play.geforcenow.com' ||\n                (host === 'luna.amazon.com' && !/^\\/(?:ap|signin|login|auth)(?:\\/|$)/i.test(location.pathname)))) return false;\n            let target = document.activeElement;\n            while (target && target.shadowRoot && target.shadowRoot.activeElement) target = target.shadowRoot.activeElement;\n            if (target && (target.isContentEditable || ['INPUT','TEXTAREA','SELECT','IFRAME'].includes(target.tagName) ||\n                (target.closest && target.closest('form')) ||\n                ['textbox','searchbox','combobox'].includes(target.getAttribute('role')))) return false;\n            if (document.querySelector('dialog[open],[role=dialog][aria-modal=true]')) return false;\n            const live = Array.from(document.querySelectorAll('video')).some(video => {\n                const stream = video.srcObject, rect = video.getBoundingClientRect();\n                return !!stream && stream.active && typeof stream.getVideoTracks === 'function' &&\n                    stream.getVideoTracks().some(track => track.readyState === 'live') &&\n                    !video.paused && !video.ended && video.readyState >= 2 && video.videoWidth >= 160 && video.videoHeight >= 90 &&\n                    video.isConnected && rect.width >= 160 && rect.height >= 90 && rect.bottom > 0 && rect.right > 0 &&\n                    rect.top < innerHeight && rect.left < innerWidth &&\n                    (!video.checkVisibility || video.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}));\n            });\n            // A Play button may retain DOM focus in a background tile. Only\n            // blur stale non-form buttons/links after live playback is present;\n            // do not activate/click them or steal native desktop keyboard focus.\n            if (live && target && ['BUTTON','A'].includes(target.tagName) && typeof target.blur === 'function') target.blur();\n            return live;\n        })()";

	internal bool IsRunning
	{
		get
		{
			if (cancellation != null)
			{
				return !cancellation.IsCancellationRequested;
			}
			return false;
		}
	}

	internal bool LastReleaseFailed { get; private set; }

	internal static int StepMilliseconds(int index)
	{
		if (index % 2 != 0)
		{
			return 187;
		}
		return 188;
	}

	internal MovementMacro(Func<Task<bool>> eligible, Func<char, bool, Task> send, Action<string> report, Func<int, CancellationToken, Task> delay = null, Func<Task> stopped = null, Func<long> milliseconds = null)
	{
		this.eligible = eligible;
		this.send = send;
		this.report = report;
		this.delay = delay ?? new Func<int, CancellationToken, Task>(Task.Delay);
		this.stopped = stopped;
		Stopwatch clock = Stopwatch.StartNew();
		this.milliseconds = milliseconds ?? ((Func<long>)(() => clock.ElapsedMilliseconds));
	}

	internal void Start()
	{
		if (running.IsCompleted)
		{
			LastReleaseFailed = false;
			running = RunAsync(cancellation = new CancellationTokenSource());
		}
	}

	internal Task StopAsync()
	{
		if (cancellation != null)
		{
			cancellation.Cancel();
		}
		return running;
	}

	private async Task RunAsync(CancellationTokenSource source)
	{
		await Task.Yield();
		CancellationToken token = source.Token;
		List<char> held = new List<char>();
		bool releaseFailed = false;
		try
		{
			int num;
			_ = num - 1;
			_ = 7;
			try
			{
				int index = 0;
				long cycleStarted = 0L;
				while (true)
				{
					token.ThrowIfCancellationRequested();
					bool flag = await eligible();
					token.ThrowIfCancellationRequested();
					if (!flag)
					{
						if (held.Count > 0)
						{
							await ReleaseForPauseAsync(held);
						}
						index = 0;
						await delay(250, token);
						continue;
					}
					string next = Steps[index];
					long stepStarted = milliseconds();
					if (index == 0)
					{
						cycleStarted = stepStarted;
					}
					char[] array = held.ToArray();
					foreach (char key in array)
					{
						if (next.IndexOf(key) < 0)
						{
							await send(key, arg2: false);
							held.Remove(key);
						}
					}
					string text = next;
					foreach (char c in text)
					{
						if (!held.Contains(c))
						{
							token.ThrowIfCancellationRequested();
							held.Add(c);
							await send(c, arg2: true);
						}
					}
					token.ThrowIfCancellationRequested();
					await delay((int)Math.Max(0L, StepMilliseconds(index) - (milliseconds() - stepStarted)), token);
					index = (index + 1) % Steps.Length;
					if (index == 0)
					{
						await ReleaseForPauseAsync(held);
						long num2 = 180000 - Math.Max(0L, milliseconds() - cycleStarted);
						await delay((int)((num2 > 0) ? num2 : 180000), token);
					}
				}
			}
			catch (OperationCanceledException)
			{
			}
			catch (Exception)
			{
				report("Movement macro stopped: the game window did not accept input.");
			}
		}
		finally
		{
			foreach (char item in held)
			{
				try
				{
					await send(item, arg2: false);
				}
				catch
				{
					releaseFailed = true;
					LastReleaseFailed = true;
				}
			}
			if (stopped != null)
			{
				try
				{
					await stopped();
				}
				catch
				{
					LastReleaseFailed = true;
					report("Macro stopped; input compatibility could not reset. Close this game window before continuing.");
				}
			}
			if (cancellation == source)
			{
				cancellation = null;
			}
			source.Dispose();
			if (releaseFailed)
			{
				report("Macro stopped; input release could not be confirmed. Close this game window before continuing.");
			}
		}
	}

	private async Task ReleaseForPauseAsync(List<char> held)
	{
		char[] array = held.ToArray();
		foreach (char key in array)
		{
			await send(key, arg2: false);
			held.Remove(key);
		}
		if (stopped == null)
		{
			return;
		}
		try
		{
			await stopped();
		}
		catch
		{
			LastReleaseFailed = true;
			throw;
		}
	}

	internal static string KeyParameters(char key, bool down)
	{
		if (key != 'W' && key != 'A' && key != 'S' && key != 'D')
		{
			throw new ArgumentOutOfRangeException("key");
		}
		string[] array = new string[11]
		{
			"{\"type\":\"",
			down ? "keyDown" : "keyUp",
			"\",\"key\":\"",
			char.ToLowerInvariant(key).ToString(),
			"\",\"code\":\"Key",
			key.ToString(),
			"\",\"windowsVirtualKeyCode\":",
			null,
			null,
			null,
			null
		};
		int num = key;
		array[7] = num.ToString();
		array[8] = ",\"nativeVirtualKeyCode\":";
		num = key;
		array[9] = num.ToString();
		array[10] = ",\"autoRepeat\":false}";
		return string.Concat(array);
	}
}
