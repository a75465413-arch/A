using System;
using System.IO;

namespace KanblazCloudShell;

internal static class StartupComponents
{
	internal static string Missing(string root)
	{
		string text = ((IntPtr.Size == 4) ? "x86" : "x64");
		string[] array = new string[8]
		{
			"Microsoft.Web.WebView2.Core.dll",
			"Microsoft.Web.WebView2.WinForms.dll",
			"WebView2Loader.dll",
			"Tesseract.dll",
			"Kanblaz.ProcessAudio.dll",
			text + "/tesseract50.dll",
			text + "/leptonica-1.82.0.dll",
			"assets/ocr/eng.traineddata"
		};
		foreach (string text2 in array)
		{
			if (!File.Exists(Path.Combine(root, text2)))
			{
				return text2;
			}
		}
		return null;
	}
}
