using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace KanblazCloudShell;

internal sealed class GuideVideoForm : Form
{
	private readonly WebView2 player = new WebView2
	{
		Dock = DockStyle.Fill
	};

	private readonly bool spanish;

	internal GuideVideoForm(bool spanish)
	{
		this.spanish = spanish;
		Text = "KANBLAZ CLOUD";
		Size = new Size(1000, 660);
		MinimumSize = new Size(600, 400);
		StartPosition = FormStartPosition.CenterParent;
		ShowInTaskbar = false;
		Controls.Add(player);
		Shown += LoadVideo;
	}

	private async void LoadVideo(object sender, EventArgs args)
	{
		_ = 1;
		try
		{
			string videoPath = Path.Combine(VisualQuickGuide.Assets, "index-audio.txt");
			if (!File.Exists(videoPath))
			{
				videoPath = Path.Combine(VisualQuickGuide.Assets, "index-audio.mp4");
			}
			if (!File.Exists(videoPath))
			{
				throw new IOException(spanish ? "Video no disponible." : "Video unavailable.");
			}
			string userDataFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "GuidePlayer");
			CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, userDataFolder);
			if (IsDisposed)
			{
				return;
			}
			await player.EnsureCoreWebView2Async(environment);
			if (IsDisposed)
			{
				return;
			}
			player.CoreWebView2.Settings.AreDevToolsEnabled = false;
			player.CoreWebView2.Settings.IsWebMessageEnabled = false;
			player.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
			player.CoreWebView2.AddWebResourceRequestedFilter("https://kanblaz-guide.local/*", CoreWebView2WebResourceContext.All);
			player.CoreWebView2.WebResourceRequested += (object s, CoreWebView2WebResourceRequestedEventArgs e) =>
			{
				if (e.Request.Uri == "https://kanblaz-guide.local/player")
				{
					e.Response = environment.CreateWebResourceResponse(new MemoryStream(Encoding.UTF8.GetBytes("<!doctype html><html><head><meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; media-src 'self'; style-src 'unsafe-inline'\"><style>html,body{margin:0;height:100%;background:#050e17}video{width:100%;height:100%;object-fit:contain}</style></head><body><video controls playsinline preload='metadata' src='/index-audio.mp4'></video></body></html>"), writable: false), 200, "OK", "Content-Type: text/html; charset=utf-8");
				}
				else if (e.Request.Uri != "https://kanblaz-guide.local/index-audio.mp4")
				{
					e.Response = environment.CreateWebResourceResponse(null, 404, "Not Found", "");
				}
				else
				{
					byte[] array = File.ReadAllBytes(videoPath);
					int result = 0;
					int num = array.Length - 1;
					bool flag = false;
					if (e.Request.Headers.Contains("Range"))
					{
						Match match = Regex.Match(e.Request.Headers.GetHeader("Range"), "^bytes=(\\d+)-(\\d*)$");
						if (!match.Success || !int.TryParse(match.Groups[1].Value, out result) || result >= array.Length || (match.Groups[2].Value.Length > 0 && (!int.TryParse(match.Groups[2].Value, out var result2) || result2 < result)))
						{
							e.Response = environment.CreateWebResourceResponse(null, 416, "Range Not Satisfiable", "Content-Range: bytes */" + array.Length);
							return;
						}
						if (match.Groups[2].Value.Length > 0)
						{
							num = Math.Min(int.Parse(match.Groups[2].Value), num);
						}
						flag = true;
					}
					int count = num - result + 1;
					MemoryStream content = new MemoryStream(array, result, count, writable: false);
					string text = "Content-Type: video/mp4\r\nAccept-Ranges: bytes\r\nContent-Length: " + count + "\r\nCache-Control: no-store";
					if (flag)
					{
						text = text + "\r\nContent-Range: bytes " + result + "-" + num + "/" + array.Length;
					}
					e.Response = environment.CreateWebResourceResponse(content, flag ? 206 : 200, flag ? "Partial Content" : "OK", text);
				}
			};
			player.CoreWebView2.NewWindowRequested += (object s, CoreWebView2NewWindowRequestedEventArgs e) =>
			{
				e.Handled = true;
			};
			player.CoreWebView2.NavigationStarting += (object s, CoreWebView2NavigationStartingEventArgs e) =>
			{
				if (e.Uri != "about:blank" && e.Uri != "https://kanblaz-guide.local/player")
				{
					e.Cancel = true;
				}
			};
			player.CoreWebView2.Navigate("https://kanblaz-guide.local/player");
		}
		catch (Exception ex)
		{
			if (!IsDisposed)
			{
				MessageBox.Show(this, (spanish ? "No se pudo abrir el video. " : "Could not open the video. ") + ex.Message, "KANBLAZ CLOUD");
			}
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			player.Dispose();
		}
		base.Dispose(disposing);
	}
}
