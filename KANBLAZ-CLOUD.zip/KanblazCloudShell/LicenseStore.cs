using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using KanblazLicensing;

namespace KanblazCloudShell;

internal static class LicenseStore
{
	private static readonly DeviceActivationStore DeviceStore = new DeviceActivationStore(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "activation-v2.dat"), "<RSAKeyValue><Modulus>uV/e4tsUMvzMBlhAzQ4gwaQw8QSgx0Wah5C0JQUSRgiLtO5Em4+GQooUJNh2CxXBuPwsxTHTPLwCJnodSYL/TlmpdpMRZDZUhQrDgbtbxncssTElv6bNHKZLb9QCvld4QFJeC1hHNrn/gxkWcB1aOKAMO/FS6fGjGGHzqf6puT0ABjHpZZPeZ2WP+fiCuGFCSIt6Cx8Iic0FMoRIo9XumRl/hge169iwpNtdFYh2VLoEn7fEvejkPpKviCJSc8mOn7iP/9NVbRD4pkPPu8nkjb25xoIbL5/5jURJjxnF4MeRkfkbOIe29f9bJDezu++JDX9u7yHALUSsV/MX9Hgo9Q==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>", "<RSAKeyValue><Modulus>z+0SswZHJ9ShjUuLF+ctkJyV3slNpbLAstAzP237QaYFuVi3r8TEX6a88rO7sFQ/TAwlR1zQr4Q4uOpuS6EvlHt5Xbx6mQU49lZk5PwEsnSroL4R6btiLBwGsi9dutqBzWKH9QKVNk9xFsen8rpkkVK987U9b5Klcza6YLwMwzjScqhHrZy1SBJk9xObrnjwa97O3Z91vejNJ0mZJna7jnS3mxRrHOsBrBLHT61+db7rIhy8S2q3yLwA7WdqfGWw0TVONMgvyCFMWKXmg0L3LTSXxJZPjsqKikedYVMJ8Vwe4LDeVXCf5lxoIE/K6uITwfzksx5Cl+EPk0L8PI3ZZQ==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>", DeviceActivationStore.WindowsDevice, new ActivationServer());

	private static readonly byte[] ProtectionEntropy = Encoding.UTF8.GetBytes("Kanblaz Cloud Shell activation v1");

	private static readonly string ActivationPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell Prototype", "activation.dat");

	internal static bool HasValidActivation()
	{
		LicenseRecord license;
		return TryLoadActivation(out license);
	}

	internal static bool TryLoadActivation(out LicenseRecord license)
	{
		license = null;
		if (DeviceStore.HasRecord)
		{
			if (!DeviceStore.TryLoad(out var license2))
			{
				return false;
			}
			license = new LicenseRecord
			{
				LicenseId = license2.Id,
				OwnerLabel = license2.Label,
				RequiresServer = true
			};
			return true;
		}
		if (!File.Exists(ActivationPath))
		{
			return false;
		}
		try
		{
			byte[] encryptedData = File.ReadAllBytes(ActivationPath);
			return TryValidateCode(Encoding.UTF8.GetString(ProtectedData.Unprotect(encryptedData, ProtectionEntropy, DataProtectionScope.CurrentUser)), out license) && !license.RequiresServer;
		}
		catch
		{
			return false;
		}
	}

	internal static bool TryActivate(string code, out string error)
	{
		if (!TryValidateCode(code, out var license) || license.RequiresServer)
		{
			error = "The activation code is invalid.";
			return false;
		}
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(ActivationPath));
			byte[] bytes = ProtectedData.Protect(Encoding.UTF8.GetBytes(NormalizeCode(code)), ProtectionEntropy, DataProtectionScope.CurrentUser);
			File.WriteAllBytes(ActivationPath, bytes);
			DeviceStore.RemoveRecord();
			error = null;
			return true;
		}
		catch (Exception ex)
		{
			error = "Activation could not be saved: " + ex.Message;
			return false;
		}
	}

	internal static bool TryValidateCode(string code, out LicenseRecord license)
	{
		if (LicenseProtocol.TryLicense(code, out var license2))
		{
			license = new LicenseRecord
			{
				LicenseId = license2.Id,
				OwnerLabel = license2.Label,
				RequiresServer = license2.RequiresServer
			};
			return true;
		}
		license = null;
		return false;
	}

	internal static async Task<string> ActivateAsync(string code)
	{
		if (!TryValidateCode(code, out var license))
		{
			return "The activation code is invalid.";
		}
		string error;
		if (!license.RequiresServer)
		{
			return TryActivate(code, out error) ? null : error;
		}
		try
		{
			await DeviceStore.ActivateAsync(code);
			return null;
		}
		catch (OperationCanceledException)
		{
			return "Activation timed out. Check your Internet connection and try again; the same device does not use another activation slot.";
		}
		catch (HttpRequestException)
		{
			return "Could not connect to the server. Check your Internet connection and try again.";
		}
		catch (InvalidOperationException ex3)
		{
			return ex3.Message;
		}
		catch
		{
			return "Activation could not be completed or saved. Retry on this device; it does not use another activation slot.";
		}
	}

	internal static string NormalizeCode(string code)
	{
		return string.Concat((code ?? string.Empty).Where((char character) => !char.IsWhiteSpace(character)));
	}

	internal static string ToBase64Url(byte[] bytes)
	{
		return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-')
			.Replace('/', '_');
	}

	internal static byte[] FromBase64Url(string value)
	{
		string text = (value ?? string.Empty).Replace('-', '+').Replace('_', '/');
		switch (text.Length % 4)
		{
		case 2:
			text += "==";
			break;
		case 3:
			text += "=";
			break;
		case 1:
			throw new FormatException("Invalid Base64.");
		}
		return Convert.FromBase64String(text);
	}
}
