using System;

namespace KanblazCloudShell;

internal sealed class CloudService
{
	internal static readonly CloudService Xbox = new CloudService("xbox", "Xbox Cloud Gaming", "https://www.xbox.com/en-US/play/launch/fortnite/BT5P2X999VH2");

	internal static readonly CloudService Geforce = new CloudService("geforce", "GeForce NOW", "https://play.geforcenow.com/");

	internal static readonly CloudService Luna = new CloudService("luna", "Amazon Luna", "https://luna.amazon.com/");

	public string Id { get; private set; }

	public string Name { get; private set; }

	public string LaunchUrl { get; private set; }

	private CloudService(string id, string name, string launchUrl)
	{
		Id = id;
		Name = name;
		LaunchUrl = launchUrl;
	}

	internal static CloudService FromId(string id)
	{
		if (!string.Equals(id, Xbox.Id, StringComparison.OrdinalIgnoreCase))
		{
			if (!string.Equals(id, Geforce.Id, StringComparison.OrdinalIgnoreCase))
			{
				if (!string.Equals(id, Luna.Id, StringComparison.OrdinalIgnoreCase))
				{
					return null;
				}
				return Luna;
			}
			return Geforce;
		}
		return Xbox;
	}

	public override string ToString()
	{
		return Name;
	}
}
