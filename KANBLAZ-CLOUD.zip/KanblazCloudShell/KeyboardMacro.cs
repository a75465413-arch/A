using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class KeyboardMacro
{
	internal static async Task PlayIndependent(IList<Func<Task>> workers, Action<int, Exception> failed)
	{
		List<Task> list = new List<Task>();
		for (int i = 0; i < workers.Count; i++)
		{
			list.Add(RunWorker(workers[i], i, failed));
		}
		await Task.WhenAll(list);
	}

	private static async Task RunWorker(Func<Task> worker, int index, Action<int, Exception> failed)
	{
		try
		{
			await worker();
		}
		catch (OperationCanceledException)
		{
		}
		catch (Exception arg)
		{
			failed(index, arg);
		}
	}

	internal static bool Allowed(Keys key)
	{
		string code;
		string name;
		return KeyboardPacket.Describe(key, out code, out name);
	}

	internal static void Validate(IList<RecordedKey> steps)
	{
		if (steps == null || steps.Count == 0 || steps.Count > 512)
		{
			throw new InvalidOperationException("Record 1-256 key presses first.");
		}
		HashSet<Keys> hashSet = new HashSet<Keys>();
		int num = 0;
		foreach (RecordedKey step in steps)
		{
			if (!Allowed(step.Key) || step.Delay < 0 || step.Delay > 60000)
			{
				throw new InvalidOperationException("Invalid macro key or delay.");
			}
			num += step.Delay;
			if (step.Down ? (!hashSet.Add(step.Key)) : (!hashSet.Remove(step.Key)))
			{
				throw new InvalidOperationException("Unbalanced key sequence.");
			}
		}
		if (hashSet.Count != 0 || num > 65000)
		{
			throw new InvalidOperationException("Macro must finish with all keys released (maximum 60 seconds recording).");
		}
	}

	internal static async Task Play(IList<RecordedKey> steps, IList<Func<Keys, bool, Task>> targets, bool repeat, int gap, CancellationToken cancel)
	{
		Validate(steps);
		if (targets.Count == 0 || gap < 100 || gap > 60000)
		{
			throw new InvalidOperationException("No ready game sessions or invalid repeat interval.");
		}
		Dictionary<Func<Keys, bool, Task>, HashSet<Keys>> pending = new Dictionary<Func<Keys, bool, Task>, HashSet<Keys>>();
		foreach (Func<Keys, bool, Task> target2 in targets)
		{
			pending[target2] = new HashSet<Keys>();
		}
		try
		{
			do
			{
				foreach (RecordedKey step in steps)
				{
					await Task.Delay(step.Delay, cancel);
					foreach (Func<Keys, bool, Task> target in targets)
					{
						cancel.ThrowIfCancellationRequested();
						if (step.Down)
						{
							pending[target].Add(step.Key);
						}
						await target(step.Key, step.Down);
						if (!step.Down)
						{
							pending[target].Remove(step.Key);
						}
					}
				}
				if (repeat)
				{
					await Task.Delay(gap, cancel);
				}
			}
			while (repeat);
		}
		finally
		{
			bool failed = false;
			foreach (KeyValuePair<Func<Keys, bool, Task>, HashSet<Keys>> pair in pending)
			{
				foreach (Keys key in pair.Value)
				{
					bool released = false;
					for (int attempt = 0; attempt < 3; attempt++)
					{
						if (released)
						{
							break;
						}
						try
						{
							await pair.Key(key, arg2: false);
							released = true;
						}
						catch
						{
							await Task.Delay(30);
						}
					}
					if (!released)
					{
						failed = true;
					}
				}
			}
			if (failed)
			{
				throw new InvalidOperationException("Key release failed. Close or restart the affected session.");
			}
		}
	}
}
