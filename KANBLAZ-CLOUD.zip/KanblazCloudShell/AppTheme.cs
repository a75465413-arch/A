using System;
using System.Drawing;

namespace KanblazCloudShell;

internal sealed class AppTheme
{
	internal Color Window { get; private set; }

	internal Color Surface { get; private set; }

	internal Color SurfaceRaised { get; private set; }

	internal Color Selection { get; private set; }

	internal Color Border { get; private set; }

	internal Color Accent { get; private set; }

	internal Color AccentText { get; private set; }

	internal Color Muted { get; private set; }

	internal Color Hover { get; private set; }

	internal Color ActiveBorder { get; private set; }

	internal Color Text { get; private set; } = Color.FromArgb(235, 245, 251);

	internal bool Glow { get; private set; }

	internal int GlowAlpha { get; private set; }

	internal static string Name(AppThemeKind kind)
	{
		if (kind != AppThemeKind.MidnightBlue)
		{
			return kind.ToString();
		}
		return "Midnight Blue";
	}

	internal static string Artwork(AppThemeKind kind)
	{
		return null;
	}

	internal static Color Blend(Color a, Color b, double amount)
	{
		amount = Math.Max(0.0, Math.Min(1.0, amount));
		return Color.FromArgb((int)((double)(int)a.R * (1.0 - amount) + (double)(int)b.R * amount), (int)((double)(int)a.G * (1.0 - amount) + (double)(int)b.G * amount), (int)((double)(int)a.B * (1.0 - amount) + (double)(int)b.B * amount));
	}

	internal static AppTheme Nexus(Color accent, bool light, bool glow, int strength)
	{
		Color window = (light ? Color.FromArgb(235, 243, 248) : Color.FromArgb(2, 8, 14));
		Color color = (light ? Color.FromArgb(249, 252, 255) : Color.FromArgb(3, 17, 27));
		Color color2 = (light ? Color.FromArgb(224, 237, 246) : Color.FromArgb(5, 25, 39));
		return new AppTheme(window, color, color2, Blend(color, accent, light ? 0.2 : 0.38), Blend(color2, accent, light ? 0.42 : 0.25), accent, Color.White, light ? Color.FromArgb(64, 88, 107) : Color.FromArgb(157, 193, 215))
		{
			Text = (light ? Color.FromArgb(15, 38, 55) : Color.FromArgb(235, 245, 251)),
			ActiveBorder = Blend(accent, light ? Color.Black : Color.FromArgb(20, 210, 255), 0.35),
			Hover = Blend(accent, light ? Color.White : Color.FromArgb(20, 210, 255), 0.24),
			Glow = (glow && strength > 0),
			GlowAlpha = 4 + Math.Max(0, Math.Min(100, strength)) / 3
		};
	}

	internal static Color Hsl(double hue, double saturation, double lightness)
	{
		double num = (hue % 360.0 + 360.0) % 360.0 / 60.0;
		double num2 = (1.0 - Math.Abs(2.0 * lightness - 1.0)) * saturation;
		double num3 = num2 * (1.0 - Math.Abs(num % 2.0 - 1.0));
		double num4 = lightness - num2 / 2.0;
		double num5 = 0.0;
		double num6 = 0.0;
		double num7 = 0.0;
		if (num < 1.0)
		{
			num5 = num2;
			num6 = num3;
		}
		else if (num < 2.0)
		{
			num5 = num3;
			num6 = num2;
		}
		else if (num < 3.0)
		{
			num6 = num2;
			num7 = num3;
		}
		else if (num < 4.0)
		{
			num6 = num3;
			num7 = num2;
		}
		else if (num < 5.0)
		{
			num5 = num3;
			num7 = num2;
		}
		else
		{
			num5 = num2;
			num7 = num3;
		}
		return Color.FromArgb((int)Math.Round((num5 + num4) * 255.0), (int)Math.Round((num6 + num4) * 255.0), (int)Math.Round((num7 + num4) * 255.0));
	}

	internal static AppTheme Matte(int hue, int strength)
	{
		double num = (double)Math.Max(0, Math.Min(100, strength)) / 100.0;
		return new AppTheme(Color.FromArgb(9, 13, 17), Color.FromArgb(14, 19, 24), Color.FromArgb(18, 25, 32), Hsl(hue, 0.2 + num * 0.357142857, 0.15), Color.FromArgb(35, 47, 57), Hsl(hue, Math.Min(1.0, num * 1.3), 0.48 + num * 0.02), Color.FromArgb(9, 13, 17), Color.FromArgb(150, 164, 179))
		{
			Hover = Hsl(hue, Math.Min(1.0, 0.55 + num * 0.5), 0.61 + num * 0.2),
			ActiveBorder = Hsl(hue, 0.35 + num * 0.5, 0.55)
		};
	}

	private AppTheme(Color window, Color surface, Color raised, Color selection, Color border, Color accent, Color accentText, Color muted)
	{
		Window = window;
		Surface = surface;
		SurfaceRaised = raised;
		Selection = selection;
		Border = border;
		Accent = accent;
		AccentText = accentText;
		Muted = muted;
	}

	internal static AppTheme For(AppThemeKind kind)
	{
		return kind switch
		{
			AppThemeKind.Ice => new AppTheme(Color.FromArgb(12, 23, 32), Color.FromArgb(20, 36, 48), Color.FromArgb(33, 52, 67), Color.FromArgb(40, 81, 97), Color.FromArgb(54, 85, 101), Color.FromArgb(165, 240, 246), Color.FromArgb(8, 34, 43), Color.FromArgb(174, 209, 219)), 
			AppThemeKind.Holiday => new AppTheme(Color.FromArgb(23, 12, 24), Color.FromArgb(34, 23, 35), Color.FromArgb(52, 30, 49), Color.FromArgb(89, 28, 59), Color.FromArgb(88, 49, 72), Color.FromArgb(255, 65, 136), Color.FromArgb(35, 3, 17), Color.FromArgb(218, 180, 203)), 
			AppThemeKind.Caramel => new AppTheme(Color.FromArgb(28, 19, 15), Color.FromArgb(42, 30, 22), Color.FromArgb(62, 44, 30), Color.FromArgb(95, 63, 39), Color.FromArgb(100, 75, 52), Color.FromArgb(237, 192, 137), Color.FromArgb(42, 23, 10), Color.FromArgb(207, 183, 156)), 
			AppThemeKind.Hearts => new AppTheme(Color.FromArgb(28, 15, 28), Color.FromArgb(42, 24, 40), Color.FromArgb(61, 32, 53), Color.FromArgb(100, 46, 76), Color.FromArgb(108, 58, 86), Color.FromArgb(255, 140, 194), Color.FromArgb(44, 9, 28), Color.FromArgb(220, 177, 205)), 
			AppThemeKind.MidnightBlue => new AppTheme(Color.FromArgb(7, 15, 29), Color.FromArgb(12, 25, 45), Color.FromArgb(18, 38, 65), Color.FromArgb(27, 65, 103), Color.FromArgb(55, 94, 128), Color.FromArgb(69, 167, 255), Color.FromArgb(4, 18, 31), Color.FromArgb(152, 185, 211)), 
			AppThemeKind.Emerald => new AppTheme(Color.FromArgb(7, 19, 16), Color.FromArgb(12, 31, 26), Color.FromArgb(20, 48, 39), Color.FromArgb(27, 72, 57), Color.FromArgb(49, 102, 82), Color.FromArgb(80, 224, 162), Color.FromArgb(4, 27, 18), Color.FromArgb(159, 199, 183)), 
			AppThemeKind.Crimson => new AppTheme(Color.FromArgb(22, 9, 13), Color.FromArgb(37, 14, 20), Color.FromArgb(57, 21, 30), Color.FromArgb(84, 30, 43), Color.FromArgb(119, 51, 67), Color.FromArgb(255, 103, 126), Color.FromArgb(38, 5, 12), Color.FromArgb(210, 166, 176)), 
			AppThemeKind.Violet => new AppTheme(Color.FromArgb(16, 10, 27), Color.FromArgb(28, 18, 45), Color.FromArgb(43, 29, 68), Color.FromArgb(66, 44, 100), Color.FromArgb(92, 67, 126), Color.FromArgb(180, 127, 255), Color.FromArgb(24, 8, 41), Color.FromArgb(193, 170, 216)), 
			_ => new AppTheme(Color.FromArgb(13, 15, 18), Color.FromArgb(19, 24, 30), Color.FromArgb(35, 41, 48), Color.FromArgb(37, 57, 73), Color.FromArgb(74, 87, 100), Color.FromArgb(221, 241, 255), Color.FromArgb(8, 21, 30), Color.FromArgb(170, 185, 198)), 
		};
	}
}
