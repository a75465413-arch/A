using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal static class CommunityLinks
{
	internal const string DiscordInvite = "https://discord.gg/SjNKDn68D";

	internal static ProcessStartInfo DiscordStartInfo()
	{
		return new ProcessStartInfo("https://discord.gg/SjNKDn68D")
		{
			UseShellExecute = true
		};
	}

	internal static LinkLabel CreateDiscordLink()
	{
		LinkLabel link = new LinkLabel
		{
			Text = "Join Discord ↗",
			AutoSize = true,
			TabStop = true,
			LinkColor = Color.FromArgb(170, 175, 255),
			ActiveLinkColor = Color.White,
			VisitedLinkColor = Color.FromArgb(170, 175, 255),
			Font = new Font("Segoe UI", 9f),
			Margin = new Padding(20, 4, 0, 0),
			AccessibleName = "Join the Kanblaz Discord server",
			AccessibleDescription = "Opens the Discord invitation in your default browser."
		};
		link.LinkClicked += delegate
		{
			try
			{
				Process.Start(DiscordStartInfo());
			}
			catch
			{
				MessageBox.Show(link.FindForm(), "Your browser could not be opened. Visit:\n\nhttps://discord.gg/SjNKDn68D", "KANBLAZ CLOUD", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
		};
		return link;
	}

	internal static Control CreateFooter()
	{
		return new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			WrapContents = true,
			FlowDirection = FlowDirection.LeftToRight,
			Margin = new Padding(0),
			Controls = 
			{
				(Control)new Label
				{
					AutoSize = true,
					Text = "© 2026 Kanblaz. All rights reserved.",
					ForeColor = Color.FromArgb(105, 124, 139),
					Font = new Font("Segoe UI", 8.5f),
					Margin = new Padding(2, 5, 0, 0)
				},
				(Control)CreateDiscordLink()
			}
		};
	}
}
