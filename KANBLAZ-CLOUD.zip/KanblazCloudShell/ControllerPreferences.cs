using System;
using System.IO;
using System.Text;

namespace KanblazCloudShell;

internal sealed class ControllerPreferences
{
	private readonly string path;

	internal ControllerPreferences(string path)
	{
		this.path = Path.GetFullPath(path);
	}

	internal static ControllerPreferences ForCurrentUser()
	{
		return new ControllerPreferences(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "controller-mode.txt"));
	}

	internal bool LoadShared()
	{
		try
		{
			if (!File.Exists(path) || new FileInfo(path).Length > 32)
			{
				return false;
			}
			return File.ReadAllText(path).Trim() == "shared";
		}
		catch (IOException)
		{
			return false;
		}
		catch (UnauthorizedAccessException)
		{
			return false;
		}
	}

	internal void Save(bool shared)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string sourceFileName = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			File.WriteAllText(sourceFileName, shared ? "shared" : "individual", new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
			if (File.Exists(path))
			{
				File.Replace(sourceFileName, path, null, ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(sourceFileName, path);
			}
		}
		finally
		{
			if (File.Exists(sourceFileName))
			{
				File.Delete(sourceFileName);
			}
		}
	}
}
