using System;
using System.Threading;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal sealed class ControllerRouting
{
	private readonly Func<bool, Task<string>> install;

	private readonly Action<string> remove;

	private readonly Func<bool, Task> apply;

	private readonly SemaphoreSlim gate = new SemaphoreSlim(1, 1);

	private bool desiredShared;

	private bool registeredShared;

	private string registration;

	internal ControllerRouting(Func<bool, Task<string>> install, Action<string> remove, Func<bool, Task> apply)
	{
		this.install = install;
		this.remove = remove;
		this.apply = apply;
	}

	internal async Task SetAsync(bool shared)
	{
		desiredShared = shared;
		await gate.WaitAsync();
		try
		{
			bool next = desiredShared;
			if (registration == null || registeredShared != next)
			{
				string obj = await install(next);
				try
				{
					if (registration != null)
					{
						remove(registration);
					}
				}
				catch
				{
					remove(obj);
					throw;
				}
				registration = obj;
				registeredShared = next;
			}
			await apply(desiredShared);
		}
		finally
		{
			gate.Release();
		}
	}
}
