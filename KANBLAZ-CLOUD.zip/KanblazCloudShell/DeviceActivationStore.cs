using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using KanblazLicensing;
using Microsoft.Win32;

namespace KanblazCloudShell;

internal sealed class DeviceActivationStore
{
	private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("KANBLAZ device activation v2");

	private readonly string path;

	private readonly string issuerKey;

	private readonly string receiptKey;

	private readonly Func<string, string> deviceForLicense;

	private readonly IActivationServer server;

	internal bool HasRecord => File.Exists(path);

	internal DeviceActivationStore(string path, string issuerKey, string receiptKey, Func<string, string> deviceForLicense, IActivationServer server)
	{
		this.path = path;
		this.issuerKey = issuerKey;
		this.receiptKey = receiptKey;
		this.deviceForLicense = deviceForLicense;
		this.server = server;
	}

	internal void RemoveRecord()
	{
		if (File.Exists(path))
		{
			File.Delete(path);
		}
	}

	internal bool TryLoad(out LicenseData license)
	{
		license = null;
		if (!HasRecord)
		{
			return false;
		}
		try
		{
			if (new FileInfo(path).Length > 32768)
			{
				return false;
			}
			string[] array = Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(path), Entropy, DataProtectionScope.CurrentUser)).Split('\n');
			if (array.Length != 2 || !LicenseProtocol.TryLicense(array[0], out var license2, issuerKey) || !license2.RequiresServer || !LicenseProtocol.TryReceipt(array[1], license2.Id, deviceForLicense(license2.Id), receiptKey))
			{
				return false;
			}
			license = license2;
			return true;
		}
		catch
		{
			return false;
		}
	}

	internal async Task ActivateAsync(string code)
	{
		code = LicenseProtocol.Normalize(code);
		if (!LicenseProtocol.TryLicense(code, out var license, issuerKey) || !license.RequiresServer)
		{
			throw new InvalidOperationException("The two-device activation code is invalid.");
		}
		string device = deviceForLicense(license.Id);
		if (!LicenseProtocol.IsDevice(device))
		{
			throw new InvalidOperationException("This device could not be identified.");
		}
		string text = await server.ActivateAsync(code, device).ConfigureAwait(continueOnCapturedContext: false);
		if (!LicenseProtocol.TryReceipt(text, license.Id, device, receiptKey))
		{
			throw new InvalidOperationException("The activation response could not be verified. No changes were saved.");
		}
		byte[] array = ProtectedData.Protect(Encoding.UTF8.GetBytes(code + "\n" + text), Entropy, DataProtectionScope.CurrentUser);
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string sourceFileName = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			using (FileStream fileStream = new FileStream(sourceFileName, FileMode.CreateNew, FileAccess.Write, FileShare.None))
			{
				fileStream.Write(array, 0, array.Length);
				fileStream.Flush(flushToDisk: true);
			}
			if (File.Exists(path))
			{
				File.Replace(sourceFileName, path, null);
			}
			else
			{
				File.Move(sourceFileName, path);
			}
		}
		finally
		{
			if (File.Exists(sourceFileName))
			{
				File.Delete(sourceFileName);
			}
		}
	}

	internal static string WindowsDevice(string licenseId)
	{
		using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
		using RegistryKey registryKey2 = registryKey.OpenSubKey("SOFTWARE\\Microsoft\\Cryptography", writable: false);
		return LicenseProtocol.DeviceHash((registryKey2 == null) ? null : (registryKey2.GetValue("MachineGuid") as string), licenseId);
	}
}
