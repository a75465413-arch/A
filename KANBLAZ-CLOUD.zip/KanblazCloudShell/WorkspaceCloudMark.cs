using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceCloudMark : Control
{
	internal Color Accent = Color.FromArgb(68, 220, 241);

	internal string PerformanceCaption = "Performance mode";

	private Image logo;

	internal WorkspaceCloudMark()
	{
		DoubleBuffered = true;
		SetStyle(ControlStyles.SupportsTransparentBackColor, value: true);
		BackColor = Color.Transparent;
		string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "nexus-header-transparent.png");
		if (!File.Exists(text))
		{
			text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "kanblaz-app-icon.png");
		}
		if (!PerformanceMode.Enabled && File.Exists(text))
		{
			using (Image original = Image.FromFile(text))
			{
				logo = new Bitmap(original);
			}
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && logo != null)
		{
			logo.Dispose();
			logo = null;
		}
		base.Dispose(disposing);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		if (Width < 5 || Height < 5)
		{
			return;
		}
		if (PerformanceMode.Enabled)
		{
			int num = Math.Max(0, (Height - Font.Height - 20) / 2);
			TextRenderer.DrawText(e.Graphics, "KANBLAZ CLOUD", Font, new Rectangle(0, num, Width, Font.Height + 2), Accent, TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
			using Font font = new Font("Segoe UI", 8.5f);
			TextRenderer.DrawText(e.Graphics, PerformanceCaption, font, new Rectangle(0, num + Font.Height + 5, Width, 18), Color.FromArgb(158, 179, 191), TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
			return;
		}
		if (logo == null)
		{
			string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "nexus-header-transparent.png");
			if (File.Exists(text))
			{
				using Image original = Image.FromFile(text);
				logo = new Bitmap(original);
			}
		}
		if (logo != null)
		{
			float num2 = Math.Min((float)Width / (float)logo.Width, (float)Height / (float)logo.Height);
			int num3 = (int)((float)logo.Width * num2);
			int num4 = (int)((float)logo.Height * num2);
			e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			e.Graphics.DrawImage(logo, new Rectangle((Width - num3) / 2, (Height - num4) / 2, num3, num4));
			return;
		}
		GraphicsState gstate = e.Graphics.Save();
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		float num5 = Math.Min((float)Width / 62f, (float)Height / 48f);
		e.Graphics.TranslateTransform(((float)Width - 62f * num5) / 2f, ((float)Height - 48f * num5) / 2f);
		e.Graphics.ScaleTransform(num5, num5);
		using (GraphicsPath graphicsPath = new GraphicsPath())
		{
			using Pen pen = new Pen(Accent, 3.4f)
			{
				LineJoin = LineJoin.Round
			};
			graphicsPath.AddBezier(16, 40, 0, 40, 0, 19, 16, 19);
			graphicsPath.AddBezier(16, 19, 17, 0, 42, 0, 45, 21);
			graphicsPath.AddBezier(45, 21, 62, 19, 66, 40, 48, 40);
			graphicsPath.AddLine(48, 40, 16, 40);
			e.Graphics.DrawPath(pen, graphicsPath);
		}
		e.Graphics.Restore(gstate);
	}
}
