using System;
using System.IO;

namespace KanblazCloudShell;

internal sealed class XboxRecoveryPreferences
{
	internal bool Enabled = true;

	internal static readonly string DefaultPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "xbox-recovery.txt");

	internal static readonly XboxRecoveryPreferences Current = Load(DefaultPath);

	internal int Revision { get; private set; }

	internal static XboxRecoveryPreferences Load(string path)
	{
		XboxRecoveryPreferences xboxRecoveryPreferences = new XboxRecoveryPreferences();
		try
		{
			if (File.Exists(path))
			{
				bool result = default;
				xboxRecoveryPreferences.Enabled = (new FileInfo(path).Length < 16 && bool.TryParse(File.ReadAllText(path), out result)) & result;
			}
		}
		catch (IOException)
		{
			xboxRecoveryPreferences.Enabled = false;
		}
		catch (UnauthorizedAccessException)
		{
			xboxRecoveryPreferences.Enabled = false;
		}
		return xboxRecoveryPreferences;
	}

	internal void Save(string path, bool enabled)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
		string text = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			File.WriteAllText(text, enabled.ToString());
			if (File.Exists(path))
			{
				File.Replace(text, path, null, ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(text, path);
			}
			Enabled = enabled;
			Revision++;
		}
		finally
		{
			if (File.Exists(text))
			{
				File.Delete(text);
			}
		}
	}
}
