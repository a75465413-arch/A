using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using KanblazCloudShell.SoundAlerts;
using KanblazCloudShell.Updates;
using KanblazCloudShell.VisualAlerts;

namespace KanblazCloudShell;

internal sealed class ShellForm : Form, IMessageFilter
{
	[DataContract]
	private sealed class GameEntry
	{
		[DataMember]
		public Guid Id;

		[DataMember]
		public string Name;

		[DataMember]
		public string Destination;

		[DataMember]
		public string CustomUrl;

		public override string ToString()
		{
			return Name;
		}
	}

	[DataContract]
	private sealed class GameLibrary
	{
		[DataMember]
		public List<GameEntry> Games = new List<GameEntry>();

		[DataMember]
		public Dictionary<Guid, Guid> Folders = new Dictionary<Guid, Guid>();

		[DataMember]
		public Dictionary<Guid, Guid> Profiles = new Dictionary<Guid, Guid>();

		[DataMember]
		public List<GameMembership> Memberships = new List<GameMembership>();
	}

	[DataContract]
	private sealed class GameMembership
	{
		[DataMember]
		public Guid Profile;

		[DataMember]
		public Guid Game;

		[DataMember]
		public Guid Folder;
	}

	private const int FocusWindowLimit = 5;

	private const string LaunchColumn = "launch";

	private const string NameColumn = "name";

	private const string ServiceColumn = "service";

	private const string RemoveColumn = "remove";

	private readonly DataGridView profileGrid = new WorkspaceGlassGrid();

	private readonly ListBox groupList = new WorkspaceGlassList();

	private readonly Button addGroup = new WorkspaceButton();

	private readonly Button renameGroup = new WorkspaceButton();

	private readonly Button deleteGroup = new WorkspaceButton();

	private readonly Label status = new Label();

	private readonly Label activeUsersStatus = new Label();

	private readonly Label accessStatus = new Label();

	private readonly Button upgradePro = new WorkspaceButton();

	private readonly Button accountButton = new WorkspaceButton();

	private readonly CheckBox audioExperiment = new CheckBox();

	private readonly Button controllerMode = new WorkspaceButton();

	private readonly Label controllerHint = new Label();

	private readonly Button macroStart = new WorkspaceButton();

	private readonly Button macroStop = new Button();

	private Button selectAllButton;

	private Button launchSelectedButton;

	private Button launchFolderButton;

	private readonly CheckBox editLayout = new WorkspaceToggle();

	private readonly ThemeBanner themeBanner = new ThemeBanner();

	private readonly AccentPreferences accentPreferences = new AccentPreferences();

	private readonly TrackBar accentHue = new WorkspaceSlider
	{
		Minimum = 0,
		Maximum = 360,
		TickStyle = TickStyle.None,
		Width = 210,
		Height = 30,
		AutoSize = false,
		AccessibleName = "Accent hue",
		Tag = "hue-slider"
	};

	private readonly TrackBar accentStrength = new WorkspaceSlider
	{
		Minimum = 0,
		Maximum = 100,
		TickStyle = TickStyle.None,
		Width = 160,
		Height = 30,
		AutoSize = false,
		AccessibleName = "Accent strength"
	};

	private readonly Label accentValue = new Label
	{
		AutoSize = true,
		MinimumSize = new Size(125, 26)
	};

	private readonly Panel accentSwatch = new Panel
	{
		Width = 24,
		Height = 24
	};

	private readonly Button resetAccent = new WorkspaceButton
	{
		Text = "Reset to Kanblaz Default",
		AutoSize = true,
		FlatStyle = FlatStyle.Flat
	};

	private readonly System.Windows.Forms.Timer accentSaveTimer = new System.Windows.Forms.Timer
	{
		Interval = 350
	};

	private readonly System.Windows.Forms.Timer accentPreviewTimer = new System.Windows.Forms.Timer
	{
		Interval = 16
	};

	private readonly NexusPreferences nexus = NexusPreferences.Load();

	private AppTheme cachedNexusTheme;

	private Color cachedNexusAccent;

	private bool cachedNexusLight;

	private bool cachedNexusGlow;

	private AppLanguage uiLanguage = LanguagePreferences.Resolve(LanguagePreferences.ForCurrentUser().Load(), CultureInfo.CurrentUICulture);

	private readonly ControllerPreferences controllerPreferences;

	private readonly SessionLayoutPreferences layoutPreferences;

	private readonly ThemePreferences themePreferences;

	private readonly ComboBox layoutMode = new WorkspaceComboBox();

	private readonly ComboBox primarySession = new WorkspaceComboBox();

	private readonly CheckBox borderlessFullscreen = new WorkspaceToggle();

	private readonly ComboBox colorTheme = new ComboBox();

	private bool controllerShared;

	private bool macroToggleQueued;

	private readonly MacroGlobalShortcut macroShortcut = new MacroGlobalShortcut();

	private readonly System.Windows.Forms.Timer controllerOwnerTimer = new System.Windows.Forms.Timer
	{
		Interval = 16
	};

	private readonly XInputCapture xinput = new XInputCapture();

	private bool updatingControllerOwner;

	private readonly CheckBox soundAlertsEnabled = new CheckBox();

	private readonly CheckBox textAlertsEnabled = new CheckBox();

	private readonly Label soundStatus = new Label();

	private readonly LinkLabel previousProfiles = new LinkLabel();

	private readonly System.Windows.Forms.Timer activeUsersTimer = new System.Windows.Forms.Timer
	{
		Interval = 60000
	};

	private readonly System.Windows.Forms.Timer membershipTimer = new System.Windows.Forms.Timer
	{
		Interval = 60000
	};

	private bool membershipRefreshing;

	private string displayedMembership;

	private readonly List<Profile> profiles;

	private readonly List<ProfileGroup> groups;

	private readonly HashSet<Guid> selectedProfiles = new HashSet<Guid>();

	private readonly Dictionary<Guid, CloudSessionForm> sessions = new Dictionary<Guid, CloudSessionForm>();

	private readonly Dictionary<Guid, object> restartingProfiles = new Dictionary<Guid, object>();

	private int sessionCloseGeneration;

	private readonly Dictionary<Guid, WelcomeRecoveryBudget> welcomeRecoveryBudgets = new Dictionary<Guid, WelcomeRecoveryBudget>();

	private readonly ControllerTouchpad controllerTouchpad = new ControllerTouchpad();

	private IntPtr touchpadFocus;

	private readonly Icon appIcon;

	private MosaicHostForm mosaicHost;

	private bool activeUsersRefreshing;

	private bool deletingProfile;

	private AccessPolicy access;

	private Guid? groupFilter;

	private bool refreshingGroups;

	private bool refreshingCustomization;

	private AppThemeKind selectedTheme;

	private bool startupComplete;

	private GameLibrary gameLibrary = new GameLibrary();

	private Guid currentGame;

	private readonly string gameLibraryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "games-library.json");

	private bool gameLibraryWritable = true;

	private readonly ComboBox gameTabs = new WorkspaceComboBox
	{
		Dock = DockStyle.Fill,
		DropDownStyle = ComboBoxStyle.DropDownList,
		AccessibleName = "Games"
	};

	private readonly Button deleteGameButton = new WorkspaceButton
	{
		Text = "−",
		AccessibleName = "Delete game",
		Size = new Size(30, 30),
		Enabled = false
	};

	private readonly Button guideIcon = new WorkspaceButton
	{
		Text = "?",
		AccessibleName = "Quick Guide",
		Size = new Size(32, 32)
	};

	private readonly ComboBox workspaceLanguage = new WorkspaceComboBox
	{
		DropDownStyle = ComboBoxStyle.DropDownList,
		AccessibleName = "Language"
	};

	private readonly Dictionary<Control, string> workspaceLabels = new Dictionary<Control, string>();

	private static readonly Dictionary<string, string> SpanishWorkspace = new Dictionary<string, string>
	{
		{ "GAMES", "JUEGOS" },
		{ "FOLDERS", "CARPETAS" },
		{ "Language", "Idioma" },
		{ "+ New Folder", "+ Nueva carpeta" },
		{ "Rename", "Renombrar" },
		{ "Delete", "Eliminar" },
		{ "Account", "Cuenta" },
		{ "Settings", "Ajustes" },
		{ "Configure how Kanblaz Cloud works.", "Configura cómo funciona Kanblaz Cloud." },
		{ "Controller", "Control" },
		{ "Movement", "Movimiento" },
		{ "Appearance", "Apariencia" },
		{ "Performance", "Rendimiento" },
		{ "Performance mode", "Modo rendimiento" },
		{ "Layout mode", "Distribución" },
		{ "Main profile", "Profile principal" },
		{ "Borderless Gameplay", "Juego sin bordes" },
		{ "Edit Layout", "Editar distribución" },
		{ "Every 3 minutes · F2 to start / stop", "Cada 3 minutos · F2 inicia / detiene" },
		{ "Accent hue", "Color de acento" },
		{ "Intensity", "Intensidad" },
		{ "Reset accent", "Restablecer color" },
		{ "Launch All", "Abrir todos" },
		{ "Close All", "Cerrar todos" },
		{ "Close Selected", "Cerrar seleccionados" },
		{ "+ Add Profile", "+ Añadir Profile" },
		{ "More…", "Más…" },
		{ "Back to Settings", "Volver a ajustes" }
	};

	private readonly TextBox workspaceSearch = new WorkspaceSearchBox
	{
		Width = 260,
		AccessibleName = "Search profiles, folders and tags",
		BorderStyle = BorderStyle.FixedSingle
	};

	private readonly ComboBox workspaceFilter = new WorkspaceComboBox
	{
		Width = 145,
		DropDownStyle = ComboBoxStyle.DropDownList,
		FlatStyle = FlatStyle.Flat
	};

	private readonly ComboBox workspaceSort = new WorkspaceComboBox
	{
		Width = 140,
		DropDownStyle = ComboBoxStyle.DropDownList,
		FlatStyle = FlatStyle.Flat
	};

	private readonly Label workspaceSummary = new Label
	{
		AutoSize = true,
		Margin = new Padding(0, 8, 0, 10)
	};

	private readonly Label emptyWorkspace = new Label
	{
		Dock = DockStyle.Fill,
		TextAlign = ContentAlignment.MiddleCenter,
		Visible = false
	};

	private readonly FlowLayoutPanel selectionActions = new FlowLayoutPanel
	{
		AutoSize = true,
		Dock = DockStyle.Fill,
		WrapContents = true
	};

	private readonly Panel workspaceDrawer = new WorkspaceScrollPanel
	{
		Dock = DockStyle.Right,
		Width = 330,
		Visible = false,
		Padding = new Padding(16),
		AutoScroll = true
	};

	private readonly ToolTip workspaceTips = new ToolTip();

	private readonly Dictionary<Guid, WorkspaceProfileInfo> workspaceInfo = new Dictionary<Guid, WorkspaceProfileInfo>();

	private readonly Dictionary<Guid, string> workspaceStates = new Dictionary<Guid, string>();

	private readonly string workspaceInfoPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "workspace-info.json");

	private FlowLayoutPanel workspaceSettings;

	private Control appearanceControls;

	private bool workspaceReady;

	private string smartView = "All";

	private Point profileDragStart;

	private Guid? draggedProfile;

	private bool workspaceInfoWritable = true;

	private bool workspaceRefreshQueued;

	private Label inspectedState;

	private Guid inspectedId;

	private readonly Label workspaceTitle = new Label
	{
		AutoSize = true,
		Font = new Font("Segoe UI Semibold", 20f),
		ForeColor = Color.White
	};

	private readonly Label workspaceCount = new Label
	{
		AutoSize = true,
		Padding = new Padding(8, 5, 8, 5),
		Margin = new Padding(12, 6, 0, 0)
	};

	private readonly Label workspaceSelected = new Label
	{
		AutoSize = true,
		Margin = new Padding(0, 8, 0, 0)
	};

	private readonly Label workspaceLayoutHint = new Label
	{
		AutoSize = true,
		MaximumSize = new Size(258, 0)
	};

	private readonly HashSet<Button> workspaceButtons = new HashSet<Button>();

	private readonly List<WorkspaceCard> workspaceCards = new List<WorkspaceCard>();

	private TableLayoutPanel workspaceColumns;

	private WorkspaceCloudMark workspaceMark;

	private Button controllerSectionHeading;

	private Control controllerSectionContent;

	private Keys controllerModeKey;

	private SharedModeIndicator sharedModeIndicator;

	private bool controllerModeHeld;

	private bool modeTogglePending;

	private string shortcutScopeReason = "Not checked";

	private int modeRawPresses;

	private int squareRawPresses;

	private int modeHookPresses;

	private int squareHookPresses;

	private string modeShortcutResult = "Waiting for assigned key";

	private string squareShortcutResult = "Waiting for assigned key";

	private Control inlineShortcutEditor;

	private readonly FolderReferences folderReferences = new FolderReferences(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "folder-references.json"));

	private readonly HashSet<Guid> copiedProfiles = new HashSet<Guid>();

	private readonly Label vpnLed = new Label
	{
		Text = "○ VPN",
		AutoSize = true,
		ForeColor = Color.Gray,
		Margin = new Padding(12, 10, 0, 0),
		AccessibleName = "VPN status unknown"
	};

	private readonly System.Windows.Forms.Timer vpnTimer = new System.Windows.Forms.Timer
	{
		Interval = 30000
	};

	private bool vpnReading;

	private PhysicalInputHook manualHook;

	private readonly KeyboardReleaseMonitor keyboardRelease = new KeyboardReleaseMonitor();

	private readonly HoldState manualHold = new HoldState();

	private readonly Dictionary<CloudSessionForm, BroadcastEndpoint> manualTargets = new Dictionary<CloudSessionForm, BroadcastEndpoint>();

	private readonly System.Windows.Forms.Timer inputSafetyTimer = new System.Windows.Forms.Timer
	{
		Interval = 25
	};

	private CursorAid cursorAid;

	private string appliedCursorStamp;

	private Action<Keys> captureInputKey;

	private CancellationTokenSource recordedMacroCancel;

	private Task recordedMacroTask;

	private Action finishMacroRecording;

	private Action toggleRecordedMacro;

	private Keys recordedMacroKey;

	private bool recordedShortcutHeld;

	private bool recordingKeys;

	private bool recordedKeyConsumed;

	private bool recordedExternalAllowed;

	private int recordedShortcutGeneration;

	private IntPtr recordedExternalForeground;

	private bool hookReady;

	private bool inputClosing;

	private bool awaitingInputClose;

	private bool inputCloseComplete;

	private readonly HashSet<Keys> physicalReleaseHeld = new HashSet<Keys>();

	private bool updateChecking;

	private bool updateInstalling;

	private readonly bool privateTrial;

	private readonly CancellationTokenSource updateLifetime = new CancellationTokenSource();

	private AppTheme CurrentTheme
	{
		get
		{
			if (cachedNexusTheme == null || cachedNexusAccent != nexus.Accent || cachedNexusLight != nexus.Light || cachedNexusGlow != nexus.Glow)
			{
				cachedNexusAccent = nexus.Accent;
				cachedNexusLight = nexus.Light;
				cachedNexusGlow = nexus.Glow;
				cachedNexusTheme = (PerformanceMode.Enabled ? AppTheme.Matte(187, 70) : AppTheme.Nexus(nexus.Accent, nexus.Light, nexus.Glow, 20));
			}
			return cachedNexusTheme;
		}
	}

	private SessionLayoutMode EffectiveLayoutMode
	{
		get
		{
			if (!access.CanUseLayouts)
			{
				return SessionLayoutMode.Grid;
			}
			return layoutPreferences.Mode;
		}
	}

	private bool EffectiveBorderless => layoutPreferences.Borderless;

	private AppThemeKind EffectiveTheme
	{
		get
		{
			if (!access.CanUseColorThemes)
			{
				return AppThemeKind.Obsidian;
			}
			return selectedTheme;
		}
	}

	private IEnumerable<ProfileGroup> CurrentGameFolders => groups.Where((ProfileGroup g) => GameForFolder(g.Id) == currentGame);

	private static string ModeKeyPath => Path.Combine(Path.GetDirectoryName(InputPreferences.DefaultPath), "controller-mode-key.txt");

	private bool IsAllProfiles
	{
		get
		{
			if (groupFilter.HasValue)
			{
				return groupFilter.Value == Guid.Empty;
			}
			return false;
		}
	}

	internal event EventHandler StartupReady;

	private string Ui(string en, string es)
	{
		if (uiLanguage != AppLanguage.Spanish)
		{
			return en;
		}
		return es;
	}

	internal ShellForm()
		: this(ControllerPreferences.ForCurrentUser())
	{
	}

	internal void CompleteStartup()
	{
		if (!startupComplete && !IsDisposed)
		{
			startupComplete = true;
			StartupReady?.Invoke(this, EventArgs.Empty);
		}
	}

	internal ShellForm(ControllerPreferences controllerPreferences)
	{
		StartupTiming.Mark("shell-construction-start");
		this.controllerPreferences = controllerPreferences;
		layoutPreferences = SessionLayoutPreferences.ForCurrentUser();
		layoutPreferences.Load();
		themePreferences = ThemePreferences.ForCurrentUser();
		selectedTheme = themePreferences.Load();
		accentPreferences.Load();
		accentSaveTimer.Tick += delegate
		{
			if (!accentHue.Capture && !accentStrength.Capture)
			{
				SaveAccentPreferences();
			}
		};
		accentPreviewTimer.Tick += delegate
		{
			FlushAccentPreview();
		};
		accentHue.MouseCaptureChanged += delegate
		{
			if (!accentHue.Capture)
			{
				FlushAccentPreview();
			}
		};
		accentStrength.MouseCaptureChanged += delegate
		{
			if (!accentStrength.Capture)
			{
				FlushAccentPreview();
			}
		};
		FormClosed += delegate
		{
			accentPreviewTimer.Stop();
			accentPreviewTimer.Dispose();
			if (accentSaveTimer.Enabled)
			{
				SaveAccentPreferences();
			}
			accentSaveTimer.Dispose();
		};
		access = AccessPolicy.ForCurrentUser();
		controllerShared = controllerPreferences.LoadShared();
		profiles = ShellStorage.LoadProfiles();
		groups = ShellStorage.LoadGroups();
		appIcon = LoadIcon();
		Text = "KANBLAZ CLOUD";
		Icon = appIcon;
		StartPosition = FormStartPosition.CenterScreen;
		ClientSize = new Size(970, 546);
		MinimumSize = new Size(970, 546);
		FormBorderStyle = FormBorderStyle.Sizable;
		ShowInTaskbar = true;
		BackColor = Color.FromArgb(13, 15, 18);
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 10f, FontStyle.Regular, GraphicsUnit.Point);
		InputPreferences.Current = InputPreferences.Load(InputPreferences.DefaultPath);
		SuspendLayout();
		try
		{
			BuildInterface();
			StartupTiming.Mark("controls-created");
			BuildModernWorkspace();
			RefreshCustomizationAccess();
			RefreshGroups();
			RefreshProfiles(persist: false);
			ApplyTheme();
		}
		finally
		{
			ResumeLayout(performLayout: true);
		}
		StartupTiming.Mark("shell-construction-finished");
		Load += delegate
		{
			ConfigureStartupWindow(this, Screen.FromControl(this).WorkingArea);
			StartupTiming.Mark("startup-layout-finished");
		};
		Application.AddMessageFilter(this);
		Activated += delegate
		{
			if (startupComplete)
			{
				if (NativeInputOwnership.ForegroundWindow == Handle)
				{
					CursorAid.Recover();
				}
				RestoreShellToFront();
			}
		};
		StartupReady += async delegate
		{
			StartupTiming.Mark("shell-revealed");
			EventHandler firstIdle = null;
			firstIdle = delegate
			{
				Application.Idle -= firstIdle;
				StartupTiming.Mark("first-ui-idle");
				StartupTiming.Save();
			};
			Application.Idle += firstIdle;
			FormClosed += delegate
			{
				Application.Idle -= firstIdle;
			};
			StartManualInput();
			StartVpnStatus();
			if (!controllerTouchpad.Register(Handle))
			{
				status.Text = "Controller touchpad unavailable. F1 / F9 still release the mouse.";
			}
			if (!macroShortcut.Register(Handle))
			{
				status.Text = "F2 is used by another application. Use Start / Stop here.";
			}
			controllerOwnerTimer.Start();
			membershipTimer.Start();
			await RefreshMembershipAsync();
			if (ShellStorage.RecoveredBackup)
			{
				status.Text = "Profiles recovered from the local backup.";
			}
			await CheckUpdatesAsync(automatic: true);
		};
		controllerOwnerTimer.Tick += async delegate
		{
			if (!PerformanceMode.Enabled || (WindowState != FormWindowState.Minimized && macroStart.Text != (sessions.Values.Any((CloudSessionForm s) => s.MovementMacroRunning) ? Ui("Deactivate Movement (F2)", "Desactivar movimiento (F2)") : Ui("Start Movement (F2)", "Activar movimiento (F2)"))))
			{
				UpdateMovementButton();
			}
			await RefreshControllerOwnerAsync();
		};
		FormClosed += delegate
		{
			activeUsersTimer.Stop();
			updateLifetime.Cancel();
		};
		membershipTimer.Tick += async delegate
		{
			await RefreshMembershipAsync();
		};
		FormClosed += delegate
		{
			membershipTimer.Stop();
			membershipTimer.Dispose();
		};
	}

	internal static void ConfigureStartupWindow(Form window, Rectangle workingArea)
	{
		if (workingArea.Width > 0 && workingArea.Height > 0)
		{
			window.MinimumSize = new Size(Math.Min(window.MinimumSize.Width, workingArea.Width), Math.Min(window.MinimumSize.Height, workingArea.Height));
			int num = Math.Min(window.Width, workingArea.Width);
			int num2 = Math.Min(window.Height, workingArea.Height);
			window.StartPosition = FormStartPosition.Manual;
			window.Bounds = new Rectangle(workingArea.Left + (workingArea.Width - num) / 2, workingArea.Top + (workingArea.Height - num2) / 2, num, num2);
			window.WindowState = FormWindowState.Maximized;
		}
	}

	private void RestoreShellToFront()
	{
		if (WindowState == FormWindowState.Minimized)
		{
			WindowState = FormWindowState.Normal;
		}
		BeginInvoke((Action)(() =>
		{
			if (!IsDisposed)
			{
				Show();
				BringToFront();
				Activate();
			}
		}));
	}

	private void BuildInterface()
	{
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			Padding = new Padding(20),
			ColumnCount = 1,
			RowCount = 5,
			BackColor = BackColor
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		Controls.Add(tableLayoutPanel);
		Label value = new Label
		{
			AutoSize = true,
			Text = "KANBLAZ CLOUD",
			Font = new Font("Segoe UI Semibold", 20f),
			ForeColor = Color.White,
			Margin = new Padding(0, 0, 0, 3)
		};
		Label value2 = new Label
		{
			AutoSize = true,
			Text = (LaptopDevice.IsLaptop ? "Saved profiles · Release mouse: F1 / F9 / Q (laptop, in game)" : "Saved profiles · Release mouse: F1 / F9"),
			ForeColor = Color.FromArgb(170, 185, 198),
			Margin = new Padding(2, 0, 0, 6)
		};
		FlowLayoutPanel heading = new FlowLayoutPanel
		{
			AutoSize = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Dock = DockStyle.Fill
		};
		heading.Controls.Add(value);
		heading.Controls.Add(value2);
		themeBanner.Size = new Size(900, 54);
		heading.SizeChanged += delegate
		{
			themeBanner.Width = Math.Max(300, heading.ClientSize.Width - 6);
		};
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			WrapContents = true,
			MaximumSize = new Size(910, 0),
			Margin = new Padding(0, 0, 0, 4)
		};
		accessStatus.AutoSize = true;
		accessStatus.Font = new Font("Segoe UI Semibold", 9f);
		Label label = accessStatus;
		Color foreColor;
		if (access.Tier != AccessTier.Pro)
		{
			foreColor = CurrentTheme.Muted;
		}
		else
		{
			foreColor = (nexus.Light ? Color.FromArgb(115, 79, 0) : Color.FromArgb(255, 211, 92));
		}
		label.ForeColor = foreColor;
		accessStatus.Margin = new Padding(2, 7, 10, 0);
		flowLayoutPanel.Controls.Add(accessStatus);
		accountButton.AutoSize = true;
		accountButton.Height = 30;
		accountButton.FlatStyle = FlatStyle.Flat;
		accountButton.FlatAppearance.BorderColor = Color.FromArgb(80, 105, 122);
		accountButton.BackColor = Color.FromArgb(30, 36, 43);
		accountButton.ForeColor = Color.White;
		accountButton.Text = "Account";
		accountButton.Margin = new Padding(0, 0, 8, 0);
		accountButton.Click += OpenAccount;
		flowLayoutPanel.Controls.Add(accountButton);
		upgradePro.AutoSize = true;
		upgradePro.Height = 30;
		upgradePro.FlatStyle = FlatStyle.Flat;
		upgradePro.FlatAppearance.BorderColor = Color.FromArgb(255, 196, 64);
		upgradePro.BackColor = Color.FromArgb(50, 40, 18);
		upgradePro.ForeColor = Color.FromArgb(255, 224, 140);
		upgradePro.Text = "Upgrade to Pro";
		upgradePro.Margin = new Padding(0, 0, 16, 0);
		upgradePro.Click += UpgradeToPro;
		flowLayoutPanel.Controls.Add(upgradePro);
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Controller",
			AutoSize = true,
			Margin = new Padding(2, 5, 8, 0)
		});
		controllerMode.Width = 120;
		controllerMode.Height = 30;
		controllerMode.FlatStyle = FlatStyle.Flat;
		controllerMode.FlatAppearance.BorderColor = Color.FromArgb(80, 105, 122);
		controllerMode.BackColor = Color.FromArgb(30, 36, 43);
		controllerMode.ForeColor = Color.White;
		controllerMode.Text = (controllerShared ? "Shared" : "Individual");
		controllerMode.AccessibleName = "Controller mode";
		controllerMode.AccessibleDescription = "Click to switch between Individual and Shared. Applies live and is saved. Shared depends on service support.";
		controllerMode.Click += ControllerModeChanged;
		flowLayoutPanel.Controls.Add(controllerMode);
		controllerHint.AutoSize = true;
		controllerHint.Font = new Font("Segoe UI", 8f);
		controllerHint.ForeColor = Color.FromArgb(183, 196, 207);
		controllerHint.Margin = new Padding(8, 7, 0, 0);
		controllerHint.Text = ControllerModeHint();
		flowLayoutPanel.Controls.Add(controllerHint);
		Button[] array = new Button[1] { macroStart };
		foreach (Button button in array)
		{
			button.AutoSize = true;
			button.Size = new Size(175, 32);
			button.FlatStyle = FlatStyle.Flat;
			button.BackColor = Color.FromArgb(30, 36, 43);
			button.ForeColor = Color.White;
			button.FlatAppearance.BorderColor = Color.FromArgb(80, 105, 122);
			flowLayoutPanel.Controls.Add(button);
		}
		macroStart.Text = Ui("Start Movement (F2)", "Activar movimiento (F2)");
		macroStart.AccessibleName = "Run a 1.5-second circle now and every 3 minutes in all open game windows; F2 toggles Start and Stop";
		macroStart.Click += delegate
		{
			QueueMovementMacroToggle();
		};
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "3 min",
			AutoSize = true,
			Margin = new Padding(4, 8, 0, 0)
		});
		macroStop.Text = "Stop";
		macroStop.AccessibleName = "Stop all movement macros, cancel scheduled repeats and release virtual input";
		macroStop.Enabled = false;
		macroStop.Click += StopMovementMacros;
		heading.Controls.Add(flowLayoutPanel);
		heading.Controls.Add(BuildCustomizationRow());
		RefreshAccessDisplay();
		audioExperiment.Text = "Background audio (applies when opening sessions)";
		audioExperiment.AutoSize = true;
		audioExperiment.Checked = true;
		audioExperiment.Margin = new Padding(2, 0, 0, 10);
		audioExperiment.CheckedChanged += delegate
		{
			status.Text = "Close and reopen profiles to compare the setting " + (audioExperiment.Checked ? "enabled." : "disabled.");
		};
		soundAlertsEnabled.Text = "Sound alerts · " + SoundReferences.FileNames.Length + " sounds · " + 32 + " seconds (local analysis)";
		soundAlertsEnabled.AutoSize = true;
		soundAlertsEnabled.Checked = true;
		soundAlertsEnabled.Margin = new Padding(2, 0, 0, 2);
		soundAlertsEnabled.CheckedChanged += delegate
		{
			foreach (CloudSessionForm item in sessions.Values.ToList())
			{
				item.SetSoundAlertsEnabled(soundAlertsEnabled.Checked);
			}
			soundStatus.Text = (soundAlertsEnabled.Checked ? "Detector ready: open a profile to monitor its audio." : "Detector disabled; audio is not analyzed.");
		};
		textAlertsEnabled.Text = "Brainrot alerts · spawn / name / event log (local analysis)";
		textAlertsEnabled.AutoSize = true;
		textAlertsEnabled.Checked = true;
		textAlertsEnabled.Margin = new Padding(2, 0, 0, 2);
		textAlertsEnabled.CheckedChanged += delegate
		{
			foreach (CloudSessionForm item2 in sessions.Values.ToList())
			{
				item2.SetTextAlertsEnabled(textAlertsEnabled.Checked);
			}
			soundStatus.Text = (textAlertsEnabled.Checked ? "Text detector ready: watches the game notice area." : "Text detector and Eternal bell disabled.");
		};
		soundStatus.AutoSize = true;
		soundStatus.MaximumSize = new Size(880, 0);
		soundStatus.Font = new Font("Segoe UI", 8f);
		soundStatus.ForeColor = Color.FromArgb(183, 196, 207);
		soundStatus.Margin = new Padding(2, 0, 0, 8);
		soundStatus.Text = "Local analysis · no microphone or recordings · requires Windows 11/build 20348+";
		previousProfiles.AutoSize = true;
		previousProfiles.LinkColor = Color.FromArgb(170, 215, 248);
		previousProfiles.Margin = new Padding(2, 0, 0, 8);
		previousProfiles.LinkClicked += RestorePreviousProfiles;
		heading.Controls.Add(previousProfiles);
		tableLayoutPanel.Controls.Add(heading, 0, 0);
		tableLayoutPanel.Controls.Add(BuildProfileWorkspace(), 0, 1);
		FlowLayoutPanel flowLayoutPanel2 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			Padding = new Padding(0, 14, 0, 4)
		};
		flowLayoutPanel2.Controls.Add(CreateButton("Add Profile", AddProfile));
		selectAllButton = CreateButton("Select All", SelectAll);
		flowLayoutPanel2.Controls.Add(selectAllButton);
		flowLayoutPanel2.Controls.Add(CreateButton("Launch All", (object sender, EventArgs args) =>
		{
			LaunchProfiles(ProfilesInCurrentScope());
		}, primary: true));
		launchSelectedButton = CreateButton("Launch Selected", (object sender, EventArgs args) =>
		{
			LaunchProfiles(CheckedProfiles());
		}, primary: true);
		flowLayoutPanel2.Controls.Add(launchSelectedButton);
		launchFolderButton = CreateButton("Launch Folder", (object sender, EventArgs args) =>
		{
			if (access.CanUseGroups && groupFilter.HasValue && groupFilter.Value != Guid.Empty)
			{
				LaunchProfiles(ProfilesInCurrentScope());
			}
		}, primary: true);
		flowLayoutPanel2.Controls.Add(launchFolderButton);
		flowLayoutPanel2.Controls.Add(CreateButton("Close All", CloseAllSessionsButton));
		flowLayoutPanel2.Controls.Add(CreateButton("Close Selected", CloseSelectedSessions));
		tableLayoutPanel.Controls.Add(flowLayoutPanel2, 0, 2);
		status.AutoSize = true;
		status.ForeColor = Color.FromArgb(145, 166, 182);
		status.Margin = new Padding(2, 6, 20, 0);
		activeUsersStatus.AutoSize = true;
		activeUsersStatus.Text = "●  Checking active users…";
		activeUsersStatus.ForeColor = Color.FromArgb(88, 225, 132);
		activeUsersStatus.Font = new Font("Segoe UI Semibold", 9f);
		activeUsersStatus.Margin = new Padding(0, 6, 0, 0);
		activeUsersStatus.AccessibleDescription = "Approximate count. Only retrieves an anonymous total from Cloudflare.";
		FlowLayoutPanel flowLayoutPanel3 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			WrapContents = false,
			FlowDirection = FlowDirection.LeftToRight
		};
		flowLayoutPanel3.Controls.Add(status);
		tableLayoutPanel.Controls.Add(flowLayoutPanel3, 0, 3);
		tableLayoutPanel.Controls.Add(CommunityLinks.CreateFooter(), 0, 4);
	}

	private Control BuildCustomizationRow()
	{
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			WrapContents = true,
			MaximumSize = new Size(910, 0),
			Margin = new Padding(0, 0, 0, 8)
		};
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "PRO · Layout",
			AutoSize = true,
			Margin = new Padding(2, 7, 7, 0)
		});
		layoutMode.DropDownStyle = ComboBoxStyle.DropDownList;
		layoutMode.Width = 112;
		layoutMode.Items.AddRange(new object[3]
		{
			SessionLayoutMode.Mosaic,
			SessionLayoutMode.Grid,
			SessionLayoutMode.Focus
		});
		layoutMode.FlatStyle = FlatStyle.Flat;
		layoutMode.SelectedIndexChanged += LayoutModeChanged;
		flowLayoutPanel.Controls.Add(layoutMode);
		editLayout.Text = "Edit Layout";
		editLayout.AutoSize = true;
		editLayout.CheckedChanged += delegate
		{
			if (mosaicHost != null && !mosaicHost.IsDisposed)
			{
				mosaicHost.SetEditing(access.CanUseLayouts && editLayout.Checked);
			}
		};
		flowLayoutPanel.Controls.Add(editLayout);
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Main",
			AutoSize = true,
			Margin = new Padding(14, 7, 7, 0)
		});
		primarySession.DropDownStyle = ComboBoxStyle.DropDownList;
		primarySession.Width = 170;
		primarySession.SelectedIndexChanged += PrimarySessionChanged;
		flowLayoutPanel.Controls.Add(primarySession);
		borderlessFullscreen.Text = "Borderless Gameplay";
		borderlessFullscreen.AutoSize = true;
		borderlessFullscreen.Margin = new Padding(14, 6, 12, 0);
		borderlessFullscreen.CheckedChanged += BorderlessFullscreenChanged;
		borderlessFullscreen.Visible = true;
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Theme",
			AutoSize = true,
			Margin = new Padding(2, 7, 7, 0)
		});
		colorTheme.DropDownStyle = ComboBoxStyle.DropDownList;
		colorTheme.Width = 125;
		colorTheme.FlatStyle = FlatStyle.Flat;
		colorTheme.DrawMode = DrawMode.OwnerDrawFixed;
		colorTheme.ItemHeight = 26;
		colorTheme.DrawItem += (object sender, DrawItemEventArgs e) =>
		{
			if (e.Index >= 0)
			{
				AppThemeKind kind = (AppThemeKind)colorTheme.Items[e.Index];
				AppTheme appTheme = AppTheme.For(kind);
				using (SolidBrush brush = new SolidBrush(appTheme.Surface))
				{
					e.Graphics.FillRectangle(brush, e.Bounds);
				}
				using (SolidBrush brush2 = new SolidBrush(appTheme.Accent))
				{
					e.Graphics.FillEllipse(brush2, e.Bounds.X + 6, e.Bounds.Y + 7, 12, 12);
				}
				TextRenderer.DrawText(e.Graphics, AppTheme.Name(kind), e.Font, new Rectangle(e.Bounds.X + 25, e.Bounds.Y, e.Bounds.Width - 25, e.Bounds.Height), Color.White, TextFormatFlags.VerticalCenter);
				e.DrawFocusRectangle();
			}
		};
		colorTheme.Items.AddRange(new object[1] { AppThemeKind.Obsidian });
		colorTheme.Format += (object sender, ListControlConvertEventArgs args) =>
		{
			if (args.ListItem is AppThemeKind && (AppThemeKind)args.ListItem == AppThemeKind.MidnightBlue)
			{
				args.Value = "Midnight Blue";
			}
		};
		colorTheme.SelectedIndexChanged += ColorThemeChanged;
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Matte Black",
			AutoSize = true,
			Margin = new Padding(2, 7, 7, 0)
		});
		FlowLayoutPanel flowLayoutPanel2 = new FlowLayoutPanel
		{
			AutoSize = true,
			WrapContents = true,
			MaximumSize = new Size(900, 0),
			Margin = new Padding(0, 8, 0, 0)
		};
		flowLayoutPanel.SetFlowBreak(flowLayoutPanel.Controls[flowLayoutPanel.Controls.Count - 1], value: true);
		flowLayoutPanel2.Controls.Add(new Label
		{
			Text = "Accent Color",
			AutoSize = true,
			Margin = new Padding(2, 7, 7, 0)
		});
		Panel panel = new Panel
		{
			Width = 214,
			Height = 34
		};
		Panel rainbow = new Panel
		{
			Left = 12,
			Top = 0,
			Width = 190,
			Height = 6
		};
		rainbow.Paint += (object sender, PaintEventArgs e) =>
		{
			for (int i = 0; i < rainbow.Width; i++)
			{
				using Pen pen = new Pen(AppTheme.Hsl((double)i * 360.0 / (double)Math.Max(1, rainbow.Width - 1), 0.85, 0.68));
				e.Graphics.DrawLine(pen, i, 0, i, rainbow.Height);
			}
		};
		rainbow.Visible = false;
		accentHue.Top = 0;
		accentHue.Value = accentPreferences.Hue;
		accentStrength.Value = accentPreferences.Strength;
		panel.Controls.Add(rainbow);
		panel.Controls.Add(accentHue);
		flowLayoutPanel2.Controls.Add(panel);
		flowLayoutPanel2.Controls.Add(accentSwatch);
		flowLayoutPanel2.Controls.Add(accentValue);
		flowLayoutPanel2.Controls.Add(new Label
		{
			Text = "Intensity",
			AutoSize = true,
			Margin = new Padding(8, 7, 3, 0)
		});
		flowLayoutPanel2.Controls.Add(accentStrength);
		flowLayoutPanel2.Controls.Add(resetAccent);
		accentHue.ValueChanged += AccentChanged;
		accentStrength.ValueChanged += AccentChanged;
		resetAccent.Click += delegate
		{
			if (access.CanUseColorThemes)
			{
				refreshingCustomization = true;
				accentHue.Value = 187;
				accentStrength.Value = 70;
				refreshingCustomization = false;
				AccentChanged(this, EventArgs.Empty);
			}
		};
		flowLayoutPanel.Controls.Add(flowLayoutPanel2);
		return flowLayoutPanel;
	}

	private void AccentChanged(object sender, EventArgs args)
	{
		if (!refreshingCustomization && access.CanUseColorThemes)
		{
			accentPreferences.Hue = accentHue.Value;
			accentPreferences.Strength = accentStrength.Value;
			if (!accentPreviewTimer.Enabled)
			{
				accentPreviewTimer.Start();
			}
			accentSaveTimer.Stop();
			accentSaveTimer.Start();
		}
	}

	private void SaveAccentPreferences()
	{
		accentSaveTimer.Stop();
		try
		{
			accentPreferences.Save();
		}
		catch (IOException)
		{
			status.Text = "Accent preview applied, but the preference could not be saved.";
		}
		catch (UnauthorizedAccessException)
		{
			status.Text = "Accent preview applied, but the preference could not be saved.";
		}
	}

	private void RefreshCustomizationAccess()
	{
		refreshingCustomization = true;
		try
		{
			layoutMode.SelectedItem = EffectiveLayoutMode;
			borderlessFullscreen.Checked = EffectiveBorderless;
			colorTheme.SelectedItem = EffectiveTheme;
			layoutMode.Enabled = access.CanUseLayouts;
			editLayout.Enabled = access.CanUseLayouts;
			primarySession.Enabled = access.CanUseLayouts && sessions.Count > 0;
			borderlessFullscreen.Enabled = true;
			colorTheme.Enabled = access.CanUseColorThemes;
			TrackBar trackBar = accentHue;
			TrackBar trackBar2 = accentStrength;
			bool flag = (resetAccent.Enabled = access.CanUseColorThemes);
			bool enabled = (trackBar2.Enabled = flag);
			trackBar.Enabled = enabled;
			accentHue.Value = (access.CanUseColorThemes ? accentPreferences.Hue : 187);
			accentStrength.Value = (access.CanUseColorThemes ? accentPreferences.Strength : 70);
			layoutMode.AccessibleDescription = (access.CanUseLayouts ? "Choose the arrangement for open sessions." : "Layouts are available with Pro.");
			colorTheme.AccessibleDescription = (access.CanUseColorThemes ? "Choose and save the application color theme." : "Color themes are available with Pro.");
		}
		finally
		{
			refreshingCustomization = false;
		}
		RefreshPrimarySessions();
	}

	private void LayoutModeChanged(object sender, EventArgs args)
	{
		if (refreshingCustomization || !(layoutMode.SelectedItem is SessionLayoutMode))
		{
			return;
		}
		if (!access.CanUseLayouts)
		{
			RefreshCustomizationAccess();
			return;
		}
		SessionLayoutMode sessionLayoutMode = (SessionLayoutMode)layoutMode.SelectedItem;
		if (sessionLayoutMode == SessionLayoutMode.Focus && sessions.Count > 5)
		{
			RefreshCustomizationAccess();
			status.Text = Ui("Focus supports up to 5 windows. Close extra sessions or keep Mosaic or Grid.", "Focus admite hasta 5 ventanas. Cierra las sesiones adicionales o conserva Mosaic o Grid.");
			MessageBox.Show(this, status.Text, "Focus", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			return;
		}
		layoutPreferences.Mode = sessionLayoutMode;
		layoutPreferences.Save();
		if (mosaicHost != null && !mosaicHost.IsDisposed)
		{
			mosaicHost.SetLayout(layoutPreferences.Mode);
		}
		RefreshWorkspaceSummary();
		status.Text = ((layoutPreferences.Mode == SessionLayoutMode.Custom) ? "Custom layout active. Drag from a window's top edge or resize its edges; positions save automatically." : (layoutPreferences.Mode.ToString() + " layout applied."));
	}

	private void BorderlessFullscreenChanged(object sender, EventArgs args)
	{
		if (refreshingCustomization)
		{
			return;
		}
		layoutPreferences.Borderless = borderlessFullscreen.Checked;
		try
		{
			if (mosaicHost != null && !mosaicHost.IsDisposed)
			{
				mosaicHost.SetBorderless(layoutPreferences.Borderless);
			}
			else
			{
				layoutPreferences.Save();
			}
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			status.Text = "Borderless preference could not be saved.";
			return;
		}
		status.Text = (layoutPreferences.Borderless ? "Borderless fullscreen enabled." : "Resizable maximized window enabled.");
	}

	private void PrimarySessionChanged(object sender, EventArgs args)
	{
		if (!refreshingCustomization && primarySession.SelectedItem is Profile profile && access.CanUseLayouts)
		{
			layoutPreferences.PrimaryProfileId = profile.StorageKey;
			layoutPreferences.Save();
			if (mosaicHost != null && !mosaicHost.IsDisposed)
			{
				mosaicHost.SetPrimary(profile.StorageKey);
			}
		}
	}

	private void RefreshPrimarySessions()
	{
		refreshingCustomization = true;
		try
		{
			Guid primaryProfileId = layoutPreferences.PrimaryProfileId;
			primarySession.Items.Clear();
			foreach (Profile item in profiles.Where((Profile profile) => sessions.ContainsKey(profile.StorageKey)))
			{
				primarySession.Items.Add(item);
			}
			int num = -1;
			for (int num2 = 0; num2 < primarySession.Items.Count; num2++)
			{
				if (((Profile)primarySession.Items[num2]).StorageKey == primaryProfileId)
				{
					num = num2;
					break;
				}
			}
			if (num < 0 && primarySession.Items.Count > 0)
			{
				num = 0;
			}
			primarySession.SelectedIndex = num;
			if (num >= 0)
			{
				layoutPreferences.PrimaryProfileId = ((Profile)primarySession.SelectedItem).StorageKey;
			}
			primarySession.Enabled = access.CanUseLayouts && primarySession.Items.Count > 0;
		}
		finally
		{
			refreshingCustomization = false;
		}
	}

	private void ColorThemeChanged(object sender, EventArgs args)
	{
		if (!refreshingCustomization && colorTheme.SelectedItem is AppThemeKind)
		{
			if (!access.CanUseColorThemes)
			{
				RefreshCustomizationAccess();
				return;
			}
			selectedTheme = (AppThemeKind)colorTheme.SelectedItem;
			themePreferences.Save(selectedTheme);
			ApplyTheme();
			status.Text = selectedTheme.ToString() + " theme applied.";
		}
	}

	private void ApplyTheme()
	{
		AppTheme currentTheme = CurrentTheme;
		themeBanner.SetTheme(EffectiveTheme);
		BackColor = currentTheme.Window;
		ApplyThemeTo(Controls, currentTheme);
		accentSwatch.BackColor = currentTheme.Accent;
		string text;
		switch (access.CanUseColorThemes ? accentPreferences.Hue : 187)
		{
		case 290:
		case 291:
		case 292:
		case 293:
		case 294:
		case 295:
		case 296:
		case 297:
		case 298:
		case 299:
		case 300:
		case 301:
		case 302:
		case 303:
		case 304:
		case 305:
		case 306:
		case 307:
		case 308:
		case 309:
		case 310:
		case 311:
		case 312:
		case 313:
		case 314:
		case 315:
		case 316:
		case 317:
		case 318:
		case 319:
		case 320:
		case 321:
		case 322:
		case 323:
		case 324:
		case 325:
		case 326:
		case 327:
		case 328:
		case 329:
		case 330:
		case 331:
		case 332:
		case 333:
		case 334:
		case 335:
		case 336:
		case 337:
		case 338:
		case 339:
		case 340:
		case 341:
		case 342:
		case 343:
		case 344:
			text = "Pink";
			break;
		case 250:
		case 251:
		case 252:
		case 253:
		case 254:
		case 255:
		case 256:
		case 257:
		case 258:
		case 259:
		case 260:
		case 261:
		case 262:
		case 263:
		case 264:
		case 265:
		case 266:
		case 267:
		case 268:
		case 269:
		case 270:
		case 271:
		case 272:
		case 273:
		case 274:
		case 275:
		case 276:
		case 277:
		case 278:
		case 279:
		case 280:
		case 281:
		case 282:
		case 283:
		case 284:
		case 285:
		case 286:
		case 287:
		case 288:
		case 289:
			text = "Purple";
			break;
		case 200:
		case 201:
		case 202:
		case 203:
		case 204:
		case 205:
		case 206:
		case 207:
		case 208:
		case 209:
		case 210:
		case 211:
		case 212:
		case 213:
		case 214:
		case 215:
		case 216:
		case 217:
		case 218:
		case 219:
		case 220:
		case 221:
		case 222:
		case 223:
		case 224:
		case 225:
		case 226:
		case 227:
		case 228:
		case 229:
		case 230:
		case 231:
		case 232:
		case 233:
		case 234:
		case 235:
		case 236:
		case 237:
		case 238:
		case 239:
		case 240:
		case 241:
		case 242:
		case 243:
		case 244:
		case 245:
		case 246:
		case 247:
		case 248:
		case 249:
			text = "Blue";
			break;
		case 160:
		case 161:
		case 162:
		case 163:
		case 164:
		case 165:
		case 166:
		case 167:
		case 168:
		case 169:
		case 170:
		case 171:
		case 172:
		case 173:
		case 174:
		case 175:
		case 176:
		case 177:
		case 178:
		case 179:
		case 180:
		case 181:
		case 182:
		case 183:
		case 184:
		case 185:
		case 186:
		case 187:
		case 188:
		case 189:
		case 190:
		case 191:
		case 192:
		case 193:
		case 194:
		case 195:
		case 196:
		case 197:
		case 198:
		case 199:
			text = "Cyan";
			break;
		case 80:
		case 81:
		case 82:
		case 83:
		case 84:
		case 85:
		case 86:
		case 87:
		case 88:
		case 89:
		case 90:
		case 91:
		case 92:
		case 93:
		case 94:
		case 95:
		case 96:
		case 97:
		case 98:
		case 99:
		case 100:
		case 101:
		case 102:
		case 103:
		case 104:
		case 105:
		case 106:
		case 107:
		case 108:
		case 109:
		case 110:
		case 111:
		case 112:
		case 113:
		case 114:
		case 115:
		case 116:
		case 117:
		case 118:
		case 119:
		case 120:
		case 121:
		case 122:
		case 123:
		case 124:
		case 125:
		case 126:
		case 127:
		case 128:
		case 129:
		case 130:
		case 131:
		case 132:
		case 133:
		case 134:
		case 135:
		case 136:
		case 137:
		case 138:
		case 139:
		case 140:
		case 141:
		case 142:
		case 143:
		case 144:
		case 145:
		case 146:
		case 147:
		case 148:
		case 149:
		case 150:
		case 151:
		case 152:
		case 153:
		case 154:
		case 155:
		case 156:
		case 157:
		case 158:
		case 159:
			text = "Green";
			break;
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
		case 52:
		case 53:
		case 54:
		case 55:
		case 56:
		case 57:
		case 58:
		case 59:
		case 60:
		case 61:
		case 62:
		case 63:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
		case 69:
		case 70:
		case 71:
		case 72:
		case 73:
		case 74:
		case 75:
		case 76:
		case 77:
		case 78:
		case 79:
			text = "Yellow";
			break;
		case 15:
		case 16:
		case 17:
		case 18:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
		case 26:
		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
		case 32:
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
			text = "Orange";
			break;
		default:
			text = "Red";
			break;
		}
		string text2 = text;
		accentValue.Text = text2 + "  " + ColorTranslator.ToHtml(currentTheme.Accent);
		controllerMode.BackColor = currentTheme.Selection;
		controllerMode.ForeColor = currentTheme.Text;
		controllerMode.FlatAppearance.BorderColor = currentTheme.ActiveBorder;
		controllerMode.FlatAppearance.BorderSize = 1;
		profileGrid.BackgroundColor = currentTheme.Surface;
		profileGrid.Tag = currentTheme;
		profileGrid.BorderStyle = BorderStyle.None;
		profileGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
		profileGrid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
		profileGrid.GridColor = currentTheme.Border;
		profileGrid.ColumnHeadersDefaultCellStyle.BackColor = currentTheme.SurfaceRaised;
		profileGrid.ColumnHeadersDefaultCellStyle.ForeColor = currentTheme.Muted;
		profileGrid.DefaultCellStyle.BackColor = currentTheme.Surface;
		profileGrid.DefaultCellStyle.SelectionBackColor = currentTheme.Selection;
		profileGrid.DefaultCellStyle.ForeColor = currentTheme.Text;
		profileGrid.DefaultCellStyle.SelectionForeColor = currentTheme.Text;
		profileGrid.Invalidate();
		groupList.Invalidate();
		groupList.BackColor = currentTheme.Surface;
		groupList.ForeColor = currentTheme.Text;
		status.ForeColor = currentTheme.Muted;
		soundStatus.ForeColor = currentTheme.Muted;
		controllerHint.ForeColor = currentTheme.Muted;
		activeUsersStatus.ForeColor = Color.FromArgb(88, 225, 132);
		previousProfiles.LinkColor = currentTheme.Accent;
		ApplyWorkspaceTheme(currentTheme);
		RefreshAccessDisplay();
		if (nexus.Light)
		{
			accessStatus.ForeColor = Color.FromArgb(115, 79, 0);
		}
	}

	private static void ApplyThemeTo(Control.ControlCollection controls, AppTheme theme)
	{
		foreach (Control control in controls)
		{
			if (control.ForeColor == Color.White)
			{
				control.ForeColor = theme.Text;
			}
			if (control is Panel || control is TableLayoutPanel || control is FlowLayoutPanel || control is SplitContainer)
			{
				control.BackColor = theme.Window;
			}
			if (control is Button button)
			{
				bool flag = string.Equals(Convert.ToString(button.Tag), "primary-button", StringComparison.Ordinal);
				button.BackColor = (flag ? theme.Accent : theme.SurfaceRaised);
				button.ForeColor = (flag ? theme.AccentText : theme.Text);
				button.FlatAppearance.BorderColor = (flag ? theme.Accent : theme.Border);
				button.FlatAppearance.BorderSize = 0;
				button.FlatAppearance.MouseOverBackColor = (flag ? theme.Hover : theme.Selection);
				button.FlatAppearance.MouseDownBackColor = (flag ? theme.Accent : theme.Selection);
			}
			if (control is ComboBox comboBox)
			{
				comboBox.BackColor = theme.Surface;
				comboBox.ForeColor = theme.Text;
			}
			if (control is TextBox textBox)
			{
				textBox.BackColor = theme.SurfaceRaised;
				textBox.ForeColor = theme.Text;
			}
			if (control is CheckBox checkBox)
			{
				checkBox.BackColor = theme.Window;
				checkBox.ForeColor = theme.Text;
				checkBox.FlatStyle = FlatStyle.Flat;
				checkBox.FlatAppearance.CheckedBackColor = theme.Selection;
				checkBox.FlatAppearance.BorderColor = theme.ActiveBorder;
			}
			if (control is TrackBar)
			{
				control.BackColor = theme.Window;
			}
			if (control is Label label && label.ForeColor != Color.FromArgb(242, 244, 245))
			{
				label.ForeColor = theme.Muted;
			}
			if (control is LinkLabel linkLabel)
			{
				linkLabel.LinkColor = theme.Accent;
			}
			if (control.HasChildren)
			{
				ApplyThemeTo(control.Controls, theme);
			}
		}
	}

	private string ControllerModeHint()
	{
		if (!controllerShared)
		{
			return Ui("Focused window only", "Solo la ventana en foco");
		}
		int num = sessions.Count((KeyValuePair<Guid, CloudSessionForm> pair) => !pair.Value.IsDisposed);
		if (num != 0)
		{
			return string.Format(Ui("Shared: all {0} open window(s)", "Shared: todas las ventanas abiertas ({0})"), num);
		}
		return Ui("Shared: open game windows to receive input", "Shared: abre ventanas de juego para recibir input");
	}

	private void RefreshAccessDisplay()
	{
		displayedMembership = access.AccessName;
		accessStatus.Text = ((access.Tier == AccessTier.Pro) ? (access.AccessName + " · Unlimited profiles and sessions") : "FREE · 2 profiles and sessions");
		Label label = accessStatus;
		Color foreColor;
		if (access.Tier != AccessTier.Pro)
		{
			foreColor = CurrentTheme.Muted;
		}
		else
		{
			foreColor = (nexus.Light ? Color.FromArgb(115, 79, 0) : Color.FromArgb(255, 211, 92));
		}
		label.ForeColor = foreColor;
		upgradePro.Visible = access.Tier == AccessTier.Free;
		upgradePro.BackColor = Color.FromArgb(50, 40, 18);
		upgradePro.ForeColor = Color.FromArgb(255, 224, 140);
		upgradePro.FlatAppearance.BorderColor = Color.FromArgb(255, 196, 64);
	}

	private void UpgradeToPro(object sender, EventArgs args)
	{
		OpenAccount(sender, args);
	}

	private async Task RefreshMembershipAsync()
	{
		if (membershipRefreshing || IsDisposed)
		{
			return;
		}
		membershipRefreshing = true;
		try
		{
			await GoogleAccountLogin.RefreshAccess(updateLifetime.Token);
		}
		catch
		{
		}
		finally
		{
			membershipRefreshing = false;
		}
		if (!IsDisposed && !(displayedMembership == access.AccessName))
		{
			RefreshAccessDisplay();
			RefreshCustomizationAccess();
			RefreshGroups();
			ApplyTheme();
			RefreshProfiles(persist: false);
		}
	}

	private void OpenAccount(object sender, EventArgs args)
	{
		using (AccountForm accountForm = new AccountForm(access, appIcon))
		{
			accountForm.ShowDialog(this);
			uiLanguage = LanguagePreferences.Resolve(LanguagePreferences.ForCurrentUser().Load(), CultureInfo.CurrentUICulture);
			UpdateMovementButton();
			UpdateSelectionButtons();
			RefreshGroups();
			ApplyTheme();
			RefreshProfiles(persist: false);
			if (!accountForm.AccessChanged)
			{
				return;
			}
		}
		access = AccessPolicy.ForCurrentUser();
		RefreshAccessDisplay();
		RefreshCustomizationAccess();
		RefreshGroups();
		ApplyTheme();
		RefreshProfiles();
		status.Text = ((access.Tier == AccessTier.Pro) ? "Pro unlocked. Profile and session limits removed." : "FREE - Existing profiles and settings are preserved.");
	}

	private void StartMovementMacros(object sender, EventArgs args)
	{
		int num = 0;
		foreach (CloudSessionForm item in sessions.Values.ToList())
		{
			if (item.StartMovementMacro())
			{
				num++;
			}
		}
		macroStop.Enabled = num > 0;
		UpdateMovementButton();
		status.Text = ((num == 0) ? "Open a game window first. The movement macro is off." : $"Joystick armed in {num} window(s) · 1.5s now, then every 3 min · F2 / Stop cancels.");
	}

	private async Task RefreshControllerOwnerAsync()
	{
		if (IsDisposed || updatingControllerOwner || !controllerMode.Enabled)
		{
			return;
		}
		updatingControllerOwner = true;
		try
		{
			List<CloudSessionForm> source = sessions.Values.Where((CloudSessionForm session) => !session.IsDisposed).ToList();
			if (controllerShared)
			{
				string text = ControllerModeHint();
				if (controllerHint.Text != text)
				{
					controllerHint.Text = text;
				}
				string pads = xinput.ReadJson();
				await Task.WhenAll(source.Select((CloudSessionForm session) => session.SetControllerBroadcastAsync(selected: true, pads)));
			}
			else
			{
				CloudSessionForm owner = source.FirstOrDefault((CloudSessionForm session) => session.HasNativeKeyboardFocus);
				if ((await Task.WhenAll(from session in source
					where session != owner && session.ControllerOwned
					select session.SetControllerOwnerAsync(owned: false))).All((bool value) => value) && owner != null && owner.HasNativeKeyboardFocus && !controllerShared)
				{
					await owner.SetControllerOwnerAsync(owned: true);
				}
			}
		}
		finally
		{
			updatingControllerOwner = false;
		}
	}

	protected override void WndProc(ref Message message)
	{
		if (message.Msg == 254)
		{
			controllerTouchpad.Remove(message.LParam);
		}
		if (message.Msg == 255)
		{
			ReadKeyboardRelease(message.LParam);
			HandleControllerTouchpad(message.LParam);
		}
		if (!TryWorkspaceResize(ref message))
		{
			if (message.Msg == 786 && message.WParam.ToInt32() == 19250 && macroShortcut.Registered)
			{
				QueueMovementMacroToggle();
			}
			else
			{
				base.WndProc(ref message);
			}
		}
	}

	private void HandleControllerTouchpad(IntPtr input)
	{
		IntPtr foregroundWindow = NativeInputOwnership.ForegroundWindow;
		MosaicHostForm mosaicHostForm = mosaicHost;
		bool flag = mosaicHostForm != null && !mosaicHostForm.IsDisposed && mosaicHostForm.IsHandleCreated && foregroundWindow == mosaicHostForm.Handle;
		if (foregroundWindow != Handle && !flag)
		{
			controllerTouchpad.Reset();
			touchpadFocus = IntPtr.Zero;
			return;
		}
		CloudSessionForm cloudSessionForm = (flag ? sessions.Values.FirstOrDefault((CloudSessionForm s) => !s.IsDisposed && s.ContainsFocus) : null);
		IntPtr intPtr = cloudSessionForm?.Handle ?? foregroundWindow;
		if (intPtr != touchpadFocus)
		{
			controllerTouchpad.Reset();
			touchpadFocus = intPtr;
		}
		if (!controllerTouchpad.Read(input, out var delta, out var release, out var mouseClick))
		{
			return;
		}
		if (mouseClick)
		{
			Point cursor = Cursor.Position;
			if (!flag && foregroundWindow == Handle && RectangleToScreen(ClientRectangle).Contains(cursor))
			{
				TouchpadMouseClick.ClickBrowser(Handle, cursor);
				return;
			}
			CloudSessionForm cloudSessionForm2 = (flag ? sessions.Values.FirstOrDefault((CloudSessionForm s) => s.CanTouchpadClick(cursor)) : null);
			if (cloudSessionForm2 != null)
			{
				cloudSessionForm?.ReleaseWindowMouseCapture();
				cloudSessionForm2.TouchpadClick(cursor);
			}
		}
		else if (release || !(delta == Point.Empty))
		{
			cloudSessionForm?.ReleaseWindowMouseCapture();
			if (delta != Point.Empty)
			{
				Rectangle rectangle = (flag ? mosaicHostForm.Bounds : Bounds);
				Point position = Cursor.Position;
				Cursor.Position = new Point(Math.Max(rectangle.Left, Math.Min(rectangle.Right - 1, position.X + delta.X)), Math.Max(rectangle.Top, Math.Min(rectangle.Bottom - 1, position.Y + delta.Y)));
			}
		}
	}

	public bool PreFilterMessage(ref Message message)
	{
		if (macroShortcut.Registered)
		{
			return false;
		}
		if (((long)message.WParam & 0xFFFF) != 113)
		{
			return false;
		}
		bool flag = IsHandleCreated && (ContainsFocus || NativeMouseCapture.IsFocusWithin(Handle));
		if (!flag && mosaicHost != null && !mosaicHost.IsDisposed && mosaicHost.IsHandleCreated)
		{
			flag = mosaicHost.ContainsFocus || NativeMouseCapture.IsFocusWithin(mosaicHost.Handle);
		}
		switch (MacroHotkey.ActionFor(message.Msg, 113, message.LParam.ToInt64(), flag, Control.ModifierKeys != Keys.None))
		{
		case 0:
			return false;
		case 2:
			QueueMovementMacroToggle();
			break;
		}
		return true;
	}

	private void QueueMovementMacroToggle()
	{
		if (macroToggleQueued || !macroStart.Enabled || IsDisposed)
		{
			return;
		}
		macroToggleQueued = true;
		BeginInvoke((Action)(() =>
		{
			macroToggleQueued = false;
			if (!IsDisposed && macroStart.Enabled)
			{
				if (sessions.Values.Any((CloudSessionForm session) => session.MovementMacroRunning))
				{
					StopMovementMacros(null, EventArgs.Empty);
				}
				else
				{
					StartMovementMacros(null, EventArgs.Empty);
				}
			}
		}));
	}

	private async void StopMovementMacros(object sender, EventArgs args)
	{
		macroStart.Enabled = false;
		macroStop.Enabled = false;
		try
		{
			bool[] source = await Task.WhenAll(from session in sessions.Values.ToList()
				select session.StopMovementMacroAsync());
			if (!IsDisposed)
			{
				status.Text = (source.All((bool value) => value) ? "Movement macros stopped. Manual control restored." : "Macros stopped; neutral input not confirmed in a window. Close that game window before continuing.");
			}
		}
		finally
		{
			if (!IsDisposed)
			{
				macroStart.Enabled = true;
				UpdateMovementButton();
			}
		}
	}

	private void UpdateMovementButton()
	{
		bool flag = sessions.Values.Any((CloudSessionForm s) => s.MovementMacroRunning);
		macroStart.BackColor = (flag ? CurrentTheme.Accent : CurrentTheme.SurfaceRaised);
		macroStart.ForeColor = (flag ? CurrentTheme.AccentText : Color.FromArgb(242, 244, 245));
		string text = (flag ? Ui("Deactivate Movement (F2)", "Desactivar movimiento (F2)") : Ui("Start Movement (F2)", "Activar movimiento (F2)"));
		if (macroStart.Text != text)
		{
			macroStart.Text = text;
		}
	}

	private async void ControllerModeChanged(object sender, EventArgs args)
	{
		controllerShared = !controllerShared;
		bool shared = controllerShared;
		RefreshControllerModeDisplay();
		bool saved = true;
		controllerMode.Enabled = false;
		controllerHint.Text = "Applying controller mode…";
		try
		{
			try
			{
				controllerPreferences.Save(shared);
			}
			catch (IOException)
			{
				saved = false;
			}
			catch (UnauthorizedAccessException)
			{
				saved = false;
			}
			bool[] source = await Task.WhenAll(from session in sessions.Values.ToList()
				select session.SetControllerSharedAsync(shared: false));
			if (!IsDisposed)
			{
				controllerHint.Text = ControllerModeHint();
				if (source.Any((bool success) => !success))
				{
					status.Text = "Some controller modes could not update; switch modes to retry.";
				}
				else if (!saved)
				{
					status.Text = "Controller mode applied now; could not save for the next launch.";
				}
			}
		}
		finally
		{
			if (!IsDisposed)
			{
				controllerMode.Enabled = true;
			}
		}
	}

	private async Task RefreshActiveUsersAsync()
	{
		if (activeUsersRefreshing || IsDisposed)
		{
			return;
		}
		activeUsersRefreshing = true;
		try
		{
			int? num = await ActivePresenceService.SendHeartbeatAsync();
			if (!IsDisposed)
			{
				if (num.HasValue)
				{
					activeUsersStatus.Text = string.Format("●  {0} user{1} online now", num.Value, (num.Value == 1) ? "" : "s");
					activeUsersStatus.AccessibleDescription = "Approximate active user count, updated from Cloudflare.";
				}
				else
				{
					activeUsersStatus.Text = "●  User count unavailable";
					activeUsersStatus.AccessibleDescription = "The active user count could not be retrieved.";
				}
			}
		}
		finally
		{
			activeUsersRefreshing = false;
		}
	}

	private Control BuildProfileWorkspace()
	{
		BuildProfileGrid();
		SplitContainer splitContainer = new SplitContainer
		{
			Size = new Size(900, 300),
			Dock = DockStyle.Fill,
			Orientation = Orientation.Vertical,
			SplitterDistance = 190,
			FixedPanel = FixedPanel.Panel1,
			Panel1MinSize = 160,
			Panel2MinSize = 520,
			BackColor = BackColor
		};
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 3,
			Padding = new Padding(0, 0, 10, 0),
			BackColor = BackColor
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.Controls.Add(new Label
		{
			Text = "FOLDERS",
			AutoSize = true,
			ForeColor = Color.FromArgb(177, 196, 210),
			Font = new Font("Segoe UI Semibold", 9f),
			Margin = new Padding(2, 0, 0, 7)
		}, 0, 0);
		groupList.Dock = DockStyle.Fill;
		groupList.BorderStyle = BorderStyle.FixedSingle;
		groupList.BackColor = Color.FromArgb(19, 24, 30);
		groupList.ForeColor = Color.White;
		groupList.Font = new Font("Segoe UI", 10f);
		groupList.IntegralHeight = false;
		groupList.DrawMode = DrawMode.OwnerDrawFixed;
		groupList.ItemHeight = 34;
		groupList.BorderStyle = BorderStyle.None;
		groupList.DrawItem += (object sender, DrawItemEventArgs e) =>
		{
			if (e.Index >= 0 && e.Index < groupList.Items.Count)
			{
				if (workspaceReady)
				{
					DrawWorkspaceFolder(e);
				}
				else
				{
					ProfileGroupOption option = (ProfileGroupOption)groupList.Items[e.Index];
					AppTheme currentTheme = CurrentTheme;
					using (SolidBrush brush = new SolidBrush(((e.State & DrawItemState.Selected) != 0) ? currentTheme.Selection : currentTheme.Surface))
					{
						e.Graphics.FillRectangle(brush, e.Bounds);
					}
					int num = profiles.Count((Profile p) => !option.Id.HasValue || p.GroupId == option.Id.Value);
					TextRenderer.DrawText(e.Graphics, option.Name + "  (" + num + ")", e.Font, new Rectangle(e.Bounds.X + 8, e.Bounds.Y, e.Bounds.Width - 10, e.Bounds.Height), Color.White, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
				}
			}
		};
		groupList.SelectedIndexChanged += GroupSelectionChanged;
		tableLayoutPanel.Controls.Add(groupList, 0, 1);
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			WrapContents = true,
			Padding = new Padding(0, 8, 0, 0),
			Margin = Padding.Empty
		};
		ConfigureGroupButton(addGroup, "+", AddGroup);
		ConfigureGroupButton(renameGroup, "Rename", RenameGroup);
		ConfigureGroupButton(deleteGroup, "Delete", DeleteGroup);
		flowLayoutPanel.Controls.Add(addGroup);
		flowLayoutPanel.Controls.Add(renameGroup);
		flowLayoutPanel.Controls.Add(deleteGroup);
		tableLayoutPanel.Controls.Add(flowLayoutPanel, 0, 2);
		splitContainer.Panel1.Controls.Add(tableLayoutPanel);
		splitContainer.Panel2.Controls.Add(profileGrid);
		return splitContainer;
	}

	private static void ConfigureGroupButton(Button button, string text, EventHandler action)
	{
		button.Text = text;
		button.AutoSize = true;
		button.FlatStyle = FlatStyle.Flat;
		button.BackColor = Color.FromArgb(35, 41, 48);
		button.ForeColor = Color.White;
		button.FlatAppearance.BorderColor = Color.FromArgb(74, 87, 100);
		button.Margin = new Padding(0, 0, 5, 0);
		button.Click += action;
	}

	private void RefreshGroups(Guid? select = null)
	{
		refreshingGroups = true;
		groupList.BeginUpdate();
		try
		{
			Guid? guid = select ?? groupFilter;
			groupList.Items.Clear();
			groupList.Items.Add(new ProfileGroupOption
			{
				Id = Guid.Empty,
				Name = Ui("All Profiles", "Todos los perfiles")
			});
			groupList.Items.Add(new ProfileGroupOption
			{
				Id = null,
				Name = Ui("Main Profiles", "Perfiles principales")
			});
			IEnumerable<ProfileGroup> source;
			if (!workspaceReady)
			{
				IEnumerable<ProfileGroup> enumerable = groups;
				source = enumerable;
			}
			else
			{
				source = CurrentGameFolders;
			}
			foreach (ProfileGroup item in source.Where((ProfileGroup value) => access.CanUseGroups).OrderBy((ProfileGroup value) => value.Name, StringComparer.CurrentCultureIgnoreCase))
			{
				groupList.Items.Add(new ProfileGroupOption
				{
					Id = item.Id,
					Name = item.Name
				});
			}
			int selectedIndex = 1;
			if (guid.HasValue)
			{
				for (int num = 0; num < groupList.Items.Count; num++)
				{
					if (((ProfileGroupOption)groupList.Items[num]).Id == guid)
					{
						selectedIndex = num;
						break;
					}
				}
			}
			groupList.SelectedIndex = selectedIndex;
			groupFilter = ((ProfileGroupOption)groupList.SelectedItem).Id;
			renameGroup.Enabled = groupFilter.HasValue && groupFilter.Value != Guid.Empty;
			deleteGroup.Enabled = renameGroup.Enabled;
			addGroup.Enabled = access.CanUseGroups;
			workspaceTips.SetToolTip(addGroup, access.CanUseGroups ? "New folder" : "Groups/Folders require Pro.");
		}
		finally
		{
			groupList.EndUpdate();
			refreshingGroups = false;
		}
	}

	private void GroupSelectionChanged(object sender, EventArgs args)
	{
		if (!refreshingGroups)
		{
			smartView = "All";
			CaptureVisibleSelection();
			groupFilter = (groupList.SelectedItem as ProfileGroupOption)?.Id;
			RememberFolder();
			renameGroup.Enabled = groupFilter.HasValue && groupFilter.Value != Guid.Empty;
			deleteGroup.Enabled = renameGroup.Enabled;
			RefreshProfiles(persist: false);
		}
	}

	private string PromptForGroupName(string title, string current)
	{
		using Form form = new Form
		{
			Text = title,
			StartPosition = FormStartPosition.CenterParent,
			ClientSize = new Size(380, 140),
			FormBorderStyle = FormBorderStyle.FixedDialog,
			MaximizeBox = false,
			MinimizeBox = false,
			ShowInTaskbar = false
		};
		using TextBox textBox = new TextBox
		{
			Text = (current ?? string.Empty),
			Location = new Point(18, 46),
			Width = 344,
			Font = new Font("Segoe UI", 11f)
		};
		using Button button = new Button
		{
			Text = "Save",
			DialogResult = DialogResult.OK,
			Location = new Point(206, 92),
			Width = 74
		};
		using Button button2 = new Button
		{
			Text = "Cancel",
			DialogResult = DialogResult.Cancel,
			Location = new Point(288, 92),
			Width = 74
		};
		form.Controls.Add(new Label
		{
			Text = "Folder name",
			AutoSize = true,
			Location = new Point(18, 18)
		});
		form.Controls.Add(textBox);
		form.Controls.Add(button);
		form.Controls.Add(button2);
		form.AcceptButton = button;
		form.CancelButton = button2;
		if (form.ShowDialog(this) != DialogResult.OK)
		{
			return null;
		}
		return textBox.Text;
	}

	private void AddGroup(object sender, EventArgs args)
	{
		if (!access.CanUseGroups)
		{
			return;
		}
		string text = PromptForGroupName("New folder", string.Empty);
		if (text == null)
		{
			return;
		}
		try
		{
			ProfileGroup profileGroup = ShellStorage.CreateGroup(text);
			gameLibrary.Folders[profileGroup.Id] = currentGame;
			SaveGameLibrary();
			groups.Add(profileGroup);
			groupFilter = profileGroup.Id;
			RefreshGroups(profileGroup.Id);
			RememberFolder();
			RefreshProfiles();
			status.Text = "Folder created. New profiles added here will stay in this folder.";
			AddExistingProfiles(profileGroup.Id);
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, ex.Message, "Folders", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void RenameGroup(object sender, EventArgs args)
	{
		if (!access.CanUseGroups || !groupFilter.HasValue)
		{
			return;
		}
		ProfileGroup profileGroup = groups.SingleOrDefault((ProfileGroup value) => value.Id == groupFilter.Value);
		if (profileGroup == null)
		{
			return;
		}
		string text = PromptForGroupName("Rename folder", profileGroup.Name);
		if (text == null)
		{
			return;
		}
		try
		{
			ShellStorage.RenameGroup(profileGroup.Id, text);
			profileGroup.Name = ProfileRepository.SafeGroupName(text);
			RefreshGroups(profileGroup.Id);
			status.Text = "Folder renamed. Profiles and saved sign-ins were unchanged.";
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, ex.Message, "Folders", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void DeleteGroup(object sender, EventArgs args)
	{
		if (!access.CanUseGroups || !groupFilter.HasValue)
		{
			return;
		}
		ProfileGroup group = groups.SingleOrDefault((ProfileGroup value) => value.Id == groupFilter.Value);
		if (group == null || MessageBox.Show(this, "Delete the folder ‘" + group.Name + "’?\n\nIts profiles will move to Main Profiles. No profile or saved sign-in will be deleted.", "Delete folder", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
		{
			return;
		}
		try
		{
			ShellStorage.DeleteGroup(group.Id);
			foreach (Profile item in profiles.Where((Profile p) => p.GroupId == group.Id))
			{
				gameLibrary.Profiles[item.StorageKey] = currentGame;
			}
			gameLibrary.Folders.Remove(group.Id);
			SaveGameLibrary();
			groups.RemoveAll((ProfileGroup value) => value.Id == group.Id);
			profiles.Clear();
			profiles.AddRange(ShellStorage.LoadProfiles());
			groupFilter = null;
			RefreshGroups();
			RememberFolder();
			RefreshProfiles();
			status.Text = "Folder deleted. Its profiles are still available in Main Profiles.";
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, ex.Message, "Folders", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
	}

	private void MoveCurrentProfileToGroup(object sender, EventArgs args)
	{
		if (!access.CanUseGroups)
		{
			return;
		}
		Profile profile = CurrentProfile();
		if (profile == null)
		{
			return;
		}
		using (Form form = new Form
		{
			Text = "Move profile",
			StartPosition = FormStartPosition.CenterParent,
			ClientSize = new Size(410, 150),
			FormBorderStyle = FormBorderStyle.FixedDialog,
			MaximizeBox = false,
			MinimizeBox = false,
			ShowInTaskbar = false
		})
		{
			using ComboBox comboBox = new ComboBox
			{
				Location = new Point(18, 50),
				Width = 374,
				DropDownStyle = ComboBoxStyle.DropDownList
			};
			using Button button = new Button
			{
				Text = "Move",
				DialogResult = DialogResult.OK,
				Location = new Point(236, 100),
				Width = 74
			};
			using Button button2 = new Button
			{
				Text = "Cancel",
				DialogResult = DialogResult.Cancel,
				Location = new Point(318, 100),
				Width = 74
			};
			comboBox.Items.Add(new ProfileGroupOption
			{
				Id = null,
				Name = "No folder"
			});
			IEnumerable<ProfileGroup> source;
			if (!workspaceReady)
			{
				IEnumerable<ProfileGroup> enumerable = groups;
				source = enumerable;
			}
			else
			{
				source = CurrentGameFolders;
			}
			foreach (ProfileGroup item in source.OrderBy((ProfileGroup value) => value.Name, StringComparer.CurrentCultureIgnoreCase))
			{
				comboBox.Items.Add(new ProfileGroupOption
				{
					Id = item.Id,
					Name = item.Name
				});
			}
			int selectedIndex = 0;
			for (int num = 1; num < comboBox.Items.Count; num++)
			{
				if (((ProfileGroupOption)comboBox.Items[num]).Id == profile.GroupId)
				{
					selectedIndex = num;
					break;
				}
			}
			comboBox.SelectedIndex = selectedIndex;
			form.Controls.Add(new Label
			{
				Text = "Move ‘" + profile.Label + "’ to",
				AutoSize = true,
				Location = new Point(18, 20)
			});
			form.Controls.Add(comboBox);
			form.Controls.Add(button);
			form.Controls.Add(button2);
			form.AcceptButton = button;
			form.CancelButton = button2;
			if (form.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			ProfileGroupOption profileGroupOption = (ProfileGroupOption)comboBox.SelectedItem;
			AssignWorkspaceFolder(new List<Profile> { profile }, profileGroupOption.Id ?? Guid.Empty);
		}
		ShellStorage.SaveProfiles(profiles);
		RefreshProfiles();
		status.Text = "Profile moved. Its saved sign-in was unchanged.";
	}

	private void BuildProfileGrid()
	{
		profileGrid.Dock = DockStyle.Fill;
		profileGrid.AllowUserToAddRows = false;
		profileGrid.AllowUserToDeleteRows = false;
		profileGrid.AllowUserToResizeRows = false;
		profileGrid.AutoGenerateColumns = false;
		profileGrid.BackgroundColor = Color.FromArgb(24, 28, 34);
		profileGrid.BorderStyle = BorderStyle.FixedSingle;
		profileGrid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
		profileGrid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
		{
			BackColor = Color.FromArgb(30, 36, 43),
			ForeColor = Color.FromArgb(177, 196, 210),
			Font = new Font("Segoe UI Semibold", 9f),
			Alignment = DataGridViewContentAlignment.MiddleLeft
		};
		profileGrid.DefaultCellStyle = new DataGridViewCellStyle
		{
			BackColor = Color.FromArgb(19, 24, 30),
			ForeColor = Color.White,
			SelectionBackColor = Color.FromArgb(37, 57, 73),
			SelectionForeColor = Color.White,
			Font = new Font("Segoe UI", 11f),
			Alignment = DataGridViewContentAlignment.MiddleLeft
		};
		profileGrid.EnableHeadersVisualStyles = false;
		profileGrid.GridColor = Color.FromArgb(55, 66, 78);
		profileGrid.MultiSelect = false;
		profileGrid.RowHeadersVisible = false;
		profileGrid.RowTemplate.Height = 46;
		profileGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
		profileGrid.Columns.Add(new DataGridViewCheckBoxColumn
		{
			CellTemplate = new ProfileSelectionCell(),
			Name = "launch",
			HeaderText = "LAUNCH",
			Width = 70,
			MinimumWidth = 60,
			FlatStyle = FlatStyle.Flat,
			ToolTipText = "Click anywhere in this cell to select or deselect this profile. Space also works."
		});
		profileGrid.Columns.Add(new DataGridViewTextBoxColumn
		{
			Name = "name",
			HeaderText = "PROFILE",
			AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
			ReadOnly = true
		});
		DataGridViewComboBoxColumn dataGridViewComboBoxColumn = new DataGridViewComboBoxColumn
		{
			Name = "service",
			HeaderText = "SERVICE",
			Width = 270,
			FlatStyle = FlatStyle.Flat
		};
		dataGridViewComboBoxColumn.ToolTipText = "Choose Xbox Cloud Gaming, GeForce NOW or Amazon Luna for this profile.";
		dataGridViewComboBoxColumn.Items.Add(CloudService.Xbox.Name);
		dataGridViewComboBoxColumn.Items.Add(CloudService.Geforce.Name);
		dataGridViewComboBoxColumn.Items.Add(CloudService.Luna.Name);
		profileGrid.Columns.Add(dataGridViewComboBoxColumn);
		profileGrid.Columns.Add(new DataGridViewButtonColumn
		{
			Name = "remove",
			HeaderText = "",
			Text = "×",
			UseColumnTextForButtonValue = true,
			Width = 52,
			FlatStyle = FlatStyle.Flat
		});
		profileGrid.CellClick += ProfileGridCellClick;
		profileGrid.CellDoubleClick += ProfileGridCellDoubleClick;
		profileGrid.CellValueChanged += ProfileGridCellValueChanged;
		profileGrid.CellPainting += ProfileGridCellPainting;
		ContextMenuStrip profileMenu = new ContextMenuStrip();
		profileMenu.Items.Add("Save profile for later", null, delegate
		{
			if (profileGrid.CurrentRow != null && profileGrid.CurrentRow.Tag is Profile profile)
			{
				if (sessions.TryGetValue(profile.StorageKey, out var value))
				{
					value.Close();
				}
				ShellStorage.ArchiveProfile(profile.StorageKey);
				selectedProfiles.Remove(profile.StorageKey);
				profiles.Clear();
				profiles.AddRange(ShellStorage.LoadProfiles());
				RefreshProfiles();
				status.Text = "Profile saved for later. Restore it with its saved sign-in using the saved profiles link.";
			}
		});
		profileMenu.Items.Add(new ToolStripSeparator());
		ToolStripItem moveToFolder = profileMenu.Items.Add("Move to folder… (Pro)", null, MoveCurrentProfileToGroup);
		profileMenu.Opening += delegate
		{
			moveToFolder.Enabled = access.CanUseGroups;
		};
		profileMenu.Opening += (object sender, CancelEventArgs args) =>
		{
			args.Cancel = profileGrid.CurrentRow == null;
		};
		profileGrid.ContextMenuStrip = profileMenu;
		profileGrid.Disposed += delegate
		{
			profileMenu.Dispose();
		};
		profileGrid.CellMouseDown += (object sender, DataGridViewCellMouseEventArgs args) =>
		{
			if (args.Button == MouseButtons.Right && args.RowIndex >= 0)
			{
				profileGrid.CurrentCell = profileGrid.Rows[args.RowIndex].Cells["name"];
			}
		};
		profileGrid.CurrentCellDirtyStateChanged += delegate
		{
			if (profileGrid.IsCurrentCellDirty)
			{
				profileGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
			}
		};
	}

	private Button CreateButton(string text, EventHandler handler, bool primary = false)
	{
		WorkspaceButton workspaceButton = new WorkspaceButton();
		workspaceButton.Text = text;
		workspaceButton.AutoSize = true;
		workspaceButton.FlatStyle = FlatStyle.Flat;
		workspaceButton.Padding = new Padding(11, 6, 11, 6);
		workspaceButton.BackColor = (primary ? Color.FromArgb(221, 241, 255) : Color.FromArgb(35, 41, 48));
		workspaceButton.ForeColor = (primary ? Color.FromArgb(8, 21, 30) : Color.White);
		workspaceButton.Margin = new Padding(0, 0, 8, 0);
		workspaceButton.Tag = (primary ? "primary-button" : null);
		workspaceButton.FlatAppearance.BorderColor = (primary ? Color.FromArgb(221, 241, 255) : Color.FromArgb(74, 87, 100));
		workspaceButton.Click += handler;
		return workspaceButton;
	}

	private Icon LoadIcon()
	{
		string fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "kanblaz.ico");
		try
		{
			return new Icon(fileName);
		}
		catch
		{
			return SystemIcons.Application;
		}
	}

	private void RefreshProfiles(bool persist = true)
	{
		CaptureVisibleSelection();
		selectedProfiles.IntersectWith(profiles.Select((Profile profile2) => profile2.StorageKey));
		List<Profile> values = ProfilesInCurrentScope();
		values = FilterWorkspaceProfiles(values);
		List<DataGridViewRow> list = new List<DataGridViewRow>();
		for (int num = 0; num < values.Count; num++)
		{
			Profile profile = values[num];
			if (string.IsNullOrWhiteSpace(profile.Label))
			{
				profile.Label = $"Profile {profiles.IndexOf(profile) + 1:00}";
			}
			DataGridViewRow dataGridViewRow = (DataGridViewRow)profileGrid.RowTemplate.Clone();
			dataGridViewRow.CreateCells(profileGrid, selectedProfiles.Contains(profile.StorageKey), profile.Label, profile.Service.Name, "×");
			dataGridViewRow.Tag = profile;
			list.Add(dataGridViewRow);
		}
		profileGrid.SuspendLayout();
		try
		{
			profileGrid.Rows.Clear();
			if (list.Count > 0)
			{
				profileGrid.Rows.AddRange(list.ToArray());
			}
			foreach (DataGridViewRow item in list)
			{
				UpdateWorkspaceRow(item, (Profile)item.Tag);
			}
		}
		finally
		{
			profileGrid.ResumeLayout(performLayout: true);
		}
		if (persist)
		{
			ShellStorage.SaveProfiles(profiles);
		}
		int count = ShellStorage.PendingProfiles.Count;
		groupList.Invalidate();
		UpdateSelectionButtons();
		previousProfiles.Visible = count > 0;
		RefreshWorkspaceSummary();
		previousProfiles.Text = $"Saved profiles ({count})";
		Label label = status;
		string text;
		if (profiles.Count != 0)
		{
			text = (access.HasUnlimitedProfiles ? $"{profiles.Count} profiles · Pro has no account limit. Check the profiles you want to open." : $"{profiles.Count}/2 Free profiles. Check the profiles you want to open.");
		}
		else
		{
			text = "Add your first profile. Each profile keeps its own local sign-in.";
		}
		label.Text = text;
	}

	private void AddProfile(object sender, EventArgs args)
	{
		if (access.AvailableProfileSlots(profiles.Count + ShellStorage.PendingProfiles.Count) == 0)
		{
			MessageBox.Show(this, Ui("Free supports 2 saved profiles, including profiles saved for later. Upgrade to Pro for unlimited profiles. Your existing profiles are preserved.", "Free admite 2 profiles guardados, incluidos los reservados para después. Actualiza a Pro para profiles ilimitados. Tus profiles existentes se conservan."), "Upgrade to Pro", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}
		else
		{
			TryAddProfile();
		}
	}

	private bool TryAddProfile()
	{
		if (workspaceReady && IsAllProfiles)
		{
			status.Text = Ui("Choose a folder before adding a profile.", "Elige una carpeta antes de añadir un perfil.");
			return false;
		}
		if (access.AvailableProfileSlots(profiles.Count + ShellStorage.PendingProfiles.Count) == 0)
		{
			return false;
		}
		Profile profile = new Profile
		{
			StorageKey = Guid.NewGuid(),
			ServiceId = CloudService.Xbox.Id,
			Label = $"Profile {profiles.Count + 1:00}",
			GroupId = ((!access.CanUseGroups) ? Guid.Empty : (groupFilter ?? Guid.Empty))
		};
		gameLibrary.Profiles[profile.StorageKey] = currentGame;
		if (!SaveGameLibrary())
		{
			gameLibrary.Profiles.Remove(profile.StorageKey);
			return false;
		}
		profiles.Add(profile);
		RefreshProfiles();
		if (profileGrid.Rows.Count > 0)
		{
			profileGrid.CurrentCell = profileGrid.Rows[profileGrid.Rows.Count - 1].Cells["name"];
		}
		return true;
	}

	private bool TryRestoreProfiles(IEnumerable<Guid> ids)
	{
		HashSet<Guid> requested = new HashSet<Guid>(ids);
		List<Profile> list = ShellStorage.PendingProfiles.Where((Profile p) => requested.Contains(p.StorageKey)).ToList();
		if (list.Count == 0 || list.Count > access.AvailableProfileSlots(profiles.Count))
		{
			return false;
		}
		if (!access.CanUseGroups && list.Any((Profile p) => p.GroupId != Guid.Empty))
		{
			return false;
		}
		ShellStorage.RestoreProfiles(list.Select((Profile p) => p.StorageKey));
		return true;
	}

	private void RestorePreviousProfiles(object sender, LinkLabelLinkClickedEventArgs args)
	{
		bool changed = false;
		bool deleting = false;
		Form dialog = new Form
		{
			Text = "Saved profiles",
			StartPosition = FormStartPosition.CenterParent,
			ClientSize = new Size(620, 410),
			FormBorderStyle = FormBorderStyle.FixedDialog,
			MaximizeBox = false,
			MinimizeBox = false
		};
		try
		{
			CheckedListBox list = new CheckedListBox
			{
				Location = new Point(16, 92),
				Size = new Size(588, 250),
				CheckOnClick = true
			};
			try
			{
				Button restore = new Button
				{
					Text = "Restore Selected",
					Location = new Point(16, 360),
					Size = new Size(195, 32),
					Enabled = false
				};
				try
				{
					Button remove = new Button
					{
						Text = "Delete Selected",
						Location = new Point(222, 360),
						Size = new Size(195, 32),
						ForeColor = Color.Firebrick,
						Enabled = false
					};
					try
					{
						using Button button = new Button
						{
							Text = "Close",
							Location = new Point(496, 360),
							Size = new Size(108, 32),
							DialogResult = DialogResult.Cancel
						};
						Label description = new Label
						{
							Location = new Point(16, 15),
							Size = new Size(588, 68)
						};
						try
						{
							Action refreshSaved = () =>
							{
								List<Profile> pendingProfiles = ShellStorage.PendingProfiles;
								list.Items.Clear();
								foreach (Profile item in pendingProfiles)
								{
									list.Items.Add(item);
								}
								restore.Enabled = false;
								remove.Enabled = false;
								Label label = description;
								string text = ((pendingProfiles.Count == 0) ? "There are no saved profiles waiting to be restored." : (access.HasUnlimitedProfiles ? $"{pendingProfiles.Count} saved profiles · Pro has unlimited profile slots.\nKept until you delete them. Check the profiles to restore or delete." : $"{pendingProfiles.Count} saved profiles · Available Free slots: {access.AvailableProfileSlots(profiles.Count)}/2.\nKept until you delete them. Check the profiles to restore or delete."));
								label.Text = text;
							};
							list.ItemCheck += (object obj, ItemCheckEventArgs e) =>
							{
								int num = list.CheckedItems.Count + ((e.NewValue == CheckState.Checked) ? 1 : 0) - ((e.CurrentValue == CheckState.Checked) ? 1 : 0);
								restore.Enabled = num > 0 && num <= access.AvailableProfileSlots(profiles.Count);
								remove.Enabled = num > 0;
							};
							refreshSaved();
							restore.Click += delegate
							{
								List<Guid> list2 = (from Profile p in list.CheckedItems
									select p.StorageKey).ToList();
								if (list2.Count == 0 || list2.Count > access.AvailableProfileSlots(profiles.Count))
								{
									return;
								}
								try
								{
									if (TryRestoreProfiles(list2))
									{
										dialog.DialogResult = DialogResult.OK;
									}
									else
									{
										MessageBox.Show(dialog, Ui("Free allows two active profiles. Restoring folder profiles requires Pro.", "Free permite dos profiles activos. Restaurar profiles de carpetas requiere Pro."), "Upgrade to Pro");
									}
								}
								catch (Exception ex)
								{
									MessageBox.Show(dialog, ex.Message, "Profiles", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								}
							};
							dialog.FormClosing += (object obj, FormClosingEventArgs e) =>
							{
								if (deleting)
								{
									e.Cancel = true;
								}
							};
							remove.Click += async delegate
							{
								List<Profile> list2 = list.CheckedItems.Cast<Profile>().ToList();
								if (list2.Count != 0)
								{
									string text = string.Join("\n", from p in list2.Take(8)
										select "• " + p.Label);
									if (list2.Count > 8)
									{
										text += $"\n… and {list2.Count - 8} more";
									}
									if (MessageBox.Show(dialog, $"Permanently delete {list2.Count} saved profile(s)?\n\n{text}\n\nTheir local sign-in data will be deleted. Other versions using these profiles will also lose those saved sign-ins. This cannot be undone.", "Delete saved profiles", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
									{
										List<string> errors = new List<string>();
										deleting = true;
										dialog.Enabled = false;
										description.Text = "Deleting selected profiles…";
										try
										{
											foreach (Profile profile in list2)
											{
												try
												{
													await ShellStorage.RemoveSavedProfileAsync(profile.StorageKey);
													changed = true;
												}
												catch (Exception ex)
												{
													errors.Add(profile.Label + ": " + ex.Message);
												}
											}
										}
										finally
										{
											deleting = false;
											dialog.Enabled = true;
										}
										refreshSaved();
										if (errors.Count > 0)
										{
											MessageBox.Show(dialog, "These profiles could not be deleted. Close other versions or windows using them and try again.\n\n" + string.Join("\n", errors), "Profiles not deleted", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
										}
									}
								}
							};
							dialog.CancelButton = button;
							dialog.Controls.Add(description);
							dialog.Controls.Add(list);
							dialog.Controls.Add(restore);
							dialog.Controls.Add(remove);
							dialog.Controls.Add(button);
							if (dialog.ShowDialog(this) == DialogResult.OK || changed)
							{
								profiles.Clear();
								profiles.AddRange(ShellStorage.LoadProfiles());
								RefreshProfiles();
							}
						}
						finally
						{
							if (description != null)
							{
								((IDisposable)description).Dispose();
							}
						}
					}
					finally
					{
						if (remove != null)
						{
							((IDisposable)remove).Dispose();
						}
					}
				}
				finally
				{
					if (restore != null)
					{
						((IDisposable)restore).Dispose();
					}
				}
			}
			finally
			{
				if (list != null)
				{
					((IDisposable)list).Dispose();
				}
			}
		}
		finally
		{
			if (dialog != null)
			{
				((IDisposable)dialog).Dispose();
			}
		}
	}

	private void SelectAll(object sender, EventArgs args)
	{
		bool flag = !profileGrid.Rows.Cast<DataGridViewRow>().All((DataGridViewRow r) => Convert.ToBoolean(r.Cells["launch"].Value ?? ((object)false)));
		foreach (DataGridViewRow item in (IEnumerable)profileGrid.Rows)
		{
			if (item.Tag is Profile profile)
			{
				item.Cells["launch"].Value = flag;
				if (flag)
				{
					selectedProfiles.Add(profile.StorageKey);
				}
				else
				{
					selectedProfiles.Remove(profile.StorageKey);
				}
			}
		}
		UpdateLaunchSelectionStatus();
		UpdateSelectionButtons();
	}

	private void UpdateSelectionButtons()
	{
		if (selectAllButton != null)
		{
			bool flag = profileGrid.Rows.Count > 0 && profileGrid.Rows.Cast<DataGridViewRow>().All((DataGridViewRow r) => Convert.ToBoolean(r.Cells["launch"].Value ?? ((object)false)));
			selectAllButton.Text = (flag ? Ui("Deselect All", "Deseleccionar todo") : Ui("Select All", "Seleccionar todo"));
			launchSelectedButton.Text = Ui("Launch Selected", "Abrir seleccionados") + " (" + ProfilesInCurrentScope().Count((Profile p) => selectedProfiles.Contains(p.StorageKey)) + ")";
			launchFolderButton.Visible = access.CanUseGroups && groupFilter.HasValue && groupFilter.Value != Guid.Empty;
			launchFolderButton.Text = Ui("Launch Folder", "Abrir carpeta") + " (" + ProfilesInCurrentScope().Count + ")";
			RefreshWorkspaceSelection();
		}
	}

	private void CaptureVisibleSelection()
	{
		try
		{
			profileGrid.EndEdit();
		}
		catch (InvalidOperationException)
		{
		}
		foreach (DataGridViewRow item in (IEnumerable)profileGrid.Rows)
		{
			if (item.Tag is Profile profile)
			{
				if (Convert.ToBoolean(item.Cells["launch"].Value ?? ((object)false)))
				{
					selectedProfiles.Add(profile.StorageKey);
				}
				else
				{
					selectedProfiles.Remove(profile.StorageKey);
				}
			}
		}
	}

	private List<Profile> CheckedProfiles()
	{
		CaptureVisibleSelection();
		return (from profile in ProfilesInCurrentScope()
			where selectedProfiles.Contains(profile.StorageKey)
			select profile).ToList();
	}

	private List<Profile> ProfilesInCurrentScope()
	{
		if (IsAllProfiles)
		{
			return (from p in profiles
				group p by p.StorageKey into g
				select g.First()).ToList();
		}
		Guid folder = groupFilter ?? Guid.Empty;
		if (folder != Guid.Empty && !access.CanUseGroups)
		{
			return new List<Profile>();
		}
		return (from p in profiles
			where (!workspaceReady) ? (p.GroupId == folder) : ProfileFolders(p).Contains(folder)
			group p by p.StorageKey into g
			select g.First()).ToList();
	}

	private Profile CurrentProfile()
	{
		if (profileGrid.CurrentRow != null)
		{
			return profileGrid.CurrentRow.Tag as Profile;
		}
		return null;
	}

	private void UpdateLaunchSelectionStatus()
	{
		int num = ProfilesInCurrentScope().Count((Profile p) => selectedProfiles.Contains(p.StorageKey));
		status.Text = ((num == 0) ? "Check one or more profiles to launch your selection." : $"{num} profile(s) selected to launch.");
	}

	private void ProfileGridCellClick(object sender, DataGridViewCellEventArgs args)
	{
		if (args.RowIndex < 0 || args.ColumnIndex < 0)
		{
			return;
		}
		if (profileGrid.Columns[args.ColumnIndex].Name == "remove")
		{
			Profile profile = (Profile)profileGrid.Rows[args.RowIndex].Tag;
			if (workspaceReady)
			{
				ShowWorkspaceProfileActions(profile);
			}
			else
			{
				RemoveProfile(profile);
			}
		}
		if (profileGrid.Columns[args.ColumnIndex].Name == "action")
		{
			LaunchProfiles(new List<Profile> { (Profile)profileGrid.Rows[args.RowIndex].Tag });
		}
	}

	private void ProfileGridCellDoubleClick(object sender, DataGridViewCellEventArgs args)
	{
		if (args.RowIndex >= 0 && !(profileGrid.Columns[args.ColumnIndex].Name != "name"))
		{
			RenameProfile((Profile)profileGrid.Rows[args.RowIndex].Tag);
		}
	}

	private void ProfileGridCellValueChanged(object sender, DataGridViewCellEventArgs args)
	{
		if (args.RowIndex < 0 || args.ColumnIndex < 0)
		{
			return;
		}
		if (profileGrid.Columns[args.ColumnIndex].Name == "launch")
		{
			if (profileGrid.Rows[args.RowIndex].Tag is Profile profile)
			{
				if (Convert.ToBoolean(profileGrid.Rows[args.RowIndex].Cells["launch"].Value ?? ((object)false)))
				{
					selectedProfiles.Add(profile.StorageKey);
				}
				else
				{
					selectedProfiles.Remove(profile.StorageKey);
				}
				UpdateLaunchSelectionStatus();
				UpdateSelectionButtons();
			}
		}
		else if (!(profileGrid.Columns[args.ColumnIndex].Name != "service"))
		{
			Profile profile2 = profileGrid.Rows[args.RowIndex].Tag as Profile;
			string text = Convert.ToString(profileGrid.Rows[args.RowIndex].Cells["service"].Value);
			if (profile2 != null)
			{
				Profile profile3 = profile2;
				string serviceId;
				if (text == CloudService.Luna.Name)
				{
					serviceId = CloudService.Luna.Id;
				}
				else
				{
					serviceId = ((text == CloudService.Geforce.Name) ? CloudService.Geforce.Id : CloudService.Xbox.Id);
				}
				profile3.ServiceId = serviceId;
				ShellStorage.SaveProfiles(profiles);
			}
		}
	}

	private void ProfileGridCellPainting(object sender, DataGridViewCellPaintingEventArgs args)
	{
		if (args.RowIndex < 0 || args.ColumnIndex < 0 || profileGrid.Columns[args.ColumnIndex].Name != "service")
		{
			return;
		}
		args.Paint(args.ClipBounds, DataGridViewPaintParts.Background | DataGridViewPaintParts.Border | DataGridViewPaintParts.Focus);
		string a = Convert.ToString(args.FormattedValue) ?? string.Empty;
		bool flag = string.Equals(a, CloudService.Geforce.Name, StringComparison.OrdinalIgnoreCase);
		bool flag2 = string.Equals(a, CloudService.Luna.Name, StringComparison.OrdinalIgnoreCase);
		Color color;
		if (flag2)
		{
			color = Color.FromArgb(145, 70, 220);
		}
		else
		{
			color = (flag ? Color.FromArgb(118, 185, 0) : Color.FromArgb(16, 124, 16));
		}
		string text;
		if (flag2)
		{
			text = "L";
		}
		else
		{
			text = (flag ? "G" : "X");
		}
		Rectangle rectangle = new Rectangle(args.CellBounds.Left + 8, args.CellBounds.Top + (args.CellBounds.Height - 19) / 2, 19, 19);
		using (SolidBrush brush = new SolidBrush(color))
		{
			using Font font = new Font("Segoe UI Semibold", 8f, FontStyle.Bold);
			using SolidBrush brush2 = new SolidBrush(Color.FromArgb(220, 230, 238));
			args.Graphics.FillEllipse(brush, rectangle);
			TextRenderer.DrawText(args.Graphics, text, font, rectangle, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
			Rectangle bounds = new Rectangle(rectangle.Right + 8, args.CellBounds.Top + 2, args.CellBounds.Width - 54, args.CellBounds.Height - 4);
			TextRenderer.DrawText(args.Graphics, a, args.CellStyle.Font, bounds, args.CellStyle.ForeColor, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
			int num = args.CellBounds.Right - 14;
			args.Graphics.FillPolygon(brush2, new Point[3]
			{
				new Point(num - 4, args.CellBounds.Top + args.CellBounds.Height / 2 - 2),
				new Point(num + 4, args.CellBounds.Top + args.CellBounds.Height / 2 - 2),
				new Point(num, args.CellBounds.Top + args.CellBounds.Height / 2 + 3)
			});
		}
		args.Handled = true;
	}

	private void RenameProfile(Profile profile)
	{
		using (Form form = new Form
		{
			Text = "Rename profile",
			StartPosition = FormStartPosition.CenterParent,
			ClientSize = new Size(360, 128),
			FormBorderStyle = FormBorderStyle.FixedDialog,
			MaximizeBox = false,
			MinimizeBox = false,
			ShowInTaskbar = false
		})
		{
			using TextBox textBox = new TextBox
			{
				Text = profile.Label,
				Location = new Point(18, 45),
				Width = 324,
				Font = new Font("Segoe UI", 11f)
			};
			using Button button = new Button
			{
				Text = "Save",
				DialogResult = DialogResult.OK,
				Location = new Point(186, 86),
				Width = 74
			};
			using Button button2 = new Button
			{
				Text = "Cancel",
				DialogResult = DialogResult.Cancel,
				Location = new Point(268, 86),
				Width = 74
			};
			form.Controls.Add(new Label
			{
				Text = "Profile name",
				AutoSize = true,
				Location = new Point(18, 18),
				Font = new Font("Segoe UI", 10f)
			});
			form.Controls.Add(textBox);
			form.Controls.Add(button);
			form.Controls.Add(button2);
			form.AcceptButton = button;
			form.CancelButton = button2;
			if (form.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			profile.Label = ShellStorage.SafeLabel(textBox.Text);
		}
		ShellStorage.SaveProfiles(profiles);
		RefreshProfiles();
		status.Text = "Profile renamed. Its isolated sign-in is unchanged.";
	}

	private void LaunchProfiles(List<Profile> selected)
	{
		selected = (from p in selected
			group p by p.StorageKey into g
			select g.First()).ToList();
		if (updateInstalling)
		{
			return;
		}
		if (!IsAllProfiles && selected.Any((Profile p) => sessions.ContainsKey(p.StorageKey) && sessions[p.StorageKey].GameContext != currentGame.ToString("N") && string.IsNullOrEmpty(p.LaunchContext)))
		{
			status.Text = Ui("Close the profile's existing session before opening it in a different game. Saved sign-in is preserved.", "Cierra la sesión existente del profile antes de abrirlo en otro juego. Se conserva el inicio de sesión.");
			return;
		}
		selected = selected.Where((Profile p) => !restartingProfiles.ContainsKey(p.StorageKey) && (access.CanUseGroups || CurrentFolder(p) == Guid.Empty)).ToList();
		if (selected.Count == 0)
		{
			status.Text = "Check at least one profile to open.";
			return;
		}
		Guid[] array = SessionLaunchPlan.NewKeys(selected.Select((Profile profile2) => profile2.StorageKey), sessions.Keys);
		int num = access.AvailableSessionSlots(sessions.Count);
		bool flag = EffectiveLayoutMode == SessionLayoutMode.Focus;
		if (flag)
		{
			num = Math.Min(num, Math.Max(0, 5 - sessions.Count));
		}
		Guid[] array2 = array.Take(num).ToArray();
		int num2 = array.Length - array2.Length;
		if (array2.Length == 0 && num2 > 0)
		{
			Label label = status;
			string text;
			if (flag)
			{
				text = Ui("Focus supports up to 5 windows. Switch to Mosaic or Grid to open more.", "Focus admite hasta 5 ventanas. Cambia a Mosaic o Grid para abrir más.");
			}
			else
			{
				text = ((access.Tier == AccessTier.Free) ? "Free supports 2 open sessions. Close one or upgrade to Pro to open more." : "The selected sessions could not be opened.");
			}
			label.Text = text;
			return;
		}
		if (mosaicHost == null || mosaicHost.IsDisposed)
		{
			mosaicHost = new MosaicHostForm(appIcon, layoutPreferences, EffectiveLayoutMode, EffectiveBorderless);
			mosaicHost.SetEditing(access.CanUseLayouts && editLayout.Checked);
			MosaicHostForm createdHost = mosaicHost;
			createdHost.FormClosed += delegate
			{
				if (mosaicHost == createdHost)
				{
					sessionCloseGeneration++;
					restartingProfiles.Clear();
					mosaicHost = null;
					foreach (CloudSessionForm item in sessions.Values.ToList())
					{
						item.Close();
					}
					sessions.Clear();
					RefreshPrimarySessions();
				}
			};
		}
		MosaicHostForm mosaicHostForm = mosaicHost;
		List<CloudSessionForm> list = new List<CloudSessionForm>();
		Guid[] array3 = array2;
		foreach (Guid key in array3)
		{
			Profile profile = ProfileForGame(selected.First((Profile value) => value.StorageKey == key));
			CloudSessionForm session = new CloudSessionForm(profile, appIcon, audioExperiment.Checked, soundAlertsEnabled.Checked);
			session.SetTextAlertsEnabled(textAlertsEnabled.Checked);
			session.SoundStatusChanged += (string value) =>
			{
				if (!IsDisposed)
				{
					soundStatus.Text = value;
				}
			};
			session.SessionStatusChanged += (string value) =>
			{
				if (!IsDisposed)
				{
					status.Text = value;
				}
			};
			session.MacroToggleRequested += QueueMovementMacroToggle;
			session.GlobalMacroShortcutActive = () => macroShortcut.Registered;
			sessions.Add(key, session);
			ObserveWorkspaceSession(profile, session);
			list.Add(session);
			session.FormClosed += delegate
			{
				if (sessions.TryGetValue(key, out var value) && value == session)
				{
					sessions.Remove(key);
				}
				RefreshPrimarySessions();
				ReflowMosaic();
				SetWorkspaceState(key, "Closed");
			};
		}
		RefreshPrimarySessions();
		if (list.Count > 0)
		{
			mosaicHostForm.ArrangeSessions(sessions.Values.ToList());
		}
		if (!mosaicHostForm.Visible)
		{
			mosaicHostForm.Show();
		}
		if (mosaicHostForm.WindowState == FormWindowState.Minimized)
		{
			mosaicHostForm.WindowState = FormWindowState.Maximized;
		}
		mosaicHostForm.Activate();
		Label label2 = status;
		string text2;
		if (num2 <= 0)
		{
			text2 = ((list.Count == 0) ? "Selected profiles are already open; their timers keep running." : $"{list.Count} new window(s). Timers wait for gameplay or retain saved time.");
		}
		else
		{
			text2 = (flag ? string.Format(Ui("Opened {0} session(s). Focus allows 5 windows; {1} remained closed. Switch to Mosaic or Grid to open more.", "Se abrieron {0} sesiones. Focus admite 5 ventanas; {1} quedaron cerradas. Cambia a Mosaic o Grid para abrir más."), list.Count, num2) : $"Opened {list.Count} session(s). Free allows 2 at once; {num2} remained closed. Upgrade to Pro for unlimited sessions.");
		}
		label2.Text = text2;
		foreach (CloudSessionForm item2 in list)
		{
			item2.BeginLoading();
		}
	}

	private void ReflowMosaic()
	{
		MosaicHostForm host = mosaicHost;
		if (host == null || host.IsDisposed)
		{
			return;
		}
		BeginInvoke((Action)(() =>
		{
			if (mosaicHost == host && !host.IsDisposed)
			{
				host.ArrangeSessions(sessions.Values.ToList());
			}
		}));
	}

	private void CloseSelectedSessions(object sender, EventArgs args)
	{
		List<Guid> list = (from profile in CheckedProfiles()
			select profile.StorageKey).ToList();
		foreach (Guid item in list)
		{
			CloseProfileSession(item);
		}
		status.Text = ((list.Count == 0) ? "No profiles are selected to close." : "Selected sessions closed. Saved sign-ins were preserved.");
	}

	private void CloseAllSessionsButton(object sender, EventArgs args)
	{
		int count = sessions.Count;
		CloseAllSessions();
		status.Text = ((count == 0) ? "There are no open sessions." : $"Closed {count} session(s). Saved sign-ins were preserved.");
	}

	private async void CloseAllSessions()
	{
		if (manualTargets.Values.Any((BroadcastEndpoint e) => e.Busy) || (recordedMacroTask != null && !recordedMacroTask.IsCompleted))
		{
			await ReleaseBeforeCloseAsync();
		}
		sessionCloseGeneration++;
		restartingProfiles.Clear();
		MosaicHostForm mosaicHostForm = mosaicHost;
		mosaicHost = null;
		foreach (CloudSessionForm item in sessions.Values.ToList())
		{
			item.Close();
		}
		sessions.Clear();
		RefreshPrimarySessions();
		if (mosaicHostForm != null && !mosaicHostForm.IsDisposed)
		{
			mosaicHostForm.Close();
		}
	}

	private async void RemoveProfile(Profile profile)
	{
		await RemoveProfileAsync(profile);
	}

	private void CloseProfileSession(Guid key)
	{
		restartingProfiles.Remove(key);
		if (sessions.TryGetValue(key, out var value))
		{
			value.Close();
		}
	}

	private Task RestartProfileAsync(Profile profile)
	{
		welcomeRecoveryBudgets.Remove(profile.StorageKey);
		return RestartProfileCoreAsync(profile, (CloudSessionForm s) => s.CloseForProfileRemovalAsync(), (Profile p) =>
		{
			LaunchProfiles(new List<Profile> { p });
		});
	}

	private async Task RecoverWelcomeAsync(Profile profile, CloudSessionForm source)
	{
		if (IsDisposed || deletingProfile || restartingProfiles.ContainsKey(profile.StorageKey) || !sessions.TryGetValue(profile.StorageKey, out var value) || value != source)
		{
			return;
		}
		if (!welcomeRecoveryBudgets.TryGetValue(profile.StorageKey, out var value2))
		{
			value2 = (welcomeRecoveryBudgets[profile.StorageKey] = new WelcomeRecoveryBudget());
		}
		if (!value2.TryBegin(DateTime.UtcNow))
		{
			SetWorkspaceState(profile.StorageKey, "Needs attention");
			status.Text = profile.Label + Ui(": automatic recovery stopped. Confirm Let's go manually or use Restart session.", ": recuperación automática detenida. Confirma Let's go manualmente o usa Reiniciar sesión.");
			return;
		}
		status.Text = profile.Label + Ui(": welcome screen stalled; restarting only this session.", ": pantalla de bienvenida detenida; reiniciando solo esta sesión.");
		await RestartProfileCoreAsync(profile, (CloudSessionForm s) => s.CloseForProfileRemovalAsync(), (Profile p) =>
		{
			LaunchProfiles(new List<Profile> { p });
		});
	}

	private async Task RestartProfileCoreAsync(Profile profile, Func<CloudSessionForm, Task> close, Action<Profile> launch)
	{
		if (profile == null || deletingProfile || !profiles.Any((Profile p) => p.StorageKey == profile.StorageKey) || (!access.CanUseGroups && profile.GroupId != Guid.Empty) || restartingProfiles.ContainsKey(profile.StorageKey))
		{
			return;
		}
		object ticket = new object();
		restartingProfiles.Add(profile.StorageKey, ticket);
		int generation = sessionCloseGeneration;
		try
		{
			if (sessions.TryGetValue(profile.StorageKey, out var value))
			{
				await close(value);
			}
			if (!IsDisposed && !Disposing && generation == sessionCloseGeneration && restartingProfiles.ContainsKey(profile.StorageKey) && restartingProfiles[profile.StorageKey] == ticket && profiles.Any((Profile p) => p.StorageKey == profile.StorageKey))
			{
				restartingProfiles.Remove(profile.StorageKey);
				launch(profile);
			}
		}
		catch (Exception ex)
		{
			if (!IsDisposed)
			{
				status.Text = Ui("Session restart failed: ", "No se pudo reiniciar la sesión: ") + ex.Message;
			}
		}
		finally
		{
			if (restartingProfiles.TryGetValue(profile.StorageKey, out var value2) && value2 == ticket)
			{
				restartingProfiles.Remove(profile.StorageKey);
			}
		}
	}

	private async Task RemoveProfileAsync(Profile profile)
	{
		if (workspaceReady && IsAllProfiles)
		{
			status.Text = Ui("Open the profile's folder to delete it.", "Abre la carpeta del perfil para eliminarlo.");
		}
		else
		{
			if (deletingProfile || MessageBox.Show(this, "Delete ‘" + profile.Label + "’? This session will close and its saved sign-in will be deleted. If this profile came from another version, that version will also lose the saved sign-in. Continue?", "Delete profile", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
			{
				return;
			}
			deletingProfile = true;
			restartingProfiles.Remove(profile.StorageKey);
			Enabled = false;
			status.Text = "Closing the session and deleting the profile…";
			try
			{
				if (sessions.TryGetValue(profile.StorageKey, out var value))
				{
					await value.CloseForProfileRemovalAsync();
				}
				await ShellStorage.RemoveActiveProfileAsync(profile.StorageKey);
				selectedProfiles.Remove(profile.StorageKey);
				workspaceStates.Remove(profile.StorageKey);
				profiles.Clear();
				profiles.AddRange(ShellStorage.LoadProfiles());
				RefreshProfiles();
				status.Text = "Profile deleted.";
			}
			catch (Exception ex)
			{
				status.Text = "Deletion could not be completed; the profile is still available to retry.";
				MessageBox.Show(this, "The profile could not be completely deleted.\n\n" + ex.Message, "KANBLAZ CLOUD", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			finally
			{
				deletingProfile = false;
				Enabled = true;
			}
		}
	}

	protected override async void OnFormClosing(FormClosingEventArgs e)
	{
		if (deletingProfile)
		{
			e.Cancel = true;
		}
		else if (!inputCloseComplete && (manualTargets.Values.Any((BroadcastEndpoint target) => target.Busy) || (recordedMacroTask != null && !recordedMacroTask.IsCompleted)))
		{
			e.Cancel = true;
			if (!awaitingInputClose)
			{
				awaitingInputClose = true;
				await ReleaseBeforeCloseAsync();
				inputCloseComplete = true;
				if (!IsDisposed)
				{
					Close();
				}
			}
		}
		else
		{
			controllerTouchpad.Dispose();
			CloseAllSessions();
			appIcon.Dispose();
			base.OnFormClosing(e);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			vpnTimer.Dispose();
			StopManualInput();
			Application.RemoveMessageFilter(this);
			macroShortcut.Dispose();
			controllerOwnerTimer.Dispose();
		}
		base.Dispose(disposing);
	}

	private bool InCurrentGame(Profile p)
	{
		return ProfileFolders(p).Length != 0;
	}

	private Guid CurrentFolder(Profile p)
	{
		Guid folder = gameLibrary.Memberships.FirstOrDefault((GameMembership m) => m.Profile == p.StorageKey && m.Game == currentGame)?.Folder ?? p.GroupId;
		if (!groups.Any((ProfileGroup g) => g.Id == folder))
		{
			return Guid.Empty;
		}
		return folder;
	}

	private void ApplyWorkspaceLanguage(Control.ControlCollection controls)
	{
		foreach (Control control in controls)
		{
			if (control == controllerMode)
			{
				RefreshControllerModeDisplay();
				continue;
			}
			if (control == controllerSectionHeading)
			{
				RefreshControllerModeDisplay();
				continue;
			}
			if (!workspaceLabels.TryGetValue(control, out var value))
			{
				value = control.Text;
				if (SpanishWorkspace.ContainsKey(value) || Convert.ToString(control.Tag) == "workspace-section")
				{
					workspaceLabels[control] = value;
				}
			}
			if (SpanishWorkspace.TryGetValue(value, out var value2))
			{
				control.Text = Ui(value, value2);
			}
			if (Convert.ToString(control.Tag) == "workspace-section")
			{
				string text = value.Split(new string[1] { "   " }, StringSplitOptions.None)[0];
				if (SpanishWorkspace.TryGetValue(text, out value2))
				{
					control.Text = Ui(text, value2) + (control.Text.EndsWith("▾") ? "   ▾" : "   ▴");
				}
			}
			if (control.HasChildren)
			{
				ApplyWorkspaceLanguage(control.Controls);
			}
		}
	}

	private Guid GameForFolder(Guid id)
	{
		if (!gameLibrary.Folders.TryGetValue(id, out var value))
		{
			return gameLibrary.Games[0].Id;
		}
		return value;
	}

	private Guid GameForProfile(Profile p)
	{
		if (p.GroupId != Guid.Empty)
		{
			return GameForFolder(p.GroupId);
		}
		if (!gameLibrary.Profiles.TryGetValue(p.StorageKey, out var value))
		{
			return gameLibrary.Games[0].Id;
		}
		return value;
	}

	private void LoadGameLibrary()
	{
		gameLibrary = new GameLibrary();
		gameLibraryWritable = true;
		try
		{
			if (File.Exists(gameLibraryPath))
			{
				if (new FileInfo(gameLibraryPath).Length > 4194304)
				{
					throw new SerializationException("Invalid game library size");
				}
				using FileStream stream = File.OpenRead(gameLibraryPath);
				GameLibrary loaded = (GameLibrary)new DataContractJsonSerializer(typeof(GameLibrary)).ReadObject(stream);
				if (loaded == null || loaded.Games == null || loaded.Games.Count == 0 || loaded.Folders == null || loaded.Profiles == null || loaded.Games.Any((GameEntry g) => g == null || g.Id == Guid.Empty || string.IsNullOrWhiteSpace(g.Name)) || loaded.Games.Select((GameEntry g) => g.Id).Distinct().Count() != loaded.Games.Count || loaded.Folders.Values.Concat(loaded.Profiles.Values).Any((Guid id) => !loaded.Games.Any((GameEntry g) => g.Id == id)))
				{
					throw new SerializationException("Invalid game library");
				}
				if (loaded.Memberships == null)
				{
					loaded.Memberships = new List<GameMembership>();
				}
				if (loaded.Memberships.Any((GameMembership m) => m == null || m.Profile == Guid.Empty || !loaded.Games.Any((GameEntry g) => g.Id == m.Game)) || loaded.Memberships.GroupBy((GameMembership m) =>
				{
					string text = m.Game.ToString();
					Guid profile = m.Profile;
					return text + profile.ToString();
				}).Any((IGrouping<string, GameMembership> g) => g.Count() > 1))
				{
					throw new SerializationException("Invalid game memberships");
				}
				gameLibrary = loaded;
			}
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is SerializationException || ex is XmlException)
		{
			gameLibraryWritable = false;
			status.Text = "Game library could not be read. Its original file was preserved.";
		}
		if (gameLibrary.Games.Count == 0)
		{
			gameLibrary.Games.Add(new GameEntry
			{
				Id = Guid.NewGuid(),
				Name = "Fortnite"
			});
		}
		currentGame = gameLibrary.Games[0].Id;
	}

	private bool SaveGameLibrary()
	{
		if (!gameLibraryWritable)
		{
			status.Text = "Game library needs recovery; changes were not saved.";
			return false;
		}
		string text = gameLibraryPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(gameLibraryPath));
			using (FileStream stream = File.Create(text))
			{
				new DataContractJsonSerializer(typeof(GameLibrary)).WriteObject(stream, gameLibrary);
			}
			if (File.Exists(gameLibraryPath))
			{
				File.Replace(text, gameLibraryPath, null);
			}
			else
			{
				File.Move(text, gameLibraryPath);
			}
			return true;
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			status.Text = "Game organization could not be saved: " + ex.Message;
			return false;
		}
		finally
		{
			try
			{
				if (File.Exists(text))
				{
					File.Delete(text);
				}
			}
			catch (IOException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
	}

	private void RefreshGameTabs()
	{
		gameTabs.Items.Clear();
		foreach (GameEntry game in gameLibrary.Games)
		{
			gameTabs.Items.Add(game);
		}
		gameTabs.SelectedItem = gameLibrary.Games.First((GameEntry g) => g.Id == currentGame);
	}

	private void AddGame(object sender, EventArgs args)
	{
		if (!gameLibraryWritable)
		{
			SaveGameLibrary();
			return;
		}
		string name = PromptForGroupName(Ui("New game", "Nuevo juego"), "");
		if (string.IsNullOrWhiteSpace(name))
		{
			return;
		}
		try
		{
			name = ProfileRepository.SafeGroupName(name);
		}
		catch (Exception ex)
		{
			MessageBox.Show(this, ex.Message);
			return;
		}
		if (gameLibrary.Games.Any((GameEntry g) => string.Equals(g.Name, name, StringComparison.OrdinalIgnoreCase)))
		{
			status.Text = Ui("That game already exists.", "Ese juego ya existe.");
			return;
		}
		GameEntry gameEntry = new GameEntry
		{
			Id = Guid.NewGuid(),
			Name = name,
			Destination = "Home"
		};
		if (EditGameDestination(gameEntry, persist: false))
		{
			gameLibrary.Games.Add(gameEntry);
			if (!SaveGameLibrary())
			{
				gameLibrary.Games.Remove(gameEntry);
				return;
			}
			currentGame = gameEntry.Id;
			RefreshGameTabs();
			AddExistingProfiles(Guid.Empty);
		}
	}

	private bool TryDeleteGame(Guid id)
	{
		if (!gameLibraryWritable || id == this.gameLibrary.Games[0].Id || !this.gameLibrary.Games.Any((GameEntry g) => g.Id == id))
		{
			return false;
		}
		GameLibrary gameLibrary = this.gameLibrary;
		Guid fallback = gameLibrary.Games[0].Id;
		this.gameLibrary = new GameLibrary
		{
			Games = gameLibrary.Games.Where((GameEntry g) => g.Id != id).ToList(),
			Folders = gameLibrary.Folders.ToDictionary((KeyValuePair<Guid, Guid> p) => p.Key, (KeyValuePair<Guid, Guid> p) => (!(p.Value == id)) ? p.Value : fallback),
			Profiles = gameLibrary.Profiles.ToDictionary((KeyValuePair<Guid, Guid> p) => p.Key, (KeyValuePair<Guid, Guid> p) => (!(p.Value == id)) ? p.Value : fallback),
			Memberships = gameLibrary.Memberships.Where((GameMembership m) => m.Game != id).ToList()
		};
		if (!SaveGameLibrary())
		{
			this.gameLibrary = gameLibrary;
			return false;
		}
		currentGame = fallback;
		RefreshGameTabs();
		RefreshGroups();
		RefreshProfiles(persist: false);
		return true;
	}

	private bool LinkProfiles(IEnumerable<Profile> selected, Guid folder)
	{
		if (folder != Guid.Empty && (!access.CanUseGroups || !CurrentGameFolders.Any((ProfileGroup g) => g.Id == folder)))
		{
			return false;
		}
		List<Profile> list = selected.ToList();
		if (list.Any((Profile p) => folderReferences.Has(p.StorageKey, currentGame)))
		{
			return UpdateFolderReferences(list, folder, move: false);
		}
		List<GameMembership> memberships = gameLibrary.Memberships;
		HashSet<Guid> ids = new HashSet<Guid>(from p in list
			where profiles.Any((Profile v) => v.StorageKey == p.StorageKey)
			select p.StorageKey);
		gameLibrary.Memberships = memberships.Where((GameMembership m) => m.Game != currentGame || !ids.Contains(m.Profile)).ToList();
		foreach (Guid item in ids)
		{
			gameLibrary.Memberships.Add(new GameMembership
			{
				Profile = item,
				Game = currentGame,
				Folder = folder
			});
		}
		if (!SaveGameLibrary())
		{
			gameLibrary.Memberships = memberships;
			return false;
		}
		return true;
	}

	private void AddExistingProfiles(Guid folder)
	{
		using Form form = new Form
		{
			Text = Ui("Add Existing Profiles", "Añadir profiles existentes"),
			ClientSize = new Size(500, 390),
			StartPosition = FormStartPosition.CenterParent
		};
		CheckedListBox list = new CheckedListBox
		{
			Dock = DockStyle.Fill,
			CheckOnClick = true
		};
		try
		{
			using FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
			{
				Dock = DockStyle.Bottom,
				Height = 45
			};
			foreach (Profile profile in profiles)
			{
				list.Items.Add(profile);
			}
			Button button = new Button
			{
				Text = Ui("Select All", "Seleccionar todos"),
				AutoSize = true
			};
			button.Click += delegate
			{
				for (int i = 0; i < list.Items.Count; i++)
				{
					list.SetItemChecked(i, value: true);
				}
			};
			Button button2 = new Button
			{
				Text = Ui("Add Selected", "Añadir seleccionados"),
				AutoSize = true,
				DialogResult = DialogResult.OK
			};
			Button button3 = new Button
			{
				Text = Ui("Skip", "Omitir"),
				DialogResult = DialogResult.Cancel
			};
			flowLayoutPanel.Controls.AddRange(new Control[3] { button, button2, button3 });
			form.Controls.Add(list);
			form.Controls.Add(flowLayoutPanel);
			form.CancelButton = button3;
			if (form.ShowDialog(this) == DialogResult.OK && LinkProfiles(list.CheckedItems.Cast<Profile>(), folder))
			{
				RefreshGroups();
				RefreshProfiles();
			}
		}
		finally
		{
			if (list != null)
			{
				((IDisposable)list).Dispose();
			}
		}
	}

	private bool EditGameDestination(GameEntry game, bool persist)
	{
		Form dialog = new Form
		{
			Text = Ui("Launch Destination", "Destino de lanzamiento"),
			ClientSize = new Size(490, 225),
			StartPosition = FormStartPosition.CenterParent
		};
		try
		{
			ComboBox mode = new ComboBox
			{
				Left = 16,
				Top = 40,
				Width = 455,
				DropDownStyle = ComboBoxStyle.DropDownList
			};
			try
			{
				TextBox url = new TextBox
				{
					Left = 16,
					Top = 100,
					Width = 455,
					Text = (game.CustomUrl ?? "")
				};
				try
				{
					mode.Items.AddRange(new object[4] { "Sign In", "Main Screen", "Home", "Custom destination / URL" });
					mode.SelectedItem = game.Destination ?? "Home";
					if (mode.SelectedIndex < 0)
					{
						mode.SelectedIndex = 2;
					}
					url.Enabled = mode.SelectedIndex == 3;
					mode.SelectedIndexChanged += delegate
					{
						url.Enabled = mode.SelectedIndex == 3;
					};
					Button button = new Button
					{
						Text = Ui("Apply", "Aplicar"),
						Left = 280,
						Top = 182,
						Width = 90
					};
					Button button2 = new Button
					{
						Text = Ui("Cancel", "Cancelar"),
						Left = 380,
						Top = 182,
						Width = 90,
						DialogResult = DialogResult.Cancel
					};
					dialog.Controls.Add(new Label
					{
						Text = game.Name,
						Left = 16,
						Top = 15,
						AutoSize = true
					});
					dialog.Controls.Add(new Label
					{
						Text = Ui("Sign In opens the service portal; existing sign-in is preserved.", "Sign In abre el portal del servicio y conserva el inicio de sesión."),
						Left = 16,
						Top = 140,
						Width = 455,
						Height = 35
					});
					dialog.Controls.AddRange(new Control[4] { mode, url, button, button2 });
					dialog.CancelButton = button2;
					button.Click += delegate
					{
						if (mode.SelectedIndex == 3 && (!Uri.TryCreate(url.Text.Trim(), UriKind.Absolute, out var result) || result.Scheme != Uri.UriSchemeHttps || !string.IsNullOrEmpty(result.UserInfo) || result.IsLoopback))
						{
							MessageBox.Show(dialog, Ui("Enter a public HTTPS destination without credentials.", "Ingresa un destino HTTPS público sin credenciales."));
						}
						else
						{
							string destination = game.Destination;
							string customUrl = game.CustomUrl;
							game.Destination = Convert.ToString(mode.SelectedItem);
							game.CustomUrl = ((mode.SelectedIndex == 3) ? url.Text.Trim() : null);
							if (persist && !SaveGameLibrary())
							{
								game.Destination = destination;
								game.CustomUrl = customUrl;
							}
							else
							{
								dialog.DialogResult = DialogResult.OK;
								dialog.Close();
							}
						}
					};
					return dialog.ShowDialog(this) == DialogResult.OK;
				}
				finally
				{
					if (url != null)
					{
						((IDisposable)url).Dispose();
					}
				}
			}
			finally
			{
				if (mode != null)
				{
					((IDisposable)mode).Dispose();
				}
			}
		}
		finally
		{
			if (dialog != null)
			{
				((IDisposable)dialog).Dispose();
			}
		}
	}

	private Profile ProfileForGame(Profile source)
	{
		if (!string.IsNullOrEmpty(source.LaunchContext))
		{
			return source;
		}
		GameEntry gameEntry = gameLibrary.Games.First((GameEntry g) => g.Id == (IsAllProfiles ? GameForProfile(source) : currentGame));
		string urlOverride = source.LaunchUrl;
		if (!string.IsNullOrEmpty(gameEntry.Destination))
		{
			if (gameEntry.Destination == "Custom destination / URL")
			{
				urlOverride = gameEntry.CustomUrl;
			}
			else
			{
				urlOverride = ((source.Service.Id == "xbox") ? "https://www.xbox.com/en-US/play" : source.Service.LaunchUrl);
			}
		}
		return new Profile
		{
			StorageKey = source.StorageKey,
			BrowserKey = source.BrowserKey,
			BrowserStore = source.BrowserStore,
			ServiceId = source.ServiceId,
			Label = source.Label,
			GroupId = CurrentFolder(source),
			UrlOverride = urlOverride,
			LaunchContext = gameEntry.Id.ToString("N")
		};
	}

	private void DeleteGame(object sender, EventArgs args)
	{
		GameEntry gameEntry = gameLibrary.Games.FirstOrDefault((GameEntry g) => g.Id == currentGame);
		if (gameEntry != null && !(gameEntry.Id == gameLibrary.Games[0].Id))
		{
			string name = gameLibrary.Games[0].Name;
			string text = string.Format(Ui("Remove the game category ‘{0}’?\n\nIts folders and profiles will move to ‘{1}’. No profile, saved sign-in or running session will be deleted.", "¿Eliminar la categoría de juego ‘{0}’?\n\nSus carpetas y profiles pasarán a ‘{1}’. No se eliminarán profiles, inicios de sesión ni sesiones abiertas."), gameEntry.Name, name);
			if (MessageBox.Show(this, text, Ui("Delete Game", "Eliminar juego"), MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes && TryDeleteGame(gameEntry.Id))
			{
				status.Text = Ui("Game category removed. All profiles and saved sign-ins were preserved.", "Categoría eliminada. Los profiles e inicios de sesión se conservaron.");
			}
		}
	}

	private WorkspaceProfileInfo Info(Guid id)
	{
		if (!workspaceInfo.TryGetValue(id, out var value))
		{
			Dictionary<Guid, WorkspaceProfileInfo> dictionary = workspaceInfo;
			WorkspaceProfileInfo workspaceProfileInfo = new WorkspaceProfileInfo
			{
				Id = id
			};
			value = workspaceProfileInfo;
			dictionary[id] = workspaceProfileInfo;
		}
		return value;
	}

	private void LoadWorkspaceInfo()
	{
		try
		{
			if (!File.Exists(workspaceInfoPath))
			{
				return;
			}
			if (new FileInfo(workspaceInfoPath).Length > 4194304)
			{
				workspaceInfoWritable = false;
				return;
			}
			using FileStream stream = File.OpenRead(workspaceInfoPath);
			foreach (WorkspaceProfileInfo item in ((List<WorkspaceProfileInfo>)new DataContractJsonSerializer(typeof(List<WorkspaceProfileInfo>)).ReadObject(stream)) ?? new List<WorkspaceProfileInfo>())
			{
				if (item != null && item.Id != Guid.Empty)
				{
					workspaceInfo[item.Id] = item;
				}
			}
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is SerializationException || ex is XmlException)
		{
			workspaceInfoWritable = false;
			status.Text = "Workspace preferences could not be loaded. The original file and profile sign-ins are unchanged.";
		}
	}

	private void SaveWorkspaceInfo()
	{
		if (!workspaceInfoWritable)
		{
			status.Text = "Workspace settings were not saved: the existing file needs recovery.";
			return;
		}
		string text = workspaceInfoPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(workspaceInfoPath));
			using (FileStream stream = File.Create(text))
			{
				new DataContractJsonSerializer(typeof(List<WorkspaceProfileInfo>)).WriteObject(stream, workspaceInfo.Values.ToList());
			}
			if (File.Exists(workspaceInfoPath))
			{
				File.Replace(text, workspaceInfoPath, null);
			}
			else
			{
				File.Move(text, workspaceInfoPath);
			}
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			status.Text = "Workspace changes are visible, but could not be saved locally.";
		}
		finally
		{
			try
			{
				if (File.Exists(text))
				{
					File.Delete(text);
				}
			}
			catch (IOException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
	}

	private void BuildModernWorkspace()
	{
		LoadWorkspaceInfo();
		LoadGameLibrary();
		RestoreFolder();
		SuspendLayout();
		List<Control> list = Controls.Cast<Control>().ToList();
		FormBorderStyle = FormBorderStyle.None;
		MaximizedBounds = Screen.FromControl(this).WorkingArea;
		WorkspaceBackdrop workspaceBackdrop = new WorkspaceBackdrop
		{
			Dock = DockStyle.Fill,
			Padding = new Padding(16, 0, 16, 10),
			ColumnCount = 1,
			RowCount = 5
		};
		workspaceBackdrop.SuspendLayout();
		workspaceBackdrop.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));
		workspaceBackdrop.RowStyles.Add(new RowStyle(SizeType.Absolute, 100f));
		workspaceBackdrop.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		workspaceBackdrop.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		workspaceBackdrop.Controls.Add(BuildWorkspaceCaption(), 0, 0);
		workspaceBackdrop.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = new Padding(0, 0, 0, 14)
		};
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28f));
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44f));
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28f));
		TableLayoutPanel tableLayoutPanel2 = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 2,
			Padding = new Padding(6, 10, 0, 0)
		};
		tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 68f));
		tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f));
		tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		workspaceMark = new WorkspaceCloudMark
		{
			Dock = DockStyle.Fill,
			Margin = new Padding(0, 4, 10, 10)
		};
		tableLayoutPanel2.Controls.Add(workspaceMark, 0, 0);
		tableLayoutPanel2.SetRowSpan(workspaceMark, 2);
		tableLayoutPanel2.SetColumnSpan(workspaceMark, 2);
		tableLayoutPanel.Controls.Add(tableLayoutPanel2, 0, 0);
		TableLayoutPanel tableLayoutPanel3 = new TableLayoutPanel
		{
			Dock = DockStyle.Top,
			Height = 58,
			ColumnCount = 2,
			RowCount = 1,
			Margin = new Padding(12, 12, 12, 0)
		};
		tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 66f));
		WorkspaceCard searchBox = NewWorkspaceCard();
		searchBox.Padding = Padding.Empty;
		searchBox.Height = 52;
		searchBox.Dock = DockStyle.Fill;
		searchBox.Margin = new Padding(0, 0, 8, 0);
		Label searchIcon = new Label
		{
			Text = "⌕",
			TextAlign = ContentAlignment.MiddleCenter,
			Font = new Font("Segoe UI", 14f)
		};
		workspaceSearch.Dock = DockStyle.None;
		workspaceSearch.BorderStyle = BorderStyle.None;
		workspaceSearch.Margin = Padding.Empty;
		searchBox.Controls.Add(workspaceSearch);
		searchBox.Controls.Add(searchIcon);
		WorkspaceButton shortcutChip = new WorkspaceButton
		{
			Text = "Ctrl + K",
			Width = 82,
			AccessibleName = "Focus profile search",
			Font = new Font("Segoe UI", 9f)
		};
		shortcutChip.Click += delegate
		{
			workspaceSearch.Focus();
			workspaceSearch.SelectAll();
		};
		searchBox.Controls.Add(shortcutChip);
		searchBox.Layout += delegate
		{
			int num = searchBox.ClientSize.Height;
			int num2 = searchBox.ClientSize.Width;
			searchIcon.Bounds = new Rectangle(12, 0, 28, num);
			shortcutChip.Bounds = new Rectangle(Math.Max(40, num2 - 94), Math.Max(0, (num - 34) / 2), 82, 34);
			workspaceSearch.Bounds = new Rectangle(44, Math.Max(0, (num - workspaceSearch.PreferredHeight) / 2), Math.Max(1, num2 - 150), workspaceSearch.PreferredHeight);
		};
		WorkspaceButton workspaceButton = new WorkspaceButton
		{
			Text = "✦",
			Dock = DockStyle.Fill,
			Tag = "nexus-help-ai",
			AccessibleName = "Kanblaz AI — local guided help",
			Font = new Font("Segoe UI", 24f),
			Margin = Padding.Empty
		};
		workspaceButton.Click += delegate
		{
			ShowWorkspaceHelp();
		};
		tableLayoutPanel3.Controls.Add(searchBox, 0, 0);
		tableLayoutPanel3.Controls.Add(workspaceButton, 1, 0);
		workspaceTips.SetToolTip(workspaceButton, Ui("Kanblaz help · local guided answers", "Ayuda Kanblaz · respuestas locales guiadas"));
		workspaceTips.SetToolTip(searchBox, "Search profiles, folders and tags · Ctrl+K");
		tableLayoutPanel.Controls.Add(tableLayoutPanel3, 1, 0);
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			WrapContents = true,
			FlowDirection = FlowDirection.RightToLeft,
			Padding = new Padding(0, 12, 0, 0)
		};
		accountButton.Height = 40;
		accountButton.MinimumSize = new Size(105, 40);
		accountButton.Margin = new Padding(8, 0, 0, 0);
		accessStatus.MaximumSize = new Size(175, 48);
		accessStatus.AutoSize = true;
		accessStatus.Margin = new Padding(12, 3, 0, 0);
		flowLayoutPanel.Controls.Add(accountButton);
		flowLayoutPanel.Controls.Add(accessStatus);
		flowLayoutPanel.Controls.Add(upgradePro);
		tableLayoutPanel.Controls.Add(flowLayoutPanel, 2, 0);
		workspaceBackdrop.Controls.Add(tableLayoutPanel, 0, 1);
		workspaceColumns = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 3,
			RowCount = 1,
			Margin = Padding.Empty
		};
		workspaceColumns.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 224f));
		workspaceColumns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		workspaceColumns.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 320f));
		WorkspaceCard workspaceCard = NewWorkspaceCard();
		workspaceCard.Dock = DockStyle.Fill;
		workspaceCard.Margin = new Padding(0, 0, 12, 0);
		TableLayoutPanel tableLayoutPanel4 = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 6,
			Margin = Padding.Empty
		};
		tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 42f));
		tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 42f));
		tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Absolute, 32f));
		tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill
		};
		panel.Controls.Add(new Label
		{
			Text = "GAMES",
			AutoSize = true,
			Location = new Point(0, 8),
			Font = new Font("Segoe UI Semibold", 10f),
			Tag = "workspace-title",
			ForeColor = Color.White
		});
		Button button = CreateButton("+", AddGame);
		button.AutoSize = false;
		button.Size = new Size(30, 30);
		button.Dock = DockStyle.Right;
		button.Padding = Padding.Empty;
		FlowLayoutPanel flowLayoutPanel2 = new FlowLayoutPanel
		{
			Dock = DockStyle.Right,
			Width = 68,
			WrapContents = false,
			Margin = Padding.Empty
		};
		button.Dock = DockStyle.None;
		button.Margin = new Padding(0, 0, 4, 0);
		deleteGameButton.Margin = Padding.Empty;
		deleteGameButton.Click += DeleteGame;
		workspaceTips.SetToolTip(deleteGameButton, "Delete this game category. Profiles and saved sign-ins are kept; the default game cannot be deleted.");
		flowLayoutPanel2.Controls.Add(button);
		flowLayoutPanel2.Controls.Add(deleteGameButton);
		panel.Controls.Add(flowLayoutPanel2);
		tableLayoutPanel4.Controls.Add(panel, 0, 0);
		RefreshGameTabs();
		gameTabs.SelectedIndexChanged += delegate
		{
			if (gameTabs.SelectedItem is GameEntry gameEntry)
			{
				CaptureVisibleSelection();
				currentGame = gameEntry.Id;
				groupFilter = null;
				smartView = "All";
				deleteGameButton.Enabled = currentGame != gameLibrary.Games[0].Id && gameLibraryWritable;
				RefreshGroups();
				RememberFolder();
				RefreshProfiles(persist: false);
			}
		};
		tableLayoutPanel4.Controls.Add(gameTabs, 0, 1);
		tableLayoutPanel4.Controls.Add(new Label
		{
			Text = "FOLDERS",
			AutoSize = true,
			Dock = DockStyle.Fill,
			Padding = new Padding(0, 9, 0, 0)
		}, 0, 2);
		groupList.Dock = DockStyle.Fill;
		groupList.ItemHeight = 50;
		tableLayoutPanel4.Controls.Add(groupList, 0, 3);
		WorkspaceComboBox views = new WorkspaceComboBox
		{
			Dock = DockStyle.Top,
			DropDownStyle = ComboBoxStyle.DropDownList,
			FlatStyle = FlatStyle.Flat,
			Margin = new Padding(0, 12, 0, 10),
			AccessibleName = "Profile views"
		};
		views.Items.AddRange(new object[4] { "Folder profiles", "Favorites", "Recently used", "Running now" });
		views.SelectedIndex = 0;
		views.SelectedIndexChanged += delegate
		{
			smartView = ((views.SelectedIndex == 0) ? "All" : Convert.ToString(views.SelectedItem));
			if (smartView != "All")
			{
				groupFilter = null;
				RefreshGroups();
			}
			RefreshProfiles();
		};
		tableLayoutPanel4.Controls.Add(views, 0, 4);
		FlowLayoutPanel flowLayoutPanel3 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			WrapContents = true,
			Padding = new Padding(0, 8, 0, 0)
		};
		addGroup.Text = "+ New Folder";
		addGroup.MinimumSize = new Size(175, 38);
		flowLayoutPanel3.Controls.Add(addGroup);
		renameGroup.Text = "Rename";
		deleteGroup.Text = "Delete";
		flowLayoutPanel3.SetFlowBreak(addGroup, value: true);
		flowLayoutPanel3.Controls.Add(renameGroup);
		flowLayoutPanel3.Controls.Add(deleteGroup);
		tableLayoutPanel4.Controls.Add(flowLayoutPanel3, 0, 5);
		workspaceCard.Controls.Add(tableLayoutPanel4);
		workspaceColumns.Controls.Add(workspaceCard, 0, 0);
		groupList.SelectedIndexChanged += delegate
		{
			if (!refreshingGroups && views.SelectedIndex != 0)
			{
				views.SelectedIndex = 0;
			}
		};
		WorkspaceCard workspaceCard2 = NewWorkspaceCard();
		workspaceCard2.Dock = DockStyle.Fill;
		workspaceCard2.Margin = new Padding(0, 0, 12, 0);
		TableLayoutPanel tableLayoutPanel5 = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 5,
			Margin = Padding.Empty
		};
		tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		FlowLayoutPanel flowLayoutPanel4 = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			AutoSize = true,
			WrapContents = true,
			Margin = new Padding(0, 0, 0, 2)
		};
		workspaceTitle.Text = "Profiles";
		workspaceTitle.Tag = "workspace-title";
		flowLayoutPanel4.Controls.Add(workspaceTitle);
		flowLayoutPanel4.Controls.Add(workspaceCount);
		Button button2 = CreateButton("+ Add Profile", AddProfile);
		button2.Margin = new Padding(16, 3, 0, 0);
		flowLayoutPanel4.Controls.Add(button2);
		flowLayoutPanel4.Controls.Add(vpnLed);
		TableLayoutPanel tableLayoutPanel6 = new TableLayoutPanel
		{
			AutoSize = false,
			Height = 52,
			Dock = DockStyle.Fill,
			ColumnCount = 2,
			RowCount = 1,
			Margin = Padding.Empty
		};
		tableLayoutPanel5.RowStyles[0] = new RowStyle(SizeType.Absolute, 52f);
		tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40f));
		guideIcon.Anchor = AnchorStyles.Top | AnchorStyles.Right;
		guideIcon.Margin = new Padding(0, 4, 0, 0);
		guideIcon.Click += (object s, EventArgs e) =>
		{
			ShowWorkspaceGuide();
		};
		workspaceTips.SetToolTip(guideIcon, Ui("Quick Guide", "Guía rápida"));
		tableLayoutPanel6.Controls.Add(flowLayoutPanel4, 0, 0);
		tableLayoutPanel6.Controls.Add(guideIcon, 1, 0);
		tableLayoutPanel5.Controls.Add(tableLayoutPanel6, 0, 0);
		FlowLayoutPanel flowLayoutPanel5 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			WrapContents = true,
			Padding = new Padding(0, 6, 0, 10),
			Margin = Padding.Empty
		};
		workspaceFilter.Items.AddRange(new object[9] { "All services", "Xbox Cloud Gaming", "GeForce NOW", "Amazon Luna", "Ready", "Launching", "Active", "Failed", "Closed" });
		workspaceFilter.SelectedIndex = 0;
		workspaceSort.Items.AddRange(new object[3] { "Name A–Z", "Name Z–A", "Recently used" });
		workspaceSort.SelectedIndex = 0;
		workspaceFilter.Width = 166;
		workspaceSort.Width = 146;
		flowLayoutPanel5.Controls.Add(workspaceFilter);
		flowLayoutPanel5.Controls.Add(workspaceSort);
		tableLayoutPanel5.Controls.Add(flowLayoutPanel5, 0, 1);
		Panel panel2 = new Panel
		{
			Dock = DockStyle.Fill,
			Margin = Padding.Empty
		};
		panel2.Controls.Add(profileGrid);
		panel2.Controls.Add(emptyWorkspace);
		tableLayoutPanel5.Controls.Add(panel2, 0, 2);
		FlowLayoutPanel flowLayoutPanel6 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			Padding = new Padding(0, 12, 0, 6),
			WrapContents = true,
			Margin = Padding.Empty
		};
		flowLayoutPanel6.Controls.Add(selectAllButton);
		selectionActions.Dock = DockStyle.None;
		selectionActions.Margin = Padding.Empty;
		selectionActions.Controls.Add(launchSelectedButton);
		selectionActions.Controls.Add(CreateButton("Close Selected", CloseSelectedSessions));
		flowLayoutPanel6.Controls.Add(selectionActions);
		flowLayoutPanel6.Controls.Add(CreateButton("Launch All", (object s, EventArgs e) =>
		{
			LaunchProfiles(ProfilesInCurrentScope());
		}));
		flowLayoutPanel6.Controls.Add(CreateButton("Close All", CloseAllSessionsButton));
		flowLayoutPanel6.Controls.Add(launchFolderButton);
		ContextMenuStrip moreActions = new ContextMenuStrip();
		moreActions.Items.Add(Ui("Suggestions…", "Sugerencias…"), null, (object s, EventArgs e) =>
		{
			using SuggestionForm suggestionForm = new SuggestionForm(Ui("en", "es") == "es");
			suggestionForm.ShowDialog(this);
		});
		moreActions.Items.Add(Ui("Add Existing Profiles…", "Añadir profiles existentes…"), null, (object s, EventArgs e) =>
		{
			AddExistingProfiles(groupFilter ?? Guid.Empty);
		});
		moreActions.Items.Add(Ui("Launch Destination…", "Destino de lanzamiento…"), null, (object s, EventArgs e) =>
		{
			EditGameDestination(gameLibrary.Games.First((GameEntry g) => g.Id == currentGame), persist: true);
		});
		moreActions.Items.Add(Ui("Check for updates", "Buscar actualizaciones"), null, async (object s, EventArgs e) =>
		{
			await CheckUpdatesAsync(automatic: false);
		});
		ToolStripItem moveSelected = moreActions.Items.Add("Move selected to Folder… (Pro)", null, (object s, EventArgs e) =>
		{
			MoveWorkspaceProfiles(CheckedProfiles());
		});
		InstallFolderContextMenus();
		moreActions.Opening += delegate
		{
			moveSelected.Enabled = access.CanUseGroups;
		};
		ToolStripItem deleteSelected = moreActions.Items.Add(Ui("Delete selected everywhere…", "Eliminar seleccionados de todas partes…"), null, async (object s, EventArgs e) =>
		{
			foreach (Profile item in CheckedProfiles().ToList())
			{
				await RemoveProfileAsync(item);
			}
		});
		moreActions.Opening += (object s, CancelEventArgs e) =>
		{
			deleteSelected.Enabled = !IsAllProfiles;
		};
		moreActions.Items.Add(new ToolStripSeparator());
		moreActions.Items.Add("Retry Failed", null, (object s, EventArgs e) =>
		{
			RetryWorkspaceFailures();
		});
		moreActions.Items.Add("Detection Event Log", null, (object s, EventArgs e) =>
		{
			string directoryPath = BrainrotEventLog.DirectoryPath;
			try
			{
				Directory.CreateDirectory(directoryPath);
				Process.Start("explorer.exe", "\"" + directoryPath + "\"");
			}
			catch
			{
				MessageBox.Show(this, "Could not open the detection event log.", "KANBLAZ CLOUD");
			}
		});
		moreActions.Items.Add("Close Failed", null, (object s, EventArgs e) =>
		{
			foreach (Guid item2 in (from p in workspaceStates
				where p.Value == "Failed"
				select p.Key).ToList())
			{
				if (sessions.TryGetValue(item2, out var value2))
				{
					value2.Close();
				}
			}
		});
		Button value = CreateButton("More…", (object s, EventArgs e) =>
		{
			Button button3 = (Button)s;
			moreActions.Show(button3, new Point(0, button3.Height));
		});
		flowLayoutPanel6.Controls.Add(value);
		tableLayoutPanel5.Controls.Add(flowLayoutPanel6, 0, 3);
		FlowLayoutPanel flowLayoutPanel7 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			Margin = Padding.Empty,
			WrapContents = true
		};
		workspaceSummary.Margin = new Padding(0, 8, 14, 0);
		workspaceSummary.MaximumSize = new Size(580, 0);
		workspaceSummary.Font = new Font("Segoe UI", 8f);
		flowLayoutPanel7.Controls.Add(workspaceSelected);
		flowLayoutPanel7.Controls.Add(workspaceSummary);
		tableLayoutPanel5.Controls.Add(flowLayoutPanel7, 0, 4);
		workspaceCard2.Controls.Add(tableLayoutPanel5);
		workspaceColumns.Controls.Add(workspaceCard2, 1, 0);
		WorkspaceCard workspaceCard3 = NewWorkspaceCard();
		workspaceCard3.Dock = DockStyle.Fill;
		workspaceCard3.Margin = Padding.Empty;
		workspaceCard3.Padding = new Padding(12);
		workspaceDrawer.Dock = DockStyle.Fill;
		workspaceDrawer.Padding = Padding.Empty;
		workspaceDrawer.Visible = true;
		workspaceCard3.Controls.Add(workspaceDrawer);
		workspaceColumns.Controls.Add(workspaceCard3, 2, 0);
		workspaceBackdrop.Controls.Add(workspaceColumns, 0, 2);
		status.MaximumSize = new Size(1100, 0);
		status.Margin = new Padding(0, 8, 0, 0);
		workspaceBackdrop.Controls.Add(status, 0, 3);
		FlowLayoutPanel flowLayoutPanel8 = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			WrapContents = true
		};
		flowLayoutPanel8.Controls.Add(CommunityLinks.CreateFooter());
		flowLayoutPanel8.Controls.Add(previousProfiles);
		workspaceBackdrop.Controls.Add(flowLayoutPanel8, 0, 4);
		appearanceControls = accentHue.Parent.Parent;
		appearanceControls.Parent = null;
		workspaceSettings = new FlowLayoutPanel
		{
			Dock = DockStyle.Top,
			AutoSize = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Width = 278,
			Margin = Padding.Empty
		};
		workspaceSettings.Controls.Add(new Label
		{
			Text = "Settings",
			AutoSize = true,
			Font = new Font("Segoe UI Semibold", 17f),
			ForeColor = Color.White,
			Tag = "workspace-title"
		});
		workspaceSettings.Controls.Add(new Label
		{
			Text = "Configure how Kanblaz Cloud works.",
			AutoSize = true,
			Font = new Font("Segoe UI", 9f),
			Margin = new Padding(0, 0, 0, 12)
		});
		Control control = BuildRecordMacro(InputPreferences.DefaultPath);
		controllerMode.Tag = "nexus-mode";
		AddSettingsSection("Controller", controllerMode, controllerHint, BuildControllerModeBinding(), NexusHelp(Ui("Touchpad: deliberate touch = F1; press = mouse click in games and main menu. Slide gently to move cursor.", "Touchpad: toque sostenido = F1; presionar = clic en juegos y menú principal. Desliza para mover cursor.")));
		AddSettingsSection("Movement", macroStart, NexusHelp(Ui("Every 3 minutes · F2 to start / stop", "Cada 3 minutos · F2 para iniciar / detener")));
		AddSettingsSection("Input", BuildInputSettings(out var mouseSettings));
		AddSettingsSection("Mouse", mouseSettings);
		AddSettingsSection(Ui("Controller Button", "Botón del control"), control);
		AddSettingsSection("Layout", new Label
		{
			Text = "Layout mode",
			AutoSize = true
		}, layoutMode, workspaceLayoutHint, editLayout, new Label
		{
			Text = "Main profile",
			AutoSize = true
		}, primarySession, borderlessFullscreen);
		Control control2 = appearanceControls;
		appearanceControls = BuildWorkspaceAppearance();
		control2.Dispose();
		workspaceLanguage.Items.AddRange(new object[3] { "English", "Español", "System language" });
		workspaceLanguage.SelectedIndex = (int)LanguagePreferences.ForCurrentUser().Load();
		workspaceLanguage.SelectedIndexChanged += delegate
		{
			if (workspaceLanguage.SelectedIndex >= 0)
			{
				AppLanguage selectedIndex = (AppLanguage)workspaceLanguage.SelectedIndex;
				try
				{
					LanguagePreferences.ForCurrentUser().Save(selectedIndex);
				}
				catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
				{
					status.Text = "Language could not be saved.";
					return;
				}
				uiLanguage = LanguagePreferences.Resolve(selectedIndex, CultureInfo.CurrentUICulture);
				ApplyTheme();
				UpdateMovementButton();
				UpdateSelectionButtons();
				RefreshGroups();
				RefreshProfiles(persist: false);
			}
		};
		AddSettingsSection("Appearance", appearanceControls, new Label
		{
			Text = "Language",
			AutoSize = true
		}, workspaceLanguage);
		WorkspaceToggle performance = new WorkspaceToggle
		{
			Text = Ui("Performance mode", "Modo rendimiento"),
			AutoSize = false,
			Width = 250,
			Height = 36,
			Checked = PerformanceMode.Enabled
		};
		bool restoringPerformance = false;
		performance.CheckedChanged += delegate
		{
			if (!restoringPerformance)
			{
				try
				{
					PerformanceMode.Save(performance.Checked);
				}
				catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
				{
					status.Text = Ui("Could not save performance mode.", "No se pudo guardar el modo rendimiento.");
					restoringPerformance = true;
					performance.Checked = PerformanceMode.Enabled;
					restoringPerformance = false;
					return;
				}
				cachedNexusTheme = null;
				SuspendLayout();
				try
				{
					ApplyTheme();
					ResizeWorkspaceColumns();
				}
				finally
				{
					ResumeLayout(performLayout: true);
				}
				Invalidate(invalidateChildren: true);
			}
		};
		AddSettingsSection("Performance", performance, BuildPerformanceMonitor(), NexusHelp(Ui("Simpler main window. Game audio, callouts and controls stay active.", "Panel simple. Audio, callouts y controles siguen activos.")));
		AddSettingsSection("Extras", BuildHudSettings());
		workspaceDrawer.Controls.Add(workspaceSettings);
		foreach (Control item3 in list)
		{
			Controls.Remove(item3);
			item3.Dispose();
		}
		Controls.Add(workspaceBackdrop);
		ClientSize = new Size(1500, 860);
		MinimumSize = new Size(1180, 720);
		profileGrid.Columns["launch"].HeaderText = "";
		profileGrid.Columns["name"].HeaderText = "PROFILE NAME";
		profileGrid.Columns["service"].HeaderText = "SERVICE";
		profileGrid.Columns["service"].Width = 210;
		((DataGridViewComboBoxColumn)profileGrid.Columns["service"]).DisplayStyleForCurrentCellOnly = true;
		profileGrid.Columns["name"].MinimumWidth = 125;
		profileGrid.Columns.Add(new DataGridViewTextBoxColumn
		{
			Name = "folder",
			HeaderText = "Folder",
			Width = 85,
			ReadOnly = true
		});
		profileGrid.Columns.Add(new DataGridViewTextBoxColumn
		{
			Name = "state",
			HeaderText = "Status",
			Width = 95,
			ReadOnly = true
		});
		profileGrid.Columns.Add(new DataGridViewButtonColumn
		{
			Name = "action",
			HeaderText = "Action",
			Text = "Launch",
			UseColumnTextForButtonValue = true,
			Width = 90,
			FlatStyle = FlatStyle.Flat
		});
		profileGrid.Columns["remove"].DisplayIndex = profileGrid.Columns.Count - 1;
		profileGrid.Columns["folder"].DisplayIndex = 2;
		profileGrid.Columns["launch"].Width = 54;
		profileGrid.Columns["launch"].MinimumWidth = 50;
		profileGrid.Columns["launch"].Visible = false;
		profileGrid.Columns["remove"].Width = 38;
		profileGrid.Columns["remove"].HeaderText = "";
		((DataGridViewButtonColumn)profileGrid.Columns["remove"]).Text = "…";
		profileGrid.Columns["remove"].ToolTipText = "Profile actions: rename, move, close, save for later or remove.";
		profileGrid.RowTemplate.Height = 44;
		profileGrid.ColumnHeadersHeight = 38;
		profileGrid.Columns["name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
		profileGrid.Columns["name"].FillWeight = 38f;
		profileGrid.Columns["folder"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
		profileGrid.Columns["folder"].FillWeight = 24f;
		profileGrid.Columns["service"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
		profileGrid.Columns["service"].FillWeight = 38f;
		profileGrid.Columns["name"].DefaultCellStyle.Padding = new Padding(12, 0, 0, 0);
		profileGrid.DefaultCellStyle.Font = new Font("Segoe UI", 11f);
		profileGrid.CellPainting += PaintWorkspaceCell;
		profileGrid.SelectionChanged += delegate
		{
			if (workspaceReady)
			{
				RefreshWorkspaceSummary();
			}
		};
		profileGrid.ContextMenuStrip.Items.Add("Profile details…", null, (object s, EventArgs e) =>
		{
			ShowProfileDetails(CurrentProfile());
		});
		profileGrid.ContextMenuStrip.Items.Add("Favorite / Unfavorite", null, (object s, EventArgs e) =>
		{
			Profile profile = CurrentProfile();
			if (profile != null)
			{
				Info(profile.StorageKey).Favorite = !Info(profile.StorageKey).Favorite;
				SaveWorkspaceInfo();
				RefreshProfiles();
			}
		});
		profileGrid.CellMouseClick += (object s, DataGridViewCellMouseEventArgs e) =>
		{
			if (e.Button == MouseButtons.Left && e.RowIndex >= 0 && e.ColumnIndex >= 0)
			{
				switch (profileGrid.Columns[e.ColumnIndex].Name)
				{
				case "name":
				case "folder":
				case "state":
					ToggleWorkspaceProfile(e.RowIndex);
					break;
				}
			}
		};
		profileGrid.KeyDown += (object s, KeyEventArgs e) =>
		{
			if (e.KeyCode == Keys.Space && e.Modifiers == Keys.None && !profileGrid.IsCurrentCellInEditMode && profileGrid.CurrentCell != null)
			{
				string name = profileGrid.CurrentCell.OwningColumn.Name;
				if (!(name != "name") || !(name != "folder") || !(name != "state"))
				{
					ToggleWorkspaceProfile(profileGrid.CurrentCell.RowIndex);
					e.Handled = true;
					e.SuppressKeyPress = true;
				}
			}
		};
		workspaceSearch.TextChanged += (object s, EventArgs e) =>
		{
			RefreshProfiles(persist: false);
		};
		workspaceFilter.SelectedIndexChanged += (object s, EventArgs e) =>
		{
			RefreshProfiles(persist: false);
		};
		workspaceSort.SelectedIndexChanged += (object s, EventArgs e) =>
		{
			RefreshProfiles(persist: false);
		};
		workspaceTips.SetToolTip(workspaceSearch, "Search saved profile names, folders or your local tags. No game account data is read.");
		workspaceTips.SetToolTip(controllerMode, "Individual: only the focused game window. Shared: all supported game windows.");
		workspaceTips.SetToolTip(macroStart, "F2 starts/stops movement in open Kanblaz sessions. Repeats every 3 minutes.");
		workspaceTips.SetToolTip(primarySession, "Choose the large window in Focus. Focus supports up to 5 sessions.");
		workspaceTips.SetToolTip(profileGrid, "Click a profile row or press Space to select. Right-click for details. Drag a profile name to a folder.");
		EnableProfileFolderDrag();
		workspaceReady = true;
		Resize += delegate
		{
			ResizeWorkspaceColumns();
		};
		ResizeWorkspaceColumns();
		KeyPreview = true;
		KeyDown += (object s, KeyEventArgs e) =>
		{
			if (e.Control && e.KeyCode == Keys.K)
			{
				workspaceSearch.Focus();
				workspaceSearch.SelectAll();
				e.SuppressKeyPress = true;
			}
		};
		StartupReady += delegate
		{
			if (profiles.Count == 0)
			{
				ShowWorkspaceGuide();
			}
		};
		FormClosed += delegate
		{
			workspaceTips.Dispose();
			workspaceSettings.Dispose();
			moreActions.Dispose();
		};
		workspaceBackdrop.ResumeLayout(performLayout: true);
		ResumeLayout(performLayout: true);
	}

	private void RefreshControllerModeDisplay()
	{
		string text = (controllerShared ? "Shared" : "Individual");
		controllerMode.Text = text;
		controllerMode.Invalidate();
		if (controllerSectionHeading != null && !controllerSectionHeading.IsDisposed)
		{
			controllerSectionHeading.Text = Ui("Controller", "Control") + " · " + text + ((controllerSectionContent != null && controllerSectionContent.Visible) ? "   ▴" : "   ▾");
			controllerSectionHeading.Invalidate();
		}
	}

	private void AddSettingsSection(string title, params Control[] controls)
	{
		WorkspaceCard workspaceCard = NewWorkspaceCard();
		workspaceCard.Width = 274;
		workspaceCard.AutoSize = true;
		workspaceCard.AutoSizeMode = AutoSizeMode.GrowAndShrink;
		workspaceCard.MinimumSize = new Size(274, 0);
		workspaceCard.Padding = new Padding(10);
		workspaceCard.Margin = new Padding(0, 0, 0, 10);
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Top,
			AutoSize = true,
			ColumnCount = 1,
			RowCount = 2,
			Width = 248,
			Margin = Padding.Empty
		};
		tableLayoutPanel.MinimumSize = new Size(248, 0);
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		WorkspaceButton heading = new WorkspaceButton
		{
			Text = title + "   ▾",
			Width = 248,
			Height = 38,
			TextAlign = ContentAlignment.MiddleLeft,
			FlatStyle = FlatStyle.Flat,
			Font = new Font("Segoe UI Semibold", 11f),
			AccessibleName = title + " settings",
			Tag = "workspace-section"
		};
		FlowLayoutPanel content = new FlowLayoutPanel
		{
			Visible = false,
			AutoSize = true,
			Width = 248,
			MaximumSize = new Size(248, 0),
			Dock = DockStyle.Top,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Margin = Padding.Empty,
			Padding = new Padding(0, 4, 0, 0)
		};
		for (int i = 0; i < controls.Length; i++)
		{
			Control control = controls[i];
			control.Margin = new Padding(0, 1, 0, 4);
			if ((control is ComboBox || control is Button) && Convert.ToString(control.Tag) != "nexus-help")
			{
				control.Width = 244;
				control.MinimumSize = new Size(244, 30);
			}
			if (control is Button)
			{
				((Button)control).AutoSize = false;
				control.Height = 34;
			}
			if (control is WorkspaceToggle)
			{
				((CheckBox)control).AutoSize = false;
				control.Size = new Size(244, 32);
			}
			if (control is Label label)
			{
				label.MaximumSize = new Size(244, 0);
			}
			if (control is Label && i + 1 < controls.Length && controls[i + 1] is ComboBox)
			{
				Control control2 = controls[++i];
				control2.MinimumSize = Size.Empty;
				control2.Width = 154;
				control2.Margin = Padding.Empty;
				TableLayoutPanel tableLayoutPanel2 = new TableLayoutPanel
				{
					Width = 248,
					Height = 36,
					ColumnCount = 2,
					RowCount = 1,
					Margin = new Padding(0, 0, 0, 3)
				};
				tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 88f));
				tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
				control.Dock = DockStyle.Fill;
				control.Margin = Padding.Empty;
				((Label)control).TextAlign = ContentAlignment.MiddleLeft;
				control2.Dock = DockStyle.Fill;
				tableLayoutPanel2.Controls.Add(control, 0, 0);
				tableLayoutPanel2.Controls.Add(control2, 1, 0);
				content.Controls.Add(tableLayoutPanel2);
			}
			else
			{
				content.Controls.Add(control);
			}
		}
		Action refreshHeading = () =>
		{
			string text = (SpanishWorkspace.TryGetValue(title, out var value) ? Ui(title, value) : title);
			if (title == "Controller")
			{
				text = text + " · " + (controllerShared ? "Shared" : "Individual");
			}
			heading.Text = text + (content.Visible ? "   ▴" : "   ▾");
			heading.Invalidate();
		};
		heading.Click += delegate
		{
			content.Visible = !content.Visible;
			refreshHeading();
		};
		if (title == "Controller")
		{
			controllerSectionHeading = heading;
			controllerSectionContent = content;
			heading.VisibleChanged += (object s, EventArgs e) =>
			{
				RefreshControllerModeDisplay();
			};
			EventHandler modeChanged = (object s, EventArgs e) =>
			{
				refreshHeading();
			};
			controllerMode.TextChanged += modeChanged;
			heading.Disposed += delegate
			{
				controllerMode.TextChanged -= modeChanged;
			};
		}
		refreshHeading();
		tableLayoutPanel.Controls.Add(heading, 0, 0);
		tableLayoutPanel.Controls.Add(content, 0, 1);
		workspaceCard.Controls.Add(tableLayoutPanel);
		workspaceSettings.Controls.Add(workspaceCard);
	}

	private Control BuildPerformanceMonitor()
	{
		Label reading = new Label
		{
			AutoSize = true,
			MaximumSize = new Size(244, 0),
			Padding = new Padding(0, 6, 0, 6),
			AccessibleName = "Main program performance"
		};
		System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer
		{
			Interval = 3000
		};
		Stopwatch clock = Stopwatch.StartNew();
		double previousTime = 0.0;
		double previousCpu = 0.0;
		bool baseline = false;
		Action reset = () =>
		{
			baseline = false;
			reading.Text = Ui("Main program only\nCPU: measuring…\nMemory: —\nUpdates every 3 seconds.\nGame processes are not included.", "Solo programa principal\nCPU: midiendo…\nMemoria: —\nActualiza cada 3 segundos.\nNo incluye procesos de juego.");
		};
		Func<bool> visible = () =>
		{
			if (IsDisposed || reading.IsDisposed || !reading.Visible || WindowState == FormWindowState.Minimized)
			{
				return false;
			}
			Rectangle a = reading.RectangleToScreen(reading.ClientRectangle);
			for (Control control = reading.Parent; control != null; control = control.Parent)
			{
				a = Rectangle.Intersect(a, control.RectangleToScreen(control.ClientRectangle));
			}
			return a.Width > 0 && a.Height > 0;
		};
		Action sample = () =>
		{
			if (!visible())
			{
				baseline = false;
				return;
			}
			try
			{
				using Process process = Process.GetCurrentProcess();
				double totalMilliseconds = clock.Elapsed.TotalMilliseconds;
				double totalMilliseconds2 = process.TotalProcessorTime.TotalMilliseconds;
				string text = (baseline ? (PerformanceReading.CpuPercent(totalMilliseconds2 - previousCpu, totalMilliseconds - previousTime, Environment.ProcessorCount).ToString("F1") + "%") : Ui("measuring…", "midiendo…"));
				previousTime = totalMilliseconds;
				previousCpu = totalMilliseconds2;
				baseline = true;
				reading.Text = Ui("Main program only", "Solo programa principal") + "\nCPU: " + text + "\n" + Ui("Memory: ", "Memoria: ") + ((double)process.WorkingSet64 / 1048576.0).ToString("F0") + " MB\n" + Ui("Updates every 3 seconds.\nGame processes are not included.", "Actualiza cada 3 segundos.\nNo incluye procesos de juego.");
			}
			catch (Exception ex) when (ex is InvalidOperationException || ex is Win32Exception)
			{
				baseline = false;
				reading.Text = Ui("Measurement unavailable.", "Medición no disponible.");
			}
		};
		EventHandler sync = delegate
		{
			timer.Stop();
			reset();
			if (reading.Visible && WindowState != FormWindowState.Minimized)
			{
				sample();
				timer.Start();
			}
		};
		timer.Tick += delegate
		{
			sample();
		};
		reading.VisibleChanged += sync;
		Resize += sync;
		reading.Disposed += delegate
		{
			Resize -= sync;
			timer.Stop();
			timer.Dispose();
		};
		reset();
		return reading;
	}

	private Control NexusHelp(string explanation)
	{
		WorkspaceButton workspaceButton = new WorkspaceButton
		{
			Text = "?",
			AutoSize = false,
			Size = new Size(30, 30),
			MinimumSize = new Size(30, 30),
			Tag = "nexus-help",
			AccessibleName = Ui("Help", "Ayuda")
		};
		workspaceTips.SetToolTip(workspaceButton, explanation);
		workspaceButton.Click += delegate
		{
			MessageBox.Show(this, explanation, Ui("Settings help", "Ayuda de ajustes"), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		};
		return workspaceButton;
	}

	private void ShowWorkspaceSettings()
	{
		ClearWorkspaceDrawer();
		workspaceDrawer.Controls.Add(workspaceSettings);
		workspaceDrawer.Visible = true;
		ApplyTheme();
	}

	private Control BuildWorkspaceAppearance()
	{
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Width = 248,
			AutoSize = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Margin = Padding.Empty
		};
		WorkspaceButton color = new WorkspaceButton
		{
			Text = "Nexus  " + ColorTranslator.ToHtml(nexus.Accent),
			Width = 244,
			Height = 34
		};
		color.Click += delegate
		{
			using ColorDialog colorDialog = new ColorDialog
			{
				Color = nexus.Accent,
				FullOpen = true
			};
			if (colorDialog.ShowDialog(this) == DialogResult.OK)
			{
				nexus.Accent = colorDialog.Color;
				color.Text = "Nexus  " + ColorTranslator.ToHtml(nexus.Accent);
				SaveNexusAppearance();
			}
		};
		flowLayoutPanel.Controls.Add(color);
		WorkspaceToggle light = new WorkspaceToggle
		{
			Text = Ui("Light mode", "Modo claro"),
			Checked = nexus.Light
		};
		light.CheckedChanged += delegate
		{
			nexus.Light = light.Checked;
			SaveNexusAppearance();
		};
		flowLayoutPanel.Controls.Add(light);
		WorkspaceToggle glow = new WorkspaceToggle
		{
			Text = "Nexus Glow",
			Checked = nexus.Glow
		};
		glow.CheckedChanged += delegate
		{
			nexus.Glow = glow.Checked;
			SaveNexusAppearance();
		};
		flowLayoutPanel.Controls.Add(glow);
		WorkspaceButton workspaceButton = new WorkspaceButton
		{
			Text = Ui("Reset Nexus color", "Restablecer color Nexus"),
			Width = 244,
			Height = 34
		};
		workspaceButton.Click += delegate
		{
			nexus.Accent = Color.FromArgb(7, 89, 133);
			color.Text = "Nexus  #075985";
			SaveNexusAppearance();
		};
		flowLayoutPanel.Controls.Add(workspaceButton);
		return flowLayoutPanel;
	}

	private void SaveNexusAppearance()
	{
		try
		{
			nexus.SaveTo(NexusPreferences.FilePath);
		}
		catch (IOException)
		{
			status.Text = "Appearance could not be saved.";
		}
		catch (UnauthorizedAccessException)
		{
			status.Text = "Extract the trial into a writable folder to save appearance.";
		}
		ApplyTheme();
	}

	private Control BuildWorkspaceCaption()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.Fill,
			Margin = Padding.Empty
		};
		MouseEventHandler value = (object sender, MouseEventArgs e) =>
		{
			if (e.Button == MouseButtons.Left)
			{
				WorkspaceWindowDrag.Start(Handle);
			}
		};
		panel.MouseDown += value;
		panel.DoubleClick += delegate
		{
			WindowState = ((WindowState != FormWindowState.Maximized) ? FormWindowState.Maximized : FormWindowState.Normal);
		};
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Right,
			Width = 132,
			FlowDirection = FlowDirection.LeftToRight,
			WrapContents = false,
			Margin = Padding.Empty
		};
		string[] array = new string[3] { "—", "□", "×" };
		foreach (string text in array)
		{
			string action = text;
			WorkspaceButton workspaceButton = new WorkspaceButton
			{
				Text = text,
				Size = new Size(42, 30),
				Margin = Padding.Empty,
				Tag = "window-button",
				Font = new Font("Segoe UI", 12f)
			};
			WorkspaceButton workspaceButton2 = workspaceButton;
			string accessibleName;
			if (action == "—")
			{
				accessibleName = "Minimize";
			}
			else
			{
				accessibleName = ((action == "□") ? "Maximize or restore" : "Close");
			}
			workspaceButton2.AccessibleName = accessibleName;
			workspaceButton.Click += delegate
			{
				if (action == "×")
				{
					Close();
				}
				else if (action == "—")
				{
					WindowState = FormWindowState.Minimized;
				}
				else
				{
					WindowState = ((WindowState != FormWindowState.Maximized) ? FormWindowState.Maximized : FormWindowState.Normal);
				}
			};
			flowLayoutPanel.Controls.Add(workspaceButton);
		}
		panel.Controls.Add(flowLayoutPanel);
		return panel;
	}

	private bool TryWorkspaceResize(ref Message message)
	{
		if (!workspaceReady || FormBorderStyle != FormBorderStyle.None || WindowState != FormWindowState.Normal || message.Msg != 132)
		{
			return false;
		}
		long num = message.LParam.ToInt64();
		Point point = PointToClient(new Point((short)(num & 0xFFFF), (short)((num >> 16) & 0xFFFF)));
		int num2 = Math.Max(6, (int)((float)(6 * DeviceDpi) / 96f));
		bool flag = point.X < num2;
		bool flag2 = point.X >= ClientSize.Width - num2;
		bool flag3 = point.Y < num2;
		bool flag4 = point.Y >= ClientSize.Height - num2;
		int num3;
		if (flag3)
		{
			if (flag)
			{
				num3 = 13;
			}
			else
			{
				num3 = (flag2 ? 14 : 12);
			}
		}
		else if (flag4)
		{
			if (flag)
			{
				num3 = 16;
			}
			else
			{
				num3 = (flag2 ? 17 : 15);
			}
		}
		else
		{
			num3 = (flag ? 10 : (flag2 ? 11 : 0));
		}
		if (num3 == 0)
		{
			return false;
		}
		message.Result = new IntPtr(num3);
		return true;
	}

	private WorkspaceCard NewWorkspaceCard()
	{
		WorkspaceCard workspaceCard = new WorkspaceCard
		{
			Padding = new Padding(16),
			Margin = new Padding(0, 0, 0, 12)
		};
		workspaceCards.Add(workspaceCard);
		return workspaceCard;
	}

	private void ResizeWorkspaceColumns()
	{
		if (workspaceColumns == null)
		{
			return;
		}
		float num = (float)DeviceDpi / 96f;
		bool flag = (float)ClientSize.Width / num < 1360f;
		workspaceColumns.ColumnStyles[0].Width = (flag ? 210f : ((float)ClientSize.Width / num * 0.155f)) * num;
		workspaceColumns.ColumnStyles[2].Width = (flag ? 320f : ((float)ClientSize.Width / num * 0.275f)) * num;
		if (PerformanceMode.Enabled)
		{
			workspaceColumns.ColumnStyles[0].Width = 210f * num;
			workspaceColumns.ColumnStyles[2].Width = 320f * num;
		}
		int num2 = Math.Max(248, (int)workspaceColumns.ColumnStyles[2].Width - (int)(55f * num));
		workspaceSettings.Width = num2;
		foreach (Control control2 in workspaceSettings.Controls)
		{
			if (!(control2 is WorkspaceCard workspaceCard))
			{
				continue;
			}
			workspaceCard.MinimumSize = new Size(num2, 0);
			workspaceCard.Width = num2;
			if (workspaceCard.Controls.Count == 0 || !(workspaceCard.Controls[0] is TableLayoutPanel tableLayoutPanel))
			{
				continue;
			}
			tableLayoutPanel.Width = num2 - workspaceCard.Padding.Horizontal;
			foreach (Control control3 in tableLayoutPanel.Controls)
			{
				control3.Width = tableLayoutPanel.Width;
				if (!(control3 is Button))
				{
					control3.MaximumSize = new Size(tableLayoutPanel.Width, 0);
				}
				if (control3 is FlowLayoutPanel)
				{
					ResizeNexusContent(control3, tableLayoutPanel.Width);
				}
			}
		}
		if (workspaceReady)
		{
			profileGrid.Columns["folder"].Visible = !flag;
		}
	}

	private static void ResizeNexusContent(Control parent, int width)
	{
		parent.Width = width;
		foreach (Control control in parent.Controls)
		{
			int num = Math.Max(100, width - parent.Padding.Horizontal - control.Margin.Horizontal);
			if (control is FlowLayoutPanel)
			{
				control.MaximumSize = new Size(num, 0);
				ResizeNexusContent(control, num);
			}
			else if ((control is WorkspaceToggle || control is Button || control is TrackBar) && Convert.ToString(control.Tag) != "nexus-help" && Convert.ToString(control.Tag) != "background-thumb")
			{
				control.MinimumSize = Size.Empty;
				control.Width = num;
			}
			else if (control is Label)
			{
				control.MaximumSize = new Size(num, 0);
			}
		}
	}

	private void ShowWorkspaceProfileActions(Profile profile)
	{
		if (profile == null)
		{
			return;
		}
		ContextMenuStrip menu = new ContextMenuStrip();
		menu.Items.Add("Profile details…", null, (object s, EventArgs e) =>
		{
			ShowProfileDetails(profile);
		});
		menu.Items.Add("Rename…", null, (object s, EventArgs e) =>
		{
			RenameProfile(profile);
		});
		menu.Items.Add("Move to Folder… (Pro)", null, (object s, EventArgs e) =>
		{
			MoveWorkspaceProfiles(new List<Profile> { profile });
		}).Enabled = access.CanUseGroups;
		menu.Items.Add("Favorite / Unfavorite", null, (object s, EventArgs e) =>
		{
			Info(profile.StorageKey).Favorite = !Info(profile.StorageKey).Favorite;
			SaveWorkspaceInfo();
			RefreshProfiles();
		});
		menu.Items.Add(Ui("Restart session", "Reiniciar sesión"), null, async (object s, EventArgs e) =>
		{
			await RestartProfileAsync(profile);
		});
		menu.Items.Add("Close", null, (object s, EventArgs e) =>
		{
			CloseProfileSession(profile.StorageKey);
		});
		menu.Items.Add("Save profile for later", null, (object s, EventArgs e) =>
		{
			if (sessions.TryGetValue(profile.StorageKey, out var value))
			{
				value.Close();
			}
			ShellStorage.ArchiveProfile(profile.StorageKey);
			selectedProfiles.Remove(profile.StorageKey);
			profiles.Clear();
			profiles.AddRange(ShellStorage.LoadProfiles());
			RefreshProfiles();
		});
		if (!IsAllProfiles)
		{
			menu.Items.Add(new ToolStripSeparator());
			menu.Items.Add(Ui("Remove from this folder", "Quitar de esta carpeta"), null, (object s, EventArgs e) =>
			{
				RemoveFolderReference(profile);
			});
			menu.Items.Add(Ui("Delete profile everywhere…", "Eliminar perfil de todas partes…"), null, (object s, EventArgs e) =>
			{
				RemoveProfile(profile);
			});
		}
		menu.Closed += delegate
		{
			if (!IsDisposed && IsHandleCreated)
			{
				BeginInvoke(new Action(menu.Dispose));
			}
		};
		Point position = profileGrid.PointToClient(Cursor.Position);
		menu.Show(profileGrid, position);
	}

	private void PaintWorkspaceCell(object sender, DataGridViewCellPaintingEventArgs e)
	{
		if (e.ColumnIndex < 0 || !workspaceReady)
		{
			return;
		}
		if (e.RowIndex < 0)
		{
			WorkspaceBackdrop.PaintBehind(profileGrid, e.Graphics, e.CellBounds, 45);
			e.PaintContent(e.ClipBounds);
			e.Handled = true;
			return;
		}
		string name = profileGrid.Columns[e.ColumnIndex].Name;
		AppTheme currentTheme = CurrentTheme;
		Rectangle cellBounds = e.CellBounds;
		if (!(profileGrid.Rows[e.RowIndex].Tag is Profile profile))
		{
			return;
		}
		GraphicsState gstate = e.Graphics.Save();
		e.Graphics.SetClip(Rectangle.Intersect(e.ClipBounds, e.CellBounds), CombineMode.Intersect);
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		WorkspaceBackdrop.PaintBehind(profileGrid, e.Graphics, cellBounds, 35);
		bool flag = selectedProfiles.Contains(profile.StorageKey);
		Rectangle rowDisplayRectangle = profileGrid.GetRowDisplayRectangle(e.RowIndex, cutOverflow: true);
		rowDisplayRectangle = new Rectangle(rowDisplayRectangle.Left + 1, cellBounds.Y + 3, Math.Max(1, rowDisplayRectangle.Width - 3), cellBounds.Height - 6);
		using (GraphicsPath path = WorkspaceDrawing.Round(rowDisplayRectangle, 9))
		{
			using SolidBrush brush = new SolidBrush(Color.FromArgb(flag ? 190 : 40, flag ? currentTheme.Selection : currentTheme.SurfaceRaised));
			using Pen pen = new Pen(flag ? currentTheme.ActiveBorder : currentTheme.Border);
			e.Graphics.FillPath(brush, path);
			if (flag)
			{
				e.Graphics.DrawPath(pen, path);
			}
		}
		switch (name)
		{
		case "state":
		{
			string text2 = WorkspaceState(profile.StorageKey);
			Color color2 = text2 switch
			{
				"Launching" => Color.FromArgb(243, 190, 65), 
				"Active" => Color.FromArgb(52, 217, 125), 
				"Failed" => Color.FromArgb(244, 137, 128), 
				_ => currentTheme.Muted, 
			};
			Rectangle bounds = new Rectangle(cellBounds.X + 5, cellBounds.Y + 9, Math.Max(1, cellBounds.Width - 10), Math.Max(1, cellBounds.Height - 18));
			using (GraphicsPath path2 = WorkspaceDrawing.Round(bounds, 10))
			{
				using SolidBrush brush3 = new SolidBrush((text2 == "Ready" || text2 == "Closed") ? currentTheme.SurfaceRaised : Color.FromArgb(22, color2));
				using Pen pen2 = new Pen(Color.FromArgb(65, color2));
				e.Graphics.FillPath(brush3, path2);
				e.Graphics.DrawPath(pen2, path2);
			}
			TextRenderer.DrawText(e.Graphics, text2, profileGrid.Font, bounds, color2, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			break;
		}
		case "action":
		case "remove":
		{
			Rectangle bounds2 = new Rectangle(cellBounds.X + 4, cellBounds.Y + 7, Math.Max(1, cellBounds.Width - 8), Math.Max(1, cellBounds.Height - 14));
			using (GraphicsPath path3 = WorkspaceDrawing.Round(bounds2, 6))
			{
				using SolidBrush brush4 = new SolidBrush(currentTheme.SurfaceRaised);
				using Pen pen3 = new Pen(currentTheme.Border);
				e.Graphics.FillPath(brush4, path3);
				e.Graphics.DrawPath(pen3, path3);
			}
			TextRenderer.DrawText(e.Graphics, (name == "action") ? "▶ Launch" : "…", profileGrid.Font, bounds2, currentTheme.Text, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			break;
		}
		case "service":
		{
			bool flag2 = profile.Service.Name == CloudService.Geforce.Name;
			bool flag3 = profile.Service.Name == CloudService.Luna.Name;
			Rectangle rectangle = new Rectangle(cellBounds.X + 7, cellBounds.Y + (cellBounds.Height - 18) / 2, 18, 18);
			Color color;
			if (flag3)
			{
				color = Color.FromArgb(145, 70, 220);
			}
			else
			{
				color = (flag2 ? Color.FromArgb(118, 185, 0) : Color.FromArgb(35, 195, 68));
			}
			using (SolidBrush brush2 = new SolidBrush(color))
			{
				e.Graphics.FillEllipse(brush2, rectangle);
			}
			Graphics graphics = e.Graphics;
			string text;
			if (flag3)
			{
				text = "L";
			}
			else
			{
				text = (flag2 ? "G" : "X");
			}
			TextRenderer.DrawText(graphics, text, profileGrid.Font, rectangle, Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			TextRenderer.DrawText(e.Graphics, profile.Service.Name, profileGrid.Font, new Rectangle(rectangle.Right + 8, cellBounds.Y, cellBounds.Width - 39, cellBounds.Height), currentTheme.Text, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
			break;
		}
		case "name":
		case "folder":
			TextRenderer.DrawText(e.Graphics, Convert.ToString(e.FormattedValue), profileGrid.DefaultCellStyle.Font, new Rectangle(cellBounds.X + 12, cellBounds.Y, Math.Max(1, cellBounds.Width - 18), cellBounds.Height), currentTheme.Text, TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix | TextFormatFlags.VerticalCenter);
			break;
		default:
			e.PaintContent(e.ClipBounds);
			break;
		}
		e.Graphics.Restore(gstate);
		e.Handled = true;
	}

	private void DrawWorkspaceFolder(DrawItemEventArgs e)
	{
		AppTheme currentTheme = CurrentTheme;
		ProfileGroupOption option = (ProfileGroupOption)groupList.Items[e.Index];
		bool flag = (e.State & DrawItemState.Selected) != 0;
		WorkspaceBackdrop.PaintBehind(groupList, e.Graphics, e.Bounds, 35);
		Rectangle rectangle = new Rectangle(e.Bounds.X + 1, e.Bounds.Y + 4, e.Bounds.Width - 3, e.Bounds.Height - 8);
		if (flag)
		{
			using (GraphicsPath path = WorkspaceDrawing.Round(rectangle, 8))
			{
				using LinearGradientBrush brush = new LinearGradientBrush(rectangle, currentTheme.Selection, currentTheme.SurfaceRaised, 90f);
				using Pen pen = new Pen(currentTheme.ActiveBorder);
				e.Graphics.FillPath(brush, path);
				e.Graphics.DrawPath(pen, path);
			}
			using Pen pen2 = new Pen(currentTheme.Accent, 3f);
			e.Graphics.DrawLine(pen2, rectangle.Left + 2, rectangle.Top + 6, rectangle.Left + 2, rectangle.Bottom - 6);
		}
		Color color = currentTheme.Text;
		int num = rectangle.X + 13;
		int num2 = rectangle.Y + (rectangle.Height - 16) / 2;
		using (Pen pen3 = new Pen(color, 1.6f))
		{
			e.Graphics.DrawLines(pen3, new Point[8]
			{
				new Point(num, num2 + 3),
				new Point(num, num2),
				new Point(num + 7, num2),
				new Point(num + 10, num2 + 3),
				new Point(num + 18, num2 + 3),
				new Point(num + 18, num2 + 15),
				new Point(num, num2 + 15),
				new Point(num, num2 + 3)
			});
		}
		int num3 = (from p in profiles
			where option.Id == Guid.Empty || ProfileFolders(p).Contains(option.Id ?? Guid.Empty)
			select p.StorageKey).Distinct().Count();
		TextRenderer.DrawText(bounds: new Rectangle(rectangle.Right - 34, rectangle.Y + 9, 28, rectangle.Height - 18), dc: e.Graphics, text: num3.ToString(), font: e.Font, foreColor: color, flags: TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
		TextRenderer.DrawText(e.Graphics, option.Name, e.Font, new Rectangle(num + 29, rectangle.Y, Math.Max(1, rectangle.Width - 80), rectangle.Height), color, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
		if ((e.State & DrawItemState.Focus) != 0 && groupList.Focused)
		{
			e.DrawFocusRectangle();
		}
	}

	private void ClearWorkspaceDrawer()
	{
		inspectedId = Guid.Empty;
		inspectedState = null;
		workspaceSettings.Parent = null;
		foreach (Control item in workspaceDrawer.Controls.Cast<Control>().ToList())
		{
			item.Dispose();
		}
	}

	private List<Profile> FilterWorkspaceProfiles(List<Profile> values)
	{
		if (!workspaceReady)
		{
			return values;
		}
		IEnumerable<Profile> enumerable;
		if (!IsAllProfiles)
		{
			enumerable = values.Where(InCurrentGame);
		}
		else
		{
			enumerable = values;
		}
		IEnumerable<Profile> source = enumerable;
		if (smartView == "Favorites")
		{
			source = source.Where((Profile p) => Info(p.StorageKey).Favorite);
		}
		if (smartView == "Recently used")
		{
			source = source.Where((Profile p) => Info(p.StorageKey).LastLaunch > 0);
		}
		if (smartView == "Running now")
		{
			source = source.Where((Profile p) => sessions.ContainsKey(p.StorageKey));
		}
		string text = workspaceSearch.Text.Trim();
		if (text.Length > 0)
		{
			source = source.Where((Profile p) => (p.Label + " " + FolderName(p) + " " + Info(p.StorageKey).Tags).IndexOf(text, StringComparison.CurrentCultureIgnoreCase) >= 0);
		}
		string filter = Convert.ToString(workspaceFilter.SelectedItem);
		if (filter == CloudService.Xbox.Name || filter == CloudService.Geforce.Name || filter == CloudService.Luna.Name)
		{
			source = source.Where((Profile p) => p.Service.Name == filter);
		}
		else if (filter != "All services")
		{
			source = source.Where((Profile p) => WorkspaceState(p.StorageKey) == filter);
		}
		string text2 = Convert.ToString(workspaceSort.SelectedItem);
		if (text2 == "Recently used" || smartView == "Recently used")
		{
			source = source.OrderByDescending((Profile p) => Info(p.StorageKey).LastLaunch);
		}
		else
		{
			source = ((!(text2 == "Name Z–A")) ? source.OrderBy((Profile p) => p.Label, StringComparer.CurrentCultureIgnoreCase) : source.OrderByDescending((Profile p) => p.Label, StringComparer.CurrentCultureIgnoreCase));
		}
		return source.ToList();
	}

	private string FolderName(Profile p)
	{
		return string.Join(", ", ProfileFolders(p).Select((Guid id) =>
		{
			ProfileGroup profileGroup = groups.FirstOrDefault((ProfileGroup g) => g.Id == id);
			return (profileGroup != null) ? profileGroup.Name : Ui("Main Profiles", "Perfiles principales");
		}));
	}

	private string WorkspaceState(Guid id)
	{
		if (!workspaceStates.TryGetValue(id, out var value))
		{
			if (Info(id).LastLaunch <= 0)
			{
				return "Ready";
			}
			return "Closed";
		}
		return value;
	}

	private void UpdateWorkspaceRow(DataGridViewRow row, Profile profile)
	{
		if (workspaceReady)
		{
			row.DefaultCellStyle.BackColor = (selectedProfiles.Contains(profile.StorageKey) ? CurrentTheme.Selection : CurrentTheme.Surface);
			row.Cells["folder"].Value = FolderName(profile);
			string text = WorkspaceState(profile.StorageKey);
			row.Cells["state"].Value = "● " + text;
			row.Cells["state"].Style.ForeColor = text switch
			{
				"Launching" => Color.Khaki, 
				"Active" => Color.LightGreen, 
				"Failed" => Color.Salmon, 
				_ => CurrentTheme.Muted, 
			};
			row.Cells["state"].Style.SelectionForeColor = row.Cells["state"].Style.ForeColor;
			row.Cells["state"].ToolTipText = "Active means the service page loaded; it does not confirm gameplay has started.";
		}
	}

	private void ToggleWorkspaceProfile(int rowIndex)
	{
		DataGridViewRow dataGridViewRow = profileGrid.Rows[rowIndex];
		if (dataGridViewRow.Tag is Profile profile)
		{
			bool flag = selectedProfiles.Add(profile.StorageKey);
			if (!flag)
			{
				selectedProfiles.Remove(profile.StorageKey);
			}
			dataGridViewRow.Cells["launch"].Value = flag;
			RefreshWorkspaceSelection();
			profileGrid.InvalidateRow(rowIndex);
		}
	}

	private void RefreshWorkspaceSelection()
	{
		if (!workspaceReady)
		{
			return;
		}
		selectionActions.Visible = true;
		foreach (Control control in selectionActions.Controls)
		{
			control.Enabled = ProfilesInCurrentScope().Any((Profile p) => selectedProfiles.Contains(p.StorageKey));
		}
		foreach (DataGridViewRow item in (IEnumerable)profileGrid.Rows)
		{
			if (item.Tag is Profile profile)
			{
				UpdateWorkspaceRow(item, profile);
			}
		}
		RefreshWorkspaceSummary();
	}

	private void RefreshWorkspaceSummary()
	{
		if (workspaceReady)
		{
			ProfileGroup profileGroup = ((groupFilter.HasValue && groupFilter.Value != Guid.Empty) ? groups.FirstOrDefault((ProfileGroup g) => g.Id == groupFilter.Value) : null);
			Label label = workspaceTitle;
			string text;
			if (smartView != "All")
			{
				text = smartView;
			}
			else
			{
				text = ((profileGroup != null) ? profileGroup.Name : Ui("Main Profiles", "Perfiles principales"));
			}
			label.Text = text;
			List<Profile> list = ProfilesInCurrentScope();
			workspaceCount.Text = list.Count + " profiles";
			workspaceSelected.Text = string.Format(Ui("{0} of {1} selected", "{0} de {1} seleccionados"), list.Count((Profile p) => selectedProfiles.Contains(p.StorageKey)), list.Count);
			workspaceSummary.Text = string.Format("{0} open · {1} launching · {2} failed", sessions.Count, workspaceStates.Count((KeyValuePair<Guid, string> p) => p.Value == "Launching"), workspaceStates.Count((KeyValuePair<Guid, string> p) => p.Value == "Failed"));
			workspaceLayoutHint.Text = ((EffectiveLayoutMode == SessionLayoutMode.Focus) ? "Up to 5 windows" : "No Pro window cap in this layout.");
			workspaceTips.SetToolTip(workspaceLayoutHint, "Practical capacity depends on your PC and cloud service.");
			emptyWorkspace.Visible = profileGrid.Rows.Count == 0;
			emptyWorkspace.Text = ((profiles.Count == 0) ? "No profiles yet\n\nUse Add Profile to get started." : "No matching profiles\n\nTry another folder, search or filter.");
			if (emptyWorkspace.Visible)
			{
				emptyWorkspace.BringToFront();
			}
		}
	}

	private void ObserveWorkspaceSession(Profile profile, CloudSessionForm session)
	{
		Info(profile.StorageKey).LastLaunch = DateTime.UtcNow.Ticks;
		SaveWorkspaceInfo();
		session.WorkspaceStateChanged += (string state) =>
		{
			SetWorkspaceState(profile.StorageKey, state);
		};
		session.WelcomeRecoveryRequested += async () =>
		{
			await RecoverWelcomeAsync(profile, session);
		};
		SetWorkspaceState(profile.StorageKey, "Launching");
	}

	private void SetWorkspaceState(Guid id, string state)
	{
		if (IsDisposed || Disposing)
		{
			return;
		}
		if (InvokeRequired)
		{
			BeginInvoke((Action)(() =>
			{
				SetWorkspaceState(id, state);
			}));
			return;
		}
		workspaceStates[id] = state;
		if (inspectedId == id && inspectedState != null && !inspectedState.IsDisposed)
		{
			inspectedState.Text = "Status: " + state;
		}
		Info(id).LastStatus = state;
		SaveWorkspaceInfo();
		foreach (DataGridViewRow item in (IEnumerable)profileGrid.Rows)
		{
			if (item.Tag is Profile profile && profile.StorageKey == id)
			{
				UpdateWorkspaceRow(item, profile);
			}
		}
		RefreshWorkspaceSummary();
		if (workspaceRefreshQueued || !IsHandleCreated || (!(smartView == "Running now") && !(smartView == "Recently used") && workspaceFilter.SelectedIndex < 3))
		{
			return;
		}
		workspaceRefreshQueued = true;
		BeginInvoke((Action)(() =>
		{
			workspaceRefreshQueued = false;
			if (!IsDisposed && !Disposing)
			{
				RefreshProfiles(persist: false);
			}
		}));
	}

	private void RetryWorkspaceFailures()
	{
		List<Profile> list = (from p in ProfilesInCurrentScope()
			where WorkspaceState(p.StorageKey) == "Failed"
			select p).ToList();
		foreach (Profile item in list)
		{
			if (sessions.TryGetValue(item.StorageKey, out var value))
			{
				value.Close();
			}
		}
		LaunchProfiles(list);
	}

	private void MoveWorkspaceProfiles(List<Profile> moving)
	{
		if (!access.CanUseGroups || moving.Count == 0)
		{
			return;
		}
		using Form form = new Form
		{
			Text = "Move to Folder",
			Size = new Size(360, 200),
			StartPosition = FormStartPosition.CenterParent,
			MinimizeBox = false,
			MaximizeBox = false
		};
		ComboBox comboBox = new ComboBox
		{
			Dock = DockStyle.Top,
			DropDownStyle = ComboBoxStyle.DropDownList
		};
		List<ProfileGroup> list = CurrentGameFolders.ToList();
		comboBox.Items.Add(Ui("Main Profiles", "Perfiles principales"));
		foreach (ProfileGroup item in list)
		{
			comboBox.Items.Add(item.Name);
		}
		comboBox.SelectedIndex = 0;
		Button button = new Button
		{
			Text = "Move " + moving.Count + " profiles",
			Dock = DockStyle.Bottom,
			Height = 40,
			DialogResult = DialogResult.OK
		};
		form.Controls.Add(comboBox);
		form.Controls.Add(button);
		form.AcceptButton = button;
		if (form.ShowDialog(this) == DialogResult.OK)
		{
			AssignWorkspaceFolder(moving, (comboBox.SelectedIndex == 0) ? Guid.Empty : list[comboBox.SelectedIndex - 1].Id);
		}
	}

	private void AssignWorkspaceFolder(List<Profile> moving, Guid folder)
	{
		if (access.CanUseGroups && (!(folder != Guid.Empty) || groups.Any((ProfileGroup g) => g.Id == folder)) && (!(folder != Guid.Empty) || !(GameForFolder(folder) != currentGame)) && UpdateFolderReferences(moving, folder, move: true))
		{
			RefreshProfiles(persist: false);
		}
	}

	private void EnableProfileFolderDrag()
	{
		profileGrid.MouseDown += (object s, MouseEventArgs e) =>
		{
			DataGridView.HitTestInfo hitTestInfo = profileGrid.HitTest(e.X, e.Y);
			draggedProfile = null;
			if (e.Button == MouseButtons.Left && hitTestInfo.RowIndex >= 0 && hitTestInfo.ColumnIndex == profileGrid.Columns["name"].Index)
			{
				draggedProfile = ((Profile)profileGrid.Rows[hitTestInfo.RowIndex].Tag).StorageKey;
				profileDragStart = e.Location;
			}
		};
		profileGrid.MouseMove += (object s, MouseEventArgs e) =>
		{
			if (access.CanUseGroups && e.Button == MouseButtons.Left && draggedProfile.HasValue && Math.Abs(e.X - profileDragStart.X) + Math.Abs(e.Y - profileDragStart.Y) >= 8)
			{
				Guid value = draggedProfile.Value;
				draggedProfile = null;
				profileGrid.DoDragDrop(new DataObject("KanblazProfile", value.ToString()), DragDropEffects.Move);
			}
		};
		groupList.AllowDrop = true;
		groupList.DragOver += (object s, DragEventArgs e) =>
		{
			int num = groupList.IndexFromPoint(groupList.PointToClient(new Point(e.X, e.Y)));
			e.Effect = ((access.CanUseGroups && e.Data.GetDataPresent("KanblazProfile") && num >= 0) ? DragDropEffects.Move : DragDropEffects.None);
		};
		groupList.DragDrop += (object s, DragEventArgs e) =>
		{
			int num = groupList.IndexFromPoint(groupList.PointToClient(new Point(e.X, e.Y)));
			if (num >= 0 && Guid.TryParse(Convert.ToString(e.Data.GetData("KanblazProfile")), out var id))
			{
				Guid? id2 = ((ProfileGroupOption)groupList.Items[num]).Id;
				if (!(id2 == Guid.Empty))
				{
					AssignWorkspaceFolder(profiles.Where((Profile p) => p.StorageKey == id).ToList(), id2 ?? Guid.Empty);
				}
			}
		};
	}

	private void ShowProfileDetails(Profile profile)
	{
		if (profile == null || !workspaceReady)
		{
			return;
		}
		ClearWorkspaceDrawer();
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Top,
			AutoSize = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Width = 280
		};
		WorkspaceProfileInfo info = Info(profile.StorageKey);
		inspectedId = profile.StorageKey;
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = profile.Label,
			AutoSize = true,
			MaximumSize = new Size(270, 0),
			Font = new Font("Segoe UI Semibold", 14f),
			ForeColor = Color.White
		});
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = profile.Service.Name + "\n" + FolderName(profile),
			AutoSize = true,
			Margin = new Padding(0, 12, 0, 12)
		});
		inspectedState = new Label
		{
			Text = "Status: " + WorkspaceState(profile.StorageKey),
			AutoSize = true
		};
		flowLayoutPanel.Controls.Add(inspectedState);
		string text = ((info.LastLaunch > DateTime.MinValue.Ticks && info.LastLaunch <= DateTime.MaxValue.Ticks) ? new DateTime(info.LastLaunch, DateTimeKind.Utc).ToLocalTime().ToString("g") : "Never");
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Last launch: " + text + "\nLast status: " + (info.LastStatus ?? "Ready"),
			AutoSize = true
		});
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Epic ID (optional, entered manually)",
			AutoSize = true,
			Margin = new Padding(0, 14, 0, 4)
		});
		TextBox epic = new TextBox
		{
			Text = (info.EpicId ?? ""),
			Width = 265,
			MaxLength = 100
		};
		flowLayoutPanel.Controls.Add(epic);
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = "Tags (local notes)",
			AutoSize = true
		});
		TextBox tags = new TextBox
		{
			Text = (info.Tags ?? ""),
			Width = 265,
			MaxLength = 200
		};
		flowLayoutPanel.Controls.Add(tags);
		CheckBox favorite = new CheckBox
		{
			Text = "Favorite",
			AutoSize = true,
			Checked = info.Favorite
		};
		flowLayoutPanel.Controls.Add(favorite);
		flowLayoutPanel.Controls.Add(CreateButton("Save details", (object s, EventArgs e) =>
		{
			info.EpicId = epic.Text.Trim();
			info.Tags = tags.Text.Trim();
			info.Favorite = favorite.Checked;
			SaveWorkspaceInfo();
			RefreshProfiles();
		}));
		flowLayoutPanel.Controls.Add(CreateButton("Rename", (object s, EventArgs e) =>
		{
			RenameProfile(profile);
			ShowProfileDetails(profile);
		}));
		Button button = CreateButton("Move to Folder (Pro)", (object s, EventArgs e) =>
		{
			MoveWorkspaceProfiles(new List<Profile> { profile });
		});
		button.Enabled = access.CanUseGroups;
		flowLayoutPanel.Controls.Add(button);
		flowLayoutPanel.Controls.Add(CreateButton("Launch", (object s, EventArgs e) =>
		{
			LaunchProfiles(new List<Profile> { profile });
		}, primary: true));
		flowLayoutPanel.Controls.Add(CreateButton(Ui("Restart session", "Reiniciar sesión"), async (object s, EventArgs e) =>
		{
			await RestartProfileAsync(profile);
		}));
		flowLayoutPanel.Controls.Add(CreateButton("Close", (object s, EventArgs e) =>
		{
			CloseProfileSession(profile.StorageKey);
		}));
		if (!IsAllProfiles)
		{
			flowLayoutPanel.Controls.Add(CreateButton(Ui("Delete everywhere…", "Eliminar de todas partes…"), (object s, EventArgs e) =>
			{
				RemoveProfile(profile);
				ShowWorkspaceSettings();
			}));
		}
		flowLayoutPanel.Controls.Add(CreateButton("Back to Settings", (object s, EventArgs e) =>
		{
			ShowWorkspaceSettings();
		}));
		workspaceDrawer.Controls.Add(flowLayoutPanel);
		workspaceDrawer.Visible = true;
		ApplyTheme();
	}

	private void ShowWorkspaceGuide()
	{
		using VisualQuickGuide visualQuickGuide = new VisualQuickGuide(Ui("en", "es") == "es", InputPreferences.Current.Release.ToString());
		visualQuickGuide.ShowDialog(this);
	}

	private void ApplyWorkspaceTheme(AppTheme theme)
	{
		if (!workspaceReady)
		{
			return;
		}
		ApplyWorkspaceLanguage(Controls);
		foreach (Control control in Controls)
		{
			if (control is WorkspaceBackdrop workspaceBackdrop)
			{
				workspaceBackdrop.Palette = theme;
				workspaceBackdrop.SetBackground((!nexus.Light) ? 1 : 2);
				workspaceBackdrop.Invalidate(invalidateChildren: true);
			}
		}
		workspaceDrawer.BackColor = Color.Transparent;
		profileGrid.CellBorderStyle = DataGridViewCellBorderStyle.None;
		workspaceSearch.BackColor = theme.SurfaceRaised;
		workspaceSearch.ForeColor = theme.Text;
		workspaceSummary.ForeColor = theme.Muted;
		emptyWorkspace.BackColor = theme.Surface;
		emptyWorkspace.ForeColor = theme.Muted;
		if (workspaceSettings.Parent == null)
		{
			ApplyThemeTo(workspaceSettings.Controls, theme);
		}
		foreach (WorkspaceCard item in workspaceCards.Where((WorkspaceCard c) => !c.IsDisposed))
		{
			item.Palette = theme;
			item.BackColor = Color.Transparent;
			item.Invalidate();
		}
		workspaceMark.Accent = theme.Accent;
		workspaceMark.PerformanceCaption = Ui("Performance mode", "Modo rendimiento");
		workspaceMark.Invalidate();
		workspaceCount.BackColor = Color.Transparent;
		workspaceCount.ForeColor = theme.Muted;
		workspaceTitle.ForeColor = theme.Text;
		workspaceSelected.ForeColor = theme.Muted;
		workspaceSearch.BackColor = theme.Surface;
		SkinWorkspaceButtons(Controls, theme);
		ApplyWorkspaceSurfaces(Controls, theme);
		foreach (DataGridViewRow item2 in (IEnumerable)profileGrid.Rows)
		{
			if (item2.Tag is Profile profile)
			{
				UpdateWorkspaceRow(item2, profile);
			}
		}
	}

	private void FlushAccentPreview()
	{
		if (accentPreviewTimer.Enabled && !IsDisposed && !Disposing)
		{
			accentPreviewTimer.Stop();
			ApplyTheme();
		}
	}

	private void PreviewAccentControls(Control.ControlCollection controls, AppTheme theme)
	{
		foreach (Control control in controls)
		{
			if (control is WorkspaceButton workspaceButton)
			{
				workspaceButton.Palette = theme;
				workspaceButton.Invalidate();
			}
			if (control is WorkspaceComboBox workspaceComboBox)
			{
				workspaceComboBox.Palette = theme;
				workspaceComboBox.Invalidate();
			}
			if (control is WorkspaceToggle workspaceToggle)
			{
				workspaceToggle.Accent = theme.Accent;
				workspaceToggle.Invalidate();
			}
			if (control is WorkspaceSlider workspaceSlider)
			{
				workspaceSlider.Accent = theme.Accent;
				workspaceSlider.Invalidate();
			}
			if (control is WorkspaceBrandTitle workspaceBrandTitle)
			{
				workspaceBrandTitle.Accent = theme.ActiveBorder;
				workspaceBrandTitle.ForeColor = theme.Text;
				workspaceBrandTitle.Invalidate();
			}
			if (control.HasChildren)
			{
				PreviewAccentControls(control.Controls, theme);
			}
		}
	}

	private void ApplyWorkspaceSurfaces(Control.ControlCollection controls, AppTheme theme)
	{
		foreach (Control control in controls)
		{
			if (!(control is WorkspaceBackdrop) && (control is Panel || control is Label || control is WorkspaceButton))
			{
				control.BackColor = (PerformanceMode.Enabled ? theme.Surface : Color.Transparent);
			}
			if (Convert.ToString(control.Tag) == "workspace-title")
			{
				control.ForeColor = theme.Text;
			}
			if (control.HasChildren)
			{
				ApplyWorkspaceSurfaces(control.Controls, theme);
			}
		}
	}

	private void SkinWorkspaceButtons(Control.ControlCollection controls, AppTheme theme)
	{
		foreach (Control control in controls)
		{
			Button button = control as Button;
			if (button != null)
			{
				button.FlatAppearance.BorderSize = 1;
				button.FlatAppearance.BorderColor = ((Convert.ToString(button.Tag) == "primary-button") ? theme.Accent : theme.Border);
				if (workspaceButtons.Add(button))
				{
					button.SizeChanged += delegate
					{
						RoundWorkspaceButton(button);
					};
					RoundWorkspaceButton(button);
				}
			}
			if (control is WorkspaceButton workspaceButton)
			{
				workspaceButton.Palette = theme;
				workspaceButton.Invalidate();
			}
			if (control is WorkspaceComboBox workspaceComboBox)
			{
				workspaceComboBox.Palette = theme;
				workspaceComboBox.Invalidate();
			}
			if (control is WorkspaceToggle workspaceToggle)
			{
				workspaceToggle.Accent = theme.Accent;
				workspaceToggle.Invalidate();
			}
			if (control is WorkspaceSlider workspaceSlider)
			{
				workspaceSlider.Accent = theme.Accent;
				workspaceSlider.Invalidate();
			}
			if (control is WorkspaceBrandTitle workspaceBrandTitle)
			{
				workspaceBrandTitle.Accent = theme.ActiveBorder;
				workspaceBrandTitle.ForeColor = theme.Text;
				workspaceBrandTitle.Invalidate();
			}
			if (control.HasChildren)
			{
				SkinWorkspaceButtons(control.Controls, theme);
			}
		}
	}

	private static void RoundWorkspaceButton(Button button)
	{
		if (button.Width <= 1 || button.Height <= 1)
		{
			return;
		}
		using GraphicsPath path = WorkspaceDrawing.Round(new Rectangle(0, 0, button.Width, button.Height), 7);
		Region region = button.Region;
		button.Region = new Region(path);
		region?.Dispose();
	}

	internal static int SharedIndicatorTarget(bool shared, bool mosaicVisible, bool shellVisible)
	{
		if (shared)
		{
			if (!mosaicVisible)
			{
				return shellVisible ? 1 : 0;
			}
			return 2;
		}
		return 0;
	}

	private void RefreshSharedModeIndicator()
	{
		if (inputClosing || IsDisposed)
		{
			return;
		}
		bool mosaicVisible = mosaicHost != null && !mosaicHost.IsDisposed && mosaicHost.IsHandleCreated && mosaicHost.Visible && mosaicHost.WindowState != FormWindowState.Minimized;
		Form form = SharedIndicatorTarget(controllerShared, mosaicVisible, IsHandleCreated && Visible && WindowState != FormWindowState.Minimized) switch
		{
			1 => (Form)this, 
			2 => mosaicHost, 
			_ => null, 
		};
		if (form == null)
		{
			if (sharedModeIndicator != null && !sharedModeIndicator.IsDisposed && sharedModeIndicator.Visible)
			{
				sharedModeIndicator.Hide();
			}
			return;
		}
		if (sharedModeIndicator == null || sharedModeIndicator.IsDisposed)
		{
			sharedModeIndicator = new SharedModeIndicator();
		}
		if (sharedModeIndicator.Owner != form)
		{
			sharedModeIndicator.Owner = form;
		}
		Rectangle rectangle = form.RectangleToScreen(form.ClientRectangle);
		float num = (float)form.DeviceDpi / 96f;
		Size size = new Size((int)(96f * num), (int)(24f * num));
		Point location = new Point(rectangle.Left + Math.Max(0, (rectangle.Width - size.Width) / 2), rectangle.Top + (int)(4f * num));
		Rectangle rectangle2 = new Rectangle(location, size);
		if (sharedModeIndicator.Bounds != rectangle2)
		{
			sharedModeIndicator.Bounds = rectangle2;
		}
		if (!sharedModeIndicator.Visible)
		{
			sharedModeIndicator.Show(form);
		}
	}

	private void UpdateShortcutDiagnostics(bool mode, string result)
	{
		if (mode)
		{
			modeShortcutResult = result;
		}
		else
		{
			squareShortcutResult = result;
		}
	}

	internal static bool ModeKeyEdge(ref bool held, bool down, bool eligible)
	{
		if (!down)
		{
			held = false;
			return false;
		}
		if (held)
		{
			return false;
		}
		held = true;
		return eligible;
	}

	internal static bool ModeKeyAllowed(Keys key, Keys square, Keys release)
	{
		if (InputPreferences.Allowed(key) && key != square && key != release && key != Keys.F1 && key != Keys.F2 && key != Keys.F5 && key != Keys.F9 && key != Keys.F11 && key != Keys.Q && key != Keys.Escape && key != Keys.Tab && key != Keys.Return)
		{
			return key != Keys.Space;
		}
		return false;
	}

	private Control BuildControllerModeBinding()
	{
		try
		{
			if (File.Exists(ModeKeyPath) && new FileInfo(ModeKeyPath).Length < 32 && int.TryParse(File.ReadAllText(ModeKeyPath), out var result) && ModeKeyAllowed((Keys)result, recordedMacroKey, InputPreferences.Current.Release))
			{
				controllerModeKey = (Keys)result;
			}
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			Width = 234,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Controls = { (Control)new Label
			{
				Text = Ui("Custom key", "Tecla personalizada"),
				AutoSize = true
			} }
		};
		WorkspaceButton assign = new WorkspaceButton
		{
			AutoSize = true
		};
		Action refresh = () =>
		{
			assign.Text = ((controllerModeKey == Keys.None) ? Ui("Assign key…", "Asignar tecla…") : (controllerModeKey.ToString() + " · " + Ui("Change…", "Cambiar…")));
		};
		refresh();
		assign.Click += delegate
		{
			CaptureShortcut(assign, "Toggle Controller Mode", controllerModeKey, (Keys k) => ModeKeyAllowed(k, recordedMacroKey, InputPreferences.Current.Release), (Keys key) =>
			{
				SaveShortcut(ModeKeyPath, key);
				controllerModeKey = key;
				controllerModeHeld = false;
				refresh();
			});
		};
		flowLayoutPanel.Controls.Add(assign);
		workspaceTips.SetToolTip(assign, Ui("Choose a key unused by your game. Disabled while typing.", "Elige una tecla que no use tu juego. No se activa al escribir."));
		return flowLayoutPanel;
	}

	private static void SaveShortcut(string path, Keys key)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string text = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			int num = (int)key;
			File.WriteAllText(text, num.ToString());
			if (File.Exists(path))
			{
				File.Replace(text, path, null, ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(text, path);
			}
		}
		finally
		{
			if (File.Exists(text))
			{
				File.Delete(text);
			}
		}
	}

	private void CaptureShortcut(Control anchor, string title, Keys initial, Func<Keys, bool> valid, Action<Keys> saveKey)
	{
		if (inlineShortcutEditor != null && !inlineShortcutEditor.IsDisposed)
		{
			inlineShortcutEditor.Dispose();
		}
		AppTheme currentTheme = CurrentTheme;
		FlowLayoutPanel card = new FlowLayoutPanel
		{
			AutoSize = true,
			Width = Math.Max(200, anchor.Parent.ClientSize.Width - 12),
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			BackColor = Color.Transparent,
			AccessibleName = title + " inline editor"
		};
		inlineShortcutEditor = card;
		Label label = new Label
		{
			Text = Ui("Press a key", "Pulsa una tecla"),
			AutoSize = true,
			ForeColor = currentTheme.Muted,
			BackColor = Color.Transparent
		};
		TextBox box = new TextBox
		{
			ReadOnly = true,
			ShortcutsEnabled = false,
			Width = 120,
			Text = ((initial == Keys.None) ? "—" : initial.ToString()),
			TextAlign = HorizontalAlignment.Center,
			Font = new Font("Segoe UI Semibold", 18f),
			BackColor = currentTheme.Surface,
			ForeColor = currentTheme.Text,
			BorderStyle = BorderStyle.None,
			AccessibleName = Ui("New key", "Nueva tecla")
		};
		Label message = new Label
		{
			AutoSize = true,
			MaximumSize = new Size(card.Width, 0),
			Text = "",
			ForeColor = currentTheme.Text,
			BackColor = Color.Transparent
		};
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			Width = card.Width,
			WrapContents = true,
			BackColor = Color.Transparent
		};
		WorkspaceButton workspaceButton = new WorkspaceButton
		{
			Text = Ui("Save", "Guardar"),
			AutoSize = true,
			Palette = currentTheme,
			Tag = "primary-button"
		};
		WorkspaceButton workspaceButton2 = new WorkspaceButton
		{
			Text = Ui("Clear", "Borrar"),
			AutoSize = true,
			Palette = currentTheme
		};
		WorkspaceButton workspaceButton3 = new WorkspaceButton
		{
			Text = Ui("Cancel", "Cancelar"),
			AutoSize = true,
			Palette = currentTheme
		};
		Keys selected = initial;
		box.PreviewKeyDown += (object s, PreviewKeyDownEventArgs e) =>
		{
			e.IsInputKey = true;
		};
		box.KeyDown += (object s, KeyEventArgs e) =>
		{
			e.Handled = true;
			e.SuppressKeyPress = true;
			if (e.Modifiers == Keys.None && valid(e.KeyCode))
			{
				selected = e.KeyCode;
				box.Text = selected.ToString();
				message.Text = "";
			}
			else
			{
				message.Text = Ui("Key reserved or unsupported.", "Tecla reservada o no compatible.");
			}
		};
		workspaceButton2.Click += delegate
		{
			selected = Keys.None;
			box.Text = "—";
			message.Text = "";
			box.Focus();
		};
		workspaceButton3.Click += delegate
		{
			card.Dispose();
			anchor.Focus();
		};
		workspaceButton.Click += delegate
		{
			try
			{
				if (selected != Keys.None && !valid(selected))
				{
					message.Text = "Key conflicts with another shortcut.";
				}
				else
				{
					saveKey(selected);
					card.Dispose();
					anchor.Focus();
				}
			}
			catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
			{
				message.Text = ex.Message;
			}
		};
		flowLayoutPanel.Controls.AddRange(new Control[3] { workspaceButton2, workspaceButton3, workspaceButton });
		card.Controls.AddRange(new Control[4] { label, box, message, flowLayoutPanel });
		anchor.Parent.Controls.Add(card);
		anchor.Parent.Controls.SetChildIndex(card, anchor.Parent.Controls.GetChildIndex(anchor) + 1);
		box.Focus();
	}

	private async void ToggleModeFromKey()
	{
		if (modeTogglePending || IsDisposed || !controllerMode.Enabled)
		{
			UpdateShortcutDiagnostics(mode: true, "Blocked: mode change busy");
			return;
		}
		modeTogglePending = true;
		try
		{
			if (!(await ShortcutScopeAllowsAsync()) || IsDisposed)
			{
				UpdateShortcutDiagnostics(mode: true, "Blocked: " + shortcutScopeReason);
			}
			else if (controllerMode.Enabled)
			{
				ControllerModeChanged(this, EventArgs.Empty);
				UpdateShortcutDiagnostics(mode: true, "Applied: " + (controllerShared ? "Shared" : "Individual"));
			}
		}
		catch (Exception ex) when (ex is InvalidOperationException || ex is COMException || ex is ObjectDisposedException)
		{
			if (!IsDisposed)
			{
				status.Text = "Controller mode unavailable while this session is changing.";
			}
		}
		finally
		{
			modeTogglePending = false;
		}
	}

	private async Task<bool> ShortcutScopeAllowsAsync()
	{
		IntPtr foregroundWindow = NativeInputOwnership.ForegroundWindow;
		if (sessions.Values.Any((CloudSessionForm s) => s.ReleasedMouseShortcutFocused))
		{
			shortcutScopeReason = "Released mouse target";
			return true;
		}
		CloudSessionForm target = sessions.Values.FirstOrDefault((CloudSessionForm s) => !s.IsDisposed && s.IsHandleCreated && NativeInputOwnership.OwnsKeyboard(s.Handle));
		if (target != null)
		{
			shortcutScopeReason = "Game eligibility or focus changed";
			return await target.ControllerModeKeyEligibleAsync() && !target.IsDisposed && NativeInputOwnership.OwnsKeyboard(target.Handle);
		}
		if (NeutralShortcutFocused())
		{
			shortcutScopeReason = "Neutral app focus";
			return true;
		}
		if (GlobalShortcutFocus.IsOurWindow(foregroundWindow))
		{
			shortcutScopeReason = "Other app-owned control or typing field";
			return false;
		}
		shortcutScopeReason = "External focus unverified, editable, or changed";
		return await GlobalShortcutFocus.AllowsAsync(foregroundWindow);
	}

	private bool NeutralShortcutFocused()
	{
		IntPtr foregroundWindow = NativeInputOwnership.ForegroundWindow;
		if (foregroundWindow == Handle)
		{
			return !IsTypingControl(ActiveControl);
		}
		if (mosaicHost != null && !mosaicHost.IsDisposed && mosaicHost.IsHandleCreated && foregroundWindow == mosaicHost.Handle)
		{
			return !IsTypingControl(mosaicHost.ActiveControl);
		}
		return false;
	}

	internal static bool IsTypingControl(Control focus)
	{
		while (focus is ContainerControl && ((ContainerControl)focus).ActiveControl != null)
		{
			focus = ((ContainerControl)focus).ActiveControl;
		}
		if (!(focus is TextBoxBase) && !(focus is ComboBox))
		{
			return focus is NumericUpDown;
		}
		return true;
	}

	private Control BuildHudSettings()
	{
		HudPreferences p = HudPreferences.Current;
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			Width = 234,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false
		};
		WorkspaceToggle recovery = new WorkspaceToggle
		{
			Text = Ui("Auto recovery · Xbox", "Recuperación auto. · Xbox"),
			AccessibleName = Ui("Auto Session Recovery (Xbox)", "Recuperación automática (Xbox)"),
			AutoSize = false,
			Height = 28,
			Checked = XboxRecoveryPreferences.Current.Enabled
		};
		recovery.CheckedChanged += delegate
		{
			try
			{
				XboxRecoveryPreferences.Current.Save(XboxRecoveryPreferences.DefaultPath, recovery.Checked);
			}
			catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
			{
				status.Text = "Could not save Xbox recovery: " + ex.Message;
				recovery.Checked = XboxRecoveryPreferences.Current.Enabled;
			}
		};
		flowLayoutPanel.Controls.Add(recovery);
		workspaceTips.SetToolTip(recovery, Ui("Reconnects ended Xbox sessions.", "Reconecta sesiones Xbox terminadas."));
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = Ui("Timer + Volume · local", "Tiempo + Volumen · local"),
			AutoSize = true
		});
		flowLayoutPanel.Controls.Add(NexusHelp(Ui("Local timer, not Xbox remaining time. Drag the clock to move both controls. Right-click to reset the timer.", "Temporizador local: no indica el tiempo restante de Xbox. Arrastra el reloj para mover ambos controles. Clic derecho para reiniciar el tiempo.")));
		NumericUpDown scale = new NumericUpDown
		{
			Minimum = 80m,
			Maximum = 150m,
			Increment = 5m,
			Value = p.Percent,
			Width = 100,
			AccessibleName = "HUD size percent"
		};
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = Ui("Size (%)", "Tamaño (%)"),
			AutoSize = true
		});
		flowLayoutPanel.Controls.Add(scale);
		WorkspaceButton workspaceButton = new WorkspaceButton
		{
			Text = Ui("Foreground color…", "Color del HUD…"),
			AutoSize = true
		};
		flowLayoutPanel.Controls.Add(workspaceButton);
		WorkspaceButton workspaceButton2 = new WorkspaceButton
		{
			Text = Ui("Reset position", "Restablecer posición"),
			AutoSize = true
		};
		flowLayoutPanel.Controls.Add(workspaceButton2);
		Action apply = () =>
		{
			try
			{
				p.Apply();
			}
			catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
			{
				status.Text = "HUD applied; could not save: " + ex.Message;
			}
		};
		scale.ValueChanged += delegate
		{
			p.Percent = (int)scale.Value;
			apply();
		};
		workspaceButton.Click += delegate
		{
			using ColorDialog colorDialog = new ColorDialog
			{
				Color = Color.FromArgb(255, (p.Foreground >> 16) & 0xFF, (p.Foreground >> 8) & 0xFF, p.Foreground & 0xFF),
				FullOpen = true
			};
			if (colorDialog.ShowDialog(this) == DialogResult.OK)
			{
				p.Foreground = colorDialog.Color.ToArgb() & 0xFFFFFF;
				apply();
			}
		};
		workspaceButton2.Click += delegate
		{
			p.X = 0.0;
			p.Y = 1.0;
			apply();
		};
		return flowLayoutPanel;
	}

	private void ShowWorkspaceHelp()
	{
		ClearWorkspaceDrawer();
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			ColumnCount = 1,
			RowCount = 6,
			Padding = new Padding(8),
			Margin = Padding.Empty
		};
		tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		for (int i = 0; i < 5; i++)
		{
			tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		}
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		WorkspaceButton workspaceButton = new WorkspaceButton
		{
			Text = Ui("← Settings", "← Ajustes"),
			AutoSize = true
		};
		workspaceButton.Click += delegate
		{
			ShowWorkspaceSettings();
		};
		tableLayoutPanel.Controls.Add(workspaceButton, 0, 0);
		tableLayoutPanel.Controls.Add(new Label
		{
			Text = "Kanblaz AI",
			AutoSize = true,
			Font = new Font("Segoe UI Semibold", 17f),
			Margin = new Padding(0, 12, 0, 6)
		}, 0, 1);
		Label control = new Label
		{
			Text = Ui("Local guided help. No AI model connected.", "Ayuda local guiada. Sin modelo de IA conectado."),
			AutoSize = true,
			Dock = DockStyle.Fill,
			Margin = new Padding(0, 0, 0, 12)
		};
		tableLayoutPanel.Controls.Add(control, 0, 2);
		TableLayoutPanel tableLayoutPanel2 = new TableLayoutPanel
		{
			Dock = DockStyle.Top,
			AutoSize = true,
			ColumnCount = 2,
			Margin = Padding.Empty
		};
		tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
		tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90f));
		TextBox question = new TextBox
		{
			Dock = DockStyle.Fill,
			MaxLength = 500,
			AccessibleName = Ui("Question about Kanblaz", "Pregunta sobre Kanblaz"),
			Margin = new Padding(0, 7, 8, 0)
		};
		WorkspaceButton workspaceButton2 = new WorkspaceButton
		{
			Text = Ui("Ask", "Consultar"),
			Dock = DockStyle.Fill,
			Height = 34
		};
		tableLayoutPanel2.Controls.Add(question, 0, 0);
		tableLayoutPanel2.Controls.Add(workspaceButton2, 1, 0);
		tableLayoutPanel.Controls.Add(tableLayoutPanel2, 0, 3);
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			WrapContents = true,
			Margin = new Padding(0, 8, 0, 8)
		};
		RichTextBox response = new RichTextBox
		{
			Dock = DockStyle.Fill,
			ReadOnly = true,
			DetectUrls = false,
			BorderStyle = BorderStyle.None,
			AccessibleName = Ui("Kanblaz help answer", "Respuesta de ayuda Kanblaz"),
			Font = new Font("Segoe UI", 11f),
			MinimumSize = new Size(80, 180)
		};
		Action<string> answer = (string query) =>
		{
			response.Text = KanblazHelp.Answer(query, uiLanguage == AppLanguage.Spanish, controllerModeKey.ToString(), InputPreferences.Current.Release.ToString(), recordedMacroKey.ToString());
		};
		string[] array = ((uiLanguage != AppLanguage.Spanish) ? new string[8] { "Profiles", "Controller", "Movement", "Input", "Mouse", "HUD", "Recovery", "Notifications" } : new string[8] { "Perfiles", "Control", "Movimiento", "Input", "Mouse", "HUD", "Recuperación", "Notificaciones" });
		foreach (string text in array)
		{
			string topic = text;
			WorkspaceButton workspaceButton3 = new WorkspaceButton
			{
				Text = topic,
				AutoSize = true,
				Margin = new Padding(0, 0, 6, 6)
			};
			workspaceButton3.Click += delegate
			{
				question.Text = topic;
				answer(topic);
			};
			flowLayoutPanel.Controls.Add(workspaceButton3);
		}
		tableLayoutPanel.Controls.Add(flowLayoutPanel, 0, 4);
		tableLayoutPanel.Controls.Add(response, 0, 5);
		workspaceButton2.Click += delegate
		{
			answer(question.Text);
		};
		question.KeyDown += (object s, KeyEventArgs e) =>
		{
			if (e.KeyCode == Keys.Return)
			{
				answer(question.Text);
				e.SuppressKeyPress = true;
			}
		};
		workspaceDrawer.Controls.Add(tableLayoutPanel);
		workspaceDrawer.Visible = true;
		ApplyTheme();
		response.BackColor = CurrentTheme.Surface;
		response.ForeColor = CurrentTheme.Text;
		answer("");
		question.Focus();
	}

	private void InstallFolderContextMenus()
	{
		profileGrid.ContextMenuStrip?.Items.Add(Ui("Copy selected profiles", "Copiar perfiles seleccionados"), null, (object s, EventArgs e) =>
		{
			Profile clicked = ((profileGrid.CurrentRow == null) ? null : (profileGrid.CurrentRow.Tag as Profile));
			if (clicked != null)
			{
				Profile[] array = CheckedProfiles().ToArray();
				CopyFolderProfiles(array.Any((Profile p) => p.StorageKey == clicked.StorageKey) ? array : new Profile[1] { clicked });
			}
		});
		ContextMenuStrip menu = new ContextMenuStrip();
		ToolStripItem paste = menu.Items.Add(Ui("Paste profiles into this folder", "Pegar perfiles en esta carpeta"), null, (object s, EventArgs e) =>
		{
			PasteFolderProfiles();
		});
		menu.Opening += (object s, CancelEventArgs e) =>
		{
			paste.Enabled = !IsAllProfiles && access.CanUseGroups && copiedProfiles.Count > 0;
		};
		groupList.MouseDown += (object s, MouseEventArgs e) =>
		{
			if (e.Button == MouseButtons.Right)
			{
				int num = groupList.IndexFromPoint(e.Location);
				if (num >= 0)
				{
					groupList.SelectedIndex = num;
					menu.Show(groupList, e.Location);
				}
			}
		};
		groupList.Disposed += delegate
		{
			menu.Dispose();
		};
	}

	private Guid[] ProfileFolders(Profile p)
	{
		bool flag = GameForProfile(p) == currentGame || gameLibrary.Memberships.Any((GameMembership m) => m.Profile == p.StorageKey && m.Game == currentGame);
		return folderReferences.Folders(p.StorageKey, currentGame, flag ? new Guid?(CurrentFolder(p)) : ((Guid?)null), CurrentGameFolders.Select((ProfileGroup g) => g.Id));
	}

	private void RememberFolder()
	{
		if (!workspaceReady)
		{
			return;
		}
		try
		{
			folderReferences.Remember(currentGame, groupFilter);
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			status.Text = ex.Message;
		}
	}

	private void RestoreFolder()
	{
		if (gameLibrary.Games.Any((GameEntry g) => g.Id == folderReferences.LastGame))
		{
			currentGame = folderReferences.LastGame;
		}
		Guid? last = folderReferences.LastFolder;
		groupFilter = ((last.HasValue && (last.Value == Guid.Empty || (access.CanUseGroups && CurrentGameFolders.Any((ProfileGroup g) => g.Id == last.Value)))) ? last : ((Guid?)null));
	}

	private void CopyFolderProfiles(IEnumerable<Profile> selected)
	{
		copiedProfiles.Clear();
		foreach (Profile item in selected)
		{
			copiedProfiles.Add(item.StorageKey);
		}
		status.Text = Ui("Profiles copied as references. Choose a folder and Paste profiles.", "Profiles copiados como referencias. Elige una carpeta y pega los profiles.");
	}

	private bool UpdateFolderReferences(IEnumerable<Profile> selected, Guid folder, bool move)
	{
		if (IsAllProfiles && !move)
		{
			return false;
		}
		if (!access.CanUseGroups || (folder != Guid.Empty && !CurrentGameFolders.Any((ProfileGroup g) => g.Id == folder)))
		{
			return false;
		}
		List<FolderReferences.Entry> entries = (from p in selected
			group p by p.StorageKey into g
			select g.First()).Select((Profile p) =>
		{
			FolderReferences.Entry entry = new FolderReferences.Entry
			{
				Profile = p.StorageKey,
				Game = currentGame
			};
			IEnumerable<Guid> source;
			if (!move)
			{
				source = ProfileFolders(p).Concat(new Guid[1] { folder });
			}
			else
			{
				IEnumerable<Guid> enumerable = new Guid[1] { folder };
				source = enumerable;
			}
			entry.Folders = source.Distinct().ToList();
			return entry;
		}).ToList();
		try
		{
			folderReferences.Set(entries);
			RefreshGroups();
			RefreshProfiles(persist: false);
			return true;
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			status.Text = ex.Message;
			return false;
		}
	}

	private void PasteFolderProfiles()
	{
		if (!IsAllProfiles)
		{
			UpdateFolderReferences(profiles.Where((Profile p) => copiedProfiles.Contains(p.StorageKey)), groupFilter ?? Guid.Empty, move: false);
		}
	}

	private void RemoveFolderReference(Profile profile)
	{
		if (IsAllProfiles)
		{
			return;
		}
		Guid folder = groupFilter ?? Guid.Empty;
		List<Guid> list = (from id in ProfileFolders(profile)
			where id != folder
			select id).ToList();
		if (list.Count == 0)
		{
			list.Add(Guid.Empty);
		}
		try
		{
			folderReferences.Set(new FolderReferences.Entry[1]
			{
				new FolderReferences.Entry
				{
					Profile = profile.StorageKey,
					Game = currentGame,
					Folders = list
				}
			});
			RefreshGroups();
			RefreshProfiles(persist: false);
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
		{
			status.Text = ex.Message;
		}
	}

	private void StartVpnStatus()
	{
		vpnTimer.Tick += async delegate
		{
			await RefreshVpnStatus();
		};
		vpnTimer.Start();
		RefreshVpnStatus();
	}

	private async Task RefreshVpnStatus()
	{
		if (vpnReading || IsDisposed)
		{
			return;
		}
		vpnReading = true;
		try
		{
			VpnState vpnState = await VpnStatus.ReadAsync();
			if (!IsDisposed && !Disposing)
			{
				vpnLed.Text = ((vpnState == VpnState.Unknown) ? "○ VPN" : "● VPN");
				vpnLed.ForeColor = vpnState switch
				{
					VpnState.Unknown => Color.Gray, 
					VpnState.Detected => Color.FromArgb(65, 205, 120), 
					_ => Color.FromArgb(75, 80, 85), 
				};
				string text = vpnState switch
				{
					VpnState.NotDetected => Ui("VPN not detected", "VPN no detectada"), 
					VpnState.Detected => Ui("VPN detected", "VPN detectada"), 
					_ => Ui("VPN status unknown", "Estado de VPN desconocido"), 
				};
				vpnLed.AccessibleName = text;
				workspaceTips.SetToolTip(vpnLed, text + Ui(". Windows VPN connections only; some third-party VPNs may not be detected. This does not verify traffic protection.", ". Solo conexiones VPN de Windows; algunas VPN de terceros pueden no detectarse. No verifica la protección del tráfico."));
			}
		}
		finally
		{
			vpnReading = false;
		}
	}

	internal static bool ControllerButtonRequestCurrent(bool held, int requested, int current, IntPtr source, IntPtr foreground)
	{
		if (held && requested == current)
		{
			return source == foreground;
		}
		return false;
	}

	private bool ControllerButtonFocused()
	{
		if ((!recordedExternalAllowed || !(recordedExternalForeground == NativeInputOwnership.ForegroundWindow)) && !NeutralShortcutFocused() && !GameInputFocused())
		{
			return sessions.Values.Any((CloudSessionForm s) => s.BroadcastReady && NativeInputOwnership.OwnsKeyboard(s.Handle));
		}
		return true;
	}

	private async void StartControllerButtonFromKey(int generation, IntPtr foreground)
	{
		try
		{
			if (!(await ShortcutScopeAllowsAsync()))
			{
				UpdateShortcutDiagnostics(mode: false, "Blocked: " + shortcutScopeReason);
			}
			else if (!inputClosing && !IsDisposed && ControllerButtonRequestCurrent(recordedShortcutHeld, generation, recordedShortcutGeneration, foreground, NativeInputOwnership.ForegroundWindow))
			{
				recordedExternalForeground = foreground;
				recordedExternalAllowed = !GlobalShortcutFocus.IsOurWindow(foreground);
				if (toggleRecordedMacro != null)
				{
					toggleRecordedMacro();
				}
			}
		}
		catch (Exception ex) when (ex is InvalidOperationException || ex is COMException)
		{
			if (!IsDisposed)
			{
				status.Text = "Controller Button unavailable while the session changes.";
			}
		}
	}

	private void ReleaseControllerButton()
	{
		if (recordedMacroCancel != null)
		{
			recordedMacroCancel.Cancel();
		}
	}

	private Control BuildRecordMacro(string settingsPath)
	{
		FlowLayoutPanel group = new FlowLayoutPanel
		{
			Name = "Controller Button",
			AutoSize = true,
			Width = 234,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Padding = new Padding(4)
		};
		Button assign = new Button
		{
			Text = Ui("Assign activation key…", "Asignar tecla de activación…"),
			AutoSize = true
		};
		Label keyLabel = new Label
		{
			AutoSize = true,
			MaximumSize = new Size(218, 0)
		};
		Label info = new Label
		{
			AutoSize = true,
			MaximumSize = new Size(218, 0)
		};
		string path = Path.Combine(Path.GetDirectoryName(settingsPath), "square-button-key.txt");
		Func<Keys, bool> valid = (Keys k) => InputPreferences.Allowed(k) && k != Keys.F2 && k != controllerModeKey && !InputPreferences.Current.IsRelease(k);
		recordedMacroKey = Keys.None;
		try
		{
			if (File.Exists(path) && new FileInfo(path).Length < 32 && int.TryParse(File.ReadAllText(path), out var result) && InputPreferences.Allowed((Keys)result) && result != 113 && !InputPreferences.Current.IsRelease((Keys)result))
			{
				recordedMacroKey = (Keys)result;
			}
		}
		catch
		{
		}
		Action show = () =>
		{
			keyLabel.Text = Ui("Activation key: ", "Tecla de activación: ") + ((recordedMacroKey == Keys.None) ? Ui("Not assigned", "Sin asignar") : recordedMacroKey.ToString());
		};
		show();
		assign.Click += delegate
		{
			CaptureShortcut(assign, Ui("Controller Button", "Botón del control"), recordedMacroKey, valid, (Keys selected) =>
			{
				SaveShortcut(path, selected);
				recordedMacroKey = selected;
				recordedShortcutHeld = false;
				show();
			});
		};
		Action run = async () =>
		{
			if ((recordedMacroTask == null || recordedMacroTask.IsCompleted) && recordedShortcutHeld && !inputClosing)
			{
				CloudSessionForm[] array = sessions.Values.Where((CloudSessionForm s) => s.BroadcastReady).ToArray();
				if (array.Length != 0)
				{
					UpdateShortcutDiagnostics(mode: false, "Holding in " + array.Length + " ready sessions");
					int failures = 0;
					CancellationTokenSource cancellation = new CancellationTokenSource();
					recordedMacroCancel = cancellation;
					assign.Enabled = false;
					info.Text = Ui("Holding in sessions: ", "Manteniendo en sesiones: ") + array.Length;
					try
					{
						recordedMacroTask = KeyboardMacro.PlayIndependent(((IEnumerable<CloudSessionForm>)array).Select((Func<CloudSessionForm, Func<Task>>)((CloudSessionForm s) => () => s.PlaySquareAsync(cancellation.Token))).ToArray(), (int index, Exception error) =>
						{
							failures++;
							if (!info.IsDisposed)
							{
								info.Text = Ui("Session failed: ", "Sesión fallida: ") + (index + 1) + " — " + error.Message;
							}
						});
						await recordedMacroTask;
						if (!info.IsDisposed)
						{
							info.Text = ((failures == 0) ? "" : (Ui("Sessions failed: ", "Sesiones fallidas: ") + failures));
						}
						return;
					}
					finally
					{
						if (recordedMacroCancel == cancellation)
						{
							recordedMacroCancel = null;
						}
						cancellation.Dispose();
						if (!group.IsDisposed)
						{
							assign.Enabled = true;
						}
					}
				}
				info.Text = Ui("No ready game sessions.", "No hay sesiones listas.");
				UpdateShortcutDiagnostics(mode: false, "No ready sessions");
			}
		};
		Action toggle = () =>
		{
			if (recordedMacroCancel == null)
			{
				run();
			}
		};
		toggleRecordedMacro = toggle;
		group.Controls.Add(NexusHelp(Ui("Hold your assigned key to hold PS4 Square / Xbox X in all ready sessions. Release the key to release the button. F2 unchanged.", "Mantén la tecla asignada para mantener Cuadrado PS4 / X Xbox en todas las sesiones listas. Suelta la tecla para soltar el botón. F2 sin cambios.")));
		group.Controls.Add(assign);
		group.Controls.Add(keyLabel);
		group.Controls.Add(info);
		group.Disposed += delegate
		{
			if (toggleRecordedMacro == toggle)
			{
				toggleRecordedMacro = null;
			}
			if (recordedMacroCancel != null)
			{
				recordedMacroCancel.Cancel();
			}
		};
		return group;
	}

	private void RefreshCursorPreferences()
	{
		if (cursorAid == null)
		{
			return;
		}
		string text = CursorAid.Stamp + ":" + ((mosaicHost != null) ? mosaicHost.GetHashCode() : 0) + ":" + sessions.Count;
		if (!(appliedCursorStamp == text))
		{
			appliedCursorStamp = text;
			cursorAid.ApplyTo(this, mosaicHost);
			CloudSessionForm[] array = sessions.Values.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				array[i].RefreshPageCursor();
			}
		}
	}

	private async Task ReleaseBeforeCloseAsync()
	{
		if (recordedMacroCancel != null)
		{
			recordedMacroCancel.Cancel();
		}
		if (recordedMacroTask != null)
		{
			try
			{
				await recordedMacroTask;
			}
			catch
			{
			}
		}
		CancelManualHold();
		Task[] tasks = manualTargets.Values.Select((BroadcastEndpoint e) => e.ReleaseAsync()).ToArray();
		await Task.WhenAny(Task.WhenAll(tasks), Task.Delay(1000));
	}

	private bool GameInputFocused()
	{
		if (mosaicHost != null && !mosaicHost.IsDisposed && mosaicHost.IsHandleCreated && NativeInputOwnership.ForegroundWindow == mosaicHost.Handle)
		{
			return sessions.Values.Any((CloudSessionForm s) => s.BroadcastReady);
		}
		return false;
	}

	private void StartManualInput()
	{
		InputPreferences.Current.BroadcastEnabled = false;
		cursorAid = new CursorAid();
		manualHook = new PhysicalInputHook(PhysicalEdge);
		bool flag = manualHook.Start();
		bool flag2 = keyboardRelease.Start(Handle);
		hookReady = flag & flag2;
		if (!hookReady)
		{
			status.Text = "Manual broadcast unavailable: Windows could not register input. Release shortcuts still work.";
		}
		inputSafetyTimer.Tick += delegate
		{
			bool flag3 = GameInputFocused();
			if (recordedMacroCancel != null && (!ControllerButtonFocused() || !recordedShortcutHeld || recordedMacroKey == Keys.None))
			{
				ReleaseControllerButton();
			}
			if (manualHold.Held && (!flag3 || !InputPreferences.Current.BroadcastEnabled))
			{
				CancelManualHold();
			}
			KeyValuePair<CloudSessionForm, BroadcastEndpoint>[] array = manualTargets.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				KeyValuePair<CloudSessionForm, BroadcastEndpoint> keyValuePair = array[i];
				if (!manualHold.Held || !keyValuePair.Key.BroadcastReady)
				{
					keyValuePair.Value.Release();
				}
				if (!keyValuePair.Value.Busy && (!manualHold.Held || !keyValuePair.Key.BroadcastReady))
				{
					manualTargets.Remove(keyValuePair.Key);
				}
			}
			if (manualHold.Held)
			{
				SendManualDown();
			}
			RefreshCursorPreferences();
			RefreshSharedModeIndicator();
		};
		inputSafetyTimer.Start();
	}

	private bool PhysicalEdge(Keys key, bool down)
	{
		return PhysicalEdgeFromSource(key, down, raw: false);
	}

	internal static bool AssignedShortcutSourceAllowed(bool raw)
	{
		return raw;
	}

	[DllImport("user32.dll")]
	private static extern short GetAsyncKeyState(int key);

	private static bool ShortcutModifiersClear()
	{
		if ((GetAsyncKeyState(16) & 0x8000) == 0 && (GetAsyncKeyState(17) & 0x8000) == 0 && (GetAsyncKeyState(18) & 0x8000) == 0 && (GetAsyncKeyState(91) & 0x8000) == 0)
		{
			return (GetAsyncKeyState(92) & 0x8000) == 0;
		}
		return false;
	}

	private bool PhysicalEdgeFromSource(Keys key, bool down, bool raw)
	{
		if (inputClosing || IsDisposed)
		{
			return false;
		}
		bool flag = key != Keys.None && (key == controllerModeKey || key == recordedMacroKey);
		if (!raw & down & flag)
		{
			if (key == controllerModeKey)
			{
				modeHookPresses++;
			}
			else
			{
				squareHookPresses++;
			}
		}
		if (flag && !AssignedShortcutSourceAllowed(raw))
		{
			return false;
		}
		if (key == controllerModeKey && key != Keys.None && ModeKeyAllowed(key, recordedMacroKey, InputPreferences.Current.Release))
		{
			if (ModeKeyEdge(ref controllerModeHeld, down, ShortcutModifiersClear()))
			{
				IntPtr foreground = NativeInputOwnership.ForegroundWindow;
				BeginInvoke((Action)(() =>
				{
					if (foreground == NativeInputOwnership.ForegroundWindow)
					{
						ToggleModeFromKey();
					}
				}));
			}
			return false;
		}
		if (key == recordedMacroKey && key != Keys.None && key != Keys.F2 && !InputPreferences.Current.IsRelease(key))
		{
			if (!down)
			{
				bool flag2 = recordedKeyConsumed;
				recordedShortcutHeld = false;
				recordedKeyConsumed = false;
				recordedExternalAllowed = false;
				recordedShortcutGeneration++;
				ReleaseControllerButton();
				if (flag2)
				{
					return true;
				}
			}
			else
			{
				if (recordedShortcutHeld)
				{
					return recordedKeyConsumed;
				}
				if (!recordingKeys && ShortcutModifiersClear() && toggleRecordedMacro != null)
				{
					IntPtr foreground2 = NativeInputOwnership.ForegroundWindow;
					recordedShortcutHeld = true;
					recordedKeyConsumed = false;
					recordedExternalAllowed = false;
					int generation = ++recordedShortcutGeneration;
					BeginInvoke((Action)(() =>
					{
						StartControllerButtonFromKey(generation, foreground2);
					}));
					return false;
				}
			}
		}
		if (down && InputPreferences.Current.IsRelease(key))
		{
			ReleaseControllerButton();
		}
		if (captureInputKey != null && NativeInputOwnership.ForegroundWindow == Handle && Control.ModifierKeys == Keys.None && (InputPreferences.Allowed(key) || key == Keys.Back || key == Keys.Delete))
		{
			if (down)
			{
				Action<Keys> capture = captureInputKey;
				BeginInvoke((Action)(() =>
				{
					if (captureInputKey == capture)
					{
						capture(key);
					}
				}));
			}
			return true;
		}
		if (!down)
		{
			foreach (CloudSessionForm value in sessions.Values)
			{
				value.ObserveReleaseKeyUp(key);
			}
		}
		if (!down && physicalReleaseHeld.Remove(key))
		{
			return true;
		}
		if (down && physicalReleaseHeld.Contains(key))
		{
			return true;
		}
		if (down && InputPreferences.Current.IsRelease(key) && (key < Keys.F1 || key > Keys.F24) && Control.ModifierKeys == Keys.None)
		{
			CloudSessionForm cloudSessionForm = sessions.Values.FirstOrDefault((CloudSessionForm s) => !s.IsDisposed && s.IsHandleCreated && NativeInputOwnership.OwnsKeyboard(s.Handle));
			if (cloudSessionForm != null)
			{
				physicalReleaseHeld.Add(key);
				cloudSessionForm.QueuePhysicalMouseRelease(key);
				BeginInvoke(new Action(CancelManualHold));
				return true;
			}
		}
		if (InputPreferences.Current.IsRelease(key))
		{
			return false;
		}
		if (key != InputPreferences.Current.BroadcastKey || inputClosing)
		{
			return false;
		}
		if (!down)
		{
			bool flag3 = manualHold.Up();
			if (flag3)
			{
				BeginInvoke(new Action(ReleaseManualTargets));
			}
			return flag3;
		}
		if (manualHold.Held)
		{
			return true;
		}
		if (!InputPreferences.Current.BroadcastEnabled || !hookReady || Control.ModifierKeys != Keys.None || !GameInputFocused())
		{
			return false;
		}
		if (manualHold.Down(eligible: true))
		{
			BeginInvoke(new Action(SendManualDown));
		}
		return true;
	}

	private void SendManualDown()
	{
		if (!manualHold.Held || inputClosing || !InputPreferences.Current.BroadcastEnabled || !GameInputFocused())
		{
			return;
		}
		int count = manualTargets.Count;
		CloudSessionForm[] array = sessions.Values.Where((CloudSessionForm s) => s.BroadcastReady).ToArray();
		foreach (CloudSessionForm cloudSessionForm in array)
		{
			if (manualTargets.ContainsKey(cloudSessionForm))
			{
				continue;
			}
			BroadcastEndpoint broadcastEndpoint = new BroadcastEndpoint(cloudSessionForm.SendBroadcastKeyAsync, () =>
			{
				if (!IsDisposed)
				{
					status.Text = "Broadcast interrupted: a session did not acknowledge input. Release pending; restart that session if it is frozen.";
					BeginInvoke(new Action(CancelManualHold));
				}
			});
			manualTargets.Add(cloudSessionForm, broadcastEndpoint);
			broadcastEndpoint.Down(InputPreferences.Current.BroadcastKey);
			cloudSessionForm.ManualEndpoint = broadcastEndpoint;
		}
		if (manualTargets.Count != count)
		{
			status.Text = Ui("Manual hold: ", "Tecla mantenida: ") + InputPreferences.Current.BroadcastKey.ToString() + " · " + manualTargets.Count + "/" + sessions.Count + Ui(" sessions ready", " sesiones listas");
		}
	}

	private void ReleaseManualTargets()
	{
		BroadcastEndpoint[] array = manualTargets.Values.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].Release();
		}
	}

	private void CancelManualHold()
	{
		manualHold.Cancel();
		ReleaseManualTargets();
	}

	private void StopManualInput()
	{
		if (!inputClosing)
		{
			inputClosing = true;
			CancelManualHold();
			inputSafetyTimer.Stop();
			inputSafetyTimer.Dispose();
			if (finishMacroRecording != null)
			{
				finishMacroRecording();
			}
			if (recordedMacroCancel != null)
			{
				recordedMacroCancel.Cancel();
			}
			if (manualHook != null)
			{
				manualHook.Dispose();
			}
			keyboardRelease.Dispose();
			if (cursorAid != null)
			{
				cursorAid.Dispose();
			}
			if (sharedModeIndicator != null)
			{
				sharedModeIndicator.Dispose();
				sharedModeIndicator = null;
			}
		}
	}

	private void ReadKeyboardRelease(IntPtr input)
	{
		if (controllerModeKey != Keys.None && keyboardRelease.IsPress(input, controllerModeKey))
		{
			modeRawPresses++;
			UpdateShortcutDiagnostics(mode: true, modeShortcutResult);
			PhysicalEdgeFromSource(controllerModeKey, down: true, raw: true);
		}
		if (controllerModeKey != Keys.None && keyboardRelease.IsRelease(input, controllerModeKey))
		{
			PhysicalEdgeFromSource(controllerModeKey, down: false, raw: true);
		}
		if (recordedMacroKey != Keys.None && keyboardRelease.IsPress(input, recordedMacroKey))
		{
			squareRawPresses++;
			UpdateShortcutDiagnostics(mode: false, squareShortcutResult);
			PhysicalEdgeFromSource(recordedMacroKey, down: true, raw: true);
		}
		if (recordedMacroKey != Keys.None && keyboardRelease.IsRelease(input, recordedMacroKey))
		{
			PhysicalEdgeFromSource(recordedMacroKey, down: false, raw: true);
			UpdateShortcutDiagnostics(mode: false, "Released");
		}
		if (keyboardRelease.IsRelease(input, InputPreferences.Current.BroadcastKey))
		{
			manualHold.Up();
			ReleaseManualTargets();
		}
	}

	private Control BuildInputSettings(out Control mouseSettings, string settingsPath = null)
	{
		settingsPath = settingsPath ?? InputPreferences.DefaultPath;
		FlowLayoutPanel panel = new FlowLayoutPanel
		{
			AutoSize = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false,
			Width = 242
		};
		InputPreferences current = InputPreferences.Current;
		Keys selectedRelease = current.Release;
		TextBox release = new TextBox
		{
			Name = "ReleaseMouseKey",
			ReadOnly = true,
			Width = 222,
			Text = selectedRelease.ToString(),
			ShortcutsEnabled = false
		};
		Keys selectedBroadcast = current.BroadcastKey;
		TextBox broadcast = new TextBox
		{
			Name = "ManualHoldKey",
			ReadOnly = true,
			Width = 222,
			Text = ((selectedBroadcast == Keys.None) ? "" : selectedBroadcast.ToString()),
			ShortcutsEnabled = false
		};
		WorkspaceToggle enabled = new WorkspaceToggle
		{
			Text = Ui("Enable manual key hold", "Activar tecla mantenida"),
			AutoSize = false,
			Checked = current.BroadcastEnabled
		};
		WorkspaceComboBox style = new WorkspaceComboBox
		{
			DropDownStyle = ComboBoxStyle.DropDownList,
			Width = 222
		};
		style.Items.AddRange(new object[2] { "Default Windows cursor", "Neon target" });
		style.SelectedIndex = ((current.CursorStyle != CursorStyle.Windows) ? 1 : 0);
		WorkspaceToggle highlight = new WorkspaceToggle
		{
			Text = Ui("Neon glow", "Brillo neón"),
			AutoSize = false,
			Checked = current.Highlight
		};
		WorkspaceToggle tint = new WorkspaceToggle
		{
			Text = Ui("Color default cursor", "Colorear cursor predeterminado"),
			AutoSize = false,
			Checked = current.TintCursor
		};
		NumericUpDown size = new NumericUpDown
		{
			Minimum = 16m,
			Maximum = 96m,
			Value = current.CursorSize,
			Width = 222
		};
		NumericUpDown glow = new NumericUpDown
		{
			Minimum = 0m,
			Maximum = 100m,
			Value = current.Glow,
			Width = 222
		};
		int cursorColor = current.CursorColor;
		int glowColor = current.GlowColor;
		WorkspaceButton workspaceButton = new WorkspaceButton
		{
			Text = Ui("Cursor color…", "Color del cursor…"),
			Width = 222,
			Height = 32
		};
		WorkspaceButton workspaceButton2 = new WorkspaceButton
		{
			Text = Ui("Glow color…", "Color del brillo…"),
			Width = 222,
			Height = 32
		};
		PictureBox preview = new PictureBox
		{
			Width = 222,
			Height = 64,
			BackColor = Color.Transparent,
			SizeMode = PictureBoxSizeMode.CenterImage
		};
		preview.Disposed += delegate
		{
			if (preview.Image != null)
			{
				preview.Image.Dispose();
			}
		};
		Label assigned = new Label
		{
			AutoSize = true,
			MaximumSize = new Size(230, 0),
			Text = "Active: " + current.Release.ToString() + " · Hold: " + current.BroadcastKey
		};
		Label result = new Label
		{
			AutoSize = true,
			MaximumSize = new Size(230, 0)
		};
		Action<string, Control> action = (string label, Control value3) =>
		{
			panel.Controls.Add(new Label
			{
				Text = label,
				AutoSize = true
			});
			panel.Controls.Add(value3);
		};
		panel.Controls.Add(assigned);
		action(Ui("Release mouse — click and press a key", "Liberar mouse — haz clic y presiona una tecla"), release);
		panel.Controls.Add(enabled);
		action(Ui("Click field, then press your key", "Haz clic y presiona tu tecla"), broadcast);
		panel.Controls.Add(NexusHelp(Ui("Hold = press in all sessions. Let go = release. No timer. Backspace clears the key.", "Mantener = presionar en todas las sesiones. Soltar = liberar. Sin temporizador. Backspace borra la tecla.")));
		action(Ui("Cursor style (outside capture)", "Cursor (fuera de captura)"), style);
		panel.Controls.Add(highlight);
		action(Ui("Size (px)", "Tamaño (px)"), size);
		panel.Controls.Add(tint);
		panel.Controls.Add(workspaceButton);
		action(Ui("Glow intensity", "Intensidad del brillo"), glow);
		panel.Controls.Add(workspaceButton2);
		panel.Controls.Add(preview);
		bool loading = false;
		Action refreshPreview = () =>
		{
			Bitmap image = CursorAid.Render(InputPreferences.Current, out var _);
			Image image2 = preview.Image;
			preview.Image = image;
			image2?.Dispose();
		};
		Action restoreControls = () =>
		{
			loading = true;
			InputPreferences current2 = InputPreferences.Current;
			selectedRelease = current2.Release;
			release.Text = selectedRelease.ToString();
			selectedBroadcast = current2.BroadcastKey;
			broadcast.Text = ((selectedBroadcast == Keys.None) ? "" : selectedBroadcast.ToString());
			enabled.Checked = current2.BroadcastEnabled;
			style.SelectedIndex = ((current2.CursorStyle != CursorStyle.Windows) ? 1 : 0);
			highlight.Checked = current2.Highlight;
			tint.Checked = current2.TintCursor;
			size.Value = current2.CursorSize;
			glow.Value = current2.Glow;
			cursorColor = current2.CursorColor;
			glowColor = current2.GlowColor;
			loading = false;
		};
		Action apply = () =>
		{
			if (!loading)
			{
				InputPreferences inputPreferences = new InputPreferences
				{
					Release = selectedRelease,
					BroadcastKey = selectedBroadcast,
					BroadcastEnabled = enabled.Checked,
					CursorStyle = ((style.SelectedIndex != 0) ? CursorStyle.NeonTarget : CursorStyle.Windows),
					Highlight = highlight.Checked,
					CursorSize = (int)size.Value,
					CursorColor = cursorColor,
					GlowColor = glowColor,
					Glow = (int)glow.Value,
					TintCursor = tint.Checked
				};
				string text = inputPreferences.Validate();
				if (inputPreferences.Release == controllerModeKey || (inputPreferences.BroadcastKey != Keys.None && inputPreferences.BroadcastKey == controllerModeKey))
				{
					text = "Key reserved for Toggle Controller Mode.";
				}
				if (text == null)
				{
					CancelManualHold();
					try
					{
						inputPreferences.Save(settingsPath);
						InputPreferences.Current = inputPreferences;
						result.Text = "";
						assigned.Text = "Active: " + inputPreferences.Release.ToString() + " · Hold: " + inputPreferences.BroadcastKey;
						refreshPreview();
						return;
					}
					catch (Exception ex)
					{
						result.Text = Ui("Could not save: ", "No se pudo guardar: ") + ex.Message;
						restoreControls();
						return;
					}
				}
				result.Text = text;
				restoreControls();
			}
		};
		Action<Keys> chooseKey = (Keys key) =>
		{
			if (key == Keys.Back || key == Keys.Delete)
			{
				selectedBroadcast = Keys.None;
				loading = true;
				enabled.Checked = false;
				loading = false;
			}
			else
			{
				if (!InputPreferences.Allowed(key))
				{
					return;
				}
				selectedBroadcast = key;
			}
			broadcast.Text = ((selectedBroadcast == Keys.None) ? "" : selectedBroadcast.ToString());
			apply();
		};
		broadcast.Enter += delegate
		{
			CancelManualHold();
			captureInputKey = chooseKey;
		};
		broadcast.Leave += delegate
		{
			if (captureInputKey == chooseKey)
			{
				captureInputKey = null;
			}
		};
		broadcast.Disposed += delegate
		{
			if (captureInputKey == chooseKey)
			{
				captureInputKey = null;
			}
		};
		broadcast.KeyDown += (object sender, KeyEventArgs args) =>
		{
			if (args.Modifiers == Keys.None)
			{
				args.Handled = true;
				args.SuppressKeyPress = true;
				chooseKey(args.KeyCode);
			}
		};
		Action<Keys> chooseRelease = (Keys key) =>
		{
			if (InputPreferences.Allowed(key))
			{
				selectedRelease = key;
				release.Text = key.ToString();
				apply();
			}
		};
		release.Enter += delegate
		{
			CancelManualHold();
			captureInputKey = chooseRelease;
		};
		release.Leave += delegate
		{
			if (captureInputKey == chooseRelease)
			{
				captureInputKey = null;
			}
		};
		release.Disposed += delegate
		{
			if (captureInputKey == chooseRelease)
			{
				captureInputKey = null;
			}
		};
		release.KeyDown += (object sender, KeyEventArgs args) =>
		{
			if (args.Modifiers == Keys.None)
			{
				args.Handled = true;
				args.SuppressKeyPress = true;
				chooseRelease(args.KeyCode);
			}
		};
		style.SelectedIndexChanged += delegate
		{
			apply();
		};
		WorkspaceToggle[] array = new WorkspaceToggle[3] { enabled, highlight, tint };
		for (int num = 0; num < array.Length; num++)
		{
			array[num].CheckedChanged += delegate
			{
				apply();
			};
		}
		size.ValueChanged += delegate
		{
			apply();
		};
		glow.ValueChanged += delegate
		{
			apply();
		};
		workspaceButton.Click += delegate
		{
			using ColorDialog colorDialog = new ColorDialog
			{
				FullOpen = true,
				Color = Color.FromArgb(-16777216 | cursorColor)
			};
			if (colorDialog.ShowDialog(this) == DialogResult.OK)
			{
				cursorColor = colorDialog.Color.ToArgb() & 0xFFFFFF;
				loading = true;
				if (style.SelectedIndex == 0)
				{
					tint.Checked = true;
				}
				loading = false;
				apply();
			}
		};
		workspaceButton2.Click += delegate
		{
			using ColorDialog colorDialog = new ColorDialog
			{
				FullOpen = true,
				Color = Color.FromArgb(-16777216 | glowColor)
			};
			if (colorDialog.ShowDialog(this) == DialogResult.OK)
			{
				glowColor = colorDialog.Color.ToArgb() & 0xFFFFFF;
				apply();
			}
		};
		WorkspaceButton workspaceButton3 = new WorkspaceButton
		{
			Text = Ui("Reset mouse", "Restablecer mouse"),
			Width = 222,
			Height = 32
		};
		workspaceButton3.Click += delegate
		{
			loading = true;
			style.SelectedIndex = 0;
			highlight.Checked = false;
			tint.Checked = false;
			size.Value = 32m;
			glow.Value = 60m;
			cursorColor = 6750003;
			glowColor = 16724000;
			loading = false;
			apply();
		};
		refreshPreview();
		panel.Controls.Add(workspaceButton3);
		panel.Controls.Add(result);
		assigned.Visible = false;
		Control control = panel.Controls[panel.Controls.IndexOf(release) - 1];
		Control value = panel.Controls[panel.Controls.IndexOf(broadcast) - 1];
		Control value2 = panel.Controls[panel.Controls.IndexOf(broadcast) + 1];
		Func<string, Control[], Control> func = (string title, Control[] children) =>
		{
			FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
			{
				Name = title,
				AutoSize = true,
				Width = 234,
				FlowDirection = FlowDirection.TopDown,
				WrapContents = false,
				Padding = new Padding(4),
				Margin = new Padding(0, 0, 0, 6),
				BorderStyle = BorderStyle.None
			};
			flowLayoutPanel.Controls.Add(new Label
			{
				Text = title,
				AutoSize = true,
				Font = new Font(panel.Font, FontStyle.Bold)
			});
			foreach (Control value3 in children)
			{
				flowLayoutPanel.Controls.Add(value3);
			}
			panel.Controls.Add(flowLayoutPanel);
			return flowLayoutPanel;
		};
		WorkspaceButton releaseAssign = new WorkspaceButton
		{
			Text = selectedRelease.ToString() + " · " + Ui("Change…", "Cambiar…"),
			Width = 222,
			Height = 34
		};
		releaseAssign.Click += delegate
		{
			CaptureShortcut(releaseAssign, Ui("Release mouse", "Liberar mouse"), selectedRelease, (Keys key) => InputPreferences.Allowed(key) && key != controllerModeKey && key != recordedMacroKey, (Keys key) =>
			{
				chooseRelease(key);
				releaseAssign.Text = selectedRelease.ToString() + " · " + Ui("Change…", "Cambiar…");
			});
		};
		panel.Controls.Remove(control);
		panel.Controls.Remove(release);
		Control control2 = func(Ui("Release mouse", "Liberar mouse"), new Control[1] { releaseAssign });
		panel.Controls.Remove(enabled);
		panel.Controls.Remove(value);
		panel.Controls.Remove(broadcast);
		panel.Controls.Remove(value2);
		control.Text = Ui("Custom key", "Tecla personalizada");
		release.BorderStyle = BorderStyle.None;
		release.BackColor = CurrentTheme.Surface;
		release.ForeColor = CurrentTheme.Text;
		NumericUpDown[] array2 = new NumericUpDown[2] { size, glow };
		foreach (NumericUpDown obj in array2)
		{
			obj.BorderStyle = BorderStyle.None;
			obj.BackColor = CurrentTheme.Surface;
			obj.ForeColor = CurrentTheme.Text;
		}
		panel.Controls.Remove(control2);
		mouseSettings = panel;
		return control2;
	}

	private async Task CheckUpdatesAsync(bool automatic)
	{
		if (privateTrial)
		{
			if (!automatic)
			{
				MessageBox.Show(this, "Private trial: automatic updates are disabled.", "KANBLAZ CLOUD");
			}
		}
		else
		{
			if (updateChecking || updateInstalling || IsDisposed)
			{
				return;
			}
			updateChecking = true;
			try
			{
				if (automatic)
				{
					await Task.Delay(7000, updateLifetime.Token);
				}
				using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(updateLifetime.Token);
				timeout.CancelAfter(TimeSpan.FromSeconds(20.0));
				ReleaseInfo releaseInfo = await UpdateProtocol.Check(timeout.Token);
				if (IsDisposed || Disposing)
				{
					return;
				}
				if (!UpdateProtocol.IsNewStable(releaseInfo, Assembly.GetExecutingAssembly().GetName().Version))
				{
					if (!automatic)
					{
						MessageBox.Show(this, Ui("No newer Stable version is available.", "No hay una versión Stable más nueva disponible."), "KANBLAZ CLOUD");
					}
					return;
				}
				UpdateProtocol.ValidateAsset(releaseInfo.Package);
				ShowUpdateOffer(releaseInfo);
			}
			catch (OperationCanceledException)
			{
				if (!automatic && !IsDisposed)
				{
					MessageBox.Show(this, Ui("Update check timed out. Try again later.", "La consulta tardó demasiado. Inténtalo más tarde."), "KANBLAZ CLOUD");
				}
			}
			catch (Exception ex2)
			{
				if (!automatic && !IsDisposed)
				{
					MessageBox.Show(this, Ui("Unable to check updates: ", "No se pudieron consultar las actualizaciones: ") + ex2.Message, "KANBLAZ CLOUD", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			finally
			{
				updateChecking = false;
			}
		}
	}

	private void ShowUpdateOffer(ReleaseInfo release)
	{
		Form dialog = new Form
		{
			Text = "KANBLAZ CLOUD",
			Width = 550,
			Height = 220,
			StartPosition = FormStartPosition.CenterParent,
			FormBorderStyle = FormBorderStyle.FixedDialog,
			MaximizeBox = false,
			MinimizeBox = false
		};
		try
		{
			CancellationTokenSource cancel = CancellationTokenSource.CreateLinkedTokenSource(updateLifetime.Token);
			try
			{
				bool downloading = false;
				bool installReady = false;
				Label message = new Label
				{
					Dock = DockStyle.Fill,
					Padding = new Padding(20),
					Text = Ui("A new Stable update is available.", "Hay una actualización Stable disponible.") + "\n\n" + Ui("Profiles and local settings are kept. Close game sessions before updating.", "Se conservan los profiles y ajustes locales. Cierra las sesiones de juego antes de actualizar.")
				};
				FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
				{
					Dock = DockStyle.Bottom,
					Height = 55,
					FlowDirection = FlowDirection.RightToLeft,
					Padding = new Padding(8)
				};
				Button later = new Button
				{
					Text = Ui("Later", "Después"),
					AutoSize = true
				};
				Button update = new Button
				{
					Text = Ui("Update", "Actualizar"),
					AutoSize = true
				};
				Button notes = new Button
				{
					Text = "What's New",
					AutoSize = true
				};
				flowLayoutPanel.Controls.Add(later);
				flowLayoutPanel.Controls.Add(update);
				flowLayoutPanel.Controls.Add(notes);
				dialog.Controls.Add(message);
				dialog.Controls.Add(flowLayoutPanel);
				notes.Click += (object s, EventArgs e) =>
				{
					using Form form = new Form
					{
						Text = "What's New",
						Size = new Size(650, 480),
						StartPosition = FormStartPosition.CenterParent
					};
					form.Controls.Add(new TextBox
					{
						Multiline = true,
						ReadOnly = true,
						ScrollBars = ScrollBars.Vertical,
						Dock = DockStyle.Fill,
						Text = (release.Notes ?? Ui("No release notes provided.", "No se proporcionaron notas.")).Substring(0, Math.Min(40000, (release.Notes ?? Ui("No release notes provided.", "No se proporcionaron notas.")).Length))
					});
					form.ShowDialog(dialog);
				};
				later.Click += (object s, EventArgs e) =>
				{
					if (downloading)
					{
						cancel.Cancel();
					}
					else
					{
						dialog.Close();
					}
				};
				dialog.FormClosing += (object s, FormClosingEventArgs e) =>
				{
					if (downloading)
					{
						cancel.Cancel();
						e.Cancel = true;
					}
				};
				update.Click += async (object s, EventArgs e) =>
				{
					if (sessions.Count > 0 || restartingProfiles.Count > 0 || deletingProfile)
					{
						MessageBox.Show(dialog, Ui("Close all game sessions first. Nothing will be closed automatically.", "Primero cierra todas las sesiones de juego. No se cerrarán automáticamente."), "KANBLAZ CLOUD");
					}
					else
					{
						downloading = true;
						updateInstalling = true;
						update.Enabled = false;
						notes.Enabled = false;
						later.Text = Ui("Cancel", "Cancelar");
						try
						{
							UpdateProtocol.ValidateDestination(AppDomain.CurrentDomain.BaseDirectory);
							ReleaseAsset asset = release.Package;
							UpdateProtocol.ValidateAsset(asset);
							string folder = Path.Combine(UpdateProtocol.CacheRoot, Guid.NewGuid().ToString("N"));
							UpdateProtocol.NoLinks(folder);
							Directory.CreateDirectory(folder);
							string archive = Path.Combine(folder, "package.zip");
							message.Text = Ui("Downloading and verifying the update…", "Descargando y verificando la actualización…");
							using (FileStream file = new FileStream(archive, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, useAsync: true))
							{
								await UpdateProtocol.Fetch(asset.Url, asset.Size, cancel.Token, file);
							}
							if (new FileInfo(archive).Length != asset.Size)
							{
								throw new InvalidDataException("Incomplete update download.");
							}
							await Task.Run(() =>
							{
								UpdateProtocol.Extract(archive, asset.Digest, Path.Combine(folder, "verified"));
								if (AssemblyName.GetAssemblyName(Path.Combine(folder, "verified", "KANBLAZ CLOUD.exe")).Version != release.Version)
								{
									throw new InvalidDataException("Release and executable versions do not match.");
								}
							}, cancel.Token);
							cancel.Token.ThrowIfCancellationRequested();
							if (sessions.Count > 0 || restartingProfiles.Count > 0 || IsDisposed)
							{
								throw new InvalidOperationException("Application state changed. Try again later.");
							}
							UpdateJob graph = new UpdateJob
							{
								Destination = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory).TrimEnd('\\'),
								Archive = archive,
								Digest = asset.Digest,
								Version = release.Tag,
								ParentId = Process.GetCurrentProcess().Id
							};
							string text = Path.Combine(folder, "job.json");
							using (FileStream stream = File.Create(text))
							{
								new DataContractJsonSerializer(typeof(UpdateJob)).WriteObject(stream, graph);
							}
							string text2 = Path.Combine(folder, "Kanblaz.UpdateHost.exe");
							File.Copy(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Kanblaz.UpdateHost.exe"), text2, overwrite: false);
							Process.Start(new ProcessStartInfo(text2, "\"" + text + "\"")
							{
								UseShellExecute = false,
								CreateNoWindow = true,
								WindowStyle = ProcessWindowStyle.Hidden
							});
							installReady = true;
						}
						catch (OperationCanceledException)
						{
							message.Text = Ui("Update canceled. Current version is unchanged.", "Actualización cancelada. La versión actual no cambió.");
						}
						catch (Exception ex2)
						{
							message.Text = Ui("Update was not installed: ", "No se instaló la actualización: ") + ex2.Message;
						}
						finally
						{
							downloading = false;
							updateInstalling = false;
							update.Enabled = !cancel.IsCancellationRequested;
							notes.Enabled = true;
							later.Text = Ui("Later", "Después");
						}
						if (installReady)
						{
							dialog.Close();
							Close();
						}
					}
				};
				dialog.ShowDialog(this);
			}
			finally
			{
				if (cancel != null)
				{
					((IDisposable)cancel).Dispose();
				}
			}
		}
		finally
		{
			if (dialog != null)
			{
				((IDisposable)dialog).Dispose();
			}
		}
	}
}
