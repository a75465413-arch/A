using System;

namespace KanblazCloudShell;

internal sealed class ProfileGroup
{
	internal Guid Id { get; set; }

	internal string Name { get; set; }

	public override string ToString()
	{
		return Name ?? string.Empty;
	}
}
