using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class SplashForm : Form
{
	internal SplashForm()
	{
		ClientSize = new Size(970, 546);
		FormBorderStyle = FormBorderStyle.None;
		StartPosition = FormStartPosition.CenterScreen;
		BackColor = Color.Black;
		ShowInTaskbar = false;
		CoverImagePanel coverImagePanel = new CoverImagePanel
		{
			Dock = DockStyle.Fill,
			BackColor = Color.Black
		};
		coverImagePanel.LoadCover(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "kanblaz-loading.png"));
		Controls.Add(coverImagePanel);
	}
}
