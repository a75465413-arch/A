using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal static class Program
{
	internal const string DisplayName = "KANBLAZ CLOUD";

	[STAThread]
	private static void Main()
	{
		StartupTiming.Mark("process-entry");
		using Mutex mutex = new Mutex(initiallyOwned: false, "Local\\Kanblaz.CloudShell.Stable");
		bool flag;
		try
		{
			flag = mutex.WaitOne(0);
		}
		catch (AbandonedMutexException)
		{
			flag = true;
		}
		if (!flag)
		{
			MessageBox.Show("KANBLAZ CLOUD is already open. Use the existing window.", "KANBLAZ CLOUD");
			return;
		}
		try
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(defaultValue: false);
			string text = StartupComponents.Missing(AppDomain.CurrentDomain.BaseDirectory);
			if (text != null)
			{
				MessageBox.Show("KANBLAZ CLOUD is missing a required component: " + text + "\n\nUse Extract All on the complete ZIP and open KANBLAZ CLOUD.exe from the extracted folder. Do not move the EXE by itself.", "KANBLAZ CLOUD", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			}
			else
			{
				RunShell();
			}
		}
		catch (Exception ex2)
		{
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "startup-error.txt");
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			File.WriteAllText(path, ex2.ToString());
			MessageBox.Show("KANBLAZ CLOUD could not start.\n\n" + ex2.Message, "KANBLAZ CLOUD", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}
		finally
		{
			mutex.ReleaseMutex();
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	private static void RunShell()
	{
		using PreparedStartupContext context = new PreparedStartupContext(new SplashForm(), () => new ShellForm(), (Form form) =>
		{
			((ShellForm)form).CompleteStartup();
		}, (Exception error) =>
		{
			MessageBox.Show("KANBLAZ CLOUD could not start.\n\n" + error.Message, "KANBLAZ CLOUD", MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}, (!PerformanceMode.Enabled) ? 2000 : 0);
		Application.Run(context);
	}
}
