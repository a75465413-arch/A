using System;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal static class NativeMouseCapture
{
	[DllImport("user32.dll")]
	private static extern IntPtr GetFocus();

	[DllImport("user32.dll")]
	private static extern bool IsChild(IntPtr parent, IntPtr child);

	[DllImport("user32.dll")]
	internal static extern bool ReleaseCapture();

	[DllImport("user32.dll")]
	internal static extern bool ClipCursor(IntPtr rectangle);

	internal static bool IsFocusWithin(IntPtr host)
	{
		IntPtr focus = GetFocus();
		if (focus != IntPtr.Zero)
		{
			if (!(focus == host))
			{
				return IsChild(host, focus);
			}
			return true;
		}
		return false;
	}
}
