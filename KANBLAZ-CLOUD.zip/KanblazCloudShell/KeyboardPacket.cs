using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class KeyboardPacket
{
	private readonly HashSet<Keys> held = new HashSet<Keys>();

	internal void Clear()
	{
		held.Clear();
	}

	internal static bool Describe(Keys key, out string code, out string name)
	{
		code = (name = null);
		if (key >= Keys.A && key <= Keys.Z)
		{
			code = "Key" + key;
			name = key.ToString().ToLowerInvariant();
			return true;
		}
		if (key >= Keys.D0 && key <= Keys.D9)
		{
			name = ((int)(key - 48)).ToString();
			code = "Digit" + name;
			return true;
		}
		if (key >= Keys.NumPad0 && key <= Keys.NumPad9)
		{
			name = ((int)(key - 96)).ToString();
			code = "Numpad" + name;
			return true;
		}
		if (key >= Keys.F1 && key <= Keys.F24 && key != Keys.F2)
		{
			code = (name = key.ToString());
			return true;
		}
		switch (key)
		{
		case Keys.Space:
			code = "Space";
			name = " ";
			break;
		case Keys.Left:
			code = (name = "ArrowLeft");
			break;
		case Keys.Right:
			code = (name = "ArrowRight");
			break;
		case Keys.Up:
			code = (name = "ArrowUp");
			break;
		case Keys.Down:
			code = (name = "ArrowDown");
			break;
		case Keys.ShiftKey:
		case Keys.LShiftKey:
			code = "ShiftLeft";
			name = "Shift";
			break;
		case Keys.RShiftKey:
			code = "ShiftRight";
			name = "Shift";
			break;
		case Keys.ControlKey:
		case Keys.LControlKey:
			code = "ControlLeft";
			name = "Control";
			break;
		case Keys.RControlKey:
			code = "ControlRight";
			name = "Control";
			break;
		case Keys.Menu:
		case Keys.LMenu:
			code = "AltLeft";
			name = "Alt";
			break;
		case Keys.RMenu:
			code = "AltRight";
			name = "Alt";
			break;
		case Keys.Return:
			code = (name = "Enter");
			break;
		case Keys.Back:
			code = (name = "Backspace");
			break;
		case Keys.Tab:
		case Keys.Escape:
		case Keys.End:
		case Keys.Home:
		case Keys.Insert:
		case Keys.Delete:
			code = (name = key.ToString());
			break;
		case Keys.Prior:
			code = (name = "PageUp");
			break;
		case Keys.Next:
			code = (name = "PageDown");
			break;
		case Keys.OemSemicolon:
			code = "Semicolon";
			name = ";";
			break;
		case Keys.Oemplus:
			code = "Equal";
			name = "=";
			break;
		case Keys.Oemcomma:
			code = "Comma";
			name = ",";
			break;
		case Keys.OemMinus:
			code = "Minus";
			name = "-";
			break;
		case Keys.OemPeriod:
			code = "Period";
			name = ".";
			break;
		case Keys.OemQuestion:
			code = "Slash";
			name = "/";
			break;
		case Keys.Oemtilde:
			code = "Backquote";
			name = "`";
			break;
		case Keys.OemOpenBrackets:
			code = "BracketLeft";
			name = "[";
			break;
		case Keys.OemCloseBrackets:
			code = "BracketRight";
			name = "]";
			break;
		case Keys.OemPipe:
			code = "Backslash";
			name = "\\";
			break;
		case Keys.OemQuotes:
			code = "Quote";
			name = "'";
			break;
		case Keys.Add:
			code = "NumpadAdd";
			name = "+";
			break;
		case Keys.Subtract:
			code = "NumpadSubtract";
			name = "-";
			break;
		case Keys.Multiply:
			code = "NumpadMultiply";
			name = "*";
			break;
		case Keys.Divide:
			code = "NumpadDivide";
			name = "/";
			break;
		case Keys.Decimal:
			code = "NumpadDecimal";
			name = ".";
			break;
		default:
			return false;
		}
		return true;
	}

	private bool Has(Keys generic, Keys left, Keys right)
	{
		if (!held.Contains(generic) && !held.Contains(left))
		{
			return held.Contains(right);
		}
		return true;
	}

	private static string Quote(string value)
	{
		return "\"" + value.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
	}

	internal string Create(Keys key, bool down)
	{
		if (!Describe(key, out var code, out var name))
		{
			throw new InvalidOperationException("Unsupported or reserved macro key.");
		}
		if (down)
		{
			held.Add(key);
		}
		else
		{
			held.Remove(key);
		}
		bool flag = Has(Keys.ShiftKey, Keys.LShiftKey, Keys.RShiftKey);
		int num = (flag ? 8 : 0) | (Has(Keys.ControlKey, Keys.LControlKey, Keys.RControlKey) ? 2 : 0) | (Has(Keys.Menu, Keys.LMenu, Keys.RMenu) ? 1 : 0);
		if (flag && key >= Keys.A && key <= Keys.Z)
		{
			name = name.ToUpperInvariant();
		}
		if (flag && key >= Keys.D0 && key <= Keys.D9)
		{
			name = ")!@#$%^&*("[(int)(key - 48)].ToString();
		}
		if (flag && name.Length == 1 && !code.StartsWith("Numpad"))
		{
			int num2 = ";=,-./`[\\]'".IndexOf(name[0]);
			if (num2 >= 0)
			{
				name = ":+<_>?~{|}\""[num2].ToString();
			}
		}
		int num3 = ((code.EndsWith("Right") && !code.StartsWith("Arrow")) ? 2 : ((code.EndsWith("Left") && !code.StartsWith("Arrow")) ? 1 : (code.StartsWith("Numpad") ? 3 : 0)));
		string[] array = new string[15]
		{
			"{\"type\":\"",
			down ? "rawKeyDown" : "keyUp",
			"\",\"key\":",
			Quote(name),
			",\"code\":",
			Quote(code),
			",\"windowsVirtualKeyCode\":",
			null,
			null,
			null,
			null,
			null,
			null,
			null,
			null
		};
		int num4 = (int)key;
		array[7] = num4.ToString();
		array[8] = ",\"modifiers\":";
		array[9] = num.ToString();
		array[10] = ",\"location\":";
		array[11] = num3.ToString();
		array[12] = ",\"isKeypad\":";
		array[13] = ((num3 == 3) ? "true" : "false");
		array[14] = ",\"autoRepeat\":false}";
		return string.Concat(array);
	}
}
