using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace KanblazCloudShell;

internal static class WorkspaceDrawing
{
	internal static GraphicsPath Round(Rectangle bounds, int radius)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		float num = Math.Max(1, Math.Min(radius * 2, Math.Min(bounds.Width, bounds.Height)));
		float num2 = (float)bounds.Right - 1f;
		float num3 = (float)bounds.Bottom - 1f;
		graphicsPath.AddArc(bounds.Left, bounds.Top, num, num, 180f, 90f);
		graphicsPath.AddArc(num2 - num, bounds.Top, num, num, 270f, 90f);
		graphicsPath.AddArc(num2 - num, num3 - num, num, num, 0f, 90f);
		graphicsPath.AddArc(bounds.Left, num3 - num, num, num, 90f, 90f);
		graphicsPath.CloseFigure();
		return graphicsPath;
	}
}
