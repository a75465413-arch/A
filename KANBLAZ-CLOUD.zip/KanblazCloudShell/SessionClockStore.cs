using System;
using System.IO;
using System.Runtime.Serialization.Json;

namespace KanblazCloudShell;

internal sealed class SessionClockStore
{
	private readonly string path;

	internal SessionClockStore(string directory, Guid profileId, string service)
	{
		if (profileId == Guid.Empty || CloudService.FromId(service) == null)
		{
			throw new ArgumentException("Invalid timer identity.");
		}
		path = Path.Combine(Path.GetFullPath(directory), profileId.ToString("N") + "." + service + ".json");
	}

	internal static SessionClockStore ForProfile(Guid id, string service)
	{
		return new SessionClockStore(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "session-clocks"), id, service);
	}

	internal SessionClockRecord Load()
	{
		SessionClockRecord sessionClockRecord;
		try
		{
			using FileStream fileStream = File.OpenRead(path);
			if (fileStream.Length > 4096)
			{
				throw new InvalidDataException("Invalid timer record.");
			}
			sessionClockRecord = (SessionClockRecord)new DataContractJsonSerializer(typeof(SessionClockRecord)).ReadObject(fileStream);
		}
		catch (FileNotFoundException)
		{
			if (File.Exists(path + ".bak"))
			{
				throw new InvalidDataException("The current timer record is missing; its backup was preserved.");
			}
			return new SessionClockRecord();
		}
		catch (DirectoryNotFoundException)
		{
			return new SessionClockRecord();
		}
		if (sessionClockRecord == null || sessionClockRecord.Version != 1 || double.IsNaN(sessionClockRecord.Deadline) || double.IsInfinity(sessionClockRecord.Deadline) || sessionClockRecord.Deadline < 0.0 || (sessionClockRecord.Started && sessionClockRecord.Ended) || (sessionClockRecord.Started && sessionClockRecord.Deadline == 0.0))
		{
			throw new InvalidDataException("Invalid timer record.");
		}
		return sessionClockRecord;
	}

	internal void Save(SessionClockRecord value)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string sourceFileName = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			using (FileStream fileStream = new FileStream(sourceFileName, FileMode.CreateNew, FileAccess.Write, FileShare.None))
			{
				new DataContractJsonSerializer(typeof(SessionClockRecord)).WriteObject(fileStream, value);
				fileStream.Flush(flushToDisk: true);
			}
			if (File.Exists(path))
			{
				File.Replace(sourceFileName, path, path + ".bak", ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(sourceFileName, path);
			}
		}
		finally
		{
			if (File.Exists(sourceFileName))
			{
				File.Delete(sourceFileName);
			}
		}
	}
}
