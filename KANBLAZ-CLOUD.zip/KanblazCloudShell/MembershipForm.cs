using System;
using System.Drawing;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class MembershipForm : Form
{
	private readonly GoogleAccountLogin.BillingAccount account;

	private readonly CancellationTokenSource lifetime = new CancellationTokenSource();

	private readonly ComboBox plans = new ComboBox
	{
		DropDownStyle = ComboBoxStyle.DropDownList,
		Width = 540
	};

	private readonly ListBox subscriptions = new ListBox
	{
		Width = 540,
		Height = 130
	};

	private readonly Label status = new Label
	{
		AutoSize = true,
		MaximumSize = new Size(540, 0)
	};

	private readonly Button checkout = new Button
	{
		AutoSize = true
	};

	private readonly Button refresh = new Button
	{
		AutoSize = true
	};

	private readonly Button cancel = new Button
	{
		AutoSize = true
	};

	private GoogleAccountLogin.BillingSubscription[] rows = new GoogleAccountLogin.BillingSubscription[0];

	private bool enabledByServer;

	private bool busy;

	private readonly bool spanish = LanguagePreferences.Resolve(LanguagePreferences.ForCurrentUser().Load(), CultureInfo.CurrentUICulture) == AppLanguage.Spanish;

	private string T(string en, string es)
	{
		if (!spanish)
		{
			return en;
		}
		return es;
	}

	internal static string PlanKey(int index)
	{
		return index switch
		{
			2 => "annual", 
			1 => "sixMonths", 
			0 => "monthly", 
			_ => null, 
		};
	}

	internal static bool CanCancel(GoogleAccountLogin.BillingSubscription row)
	{
		if (row != null && row.CancelAtPeriodEnd == 0)
		{
			if (!(row.Status == "active") && !(row.Status == "trialing") && !(row.Status == "past_due") && !(row.Status == "unpaid"))
			{
				return row.Status == "paused";
			}
			return true;
		}
		return false;
	}

	internal MembershipForm(Icon icon)
	{
		account = GoogleAccountLogin.OpenBillingAccount();
		Text = "KANBLAZ CLOUD";
		Icon = icon;
		ClientSize = new Size(600, 580);
		StartPosition = FormStartPosition.CenterParent;
		FormBorderStyle = FormBorderStyle.FixedDialog;
		MaximizeBox = false;
		MinimizeBox = false;
		ShowInTaskbar = false;
		Font = new Font("Segoe UI", 10f);
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			Dock = DockStyle.Fill,
			Padding = new Padding(24),
			AutoScroll = true,
			FlowDirection = FlowDirection.TopDown,
			WrapContents = false
		};
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = T("PRO MEMBERSHIPS", "MEMBRESÍAS PRO"),
			AutoSize = true,
			Font = new Font("Segoe UI Semibold", 16f)
		});
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = account.Email,
			AutoSize = true,
			MaximumSize = new Size(540, 0)
		});
		plans.Items.AddRange(new object[3]
		{
			T("USD 5 / month", "USD 5 / mes"),
			T("USD 20 / 6 months", "USD 20 / 6 meses"),
			T("USD 30 / year", "USD 30 / año")
		});
		plans.SelectedIndex = 0;
		flowLayoutPanel.Controls.Add(plans);
		flowLayoutPanel.Controls.Add(new Label
		{
			AutoSize = true,
			MaximumSize = new Size(540, 0),
			Text = T("Automatically renews until canceled. Confirm the final total in Stripe. Existing lifetime licenses remain valid.", "Renovación automática hasta cancelar. Confirma el total final en Stripe. Las licencias vitalicias existentes siguen vigentes.")
		});
		checkout.Text = T("Continue to Stripe", "Continuar a Stripe");
		checkout.Click += Buy;
		flowLayoutPanel.Controls.Add(checkout);
		flowLayoutPanel.Controls.Add(new Label
		{
			Text = T("Your subscriptions", "Tus suscripciones"),
			AutoSize = true,
			Margin = new Padding(0, 18, 0, 5)
		});
		subscriptions.SelectedIndexChanged += delegate
		{
			UpdateButtons();
		};
		flowLayoutPanel.Controls.Add(subscriptions);
		cancel.Text = T("Cancel renewal", "Cancelar renovación");
		cancel.Click += CancelRenewal;
		flowLayoutPanel.Controls.Add(cancel);
		refresh.Text = T("Refresh subscription and access", "Actualizar suscripción y acceso");
		refresh.Click += async delegate
		{
			await Run(LoadStatus);
		};
		flowLayoutPanel.Controls.Add(refresh);
		status.Margin = new Padding(0, 12, 0, 0);
		flowLayoutPanel.Controls.Add(status);
		Controls.Add(flowLayoutPanel);
		UpdateButtons();
		Shown += async delegate
		{
			await Run(LoadStatus);
		};
		FormClosed += delegate
		{
			lifetime.Cancel();
		};
	}

	private void UpdateButtons()
	{
		checkout.Enabled = !busy && enabledByServer;
		plans.Enabled = !busy;
		refresh.Enabled = !busy;
		subscriptions.Enabled = !busy;
		int selectedIndex = subscriptions.SelectedIndex;
		cancel.Enabled = !busy && selectedIndex >= 0 && selectedIndex < rows.Length && CanCancel(rows[selectedIndex]);
	}

	private async Task Run(Func<Task> operation)
	{
		if (busy)
		{
			return;
		}
		busy = true;
		UpdateButtons();
		try
		{
			await operation();
		}
		catch (OperationCanceledException)
		{
		}
		catch
		{
			if (!IsDisposed)
			{
				enabledByServer = false;
				status.Text = T("Could not confirm the result. Refresh before retrying. If your session expired, sign in again. Your lifetime license is unchanged.", "No se pudo confirmar el resultado. Actualiza antes de reintentar. Si venció la sesión, inicia sesión de nuevo. Tu licencia vitalicia no cambia.");
			}
		}
		finally
		{
			if (!IsDisposed)
			{
				busy = false;
				UpdateButtons();
			}
		}
	}

	private async Task LoadStatus()
	{
		enabledByServer = false;
		GoogleAccountLogin.Reply result = await account.Status(lifetime.Token);
		if (IsDisposed)
		{
			return;
		}
		rows = result.Subscriptions ?? new GoogleAccountLogin.BillingSubscription[0];
		subscriptions.Items.Clear();
		GoogleAccountLogin.BillingSubscription[] array = rows;
		foreach (GoogleAccountLogin.BillingSubscription billingSubscription in array)
		{
			string text = "";
			if (billingSubscription.PaidUntil.HasValue)
			{
				text = " · " + T("Paid through ", "Pagado hasta ") + DateTimeOffset.FromUnixTimeSeconds(billingSubscription.PaidUntil.Value).ToLocalTime().ToString("g");
			}
			subscriptions.Items.Add(billingSubscription.Id + " · " + billingSubscription.Status + text + ((billingSubscription.CancelAtPeriodEnd != 0) ? T(" · Cancels at period end", " · Cancela al finalizar") : ""));
		}
		if (rows.Length != 0)
		{
			subscriptions.SelectedIndex = 0;
		}
		await GoogleAccountLogin.RefreshAccess(lifetime.Token);
		if (!IsDisposed)
		{
			enabledByServer = result.PaymentsEnabled;
			status.Text = (enabledByServer ? T("Purchases available.", "Compras disponibles.") : T("New purchases are currently disabled.", "Las compras nuevas están deshabilitadas.")) + " " + T("Access is verified by the server, never by the Checkout return page.", "El servidor verifica el acceso; volver de Checkout no activa Pro.");
		}
	}

	private async void Buy(object sender, EventArgs args)
	{
		if (busy || !enabledByServer)
		{
			return;
		}
		string plan = PlanKey(plans.SelectedIndex);
		if (plan == null)
		{
			return;
		}
		string text = account.Email + "\n\n" + plans.SelectedItem?.ToString() + "\n" + T("Recurring subscription, automatically renewed until canceled. Open Stripe to review and pay?", "Suscripción recurrente con renovación automática hasta cancelar. ¿Abrir Stripe para revisar y pagar?");
		if (MessageBox.Show(this, text, "KANBLAZ CLOUD", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button2) != DialogResult.OK)
		{
			return;
		}
		await Run(async () =>
		{
			await account.OpenCheckout(plan, lifetime.Token);
			if (!IsDisposed)
			{
				status.Text = T("Complete Checkout in your browser, then refresh here. Opening Stripe does not activate Pro.", "Completa Checkout en tu navegador y luego actualiza aquí. Abrir Stripe no activa Pro.");
			}
		});
	}

	private async void CancelRenewal(object sender, EventArgs args)
	{
		int i = subscriptions.SelectedIndex;
		if (busy || i < 0 || i >= rows.Length || !CanCancel(rows[i]))
		{
			return;
		}
		string id = rows[i].Id;
		if (MessageBox.Show(this, account.Email + "\n" + id + "\n\n" + T("Cancel automatic renewal at the end of the current period? This does not request a refund.", "¿Cancelar la renovación al finalizar el período actual? Esto no solicita un reembolso."), "KANBLAZ CLOUD", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.OK)
		{
			return;
		}
		await Run(async () =>
		{
			await account.Cancel(id, lifetime.Token);
			if (!IsDisposed)
			{
				rows[i].CancelAtPeriodEnd = 1;
				status.Text = T("Renewal cancellation accepted. Refresh after the webhook arrives.", "Cancelación de renovación aceptada. Actualiza cuando llegue el webhook.");
			}
		});
	}
}
