namespace KanblazCloudShell;

internal sealed class VerifiedSessionWarning
{
	private double validUntil = -1.0;

	internal void Observe(int? seconds, bool verified, double now)
	{
		validUntil = ((verified && seconds.HasValue && seconds.Value > 0 && seconds.Value <= 300) ? (now + 3.0) : (-1.0));
	}

	internal bool Lit(double now)
	{
		if (now < validUntil)
		{
			return (int)(now * 2.0) % 2 == 0;
		}
		return false;
	}
}
