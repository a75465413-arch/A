using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class PreparedStartupContext : ApplicationContext
{
	private readonly Form splash;

	private readonly Func<Form> createShell;

	private readonly Action<Form> ready;

	private readonly Action<Exception> failed;

	private readonly int minimumMilliseconds;

	private Form shell;

	private bool disposed;

	internal PreparedStartupContext(Form splash, Func<Form> createShell, Action<Form> ready, Action<Exception> failed, int minimumMilliseconds = 2000)
	{
		this.splash = splash;
		this.createShell = createShell;
		this.ready = ready;
		this.failed = failed;
		this.minimumMilliseconds = minimumMilliseconds;
		MainForm = splash;
		splash.Shown += Prepare;
	}

	private async void Prepare(object sender, EventArgs args)
	{
		splash.Shown -= Prepare;
		try
		{
			Task minimum = Task.Delay(minimumMilliseconds);
			splash.Refresh();
			await NextTurn(splash);
			if (disposed || splash.IsDisposed)
			{
				return;
			}
			StartupTiming.Mark("preparation-start");
			shell = createShell();
			shell.Opacity = 0.0;
			shell.Show();
			shell.PerformLayout();
			await NextTurn(shell);
			if (!disposed && !shell.IsDisposed && !splash.IsDisposed)
			{
				shell.Refresh();
				await NextTurn(shell);
				StartupTiming.Mark("visuals-prepared");
				await minimum;
				if (!disposed && !shell.IsDisposed && !splash.IsDisposed)
				{
					MainForm = shell;
					shell.Opacity = 1.0;
					shell.Refresh();
					splash.Close();
					StartupTiming.Mark("splash-finished");
					shell.Activate();
					ready(shell);
				}
			}
		}
		catch (Exception obj)
		{
			if (disposed)
			{
				return;
			}
			try
			{
				failed(obj);
			}
			finally
			{
				if (shell != null && !shell.IsDisposed)
				{
					shell.Dispose();
				}
				if (!splash.IsDisposed)
				{
					splash.Dispose();
				}
				ExitThread();
			}
		}
	}

	private static Task NextTurn(Control control)
	{
		TaskCompletionSource<bool> completion = new TaskCompletionSource<bool>();
		control.BeginInvoke((Action)(() =>
		{
			completion.TrySetResult(result: true);
		}));
		return completion.Task;
	}

	protected override void Dispose(bool disposing)
	{
		disposed = true;
		if (disposing)
		{
			splash.Shown -= Prepare;
			if (shell != null && !shell.IsDisposed)
			{
				shell.Dispose();
			}
			if (!splash.IsDisposed)
			{
				splash.Dispose();
			}
		}
		base.Dispose(disposing);
	}
}
