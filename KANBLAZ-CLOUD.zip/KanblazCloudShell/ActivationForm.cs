using System;
using System.Drawing;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class ActivationForm : Form
{
	private readonly TextBox activationCode = new TextBox();

	private readonly Label feedback = new Label();

	private bool activating;

	internal ActivationForm()
	{
		Text = "Activate KANBLAZ CLOUD";
		StartPosition = FormStartPosition.CenterScreen;
		ClientSize = new Size(660, 410);
		MinimumSize = new Size(660, 410);
		FormBorderStyle = FormBorderStyle.FixedDialog;
		MaximizeBox = false;
		MinimizeBox = false;
		ShowInTaskbar = true;
		BackColor = Color.FromArgb(13, 15, 18);
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 10f);
		BuildInterface();
	}

	private void BuildInterface()
	{
		TableLayoutPanel tableLayoutPanel = new TableLayoutPanel
		{
			Dock = DockStyle.Fill,
			Padding = new Padding(30),
			ColumnCount = 1,
			RowCount = 7,
			BackColor = BackColor
		};
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
		Controls.Add(tableLayoutPanel);
		tableLayoutPanel.Controls.Add(new Label
		{
			Text = "ACTIVATE KANBLAZ CLOUD",
			AutoSize = true,
			Font = new Font("Segoe UI Semibold", 20f),
			ForeColor = Color.White,
			Margin = new Padding(0, 0, 0, 6)
		}, 0, 0);
		tableLayoutPanel.Controls.Add(new Label
		{
			Text = "Paste your code. Existing codes keep their activation. New codes support 2 devices with no expiration. First-time activation requires Internet and sends a hashed identifier for this Windows installation, different for each license. Your gaming account data is not sent.",
			AutoSize = true,
			MaximumSize = new Size(580, 0),
			ForeColor = Color.FromArgb(176, 194, 208),
			Margin = new Padding(0, 0, 0, 16)
		}, 0, 1);
		tableLayoutPanel.Controls.Add(new Label
		{
			Text = "ACTIVATION CODE",
			AutoSize = true,
			Font = new Font("Segoe UI Semibold", 9f),
			ForeColor = Color.FromArgb(177, 196, 210),
			Margin = new Padding(0, 0, 0, 6)
		}, 0, 2);
		activationCode.Multiline = true;
		activationCode.AcceptsReturn = false;
		activationCode.WordWrap = true;
		activationCode.Dock = DockStyle.Fill;
		activationCode.Font = new Font("Consolas", 9f);
		activationCode.BackColor = Color.FromArgb(24, 28, 34);
		activationCode.ForeColor = Color.White;
		activationCode.BorderStyle = BorderStyle.FixedSingle;
		activationCode.Margin = new Padding(0, 0, 0, 12);
		tableLayoutPanel.Controls.Add(activationCode, 0, 3);
		feedback.AutoSize = true;
		feedback.ForeColor = Color.FromArgb(255, 159, 159);
		feedback.Margin = new Padding(0, 0, 0, 10);
		tableLayoutPanel.Controls.Add(feedback, 0, 4);
		FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
		{
			AutoSize = true,
			Dock = DockStyle.Fill,
			FlowDirection = FlowDirection.RightToLeft
		};
		Button button = CreateButton("Activate", Activate);
		Button value = CreateButton("Exit", delegate
		{
			Close();
		}, primary: false);
		flowLayoutPanel.Controls.Add(button);
		flowLayoutPanel.Controls.Add(value);
		tableLayoutPanel.Controls.Add(flowLayoutPanel, 0, 5);
		tableLayoutPanel.Controls.Add(CommunityLinks.CreateFooter(), 0, 6);
		AcceptButton = button;
		activationCode.Focus();
	}

	private Button CreateButton(string text, EventHandler action, bool primary = true)
	{
		Button button = new Button();
		button.Text = text;
		button.AutoSize = true;
		button.FlatStyle = FlatStyle.Flat;
		button.Padding = new Padding(14, 7, 14, 7);
		button.BackColor = (primary ? Color.FromArgb(221, 241, 255) : Color.FromArgb(35, 41, 48));
		button.ForeColor = (primary ? Color.FromArgb(8, 21, 30) : Color.White);
		button.Margin = new Padding(8, 0, 0, 0);
		button.FlatAppearance.BorderColor = (primary ? Color.FromArgb(221, 241, 255) : Color.FromArgb(74, 87, 100));
		button.Click += action;
		return button;
	}

	protected override void OnFormClosing(FormClosingEventArgs e)
	{
		if (activating)
		{
			e.Cancel = true;
		}
		base.OnFormClosing(e);
	}

	private async void Activate(object sender, EventArgs args)
	{
		if (!activating)
		{
			activating = true;
			Enabled = false;
			feedback.Text = "Verifying activation…";
			string text;
			try
			{
				text = await LicenseStore.ActivateAsync(activationCode.Text);
			}
			finally
			{
				activating = false;
				Enabled = true;
			}
			if (text != null)
			{
				feedback.Text = text;
				return;
			}
			DialogResult = DialogResult.OK;
			Close();
		}
	}
}
