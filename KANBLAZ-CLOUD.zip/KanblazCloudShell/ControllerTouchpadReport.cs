namespace KanblazCloudShell;

internal static class ControllerTouchpadReport
{
	internal static bool TryRead(int vendor, int product, byte[] data, out TouchpadSample sample)
	{
		sample = default;
		if (vendor != 1356 || data == null || data.Length == 0)
		{
			return false;
		}
		bool flag = product == 3302 || product == 3570;
		bool flag2 = product == 1476 || product == 2508;
		if (!flag && !flag2)
		{
			return false;
		}
		bool flag3 = data[0] == 1 && data.Length == 64;
		bool flag4 = data[0] == (flag ? 49 : 17) && data.Length == 78;
		if (!flag3 && !flag4)
		{
			return false;
		}
		int num = (flag3 ? 1 : (flag ? 2 : 3));
		int num2 = num + (flag ? 32 : 34);
		sample.Click = (data[num + (flag ? 9 : 6)] & 2) != 0;
		if (flag2)
		{
			int num3 = data[num + 32];
			if (num3 > (flag3 ? 3 : 4))
			{
				return false;
			}
			if (num3 == 0)
			{
				return true;
			}
			num2 += (num3 - 1) * 9;
		}
		sample.Down = (data[num2] & 0x80) == 0;
		sample.Contact = data[num2] & 0x7F;
		sample.X = data[num2 + 1] | ((data[num2 + 2] & 0xF) << 8);
		sample.Y = (data[num2 + 2] >> 4) | (data[num2 + 3] << 4);
		if (sample.Down)
		{
			if (sample.X < 1920)
			{
				return sample.Y < (flag ? 1080 : 942);
			}
			return false;
		}
		return true;
	}
}
