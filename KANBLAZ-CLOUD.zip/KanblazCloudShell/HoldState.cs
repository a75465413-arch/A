namespace KanblazCloudShell;

internal sealed class HoldState
{
	private bool blockedUntilUp;

	internal bool Held { get; private set; }

	internal bool Down(bool eligible)
	{
		if (Held || blockedUntilUp || !eligible)
		{
			return false;
		}
		Held = true;
		return true;
	}

	internal bool Up()
	{
		bool held = Held;
		Held = false;
		blockedUntilUp = false;
		return held;
	}

	internal bool Cancel()
	{
		bool held = Held;
		Held = false;
		blockedUntilUp |= held;
		return held;
	}
}
