namespace KanblazCloudShell;

internal enum VpnState
{
	Unknown,
	NotDetected,
	Detected
}
