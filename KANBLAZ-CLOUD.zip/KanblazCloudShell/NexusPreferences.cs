using System;
using System.Drawing;
using System.Globalization;
using System.IO;

namespace KanblazCloudShell;

internal sealed class NexusPreferences
{
	internal Color Accent = Color.FromArgb(7, 89, 133);

	internal bool Light;

	internal bool Glow = true;

	internal int Background;

	internal static string FilePath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nexus-appearance.txt");

	internal static NexusPreferences Load()
	{
		return LoadFrom(FilePath);
	}

	internal static NexusPreferences LoadFrom(string path)
	{
		NexusPreferences nexusPreferences = new NexusPreferences();
		try
		{
			if (!File.Exists(path) || new FileInfo(path).Length > 128)
			{
				return nexusPreferences;
			}
			string[] array = File.ReadAllText(path).Split('|');
			if ((array.Length == 3 || array.Length == 4) && int.TryParse(array[0], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var result) && result >= 0 && result <= 16777215 && bool.TryParse(array[1], out var result2) && bool.TryParse(array[2], out var result3))
			{
				nexusPreferences.Accent = Color.FromArgb(255, Color.FromArgb(result));
				nexusPreferences.Light = result2;
				nexusPreferences.Glow = result3;
				if (array.Length == 4 && int.TryParse(array[3], out var result4) && result4 >= 0 && result4 <= 3)
				{
					nexusPreferences.Background = result4;
				}
			}
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		return nexusPreferences;
	}

	internal void SaveTo(string path)
	{
		string text = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			File.WriteAllText(text, (Accent.ToArgb() & 0xFFFFFF).ToString("X6") + "|" + Light + "|" + Glow + "|" + Math.Max(0, Math.Min(3, Background)));
			if (File.Exists(path))
			{
				File.Replace(text, path, null);
			}
			else
			{
				File.Move(text, path);
			}
		}
		finally
		{
			if (File.Exists(text))
			{
				File.Delete(text);
			}
		}
	}
}
