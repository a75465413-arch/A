namespace KanblazCloudShell;

internal enum CursorStyle
{
	Windows = 0,
	NeonTarget = 5
}
