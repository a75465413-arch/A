using System;

namespace KanblazCloudShell;

internal sealed class WelcomeRecoveryBudget
{
	private int attempts;

	private DateTime lastAttempt = DateTime.MinValue;

	internal bool TryBegin(DateTime now)
	{
		if (attempts >= 5 || (now - lastAttempt).TotalSeconds < 5.0)
		{
			return false;
		}
		attempts++;
		lastAttempt = now;
		return true;
	}
}
