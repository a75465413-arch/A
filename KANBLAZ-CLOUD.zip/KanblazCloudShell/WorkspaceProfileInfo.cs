using System;
using System.Runtime.Serialization;

namespace KanblazCloudShell;

[DataContract]
internal sealed class WorkspaceProfileInfo
{
	[DataMember]
	internal Guid Id;

	[DataMember]
	internal bool Favorite;

	[DataMember]
	internal string EpicId = "";

	[DataMember]
	internal string Tags = "";

	[DataMember]
	internal long LastLaunch;

	[DataMember]
	internal string LastStatus = "Ready";
}
