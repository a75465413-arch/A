using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceToggle : CheckBox
{
	internal Color Accent = Color.Cyan;

	internal WorkspaceToggle()
	{
		SetStyle(ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
		AutoSize = false;
		Size = new Size(244, 30);
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		WorkspaceBackdrop.PaintBehind(this, e.Graphics, ClientRectangle, 0);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		WorkspaceBackdrop.PaintBehind(this, e.Graphics, ClientRectangle, 0);
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		TextRenderer.DrawText(e.Graphics, Text, Font, new Rectangle(0, 0, Math.Max(1, Width - 56), Height), ForeColor, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
		Rectangle rectangle = new Rectangle(Width - 47, (Height - 24) / 2, 44, 24);
		using (GraphicsPath path = WorkspaceDrawing.Round(rectangle, 12))
		{
			using LinearGradientBrush brush = new LinearGradientBrush(rectangle, Checked ? AppTheme.Blend(Accent, Color.White, 0.18) : Color.FromArgb(66, 82, 96), Checked ? Accent : Color.FromArgb(28, 42, 54), 90f);
			e.Graphics.FillPath(brush, path);
			using Pen pen = new Pen(Checked ? Accent : Color.FromArgb(83, 106, 123));
			e.Graphics.DrawPath(pen, path);
		}
		using (SolidBrush brush2 = new SolidBrush(Color.FromArgb(228, 237, 245)))
		{
			e.Graphics.FillEllipse(brush2, Checked ? (rectangle.Right - 21) : (rectangle.X + 3), rectangle.Y + 3, 17, 17);
		}
		if (Focused && ShowFocusCues)
		{
			ControlPaint.DrawFocusRectangle(e.Graphics, ClientRectangle);
		}
	}
}
