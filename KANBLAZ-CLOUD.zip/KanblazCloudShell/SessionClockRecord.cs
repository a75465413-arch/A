using System.Runtime.Serialization;

namespace KanblazCloudShell;

[DataContract]
internal sealed class SessionClockRecord
{
	[DataMember]
	public int Version = 1;

	[DataMember]
	public bool Started;

	[DataMember]
	public double Deadline;

	[DataMember]
	public bool Ended;
}
