using System.Drawing;

namespace KanblazCloudShell;

internal sealed class SessionLayoutSlot
{
	internal int SessionIndex { get; set; }

	internal Rectangle Bounds { get; set; }

	internal bool Visible { get; set; }
}
