using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace KanblazCloudShell;

internal static class WelcomeRecovery
{
	internal static bool IsAllowedSource(string address)
	{
		if (!Uri.TryCreate(address, UriKind.Absolute, out var result) || result.Scheme != "https" || !result.IsDefaultPort)
		{
			return false;
		}
		switch (result.DnsSafeHost.ToLowerInvariant())
		{
		case "xbox.com":
		case "www.xbox.com":
		case "play.xbox.com":
		case "account.xbox.com":
		case "sisu.xboxlive.com":
		case "login.live.com":
			return true;
		default:
			return false;
		}
	}

	internal static bool IsSignal(string address, string json)
	{
		if (IsAllowedSource(address))
		{
			return json == "\"kanblaz.welcome.blocked.v1\"";
		}
		return false;
	}

	internal static Task<string> InstallAsync(CoreWebView2 browser)
	{
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Kanblaz.WelcomeRecovery.js");
		using StreamReader streamReader = new StreamReader(stream);
		return browser.AddScriptToExecuteOnDocumentCreatedAsync(streamReader.ReadToEnd());
	}
}
