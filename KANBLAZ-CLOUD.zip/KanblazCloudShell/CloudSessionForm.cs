using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using KanblazCloudShell.SoundAlerts;
using KanblazCloudShell.VisualAlerts;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace KanblazCloudShell;

internal sealed class CloudSessionForm : Form, IMessageFilter
{
	private const int WmNcHitTest = 132;

	private const int HtClient = 1;

	private const int HtCaption = 2;

	private const int HtLeft = 10;

	private const int HtRight = 11;

	private const int HtTop = 12;

	private const int HtTopLeft = 13;

	private const int HtTopRight = 14;

	private const int HtBottom = 15;

	private const int HtBottomLeft = 16;

	private const int HtBottomRight = 17;

	private const int ResizeBorderPixels = 8;

	private readonly Profile profile;

	private readonly bool backgroundAudioEnabled;

	private bool controllerShared;

	private ControllerBrowserBridge controllerRouting;

	private bool controllerOwned;

	private readonly MovementMacro movementMacro;

	private readonly VirtualJoystickOutput macroJoystick;

	private bool macroGameplayObserved;

	private bool macroNavigating = true;

	private int macroDocument;

	private int macroKeyDocument;

	private bool macroF2Held;

	private readonly WebView2 browser = new WebView2();

	private readonly Label layoutGrip = new Label();

	private readonly CoverImagePanel loader = new CoverImagePanel();

	private readonly Button mouseReleaseTarget = new Button();

	private readonly SessionCountdownOverlay sessionCountdown;

	private readonly SessionVolume sessionVolume;

	private bool loadingStarted;

	private bool embeddedInMosaic;

	private bool customLayoutEnabled;

	private bool releaseQueued;

	private Keys releaseKeyHeld;

	private SessionSoundAlerts soundAlerts;

	private SessionVisualAlerts visualAlerts;

	private bool textDetectionEnabled = true;

	private bool soundDetectionEnabled;

	private DateTime recoveryEligibleAfter;

	private bool welcomeRecoveryRequested;

	internal Func<bool> GlobalMacroShortcutActive;

	private readonly XboxRecoveryPolicy xboxRecovery = new XboxRecoveryPolicy();

	private readonly Stopwatch xboxRecoveryClock = Stopwatch.StartNew();

	private System.Windows.Forms.Timer xboxRecoveryTimer;

	private bool xboxRecoveryPolling;

	private bool xboxRecoveryNavigationFailed;

	private int xboxRecoveryRevision = -1;

	private string xboxRecoveryStatus;

	private static readonly string XboxEndedProbe = ReadXboxEndedProbe();

	internal BroadcastEndpoint ManualEndpoint;

	private bool recordedKeyboardActive;

	private readonly KeyboardPacket keyboardPacket = new KeyboardPacket();

	private bool inputCloseReady;

	private bool inputCloseWaiting;

	private string pageCursorStamp;

	private const string PrepareHoldFocus = "(() => {\n            const a=document.activeElement;\n            if(a && (a.isContentEditable || ['INPUT','TEXTAREA','SELECT'].includes(a.tagName))) return false;\n            if(!window.__kanblazHoldFocusV1) {\n                const video=document.querySelector('video');\n                const target=video && (video.closest('[tabindex]') || video.parentElement);\n                window.__kanblazHoldFocusV1={previous:a,target:target,tab:target && target.getAttribute('tabindex')};\n                if(target) { if(!target.hasAttribute('tabindex')) target.setAttribute('tabindex','-1'); target.focus({preventScroll:true}); }\n            }\n            return true;\n        })()";

	private const string RestoreHoldFocus = "(() => {\n            const saved=window.__kanblazHoldFocusV1; if(!saved) return;\n            delete window.__kanblazHoldFocusV1;\n            if(saved.target && saved.tab===null) saved.target.removeAttribute('tabindex');\n            if(document.activeElement===saved.target && saved.previous && saved.previous.isConnected) saved.previous.focus({preventScroll:true});\n        })()";

	internal Guid ProfileKey => profile.StorageKey;

	internal string GameContext => profile.LaunchContext;

	internal bool ControllerOwned => controllerOwned;

	internal bool HasNativeKeyboardFocus
	{
		get
		{
			if (!IsDisposed && !browser.IsDisposed && browser.IsHandleCreated)
			{
				return NativeInputOwnership.OwnsKeyboard(browser.Handle);
			}
			return false;
		}
	}

	internal bool MovementMacroRunning => movementMacro.IsRunning;

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			if (customLayoutEnabled)
			{
				createParams.Style |= 262144;
			}
			else
			{
				createParams.Style &= -262145;
			}
			return createParams;
		}
	}

	internal bool ReleasedMouseShortcutFocused
	{
		get
		{
			if (!IsDisposed && mouseReleaseTarget.IsHandleCreated)
			{
				return NativeInputOwnership.OwnsKeyboard(mouseReleaseTarget.Handle);
			}
			return false;
		}
	}

	internal bool BroadcastReady
	{
		get
		{
			if (!IsDisposed && !Disposing && !browser.IsDisposed && browser.CoreWebView2 != null && !macroNavigating && macroGameplayObserved)
			{
				return LaptopMouseShortcut.IsGameAddress(browser.CoreWebView2.Source);
			}
			return false;
		}
	}

	internal event Action<Guid, Guid> LayoutSwapRequested;

	internal event Action<string> SoundStatusChanged;

	internal event Action<string> SessionStatusChanged;

	internal event Action<string> WorkspaceStateChanged;

	internal event Action WelcomeRecoveryRequested;

	internal event Action MacroToggleRequested;

	internal void SetLayoutEditing(bool enabled)
	{
		layoutGrip.Visible = enabled;
		layoutGrip.BringToFront();
		Padding = (enabled ? new Padding(0, 32, 0, 0) : Padding.Empty);
		layoutGrip.SetBounds(0, 0, ClientSize.Width, 32);
	}

	private void ReportWorkspaceState(string value)
	{
		Action<string> action = WorkspaceStateChanged;
		if (!IsDisposed)
		{
			action?.Invoke(value);
		}
	}

	internal CloudSessionForm(Profile profile, Icon appIcon, bool backgroundAudioEnabled, bool soundDetectionEnabled = true, SessionCountdownState countdownState = null, bool controllerShared = false)
	{
		CloudSessionForm cloudSessionForm = this;
		this.profile = profile;
		this.backgroundAudioEnabled = backgroundAudioEnabled;
		this.controllerShared = controllerShared;
		macroJoystick = new VirtualJoystickOutput(SendJoystickStateAsync);
		movementMacro = new MovementMacro(MacroEligibleAsync, SendMacroKeyAsync, (string value) =>
		{
			Action<string> action = cloudSessionForm.SessionStatusChanged;
			if (!cloudSessionForm.IsDisposed)
			{
				action?.Invoke(profile.Label + ": " + value);
			}
		}, null, macroJoystick.ResetAsync);
		this.soundDetectionEnabled = soundDetectionEnabled;
		Text = "KANBLAZ CLOUD · " + profile.Label;
		Icon = appIcon;
		FormBorderStyle = FormBorderStyle.None;
		StartPosition = FormStartPosition.Manual;
		MinimumSize = new Size(320, 180);
		BackColor = Color.Black;
		KeyPreview = true;
		ShowInTaskbar = false;
		browser.Dock = DockStyle.Fill;
		browser.Visible = false;
		browser.KeyDown += ReleaseWindowCaptureOnF9;
		browser.KeyDown += MacroShortcutDown;
		browser.KeyUp += (object sender, KeyEventArgs args) =>
		{
			if (args.KeyCode == cloudSessionForm.releaseKeyHeld)
			{
				cloudSessionForm.releaseKeyHeld = Keys.None;
				args.Handled = true;
			}
			if (args.KeyCode == Keys.F2)
			{
				cloudSessionForm.macroF2Held = false;
				if (args.Modifiers == Keys.None)
				{
					args.Handled = true;
				}
			}
		};
		browser.LostFocus += delegate
		{
			cloudSessionForm.macroF2Held = false;
		};
		browser.MouseDoubleClick += RestoreGameFocusOnDoubleClick;
		Application.AddMessageFilter(this);
		Controls.Add(browser);
		BuildLoader();
		Controls.Add(loader);
		mouseReleaseTarget.Size = new Size(1, 1);
		mouseReleaseTarget.Location = new Point(-2, -2);
		mouseReleaseTarget.Text = string.Empty;
		mouseReleaseTarget.TabStop = true;
		Controls.Add(mouseReleaseTarget);
		layoutGrip.Text = "☰  " + profile.Label + "  ·  Drag to swap";
		layoutGrip.TextAlign = ContentAlignment.MiddleLeft;
		layoutGrip.BackColor = Color.FromArgb(30, 65, 90);
		layoutGrip.ForeColor = Color.White;
		layoutGrip.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
		layoutGrip.AllowDrop = true;
		layoutGrip.Cursor = Cursors.SizeAll;
		layoutGrip.Visible = false;
		Point dragStart = Point.Empty;
		layoutGrip.MouseDown += (object s, MouseEventArgs e) =>
		{
			if (e.Button == MouseButtons.Left)
			{
				dragStart = e.Location;
			}
		};
		layoutGrip.MouseMove += (object s, MouseEventArgs e) =>
		{
			if (e.Button == MouseButtons.Left && (Math.Abs(e.X - dragStart.X) > SystemInformation.DragSize.Width || Math.Abs(e.Y - dragStart.Y) > SystemInformation.DragSize.Height))
			{
				cloudSessionForm.layoutGrip.DoDragDrop(new DataObject("KanblazSession", cloudSessionForm.ProfileKey.ToString()), DragDropEffects.Move);
			}
		};
		layoutGrip.DragEnter += (object s, DragEventArgs e) =>
		{
			if (e.Data.GetDataPresent("KanblazSession"))
			{
				e.Effect = DragDropEffects.Move;
				cloudSessionForm.layoutGrip.BackColor = Color.FromArgb(0, 150, 190);
			}
		};
		layoutGrip.DragLeave += delegate
		{
			cloudSessionForm.layoutGrip.BackColor = Color.FromArgb(30, 65, 90);
		};
		layoutGrip.DragDrop += (object s, DragEventArgs e) =>
		{
			cloudSessionForm.layoutGrip.BackColor = Color.FromArgb(30, 65, 90);
			if (Guid.TryParse(Convert.ToString(e.Data.GetData("KanblazSession")), out var result) && cloudSessionForm.LayoutSwapRequested != null)
			{
				cloudSessionForm.LayoutSwapRequested(result, cloudSessionForm.ProfileKey);
			}
		};
		Controls.Add(layoutGrip);
		soundAlerts = new SessionSoundAlerts(this, (string value) =>
		{
			cloudSessionForm.SoundStatusChanged?.Invoke(profile.Label + ": " + value);
		}, profile.Label);
		string detectionSession = Guid.NewGuid().ToString("N");
		visualAlerts = new SessionVisualAlerts(browser, LaptopMouseShortcut.IsGameAddress, (BrainrotDetection notice) =>
		{
			if (cloudSessionForm.soundAlerts == null || cloudSessionForm.IsDisposed)
			{
				return;
			}
			string text = "ui=shown; audio=not-requested";
			NotificationChange notificationChange = cloudSessionForm.soundAlerts.ShowVisualAlert(notice);
			text = "ui=" + notificationChange.ToString() + "; audio=coordinator-policy";
			OcrTrace.Outcome(profile.Label, notice.EventId, notificationChange.ToString());
			try
			{
				BrainrotEventLog.Write(profile.Label, notice, text + "; profileId=" + cloudSessionForm.ProfileKey.ToString() + "; session=" + detectionSession + "; window=" + cloudSessionForm.Handle.ToInt64().ToString("X"));
			}
			catch
			{
				cloudSessionForm.SoundStatusChanged?.Invoke(profile.Label + ": Detection event could not be saved.");
			}
		}, (string value) =>
		{
			Action<string> action = cloudSessionForm.SoundStatusChanged;
			action?.Invoke(profile.Label + ": " + value);
			try
			{
				BrainrotEventLog.Write(profile.Label, new BrainrotDetection(), value);
			}
			catch
			{
				action?.Invoke(profile.Label + ": Detection diagnostics could not be saved.");
			}
		}, profile.Label);
		sessionCountdown = new SessionCountdownOverlay(this, countdownState ?? new SessionCountdownState(null, SessionClockStore.ForProfile(profile.StorageKey, profile.Service.Id)));
		sessionVolume = new SessionVolume(profile.StorageKey);
		sessionCountdown.SetVolume(sessionVolume);
		sessionCountdown.PersistenceWarning += (string value) =>
		{
			cloudSessionForm.SessionStatusChanged?.Invoke(profile.Label + ": " + value);
		};
	}

	internal async Task<bool> SetControllerSharedAsync(bool shared)
	{
		controllerShared = shared;
		controllerOwned = false;
		if (IsDisposed || browser.IsDisposed || controllerRouting == null)
		{
			return true;
		}
		try
		{
			await controllerRouting.SetSharedAsync(shared);
			return true;
		}
		catch (Exception)
		{
			if (IsDisposed || browser.IsDisposed)
			{
				return true;
			}
			SessionStatusChanged?.Invoke(profile.Label + ": controller mode could not update. Change the mode again to retry.");
			return false;
		}
	}

	internal async Task SetControllerBroadcastAsync(bool selected, string pads)
	{
		if (IsDisposed || browser.IsDisposed || controllerRouting == null)
		{
			return;
		}
		controllerOwned = false;
		try
		{
			await controllerRouting.SetBroadcastFrameAsync(selected, pads);
		}
		catch
		{
		}
	}

	internal async Task<bool> SetControllerOwnerAsync(bool owned)
	{
		if (IsDisposed || browser.IsDisposed || controllerRouting == null)
		{
			return true;
		}
		try
		{
			await controllerRouting.SetOwnedAsync(owned);
			controllerOwned = owned;
			return true;
		}
		catch
		{
			return false;
		}
	}

	internal bool StartMovementMacro()
	{
		if (IsDisposed || browser.IsDisposed || browser.CoreWebView2 == null || macroNavigating || !LaptopMouseShortcut.IsGameAddress(browser.CoreWebView2.Source))
		{
			return false;
		}
		movementMacro.Start();
		return movementMacro.IsRunning;
	}

	internal async Task<bool> StopMovementMacroAsync()
	{
		await movementMacro.StopAsync();
		return !movementMacro.LastReleaseFailed;
	}

	private async Task<bool> MacroEligibleAsync()
	{
		if (IsDisposed || browser.IsDisposed || browser.CoreWebView2 == null || macroNavigating || !LaptopMouseShortcut.IsGameAddress(browser.CoreWebView2.Source))
		{
			return false;
		}
		int document = macroDocument;
		return await browser.CoreWebView2.ExecuteScriptAsync("(() => {\n            const host = location.hostname;\n            if (location.protocol !== 'https:' || !(\n                ((host === 'www.xbox.com' || host === 'xbox.com') && /^\\/(?:[a-z]{2}-[a-z]{2}\\/)?play(?:\\/|$)/i.test(location.pathname)) ||\n                host === 'play.xbox.com' || host === 'play.geforcenow.com' ||\n                (host === 'luna.amazon.com' && !/^\\/(?:ap|signin|login|auth)(?:\\/|$)/i.test(location.pathname)))) return false;\n            let target = document.activeElement;\n            while (target && target.shadowRoot && target.shadowRoot.activeElement) target = target.shadowRoot.activeElement;\n            if (target && (target.isContentEditable || ['INPUT','TEXTAREA','SELECT','IFRAME'].includes(target.tagName) ||\n                (target.closest && target.closest('form')) ||\n                ['textbox','searchbox','combobox'].includes(target.getAttribute('role')))) return false;\n            if (document.querySelector('dialog[open],[role=dialog][aria-modal=true]')) return false;\n            const live = Array.from(document.querySelectorAll('video')).some(video => {\n                const stream = video.srcObject, rect = video.getBoundingClientRect();\n                return !!stream && stream.active && typeof stream.getVideoTracks === 'function' &&\n                    stream.getVideoTracks().some(track => track.readyState === 'live') &&\n                    !video.paused && !video.ended && video.readyState >= 2 && video.videoWidth >= 160 && video.videoHeight >= 90 &&\n                    video.isConnected && rect.width >= 160 && rect.height >= 90 && rect.bottom > 0 && rect.right > 0 &&\n                    rect.top < innerHeight && rect.left < innerWidth &&\n                    (!video.checkVisibility || video.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}));\n            });\n            // A Play button may retain DOM focus in a background tile. Only\n            // blur stale non-form buttons/links after live playback is present;\n            // do not activate/click them or steal native desktop keyboard focus.\n            if (live && target && ['BUTTON','A'].includes(target.tagName) && typeof target.blur === 'function') target.blur();\n            return live;\n        })()") == "true" && document == macroDocument && !macroNavigating && macroGameplayObserved;
	}

	private Task SendJoystickStateAsync(bool active, double x, double y)
	{
		if (IsDisposed || browser.IsDisposed || browser.CoreWebView2 == null || controllerRouting == null || !LaptopMouseShortcut.IsGameAddress(browser.CoreWebView2.Source))
		{
			if (active && (x != 0.0 || y != 0.0))
			{
				throw new InvalidOperationException("No eligible game document.");
			}
			return Task.FromResult(0);
		}
		return controllerRouting.SetJoystickAsync(active, x, y);
	}

	private Task SendMacroKeyAsync(char key, bool down)
	{
		if (IsDisposed || browser.IsDisposed || browser.CoreWebView2 == null || !LaptopMouseShortcut.IsGameAddress(browser.CoreWebView2.Source))
		{
			if (down)
			{
				throw new InvalidOperationException("No eligible game document.");
			}
			return Task.FromResult(0);
		}
		if (down)
		{
			if (macroNavigating || !macroGameplayObserved)
			{
				throw new InvalidOperationException("Game document changed.");
			}
			macroKeyDocument = macroDocument;
		}
		else if (macroDocument != macroKeyDocument)
		{
			return Task.FromResult(0);
		}
		return macroJoystick.SetKeyAsync(key, down);
	}

	internal void SetSoundAlertsEnabled(bool enabled)
	{
		soundDetectionEnabled = enabled;
		RefreshSoundDetection();
	}

	internal void SetTextAlertsEnabled(bool enabled)
	{
		textDetectionEnabled = enabled;
		RefreshTextDetection();
		if (!enabled && soundAlerts != null)
		{
			soundAlerts.ClearVisualAlert();
		}
	}

	private void RefreshTextDetection()
	{
		if (visualAlerts != null && !IsDisposed)
		{
			if (textDetectionEnabled && !browser.IsDisposed && browser.CoreWebView2 != null && LaptopMouseShortcut.IsGameAddress(browser.CoreWebView2.Source))
			{
				visualAlerts.Start();
			}
			else
			{
				visualAlerts.Stop();
			}
		}
	}

	private void RefreshSoundDetection()
	{
		if (!IsDisposed && soundAlerts != null && !browser.IsDisposed && browser.CoreWebView2 != null)
		{
			if (!soundDetectionEnabled || !LaptopMouseShortcut.IsGameAddress(browser.CoreWebView2.Source))
			{
				soundAlerts.Stop(clearVisual: false);
			}
			else
			{
				soundAlerts.Start(browser.CoreWebView2.BrowserProcessId);
			}
		}
	}

	internal void PrepareForMosaic(bool customLayout)
	{
		customLayoutEnabled = customLayout;
		if (!embeddedInMosaic)
		{
			embeddedInMosaic = true;
			TopLevel = false;
		}
		MinimumSize = Size.Empty;
		Dock = DockStyle.None;
		Margin = Padding.Empty;
	}

	protected override void OnHandleCreated(EventArgs args)
	{
		base.OnHandleCreated(args);
		NativeWindowAppearance.HideResizeBorder(Handle);
	}

	protected override void WndProc(ref Message message)
	{
		base.WndProc(ref message);
		if ((!embeddedInMosaic || customLayoutEnabled) && message.Msg == 132 && message.Result.ToInt32() == 1 && WindowState != FormWindowState.Maximized)
		{
			Point point = PointToClient(Control.MousePosition);
			bool flag = point.X <= 8;
			bool flag2 = point.X >= ClientSize.Width - 8;
			bool flag3 = point.Y <= 8;
			bool flag4 = point.Y >= ClientSize.Height - 8;
			if (flag3 & flag)
			{
				message.Result = (IntPtr)13;
			}
			else if (flag3 & flag2)
			{
				message.Result = (IntPtr)14;
			}
			else if (flag4 & flag)
			{
				message.Result = (IntPtr)16;
			}
			else if (flag4 & flag2)
			{
				message.Result = (IntPtr)17;
			}
			else if (flag)
			{
				message.Result = (IntPtr)10;
			}
			else if (flag2)
			{
				message.Result = (IntPtr)11;
			}
			else if (flag3)
			{
				message.Result = (IntPtr)2;
			}
			else if (flag4)
			{
				message.Result = (IntPtr)15;
			}
		}
	}

	private void BuildLoader()
	{
		loader.Dock = DockStyle.Fill;
		loader.BackColor = Color.Black;
		string file = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "kanblaz-loading.png");
		loader.LoadCover(file);
	}

	internal async Task CloseForProfileRemovalAsync()
	{
		await movementMacro.StopAsync();
		if (IsDisposed)
		{
			return;
		}
		CoreWebView2 coreWebView = (browser.IsDisposed ? null : browser.CoreWebView2);
		if (coreWebView == null)
		{
			Close();
			return;
		}
		CoreWebView2Environment environment = coreWebView.Environment;
		uint processId = coreWebView.BrowserProcessId;
		TaskCompletionSource<bool> exited = new TaskCompletionSource<bool>();
		EventHandler<CoreWebView2BrowserProcessExitedEventArgs> handler = (object sender, CoreWebView2BrowserProcessExitedEventArgs args) =>
		{
			if (args.BrowserProcessId == processId)
			{
				exited.TrySetResult(result: true);
			}
		};
		environment.BrowserProcessExited += handler;
		try
		{
			Close();
			await Task.WhenAny(exited.Task, Task.Delay(4000));
		}
		finally
		{
			environment.BrowserProcessExited -= handler;
		}
	}

	internal async void BeginLoading()
	{
		if (loadingStarted)
		{
			return;
		}
		loadingStarted = true;
		sessionCountdown.StartWatching();
		try
		{
			Directory.CreateDirectory(ShellStorage.BrowserDataFolder(profile));
			CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, ShellStorage.BrowserDataFolder(profile));
			if (IsDisposed || browser.IsDisposed)
			{
				return;
			}
			await browser.EnsureCoreWebView2Async(environment);
			if (IsDisposed || browser.IsDisposed)
			{
				return;
			}
			sessionVolume.Start(browser.CoreWebView2.BrowserProcessId);
			controllerRouting = new ControllerBrowserBridge(browser.CoreWebView2, backgroundAudioEnabled);
			await controllerRouting.SetSharedAsync(controllerShared);
			if (IsDisposed || browser.IsDisposed)
			{
				return;
			}
			browser.CoreWebView2.WebMessageReceived += ObserveSessionLifecycle;
			if (profile.ServiceId == CloudService.Xbox.Id)
			{
				browser.CoreWebView2.WebMessageReceived += ObserveWelcomeRecovery;
				browser.CoreWebView2.FrameCreated += (object sender, CoreWebView2FrameCreatedEventArgs args) =>
				{
					args.Frame.WebMessageReceived += ObserveWelcomeRecovery;
				};
				await WelcomeRecovery.InstallAsync(browser.CoreWebView2);
				if (IsDisposed || browser.IsDisposed)
				{
					return;
				}
			}
			await SessionLifecycle.InstallAsync(browser.CoreWebView2);
			StartXboxSessionRecovery();
			if (IsDisposed || browser.IsDisposed)
			{
				return;
			}
			browser.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
			browser.CoreWebView2.Settings.AreDevToolsEnabled = false;
			browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
			browser.CoreWebView2.Settings.IsZoomControlEnabled = false;
			browser.CoreWebView2.NavigationStarting += async delegate
			{
				recoveryEligibleAfter = DateTime.UtcNow.AddSeconds(5.0);
				welcomeRecoveryRequested = false;
				ReportWorkspaceState("Launching");
				macroNavigating = true;
				macroGameplayObserved = false;
				if (ManualEndpoint != null)
				{
					ManualEndpoint.Release();
				}
				await movementMacro.StopAsync();
				macroDocument++;
				if (soundAlerts != null)
				{
					soundAlerts.Stop();
				}
				if (visualAlerts != null)
				{
					visualAlerts.Stop();
				}
			};
			browser.CoreWebView2.NavigationCompleted += async (object sender, CoreWebView2NavigationCompletedEventArgs args) =>
			{
				ReportWorkspaceState(args.IsSuccess ? "Active" : "Failed");
				macroNavigating = !args.IsSuccess;
				await ApplyPageCursorAsync();
				await SetControllerSharedAsync(controllerShared);
				RefreshSoundDetection();
				RefreshTextDetection();
			};
			browser.CoreWebView2.ProcessFailed += async delegate
			{
				ReportWorkspaceState("Failed");
				macroNavigating = true;
				macroGameplayObserved = false;
				macroDocument++;
				if (ManualEndpoint != null)
				{
					ManualEndpoint.Release();
				}
				await movementMacro.StopAsync();
				if (soundAlerts != null)
				{
					soundAlerts.Stop();
				}
				if (visualAlerts != null)
				{
					visualAlerts.Stop();
				}
				SoundStatusChanged?.Invoke(profile.Label + ": detector stopped because the browser closed or restarted.");
			};
			await Task.Delay(3000);
			if (!IsDisposed)
			{
				browser.Visible = true;
				loader.Visible = false;
				browser.CoreWebView2.Navigate(profile.LaunchUrl);
			}
		}
		catch (Exception ex)
		{
			if (!IsDisposed)
			{
				ReportWorkspaceState("Failed");
				ShowError(ex.Message);
			}
		}
	}

	private void ObserveSessionLifecycle(object sender, CoreWebView2WebMessageReceivedEventArgs args)
	{
		if (!IsDisposed && !browser.IsDisposed && browser.CoreWebView2 != null && SessionLifecycle.TrySignal(args.Source, browser.CoreWebView2.Source, args.WebMessageAsJson, out var signal))
		{
			switch (signal)
			{
			case "playing":
			case "next-playing":
				macroGameplayObserved = true;
				break;
			case "ended":
			case "idle":
			case "quit":
			case "launch":
				macroGameplayObserved = false;
				break;
			}
			if (signal == "ended" || signal == "quit")
			{
				movementMacro.StopAsync();
			}
			sessionCountdown.Observe(signal);
		}
	}

	private void ReleaseWindowCaptureOnF9(object sender, KeyEventArgs args)
	{
		if (InputPreferences.Current.IsRelease(args.KeyCode) && args.Modifiers == Keys.None)
		{
			args.Handled = true;
			args.SuppressKeyPress = true;
			QueueKeyboardMouseRelease(args.KeyCode);
		}
	}

	private void MacroShortcutDown(object sender, KeyEventArgs args)
	{
		if (args.KeyCode == Keys.F2 && args.Modifiers == Keys.None)
		{
			args.Handled = true;
			if ((GlobalMacroShortcutActive == null || !GlobalMacroShortcutActive()) && !macroF2Held)
			{
				macroF2Held = true;
				MacroToggleRequested?.Invoke();
			}
		}
	}

	private void ReleaseMouseFromLaptopQ(object sender, CoreWebView2WebMessageReceivedEventArgs args)
	{
		if (LaptopDevice.IsLaptop && !IsDisposed && LaptopMouseShortcut.IsGameAddress(args.Source) && (ContainsFocus || NativeMouseCapture.IsFocusWithin(Handle)) && args.WebMessageAsJson == "\"kanblaz.release-mouse.q.v1\"")
		{
			ReleaseWindowMouseCapture();
		}
	}

	public bool PreFilterMessage(ref Message message)
	{
		Keys keys = (Keys)((long)message.WParam & 0xFFFF);
		if ((message.Msg == 257 || message.Msg == 261) && keys == releaseKeyHeld)
		{
			releaseKeyHeld = Keys.None;
			return true;
		}
		if ((message.Msg != 256 && message.Msg != 260) || (!ContainsFocus && !NativeMouseCapture.IsFocusWithin(Handle)))
		{
			return false;
		}
		if (!InputPreferences.Current.IsRelease(keys) || Control.ModifierKeys != Keys.None)
		{
			return false;
		}
		if ((message.LParam.ToInt64() & 0x40000000) == 0L)
		{
			QueueKeyboardMouseRelease(keys);
		}
		return true;
	}

	private void QueueKeyboardMouseRelease(Keys key, bool physicalLetter = false)
	{
		if (releaseKeyHeld == key)
		{
			return;
		}
		releaseKeyHeld = key;
		if (releaseQueued)
		{
			return;
		}
		releaseQueued = true;
		BeginInvoke((Action)(() =>
		{
			releaseQueued = false;
			if (!IsDisposed)
			{
				if (physicalLetter)
				{
					if (!NativeInputOwnership.OwnsKeyboard(Handle))
					{
						return;
					}
					NativeInputOwnership.FocusReleaseTarget(mouseReleaseTarget.Handle);
				}
				ReleaseWindowMouseCapture();
				if (physicalLetter)
				{
					ReleaseBackgroundPointerLock();
				}
			}
		}));
	}

	internal void ObserveReleaseKeyUp(Keys key)
	{
		if (releaseKeyHeld == key)
		{
			releaseKeyHeld = Keys.None;
		}
	}

	internal void QueuePhysicalMouseRelease(Keys key)
	{
		QueueKeyboardMouseRelease(key, physicalLetter: true);
	}

	internal void ReleaseWindowMouseCapture()
	{
		Capture = false;
		browser.Capture = false;
		NativeMouseCapture.ReleaseCapture();
		NativeMouseCapture.ClipCursor(IntPtr.Zero);
		mouseReleaseTarget.Focus();
	}

	private void ObserveWelcomeRecovery(object sender, CoreWebView2WebMessageReceivedEventArgs args)
	{
		if (IsDisposed || browser.IsDisposed || browser.CoreWebView2 == null || macroGameplayObserved || welcomeRecoveryRequested || DateTime.UtcNow < recoveryEligibleAfter || !WelcomeRecovery.IsSignal(args.Source, args.WebMessageAsJson) || (sender == browser.CoreWebView2 && args.Source != browser.CoreWebView2.Source))
		{
			return;
		}
		welcomeRecoveryRequested = true;
		int recoveryDocument = macroDocument;
		BeginInvoke((Action)(() =>
		{
			if (!IsDisposed && !macroGameplayObserved && macroDocument == recoveryDocument)
			{
				WelcomeRecoveryRequested?.Invoke();
			}
		}));
	}

	internal bool CanTouchpadClick(Point cursor)
	{
		if (!IsDisposed && !browser.IsDisposed && browser.Visible && browser.IsHandleCreated && browser.CoreWebView2 != null)
		{
			return browser.RectangleToScreen(browser.ClientRectangle).Contains(cursor);
		}
		return false;
	}

	internal void TouchpadClick(Point cursor)
	{
		if (CanTouchpadClick(cursor))
		{
			browser.Focus();
			TouchpadMouseClick.ClickBrowser(browser.Handle, cursor);
		}
	}

	private void RestoreGameFocusOnDoubleClick(object sender, MouseEventArgs args)
	{
		if (args.Button == MouseButtons.Left)
		{
			Activate();
			browser.Focus();
		}
	}

	internal void FocusFromNotification()
	{
		if (!IsDisposed && !browser.IsDisposed && Visible)
		{
			Select();
			browser.Focus();
		}
	}

	private void ShowError(string message)
	{
		foreach (Control control in loader.Controls)
		{
			control.Dispose();
		}
		loader.Controls.Clear();
		loader.Controls.Add(new Label
		{
			Dock = DockStyle.Fill,
			Padding = new Padding(34),
			ForeColor = Color.White,
			Font = new Font("Segoe UI", 11f),
			Text = "WebView2 could not start. Make sure Microsoft Edge WebView2 Runtime is installed.\n\n" + message
		});
	}

	protected override void OnFormClosed(FormClosedEventArgs e)
	{
		if (ContainsFocus || NativeMouseCapture.IsFocusWithin(Handle))
		{
			NativeMouseCapture.ReleaseCapture();
			NativeMouseCapture.ClipCursor(IntPtr.Zero);
			CursorAid.Recover();
		}
		movementMacro.StopAsync();
		Application.RemoveMessageFilter(this);
		sessionCountdown.Dispose();
		if (visualAlerts != null)
		{
			visualAlerts.Dispose();
			visualAlerts = null;
		}
		if (soundAlerts != null)
		{
			soundAlerts.Dispose();
			soundAlerts = null;
		}
		if (browser.CoreWebView2 != null)
		{
			browser.Dispose();
		}
		base.OnFormClosed(e);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && movementMacro != null)
		{
			movementMacro.StopAsync();
		}
		if (disposing && controllerRouting != null)
		{
			controllerRouting.Dispose();
			controllerRouting = null;
		}
		if (disposing && sessionCountdown != null)
		{
			sessionCountdown.Dispose();
		}
		if (disposing && visualAlerts != null)
		{
			visualAlerts.Dispose();
			visualAlerts = null;
		}
		base.Dispose(disposing);
	}

	private static string ReadXboxEndedProbe()
	{
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Kanblaz.XboxEndedProbe.js");
		using StreamReader streamReader = new StreamReader(stream);
		return streamReader.ReadToEnd();
	}

	private void StartXboxSessionRecovery()
	{
		if (!(profile.ServiceId != CloudService.Xbox.Id) && xboxRecoveryTimer == null)
		{
			browser.CoreWebView2.NavigationStarting += (object s, CoreWebView2NavigationStartingEventArgs e) =>
			{
				xboxRecoveryNavigationFailed = false;
				xboxRecovery.InvalidateEvidence();
			};
			browser.CoreWebView2.NavigationCompleted += (object s, CoreWebView2NavigationCompletedEventArgs e) =>
			{
				xboxRecoveryNavigationFailed = !e.IsSuccess;
			};
			xboxRecoveryTimer = new System.Windows.Forms.Timer
			{
				Interval = 1000
			};
			xboxRecoveryTimer.Tick += (object s, EventArgs e) =>
			{
				PollXboxSessionRecovery();
			};
			xboxRecoveryTimer.Start();
			Disposed += delegate
			{
				xboxRecoveryTimer.Stop();
				xboxRecoveryTimer.Dispose();
			};
		}
	}

	private async void PollXboxSessionRecovery()
	{
		if (xboxRecoveryPolling || IsDisposed || browser.IsDisposed)
		{
			return;
		}
		if (xboxRecoveryRevision != XboxRecoveryPreferences.Current.Revision)
		{
			xboxRecovery.Suspend();
			xboxRecoveryRevision = XboxRecoveryPreferences.Current.Revision;
		}
		if (!XboxRecoveryPreferences.Current.Enabled)
		{
			xboxRecovery.Suspend();
			return;
		}
		xboxRecoveryPolling = true;
		int document = macroDocument;
		try
		{
			CoreWebView2 core = browser.CoreWebView2;
			if (core == null)
			{
				return;
			}
			if (!XboxRecoveryPolicy.IsFortniteXbox(core.Source))
			{
				xboxRecovery.Suspend();
				return;
			}
			string screen = (xboxRecoveryNavigationFailed ? "failed" : "unknown");
			if (!macroNavigating)
			{
				switch (await core.ExecuteScriptAsync(XboxEndedProbe))
				{
				case "\"playing\"":
					screen = "playing";
					break;
				case "\"ended\"":
					screen = "ended";
					break;
				case "\"loading\"":
					screen = "loading";
					break;
				case "\"play\"":
					screen = "play";
					break;
				}
			}
			if (!IsDisposed && !browser.IsDisposed && document == macroDocument && xboxRecoveryRevision == XboxRecoveryPreferences.Current.Revision && XboxRecoveryPreferences.Current.Enabled && XboxRecoveryPolicy.IsFortniteXbox(core.Source))
			{
				if (screen != "ended" && macroGameplayObserved)
				{
					screen = "playing";
				}
				bool flag = xboxRecovery.Observe(screen, xboxRecoveryClock.Elapsed.TotalSeconds, enabled: true);
				if (xboxRecovery.Status != xboxRecoveryStatus)
				{
					xboxRecoveryStatus = xboxRecovery.Status;
					SessionStatusChanged?.Invoke(profile.Label + ": " + xboxRecoveryStatus);
				}
				if (flag)
				{
					sessionCountdown.Observe("ended");
					core.Reload();
				}
			}
		}
		catch (Exception ex) when (ex is InvalidOperationException || ex is COMException)
		{
			xboxRecovery.InvalidateEvidence();
			if (xboxRecoveryStatus != "Xbox recovery could not inspect/reload this window.")
			{
				xboxRecoveryStatus = "Xbox recovery could not inspect/reload this window.";
				SessionStatusChanged?.Invoke(profile.Label + ": Xbox recovery could not inspect/reload this window.");
			}
		}
		finally
		{
			xboxRecoveryPolling = false;
		}
	}

	internal Task<bool> ControllerModeKeyEligibleAsync()
	{
		return MacroEligibleAsync();
	}

	internal async Task PlaySquareAsync(CancellationToken cancel)
	{
		if (!(await MacroEligibleAsync()))
		{
			throw new InvalidOperationException("Session not ready for gameplay.");
		}
		int document = macroDocument;
		try
		{
			while (true)
			{
				cancel.ThrowIfCancellationRequested();
				if (!BroadcastReady || document != macroDocument)
				{
					break;
				}
				await controllerRouting.SetSquareAsync(active: true);
				await Task.Delay(200, cancel);
			}
			throw new InvalidOperationException("Game session changed.");
		}
		finally
		{
			if (controllerRouting != null)
			{
				await controllerRouting.SetSquareAsync(active: false);
			}
		}
	}

	internal async Task BeginRecordedKeyboardAsync()
	{
		if (recordedKeyboardActive)
		{
			throw new InvalidOperationException("Macro already running in this session.");
		}
		if (!(await MacroEligibleAsync()))
		{
			throw new InvalidOperationException("Session is not ready for gameplay input.");
		}
		recordedKeyboardActive = true;
		keyboardPacket.Clear();
	}

	internal async Task EndRecordedKeyboardAsync()
	{
		recordedKeyboardActive = false;
		keyboardPacket.Clear();
		if (!IsDisposed && !browser.IsDisposed && browser.CoreWebView2 != null)
		{
			try
			{
				await browser.CoreWebView2.CallDevToolsProtocolMethodAsync("Emulation.setFocusEmulationEnabled", "{\"enabled\":false}");
			}
			finally
			{
				await browser.CoreWebView2.ExecuteScriptAsync("(() => {\n            const saved=window.__kanblazHoldFocusV1; if(!saved) return;\n            delete window.__kanblazHoldFocusV1;\n            if(saved.target && saved.tab===null) saved.target.removeAttribute('tabindex');\n            if(document.activeElement===saved.target && saved.previous && saved.previous.isConnected) saved.previous.focus({preventScroll:true});\n        })()");
			}
		}
	}

	internal async void RefreshPageCursor()
	{
		await ApplyPageCursorAsync();
	}

	internal async Task ApplyPageCursorAsync()
	{
		if (IsDisposed || browser.IsDisposed || browser.CoreWebView2 == null)
		{
			return;
		}
		string stamp = CursorAid.Stamp + ":" + macroDocument;
		if (pageCursorStamp == stamp)
		{
			return;
		}
		string text = CursorAid.CssCursor();
		string javaScript = "(() => {\n                const value='" + text + "';\n                const old=window.__kanblazCursorV2;\n                if(old)old.stop();\n                if(!value){delete window.__kanblazCursorV2;return;}\n                let element=null,previous='',priority='';\n                const restore=()=>{if(element){if(previous)element.style.setProperty('cursor',previous,priority);else element.style.removeProperty('cursor');element=null;}};\n                const set=target=>{if(!(target instanceof Element)||target===element)return;restore();element=target;previous=element.style.getPropertyValue('cursor');priority=element.style.getPropertyPriority('cursor');element.style.setProperty('cursor',value,'important');};\n                const hover=()=>{const targets=document.querySelectorAll(':hover');set(targets[targets.length-1]||document.documentElement);};\n                const move=e=>{if(!document.pointerLockElement)set(e.target);};\n                const lock=()=>{if(document.pointerLockElement)restore();else hover();};\n                document.addEventListener('pointerover',move,true);\n                document.addEventListener('pointerlockchange',lock,true);\n                lock();\n                window.__kanblazCursorV2={stop:()=>{restore();document.removeEventListener('pointerover',move,true);document.removeEventListener('pointerlockchange',lock,true);}};\n            })()";
		try
		{
			await browser.CoreWebView2.ExecuteScriptAsync(javaScript);
			pageCursorStamp = stamp;
		}
		catch (Exception)
		{
			pageCursorStamp = null;
		}
	}

	internal async void ReleaseBackgroundPointerLock()
	{
		try
		{
			if (!IsDisposed && !browser.IsDisposed && browser.CoreWebView2 != null)
			{
				await browser.CoreWebView2.ExecuteScriptAsync("if(document.pointerLockElement)document.exitPointerLock();");
			}
		}
		catch (Exception)
		{
		}
	}

	protected override async void OnFormClosing(FormClosingEventArgs e)
	{
		if (!inputCloseReady && ManualEndpoint != null && ManualEndpoint.Busy)
		{
			e.Cancel = true;
			if (!inputCloseWaiting)
			{
				inputCloseWaiting = true;
				macroNavigating = true;
				await Task.WhenAny(ManualEndpoint.ReleaseAsync(), Task.Delay(1000));
				inputCloseReady = true;
				if (!IsDisposed)
				{
					Close();
				}
			}
		}
		else
		{
			base.OnFormClosing(e);
		}
	}

	internal async Task SendBroadcastKeyAsync(Keys key, bool down)
	{
		if (IsDisposed || browser.IsDisposed || browser.CoreWebView2 == null)
		{
			if (down)
			{
				throw new InvalidOperationException("Game session closed.");
			}
			return;
		}
		if (down && !BroadcastReady)
		{
			throw new InvalidOperationException("Session not ready for gameplay input.");
		}
		string json = keyboardPacket.Create(key, down);
		CoreWebView2 core = browser.CoreWebView2;
		int document = macroDocument;
		if (down)
		{
			if (await core.ExecuteScriptAsync("(() => {\n            const a=document.activeElement;\n            if(a && (a.isContentEditable || ['INPUT','TEXTAREA','SELECT'].includes(a.tagName))) return false;\n            if(!window.__kanblazHoldFocusV1) {\n                const video=document.querySelector('video');\n                const target=video && (video.closest('[tabindex]') || video.parentElement);\n                window.__kanblazHoldFocusV1={previous:a,target:target,tab:target && target.getAttribute('tabindex')};\n                if(target) { if(!target.hasAttribute('tabindex')) target.setAttribute('tabindex','-1'); target.focus({preventScroll:true}); }\n            }\n            return true;\n        })()") != "true")
			{
				throw new InvalidOperationException("Editable field has focus; broadcast blocked.");
			}
			await core.CallDevToolsProtocolMethodAsync("Emulation.setFocusEmulationEnabled", "{\"enabled\":true}");
			if (!BroadcastReady || macroDocument != document)
			{
				throw new InvalidOperationException("Game document changed.");
			}
		}
		try
		{
			await core.CallDevToolsProtocolMethodAsync("Input.dispatchKeyEvent", json);
		}
		finally
		{
			if (!down && !recordedKeyboardActive)
			{
				try
				{
					await core.CallDevToolsProtocolMethodAsync("Emulation.setFocusEmulationEnabled", "{\"enabled\":false}");
				}
				finally
				{
					await core.ExecuteScriptAsync("(() => {\n            const saved=window.__kanblazHoldFocusV1; if(!saved) return;\n            delete window.__kanblazHoldFocusV1;\n            if(saved.target && saved.tab===null) saved.target.removeAttribute('tabindex');\n            if(document.activeElement===saved.target && saved.previous && saved.previous.isConnected) saved.previous.focus({preventScroll:true});\n        })()");
				}
			}
		}
	}
}
