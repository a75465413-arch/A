using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class SuggestionForm : Form
{
	internal SuggestionForm(bool es, string draftPath = null)
	{
		SuggestionForm suggestionForm = this;
		Text = (es ? "Sugerencias" : "Suggestions");
		ClientSize = new Size(520, 430);
		StartPosition = FormStartPosition.CenterParent;
		ShowInTaskbar = false;
		ComboBox category = new ComboBox
		{
			Left = 20,
			Top = 40,
			Width = 475,
			DropDownStyle = ComboBoxStyle.DropDownList
		};
		category.Items.AddRange((!es) ? new object[3] { "Suggestion", "Bug", "Other" } : new object[3] { "Sugerencia", "Error", "Otro" });
		category.SelectedIndex = 0;
		TextBox message = new TextBox
		{
			Left = 20,
			Top = 108,
			Width = 475,
			Height = 180,
			Multiline = true,
			ScrollBars = ScrollBars.Vertical,
			MaxLength = 4000
		};
		Label status = new Label
		{
			Left = 20,
			Top = 302,
			Width = 475,
			Height = 65,
			Text = (es ? "Verificando cuenta… No incluyas contraseñas ni claves." : "Checking account… Do not include passwords or keys.")
		};
		Button submit = new Button
		{
			Text = (es ? "Enviar" : "Submit"),
			Left = 395,
			Top = 379,
			Width = 100,
			Enabled = false
		};
		Button draft = new Button
		{
			Text = (es ? "Guardar borrador" : "Save Draft"),
			Left = 20,
			Top = 379,
			Width = 155
		};
		string path = draftPath ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "suggestion-draft.txt");
		try
		{
			if (File.Exists(path) && new FileInfo(path).Length < 20000)
			{
				message.Text = File.ReadAllText(path);
			}
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		CancellationTokenSource cancellation = new CancellationTokenSource();
		FormClosed += delegate
		{
			cancellation.Cancel();
		};
		bool ready = false;
		bool busy = false;
		string requestId = Guid.NewGuid().ToString();
		Action changed = () =>
		{
			requestId = Guid.NewGuid().ToString();
			submit.Enabled = ready && !busy && !string.IsNullOrWhiteSpace(message.Text);
		};
		category.SelectedIndexChanged += delegate
		{
			changed();
		};
		message.TextChanged += delegate
		{
			changed();
		};
		Shown += async delegate
		{
			try
			{
				GoogleAccountLogin.Reply reply = await GoogleAccountLogin.Current(cancellation.Token);
				if (!suggestionForm.IsDisposed)
				{
					ready = reply != null;
					status.Text = (ready ? ((es ? "Cuenta: " : "Account: ") + reply.Email + (es ? "\nNo incluyas contraseñas ni claves." : "\nDo not include passwords or keys.")) : (es ? "Inicia sesión con Google en Account Access y vuelve a abrir Sugerencias." : "Sign in with Google in Account Access, then reopen Suggestions."));
					submit.Enabled = ready && !string.IsNullOrWhiteSpace(message.Text);
				}
			}
			catch (Exception)
			{
				if (!suggestionForm.IsDisposed)
				{
					status.Text = (es ? "No se pudo verificar la cuenta. Revisa la conexión e inicia sesión de nuevo." : "Could not verify account. Check your connection and sign in again.");
				}
			}
		};
		submit.Click += async delegate
		{
			busy = true;
			submit.Enabled = false;
			draft.Enabled = false;
			category.Enabled = false;
			message.ReadOnly = true;
			status.Text = (es ? "Enviando…" : "Submitting…");
			try
			{
				string text = await GoogleAccountLogin.SubmitSuggestion((new string[3] { "suggestion", "bug", "other" })[category.SelectedIndex], message.Text, requestId, cancellation.Token);
				if (!suggestionForm.IsDisposed)
				{
					status.Text = (es ? "Enviado. Referencia: " : "Submitted. Reference: ") + text;
				}
				return;
			}
			catch (GoogleAccountLogin.AccountRequestException ex3)
			{
				if (!suggestionForm.IsDisposed)
				{
					status.Text = ((!(ex3.Code == "sign_in_required")) ? ((!(ex3.Code == "rate_limit")) ? (es ? "Envío sin confirmar. Reintenta aquí sin cambiar el mensaje para evitar duplicados." : "Submission unconfirmed. Retry here without changing the message to avoid duplicates.") : (es ? "Máximo 5 envíos por hora. Inténtalo más tarde." : "Maximum 5 submissions per hour. Try later.")) : (es ? "La sesión caducó. Inicia sesión y vuelve a abrir Sugerencias." : "Session expired. Sign in and reopen Suggestions."));
				}
				if (ex3.Code == "sign_in_required")
				{
					ready = false;
				}
			}
			catch (Exception)
			{
				if (!suggestionForm.IsDisposed)
				{
					status.Text = (es ? "Envío sin confirmar. Reintenta aquí sin cambiar el mensaje para evitar duplicados." : "Submission unconfirmed. Retry here without changing the message to avoid duplicates.");
				}
			}
			if (!suggestionForm.IsDisposed)
			{
				busy = false;
				submit.Enabled = ready;
				draft.Enabled = true;
				category.Enabled = true;
				message.ReadOnly = false;
			}
		};
		draft.Click += delegate
		{
			try
			{
				Directory.CreateDirectory(Path.GetDirectoryName(path));
				File.WriteAllText(path, message.Text);
				status.Text = (es ? "Borrador guardado en este equipo. No se ha enviado." : "Draft saved on this computer. It has NOT been submitted.");
			}
			catch (Exception)
			{
				status.Text = (es ? "No se pudo guardar el borrador." : "Could not save draft.");
			}
		};
		Controls.Add(new Label
		{
			Text = (es ? "Categoría" : "Category"),
			Left = 20,
			Top = 15,
			AutoSize = true
		});
		Controls.Add(new Label
		{
			Text = (es ? "Mensaje" : "Message"),
			Left = 20,
			Top = 83,
			AutoSize = true
		});
		Controls.AddRange(new Control[5] { category, message, status, submit, draft });
	}
}
