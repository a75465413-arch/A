using System;

namespace KanblazCloudShell;

internal static class PerformanceReading
{
	internal static double CpuPercent(double cpuMilliseconds, double elapsedMilliseconds, int processors)
	{
		if (elapsedMilliseconds <= 0.0 || processors <= 0 || cpuMilliseconds < 0.0)
		{
			return 0.0;
		}
		return Math.Min(100.0, cpuMilliseconds / elapsedMilliseconds / (double)processors * 100.0);
	}
}
