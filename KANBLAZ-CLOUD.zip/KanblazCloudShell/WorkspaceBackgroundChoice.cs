using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceBackgroundChoice : Button
{
	internal readonly int BackgroundId;

	internal bool Selected;

	private Image preview;

	internal WorkspaceBackgroundChoice(int id)
	{
		BackgroundId = id;
		preview = WorkspaceBackdrop.LoadBackground(id);
		SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && preview != null)
		{
			preview.Dispose();
		}
		base.Dispose(disposing);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		using (GraphicsPath graphicsPath = WorkspaceDrawing.Round(new Rectangle(1, 1, Width - 2, Height - 2), 8))
		{
			GraphicsState gstate = e.Graphics.Save();
			e.Graphics.SetClip(graphicsPath);
			e.Graphics.Clear(Color.FromArgb(2, 8, 14));
			if (preview != null)
			{
				e.Graphics.DrawImage(preview, new Rectangle(0, 0, Width, Height));
			}
			using (SolidBrush brush = new SolidBrush(Color.FromArgb(150, Color.Black)))
			{
				e.Graphics.FillRectangle(brush, 0, Height - 19, Width, 19);
			}
			TextRenderer.DrawText(e.Graphics, Text, Font, new Rectangle(0, Height - 20, Width, 20), Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			e.Graphics.Restore(gstate);
			using Pen pen = new Pen(Selected ? Color.DeepSkyBlue : Color.FromArgb(55, 85, 105), (!Selected) ? 1 : 3);
			e.Graphics.DrawPath(pen, graphicsPath);
		}
		if (Focused)
		{
			ControlPaint.DrawFocusRectangle(e.Graphics, new Rectangle(5, 5, Width - 10, Height - 10));
		}
	}
}
