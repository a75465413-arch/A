using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceButton : Button
{
	internal AppTheme Palette;

	private bool hovered;

	internal WorkspaceButton()
	{
		FlatStyle = FlatStyle.Flat;
		DoubleBuffered = true;
		MinimumSize = new Size(0, 32);
	}

	public override Size GetPreferredSize(Size proposedSize)
	{
		if (!AutoSize)
		{
			return Size;
		}
		Size preferredSize = base.GetPreferredSize(proposedSize);
		return new Size(Math.Max(preferredSize.Width, TextRenderer.MeasureText(Text, Font).Width + 28), Math.Max(preferredSize.Height, 34));
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		hovered = true;
		Invalidate();
		base.OnMouseEnter(e);
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		hovered = false;
		Invalidate();
		base.OnMouseLeave(e);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		if (Width < 3 || Height < 3)
		{
			return;
		}
		AppTheme appTheme = Palette ?? AppTheme.Matte(187, 70);
		bool flag = Convert.ToString(Tag) == "primary-button";
		bool flag2 = Convert.ToString(Tag) == "workspace-section";
		bool flag3 = Convert.ToString(Tag) == "workspace-section" || Convert.ToString(Tag) == "window-button";
		Color color = ((Parent == null) ? appTheme.Window : Parent.BackColor);
		base.OnPaintBackground(e);
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		Rectangle rectangle = new Rectangle(3, 3, Width - 6, Height - 6);
		using (GraphicsPath path = WorkspaceDrawing.Round(rectangle, Math.Min(13, rectangle.Height / 2)))
		{
			Rectangle rectangle2 = rectangle;
			Color color2;
			if (Enabled)
			{
				if (flag)
				{
					color2 = appTheme.Hover;
				}
				else if (hovered)
				{
					color2 = appTheme.Selection;
				}
				else if (flag2)
				{
					color2 = Color.FromArgb(90, appTheme.Accent);
				}
				else
				{
					color2 = (flag3 ? color : appTheme.SurfaceRaised);
				}
			}
			else
			{
				color2 = appTheme.SurfaceRaised;
			}
			Rectangle rect = rectangle2;
			Color color3 = color2;
			Color color4;
			if (Enabled)
			{
				if (flag)
				{
					color4 = appTheme.Accent;
				}
				else
				{
					color4 = (flag3 ? Color.Transparent : appTheme.Surface);
				}
			}
			else
			{
				color4 = appTheme.Surface;
			}
			using LinearGradientBrush brush = new LinearGradientBrush(rect, color3, color4, 90f);
			Color color5;
			if (Enabled)
			{
				if (flag)
				{
					color5 = appTheme.ActiveBorder;
				}
				else
				{
					color5 = (hovered ? appTheme.ActiveBorder : appTheme.Border);
				}
			}
			else
			{
				color5 = appTheme.Border;
			}
			using Pen pen = new Pen(color5);
			e.Graphics.FillPath(brush, path);
			if (Enabled && appTheme.Glow && (!flag3 | flag2))
			{
				using Pen pen2 = new Pen(Color.FromArgb(appTheme.GlowAlpha, appTheme.ActiveBorder), 4f);
				e.Graphics.DrawPath(pen2, path);
			}
			if (!flag3 || hovered)
			{
				e.Graphics.DrawPath(pen, path);
			}
		}
		Rectangle rectangle3 = new Rectangle(12, 1, Math.Max(1, Width - 24), Height - 2);
		if (Convert.ToString(Tag) == "nexus-ai")
		{
			TextRenderer.DrawText(e.Graphics, "✦", Font, new Rectangle(0, 0, Width, Math.Max(1, Height - 16)), appTheme.ActiveBorder, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			using Font font = new Font("Segoe UI", 7f);
			TextRenderer.DrawText(e.Graphics, "AI · Soon", font, new Rectangle(0, Height - 18, Width, 16), appTheme.Muted, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			return;
		}
		if (Convert.ToString(Tag) == "workspace-section")
		{
			string text = AccessibleName ?? "";
			string text2;
			if (text.Contains("Controller settings"))
			{
				text2 = "\ue7fc";
			}
			else if (text.Contains("Movement"))
			{
				text2 = "\ue8ab";
			}
			else if (text.Contains("Mouse"))
			{
				text2 = "\ue962";
			}
			else if (text.Contains("Layout"))
			{
				text2 = "\ue80a";
			}
			else if (text.Contains("Appearance"))
			{
				text2 = "\ue790";
			}
			else
			{
				text2 = (text.Contains("Extras") ? "\ue713" : "\ue91f");
			}
			using (Font font2 = new Font("Segoe MDL2 Assets", 13f))
			{
				TextRenderer.DrawText(e.Graphics, text2, font2, new Rectangle(10, 0, 26, Height), appTheme.ActiveBorder, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			}
			rectangle3.X = 46;
			rectangle3.Width = Math.Max(1, Width - 76);
			using Pen pen3 = new Pen(appTheme.Muted, 1.6f);
			int num = Width - 22;
			int num2 = Height / 2;
			bool flag4 = Text.EndsWith("▴");
			e.Graphics.DrawLines(pen3, new Point[3]
			{
				new Point(num - 5, num2 + (flag4 ? 2 : (-2))),
				new Point(num, num2 + (flag4 ? (-3) : 3)),
				new Point(num + 5, num2 + (flag4 ? 2 : (-2)))
			});
		}
		if (Convert.ToString(Tag) == "nexus-mode")
		{
			bool flag5 = Text == "Shared";
			Rectangle bounds = new Rectangle(Width - 55, (Height - 22) / 2, 42, 22);
			using (GraphicsPath path2 = WorkspaceDrawing.Round(bounds, 11))
			{
				using SolidBrush brush2 = new SolidBrush(flag5 ? appTheme.Accent : appTheme.Border);
				e.Graphics.FillPath(brush2, path2);
			}
			using (SolidBrush brush3 = new SolidBrush(Color.White))
			{
				e.Graphics.FillEllipse(brush3, flag5 ? (bounds.Right - 19) : (bounds.Left + 3), bounds.Top + 3, 16, 16);
			}
			rectangle3.Width = Math.Max(1, Width - 76);
		}
		if (Convert.ToString(Tag) == "window-button" || Width < 50)
		{
			rectangle3 = ClientRectangle;
		}
		TextFormatFlags textFormatFlags = ((TextAlign != ContentAlignment.MiddleLeft) ? TextFormatFlags.HorizontalCenter : TextFormatFlags.Default);
		string text3 = (flag2 ? Text.TrimEnd(' ', '▾', '▴') : Text);
		Graphics graphics = e.Graphics;
		string text4 = text3;
		Font font3 = Font;
		Rectangle bounds2 = rectangle3;
		Color foreColor;
		if (Enabled)
		{
			foreColor = (flag ? appTheme.AccentText : appTheme.Text);
		}
		else
		{
			foreColor = appTheme.Muted;
		}
		TextRenderer.DrawText(graphics, text4, font3, bounds2, foreColor, textFormatFlags | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding | TextFormatFlags.SingleLine | TextFormatFlags.NoPrefix);
		if (Focused && ShowFocusCues)
		{
			ControlPaint.DrawFocusRectangle(e.Graphics, new Rectangle(5, 5, Width - 10, Height - 10), appTheme.Accent, color);
		}
	}
}
