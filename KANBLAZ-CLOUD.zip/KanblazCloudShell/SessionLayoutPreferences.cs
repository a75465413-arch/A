using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Xml;

namespace KanblazCloudShell;

internal sealed class SessionLayoutPreferences
{
	[DataContract]
	private sealed class LayoutState
	{
		[DataMember]
		public int Version = 1;

		[DataMember]
		public string Mode = SessionLayoutMode.Grid.ToString();

		[DataMember]
		public bool Borderless;

		[DataMember]
		public Guid PrimaryProfileId;

		[DataMember]
		public List<Guid> Order = new List<Guid>();

		[DataMember]
		public List<StoredBounds> CustomBounds = new List<StoredBounds>();
	}

	[DataContract]
	private sealed class StoredBounds
	{
		[DataMember]
		public Guid ProfileId;

		[DataMember]
		public float X;

		[DataMember]
		public float Y;

		[DataMember]
		public float Width;

		[DataMember]
		public float Height;
	}

	private readonly string path;

	internal SessionLayoutMode Mode { get; set; }

	internal bool Borderless { get; set; }

	internal Guid PrimaryProfileId { get; set; }

	internal List<Guid> Order { get; private set; }

	internal Dictionary<Guid, RectangleF> CustomBounds { get; private set; }

	internal SessionLayoutPreferences(string path)
	{
		this.path = Path.GetFullPath(path);
		Mode = SessionLayoutMode.Mosaic;
		Order = new List<Guid>();
		CustomBounds = new Dictionary<Guid, RectangleF>();
	}

	internal static SessionLayoutPreferences ForCurrentUser()
	{
		return new SessionLayoutPreferences(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "layout-preferences.json"));
	}

	internal void Load()
	{
		try
		{
			if (!File.Exists(path) || new FileInfo(path).Length > 65536)
			{
				return;
			}
			LayoutState layoutState;
			using (FileStream stream = File.OpenRead(path))
			{
				layoutState = (LayoutState)new DataContractJsonSerializer(typeof(LayoutState)).ReadObject(stream);
			}
			if (layoutState == null || layoutState.Version != 1 || !Enum.TryParse<SessionLayoutMode>(layoutState.Mode, ignoreCase: true, out var result))
			{
				return;
			}
			Dictionary<Guid, RectangleF> dictionary = new Dictionary<Guid, RectangleF>();
			foreach (StoredBounds item in layoutState.CustomBounds ?? new List<StoredBounds>())
			{
				RectangleF value = new RectangleF(item.X, item.Y, item.Width, item.Height);
				if (!(item.ProfileId == Guid.Empty) && IsValid(value))
				{
					dictionary[item.ProfileId] = value;
				}
			}
			Mode = ((result == SessionLayoutMode.Focus || result == SessionLayoutMode.Grid) ? result : SessionLayoutMode.Mosaic);
			Order = (layoutState.Order ?? new List<Guid>()).Where((Guid id) => id != Guid.Empty).Distinct().ToList();
			Borderless = layoutState.Borderless;
			PrimaryProfileId = layoutState.PrimaryProfileId;
			CustomBounds = dictionary;
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		catch (SerializationException)
		{
		}
		catch (XmlException)
		{
		}
	}

	internal void Save()
	{
		LayoutState graph = new LayoutState
		{
			Mode = Mode.ToString(),
			Borderless = Borderless,
			PrimaryProfileId = PrimaryProfileId,
			Order = Order,
			CustomBounds = CustomBounds.Select((KeyValuePair<Guid, RectangleF> item) => new StoredBounds
			{
				ProfileId = item.Key,
				X = item.Value.X,
				Y = item.Value.Y,
				Width = item.Value.Width,
				Height = item.Value.Height
			}).ToList()
		};
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string sourceFileName = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			using (FileStream stream = new FileStream(sourceFileName, FileMode.CreateNew, FileAccess.Write, FileShare.None))
			{
				new DataContractJsonSerializer(typeof(LayoutState)).WriteObject(stream, graph);
			}
			if (File.Exists(path))
			{
				File.Replace(sourceFileName, path, null, ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(sourceFileName, path);
			}
		}
		finally
		{
			if (File.Exists(sourceFileName))
			{
				File.Delete(sourceFileName);
			}
		}
	}

	internal void SetCustomBounds(Guid profileId, RectangleF bounds)
	{
		if (!(profileId == Guid.Empty) && IsValid(bounds))
		{
			CustomBounds[profileId] = bounds;
		}
	}

	internal bool SwapOrder(Guid source, Guid target)
	{
		int num = Order.IndexOf(source);
		int num2 = Order.IndexOf(target);
		if (num < 0 || num2 < 0 || num == num2)
		{
			return false;
		}
		Order[num] = target;
		Order[num2] = source;
		if (PrimaryProfileId == source)
		{
			PrimaryProfileId = target;
		}
		else if (PrimaryProfileId == target)
		{
			PrimaryProfileId = source;
		}
		return true;
	}

	private static bool IsValid(RectangleF value)
	{
		if (value.X >= 0f && value.Y >= 0f && value.Width >= 0.12f && value.Height >= 0.12f && value.Right <= 1.001f)
		{
			return value.Bottom <= 1.001f;
		}
		return false;
	}
}
