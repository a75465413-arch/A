namespace KanblazCloudShell;

internal sealed class LicenseRecord
{
	internal string LicenseId { get; set; }

	internal string OwnerLabel { get; set; }

	internal bool RequiresServer { get; set; }
}
