using System;
using System.Globalization;
using System.IO;

namespace KanblazCloudShell;

internal sealed class AccentPreferences
{
	internal const int DefaultHue = 187;

	internal const int DefaultStrength = 70;

	internal int Hue = 187;

	internal int Strength = 70;

	private readonly string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "accent-color.txt");

	internal void Load()
	{
		try
		{
			if (File.Exists(path) && new FileInfo(path).Length <= 64)
			{
				string[] array = File.ReadAllText(path).Split(',');
				if (array.Length == 2 && int.TryParse(array[0], out var result) && int.TryParse(array[1], out var result2) && result >= 0 && result <= 360 && result2 >= 0 && result2 <= 100)
				{
					Hue = result;
					Strength = result2;
				}
			}
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
	}

	internal void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string sourceFileName = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			File.WriteAllText(sourceFileName, Hue.ToString(CultureInfo.InvariantCulture) + "," + Strength.ToString(CultureInfo.InvariantCulture));
			if (File.Exists(path))
			{
				File.Replace(sourceFileName, path, null);
			}
			else
			{
				File.Move(sourceFileName, path);
			}
		}
		finally
		{
			if (File.Exists(sourceFileName))
			{
				File.Delete(sourceFileName);
			}
		}
	}
}
