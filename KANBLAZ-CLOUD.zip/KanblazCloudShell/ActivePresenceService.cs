using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal static class ActivePresenceService
{
	private const string Endpoint = "https://kanblaz-active-users.kanblaz.workers.dev/v1/presence";

	private static readonly HttpClient Client = new HttpClient
	{
		Timeout = TimeSpan.FromSeconds(8.0)
	};

	private static readonly string InstallationIdPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell V2", "presence-installation-id.txt");

	internal static async Task<int?> SendHeartbeatAsync()
	{
		_ = 1;
		try
		{
			string content = "{\"installationId\":\"" + GetInstallationId() + "\"}";
			using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://kanblaz-active-users.kanblaz.workers.dev/v1/presence");
			request.Headers.Add("X-Kanblaz-Client", "cloud-shell-v1");
			request.Content = new StringContent(content, Encoding.UTF8, "application/json");
			using HttpResponseMessage response = await Client.SendAsync(request);
			if (!response.IsSuccessStatusCode)
			{
				return null;
			}
			Match match = Regex.Match(await response.Content.ReadAsStringAsync(), "\\\"activeUsers\\\"\\s*:\\s*(\\d+)");
			int result;
			return (match.Success && int.TryParse(match.Groups[1].Value, out result)) ? new int?(result) : ((int?)null);
		}
		catch
		{
			return null;
		}
	}

	private static string GetInstallationId()
	{
		try
		{
			if (File.Exists(InstallationIdPath))
			{
				string text = File.ReadAllText(InstallationIdPath).Trim();
				if (Regex.IsMatch(text, "^[a-f0-9]{32}$", RegexOptions.IgnoreCase))
				{
					return text.ToLowerInvariant();
				}
			}
			string text2 = Guid.NewGuid().ToString("N");
			Directory.CreateDirectory(Path.GetDirectoryName(InstallationIdPath));
			File.WriteAllText(InstallationIdPath, text2, Encoding.ASCII);
			return text2;
		}
		catch
		{
			return Guid.NewGuid().ToString("N");
		}
	}
}
