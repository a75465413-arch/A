using System;
using System.Drawing;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceGlassList : ListBox
{
	protected override void WndProc(ref Message m)
	{
		base.WndProc(ref m);
		if (m.Msg == 277 || m.Msg == 276 || m.Msg == 522 || m.Msg == 526 || m.Msg == 256)
		{
			Invalidate();
		}
		else
		{
			if (m.Msg != 15 || !IsHandleCreated)
			{
				return;
			}
			int num = ((Items.Count != 0) ? GetItemRectangle(Items.Count - 1).Bottom : 0);
			if (num < ClientSize.Height)
			{
				using (Graphics graphics = Graphics.FromHwnd(Handle))
				{
					WorkspaceBackdrop.PaintBehind(this, graphics, new Rectangle(0, Math.Max(0, num), ClientSize.Width, ClientSize.Height - Math.Max(0, num)), 35);
				}
			}
		}
	}
}
