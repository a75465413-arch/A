using System;
using System.Globalization;
using System.IO;

namespace KanblazCloudShell;

internal sealed class LanguagePreferences
{
	private readonly string path;

	internal LanguagePreferences(string path)
	{
		this.path = path;
	}

	internal static LanguagePreferences ForCurrentUser()
	{
		return new LanguagePreferences(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "ui-language.txt"));
	}

	internal AppLanguage Load()
	{
		try
		{
			if (!File.Exists(path))
			{
				return AppLanguage.System;
			}
			AppLanguage result;
			return (Enum.TryParse<AppLanguage>(File.ReadAllText(path).Trim(), ignoreCase: true, out result) && Enum.IsDefined(typeof(AppLanguage), result)) ? result : AppLanguage.System;
		}
		catch
		{
			return AppLanguage.System;
		}
	}

	internal void Save(AppLanguage language)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		File.WriteAllText(path, language.ToString());
	}

	internal static AppLanguage Resolve(AppLanguage selected, CultureInfo systemCulture)
	{
		if (selected != AppLanguage.System)
		{
			return selected;
		}
		if (!string.Equals((systemCulture ?? CultureInfo.InvariantCulture).TwoLetterISOLanguageName, "es", StringComparison.OrdinalIgnoreCase))
		{
			return AppLanguage.English;
		}
		return AppLanguage.Spanish;
	}
}
