namespace KanblazCloudShell;

internal static class MacroHotkey
{
	internal static int ActionFor(int message, int key, long flags, bool ownFocus, bool modified)
	{
		if ((!ownFocus | modified) || key != 113)
		{
			return 0;
		}
		switch (message)
		{
		case 257:
		case 261:
			return 1;
		default:
			return 0;
		case 256:
		case 260:
			if ((flags & 0x40000000) != 0L)
			{
				return 1;
			}
			return 2;
		}
	}
}
