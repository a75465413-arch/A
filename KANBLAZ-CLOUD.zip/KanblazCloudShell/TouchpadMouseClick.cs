using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace KanblazCloudShell;

internal static class TouchpadMouseClick
{
	private struct MouseInput
	{
		internal int X;

		internal int Y;

		internal uint Data;

		internal uint Flags;

		internal uint Time;

		internal UIntPtr Extra;
	}

	private struct Input
	{
		internal uint Type;

		internal MouseInput Mouse;
	}

	[DllImport("user32.dll")]
	private static extern uint SendInput(uint count, Input[] inputs, int size);

	[DllImport("user32.dll")]
	private static extern IntPtr WindowFromPoint(Point point);

	[DllImport("user32.dll")]
	private static extern bool IsChild(IntPtr parent, IntPtr child);

	[DllImport("user32.dll")]
	private static extern IntPtr GetAncestor(IntPtr window, uint flags);

	internal static bool ClickBrowser(IntPtr browser, Point cursor)
	{
		IntPtr intPtr = WindowFromPoint(cursor);
		if (browser == IntPtr.Zero || (intPtr != browser && !IsChild(browser, intPtr) && GetAncestor(intPtr, 3u) != browser))
		{
			return false;
		}
		Input[] array = new Input[2]
		{
			new Input
			{
				Mouse = new MouseInput
				{
					Flags = 2u
				}
			},
			new Input
			{
				Mouse = new MouseInput
				{
					Flags = 4u
				}
			}
		};
		uint num = SendInput(2u, array, Marshal.SizeOf(typeof(Input)));
		if (num == 1)
		{
			SendInput(1u, new Input[1] { array[1] }, Marshal.SizeOf(typeof(Input)));
		}
		return num == 2;
	}
}
