using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class BroadcastEndpoint
{
	private readonly Func<Keys, bool, Task> send;

	private readonly Action failed;

	private bool desired;

	private bool pumping;

	private bool mayBeDown;

	private Keys key;

	private TaskCompletionSource<bool> idle;

	internal bool Busy
	{
		get
		{
			if (!pumping)
			{
				return mayBeDown;
			}
			return true;
		}
	}

	internal BroadcastEndpoint(Func<Keys, bool, Task> send, Action failed)
	{
		this.send = send;
		this.failed = failed;
	}

	internal void Down(Keys value)
	{
		if (!pumping && !mayBeDown)
		{
			key = value;
			desired = true;
			Pump();
		}
	}

	internal void Release()
	{
		desired = false;
		Pump();
	}

	internal Task ReleaseAsync()
	{
		Release();
		if (idle != null)
		{
			return idle.Task;
		}
		return Task.FromResult(result: true);
	}

	private async void Pump()
	{
		if (pumping)
		{
			return;
		}
		pumping = true;
		idle = new TaskCompletionSource<bool>();
		TaskCompletionSource<bool> completion = idle;
		try
		{
			if (desired && !mayBeDown)
			{
				mayBeDown = true;
				try
				{
					await send(key, arg2: true);
				}
				catch
				{
					desired = false;
					failed();
				}
			}
			if (desired || !mayBeDown)
			{
				return;
			}
			for (int attempt = 0; attempt < 3; attempt++)
			{
				if (!mayBeDown)
				{
					break;
				}
				try
				{
					await send(key, arg2: false);
					mayBeDown = false;
				}
				catch
				{
					if (attempt < 2)
					{
						await Task.Delay(30);
					}
				}
			}
			if (mayBeDown)
			{
				failed();
			}
		}
		finally
		{
			pumping = false;
			completion.TrySetResult(!mayBeDown);
		}
	}
}
