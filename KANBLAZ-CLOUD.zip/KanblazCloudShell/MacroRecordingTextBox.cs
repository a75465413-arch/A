using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class MacroRecordingTextBox : TextBox
{
	protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
	{
		if (Focused && KeyboardMacro.Allowed(keyData & Keys.KeyCode))
		{
			OnKeyDown(new KeyEventArgs(keyData));
			return true;
		}
		return base.ProcessCmdKey(ref msg, keyData);
	}
}
