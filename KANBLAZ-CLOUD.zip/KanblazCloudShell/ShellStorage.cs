using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal static class ShellStorage
{
	private static readonly ProfileRepository Repository = new ProfileRepository(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz"));

	internal static string RegistryPath => Repository.RegistryPath;

	internal static List<Profile> PendingProfiles => Repository.PendingProfiles;

	internal static bool RecoveredBackup => Repository.RecoveredBackup;

	internal static string BrowserDataFolder(Profile profile)
	{
		return Repository.BrowserDataFolder(profile);
	}

	internal static List<Profile> LoadProfiles()
	{
		return Repository.LoadProfiles();
	}

	internal static List<ProfileGroup> LoadGroups()
	{
		return Repository.LoadGroups();
	}

	internal static ProfileGroup CreateGroup(string name)
	{
		return Repository.CreateGroup(name);
	}

	internal static void RenameGroup(Guid id, string name)
	{
		Repository.RenameGroup(id, name);
	}

	internal static void DeleteGroup(Guid id)
	{
		Repository.DeleteGroup(id);
	}

	internal static void SaveProfiles(IEnumerable<Profile> profiles)
	{
		Repository.SaveProfiles(profiles);
	}

	internal static void RestoreProfiles(IEnumerable<Guid> ids)
	{
		Repository.RestoreProfiles(ids);
	}

	internal static void ArchiveProfile(Guid id)
	{
		Repository.ArchiveProfile(id);
	}

	internal static Task RemoveSavedProfileAsync(Guid id)
	{
		return Repository.RemoveSavedProfileAsync(id);
	}

	internal static Task RemoveActiveProfileAsync(Guid id)
	{
		return Repository.RemoveActiveProfileAsync(id);
	}

	internal static string SafeLabel(string value)
	{
		string text = (value ?? "Profile").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ')
			.Trim();
		if (!string.IsNullOrWhiteSpace(text))
		{
			return text;
		}
		return "Profile";
	}

	internal static string SafeUrl(string value)
	{
		string text = (value ?? string.Empty).Trim();
		if (text.Length == 0)
		{
			return string.Empty;
		}
		if (!Uri.TryCreate(text, UriKind.Absolute, out var result) || !(result.Scheme == Uri.UriSchemeHttps) || !string.IsNullOrEmpty(result.UserInfo))
		{
			return string.Empty;
		}
		return result.AbsoluteUri;
	}
}
