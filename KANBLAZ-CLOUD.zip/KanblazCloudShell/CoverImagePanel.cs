using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class CoverImagePanel : Panel
{
	private Image coverImage;

	internal void LoadCover(string file)
	{
		if (File.Exists(file))
		{
			using (Image original = Image.FromFile(file))
			{
				coverImage = new Bitmap(original);
			}
			Invalidate();
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		if (coverImage != null && ClientSize.Width > 0 && ClientSize.Height > 0)
		{
			float num = Math.Max((float)ClientSize.Width / (float)coverImage.Width, (float)ClientSize.Height / (float)coverImage.Height);
			int num2 = (int)Math.Ceiling((float)coverImage.Width * num);
			int num3 = (int)Math.Ceiling((float)coverImage.Height * num);
			int num4 = (ClientSize.Width - num2) / 2;
			int num5 = (ClientSize.Height - num3) / 2;
			e.Graphics.DrawImage(coverImage, new Rectangle(num4, num5, num2, num3));
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && coverImage != null)
		{
			coverImage.Dispose();
		}
		base.Dispose(disposing);
	}
}
