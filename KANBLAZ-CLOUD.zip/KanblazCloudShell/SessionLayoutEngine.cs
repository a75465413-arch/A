using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace KanblazCloudShell;

internal static class SessionLayoutEngine
{
	internal static List<SessionLayoutSlot> Build(SessionLayoutMode mode, int count, int primaryIndex, Size area)
	{
		List<SessionLayoutSlot> list = (from index in Enumerable.Range(0, Math.Max(0, count))
			select new SessionLayoutSlot
			{
				SessionIndex = index,
				Bounds = Rectangle.Empty,
				Visible = true
			}).ToList();
		if (count <= 0 || area.Width <= 0 || area.Height <= 0)
		{
			return list;
		}
		primaryIndex = ((primaryIndex >= 0 && primaryIndex < count) ? primaryIndex : 0);
		if (mode == SessionLayoutMode.Individual)
		{
			foreach (SessionLayoutSlot item in list)
			{
				item.Visible = item.SessionIndex == primaryIndex;
			}
			list[primaryIndex].Bounds = new Rectangle(0, 0, area.Width, area.Height);
			return list;
		}
		if (count == 1)
		{
			list[0].Bounds = new Rectangle(0, 0, area.Width, area.Height);
			if (mode == SessionLayoutMode.Grid)
			{
				list[0].Bounds = GridContentBounds(list[0].Bounds);
			}
			return list;
		}
		if (mode == SessionLayoutMode.Focus)
		{
			int num = Math.Max(1, area.Height * 3 / 4);
			list[primaryIndex].Bounds = new Rectangle(0, 0, area.Width, num);
			ApplyStrip(list.Where((SessionLayoutSlot slot) => slot.SessionIndex != primaryIndex).ToList(), new Rectangle(0, num, area.Width, area.Height - num), horizontal: true);
			return list;
		}
		ApplyGrid(list, area);
		if (mode == SessionLayoutMode.Grid)
		{
			foreach (SessionLayoutSlot item2 in list)
			{
				item2.Bounds = GridContentBounds(item2.Bounds);
			}
		}
		return list;
	}

	internal static Rectangle GridContentBounds(Rectangle cell)
	{
		int num = Math.Min(6, Math.Max(0, (Math.Min(cell.Width, cell.Height) - 1) / 2));
		return Rectangle.Inflate(cell, -num, -num);
	}

	internal static Rectangle FromNormalized(RectangleF normalized, Size area)
	{
		return Rectangle.FromLTRB((int)Math.Round(normalized.Left * (float)area.Width), (int)Math.Round(normalized.Top * (float)area.Height), (int)Math.Round(normalized.Right * (float)area.Width), (int)Math.Round(normalized.Bottom * (float)area.Height));
	}

	internal static RectangleF ToNormalized(Rectangle bounds, Size area)
	{
		if (area.Width <= 0 || area.Height <= 0)
		{
			return RectangleF.Empty;
		}
		Rectangle rectangle = Rectangle.Intersect(new Rectangle(Point.Empty, area), bounds);
		return new RectangleF((float)rectangle.X / (float)area.Width, (float)rectangle.Y / (float)area.Height, (float)rectangle.Width / (float)area.Width, (float)rectangle.Height / (float)area.Height);
	}

	private static void ApplyGrid(IList<SessionLayoutSlot> slots, Size area)
	{
		int num = (int)Math.Ceiling(Math.Sqrt(slots.Count));
		int num2 = (int)Math.Ceiling((double)slots.Count / (double)num);
		for (int i = 0; i < slots.Count; i++)
		{
			int num3 = i % num;
			int num4 = i / num;
			int num5 = num3 * (area.Width / num) + Math.Min(num3, area.Width % num);
			int right = num5 + area.Width / num + ((num3 < area.Width % num) ? 1 : 0);
			int num6 = num4 * (area.Height / num2) + Math.Min(num4, area.Height % num2);
			int bottom = num6 + area.Height / num2 + ((num4 < area.Height % num2) ? 1 : 0);
			slots[i].Bounds = Rectangle.FromLTRB(num5, num6, right, bottom);
		}
	}

	private static void ApplyStrip(IList<SessionLayoutSlot> slots, Rectangle area, bool horizontal)
	{
		for (int i = 0; i < slots.Count; i++)
		{
			if (horizontal)
			{
				slots[i].Bounds = Rectangle.FromLTRB(area.Left + i * area.Width / slots.Count, area.Top, area.Left + (i + 1) * area.Width / slots.Count, area.Bottom);
			}
			else
			{
				slots[i].Bounds = Rectangle.FromLTRB(area.Left, area.Top + i * area.Height / slots.Count, area.Right, area.Top + (i + 1) * area.Height / slots.Count);
			}
		}
	}
}
