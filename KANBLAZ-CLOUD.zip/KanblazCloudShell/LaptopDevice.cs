using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal static class LaptopDevice
{
	private static readonly Lazy<bool> Detected = new Lazy<bool>(Detect);

	internal static bool IsLaptop => Detected.Value;

	internal static bool IsLaptopChassis(IEnumerable<ushort> types)
	{
		return types?.Any((ushort t) => t == 8 || t == 9 || t == 10 || t == 14 || t == 31 || t == 32) ?? false;
	}

	private static bool Detect()
	{
		try
		{
			Task<bool> task = Task.Run(() =>
			{
				EnumerationOptions options = new EnumerationOptions
				{
					Timeout = TimeSpan.FromSeconds(2.0),
					ReturnImmediately = false
				};
				using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT ChassisTypes FROM Win32_SystemEnclosure", options))
				{
					using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
					foreach (ManagementObject item in managementObjectCollection)
					{
						using (item)
						{
							if (IsLaptopChassis(item["ChassisTypes"] as ushort[]))
							{
								return true;
							}
						}
					}
				}
				return false;
			});
			return task.Wait(TimeSpan.FromSeconds(3.0)) && task.Result;
		}
		catch
		{
			return false;
		}
	}
}
