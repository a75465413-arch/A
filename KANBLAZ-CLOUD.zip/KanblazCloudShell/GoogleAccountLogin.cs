using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace KanblazCloudShell;

internal static class GoogleAccountLogin
{
	[DataContract]
	internal sealed class Reply
	{
		[DataMember(Name = "state")]
		public string State;

		[DataMember(Name = "authorizationUrl")]
		public string AuthorizationUrl;

		[DataMember(Name = "session")]
		public string Session;

		[DataMember(Name = "email")]
		public string Email;

		[DataMember(Name = "accountId")]
		public string AccountId;

		[DataMember(Name = "error")]
		public string Error;

		[DataMember(Name = "expiresAt")]
		public long ExpiresAt;

		[DataMember(Name = "id")]
		public string Id;

		[DataMember(Name = "errorCode")]
		public string ErrorCode;

		[DataMember(Name = "admin")]
		public bool Admin;

		[DataMember(Name = "adminUrl")]
		public string AdminUrl;

		[DataMember(Name = "accessMode")]
		public string AccessMode;

		[DataMember(Name = "accessSource")]
		public string AccessSource;

		[DataMember(Name = "accessPro")]
		public bool AccessPro;

		[DataMember(Name = "accessOg")]
		public bool AccessOg;

		[DataMember(Name = "liveAccess")]
		public bool LiveAccess;

		[DataMember(Name = "accessUntil")]
		public long? AccessUntil;

		[DataMember(Name = "issuedAt")]
		public long IssuedAt;

		[DataMember(Name = "leaseExpiresAt")]
		public long LeaseExpiresAt;

		[DataMember(Name = "paymentsEnabled")]
		public bool PaymentsEnabled;

		[DataMember(Name = "subscriptions")]
		public BillingSubscription[] Subscriptions;

		[DataMember(Name = "url")]
		public string CheckoutUrl;

		[DataMember(Name = "testMode")]
		public bool? TestMode;

		[DataMember(Name = "cancelAtPeriodEnd")]
		public bool CancelAtPeriodEnd;
	}

	[DataContract]
	internal sealed class BillingSubscription
	{
		[DataMember(Name = "id")]
		public string Id;

		[DataMember(Name = "status")]
		public string Status;

		[DataMember(Name = "paid_until")]
		public long? PaidUntil;

		[DataMember(Name = "cancel_at_period_end")]
		public int CancelAtPeriodEnd;
	}

	[DataContract]
	private sealed class BillingBody
	{
		[DataMember(Name = "plan", EmitDefaultValue = false)]
		public string Plan;

		[DataMember(Name = "subscriptionId", EmitDefaultValue = false)]
		public string SubscriptionId;
	}

	internal sealed class BillingAccount
	{
		private readonly string session;

		private readonly int generation;

		internal readonly string Email;

		internal BillingAccount(string token, string email, int version)
		{
			session = token;
			Email = email;
			generation = version;
		}

		private void Check(CancellationToken cancel)
		{
			cancel.ThrowIfCancellationRequested();
			if (generation != accountGeneration)
			{
				throw new InvalidOperationException("Account changed. Close memberships and sign in again.");
			}
		}

		private async Task<Reply> Request(string path, BillingBody body, CancellationToken cancel)
		{
			Check(cancel);
			Reply result = await Send(path, body, session, cancel);
			Check(cancel);
			return result;
		}

		internal Task<Reply> Status(CancellationToken cancel)
		{
			return Request("/auth/billing/status", new BillingBody(), cancel);
		}

		internal async Task OpenCheckout(string plan, CancellationToken cancel)
		{
			if (plan != "monthly" && plan != "sixMonths" && plan != "annual")
			{
				throw new ArgumentException("Invalid plan.");
			}
			Reply reply = await Request("/auth/billing/checkout", new BillingBody
			{
				Plan = plan
			}, cancel);
			if (reply.TestMode != false || !ValidCheckoutUrl(reply.CheckoutUrl))
			{
				throw new InvalidOperationException("Invalid LIVE Checkout destination.");
			}
			Check(cancel);
			Process.Start(new ProcessStartInfo(reply.CheckoutUrl)
			{
				UseShellExecute = true
			});
		}

		internal async Task Cancel(string id, CancellationToken cancel)
		{
			if (!Regex.IsMatch(id ?? "", "^sub_[A-Za-z0-9]+$"))
			{
				throw new ArgumentException("Invalid subscription.");
			}
			Reply reply = await Request("/auth/billing/cancel", new BillingBody
			{
				SubscriptionId = id
			}, cancel);
			if (reply.TestMode != false || !reply.CancelAtPeriodEnd)
			{
				throw new InvalidOperationException("Cancellation was not confirmed.");
			}
		}
	}

	internal sealed class AccountRequestException : InvalidOperationException
	{
		internal readonly string Code;

		internal AccountRequestException(string message, string code)
			: base(message)
		{
			Code = code;
		}
	}

	[DataContract]
	private sealed class SuggestionBody
	{
		[DataMember(Name = "category")]
		public string Category;

		[DataMember(Name = "message")]
		public string Message;

		[DataMember(Name = "appVersion")]
		public string AppVersion;

		[DataMember(Name = "requestId")]
		public string RequestId;
	}

	[DataContract]
	private sealed class StartBody
	{
		[DataMember(Name = "redirectUri")]
		public string RedirectUri;

		[DataMember(Name = "challenge")]
		public string Challenge;
	}

	[DataContract]
	private sealed class FinishBody
	{
		[DataMember(Name = "state")]
		public string State;

		[DataMember(Name = "verifier")]
		public string Verifier;

		[DataMember(Name = "code")]
		public string Code;
	}

	internal const string Server = "https://kanblaz-memberships.kanblaz.workers.dev";

	private static readonly string SessionPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "account-session.dat");

	private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("KANBLAZ-account-session-v1");

	private static int accountGeneration;

	private static readonly HttpClient Http = new HttpClient(new HttpClientHandler
	{
		AllowAutoRedirect = false,
		UseCookies = false
	})
	{
		Timeout = TimeSpan.FromSeconds(25.0)
	};

	private static readonly SemaphoreSlim AccessGate = new SemaphoreSlim(1, 1);

	internal static bool ValidCheckoutUrl(string value)
	{
		if (Uri.TryCreate(value, UriKind.Absolute, out var result) && result.Scheme == "https" && result.Host == "checkout.stripe.com" && result.Port == 443 && result.UserInfo.Length == 0)
		{
			return result.AbsolutePath.StartsWith("/c/pay/", StringComparison.Ordinal);
		}
		return false;
	}

	internal static BillingAccount OpenBillingAccount()
	{
		int num = accountGeneration;
		Reply reply = Load();
		if (reply == null || string.IsNullOrEmpty(reply.Session) || num != accountGeneration)
		{
			throw new InvalidOperationException("Sign in with Google first.");
		}
		return new BillingAccount(reply.Session, reply.Email, num);
	}

	private static byte[] Serialize<T>(T value)
	{
		using MemoryStream memoryStream = new MemoryStream();
		new DataContractJsonSerializer(typeof(T)).WriteObject(memoryStream, value);
		return memoryStream.ToArray();
	}

	private static T Deserialize<T>(byte[] bytes)
	{
		using MemoryStream stream = new MemoryStream(bytes);
		return (T)new DataContractJsonSerializer(typeof(T)).ReadObject(stream);
	}

	internal static string Base64Url(byte[] bytes)
	{
		return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-')
			.Replace('/', '_');
	}

	internal static string Challenge(string verifier)
	{
		using SHA256 sHA = SHA256.Create();
		return Base64Url(sHA.ComputeHash(Encoding.ASCII.GetBytes(verifier)));
	}

	private static string Random()
	{
		byte[] array = new byte[32];
		using (RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create())
		{
			randomNumberGenerator.GetBytes(array);
		}
		return Base64Url(array);
	}

	private static async Task<Reply> Send(string path, object body, string session, CancellationToken cancel)
	{
		using HttpRequestMessage request = new HttpRequestMessage((body == null) ? HttpMethod.Get : HttpMethod.Post, "https://kanblaz-memberships.kanblaz.workers.dev" + path);
		if (body != null)
		{
			byte[] content;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				new DataContractJsonSerializer(body.GetType()).WriteObject(memoryStream, body);
				content = memoryStream.ToArray();
			}
			request.Content = new ByteArrayContent(content);
			request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
		}
		if (session != null)
		{
			request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", session);
		}
		using HttpResponseMessage response = await Http.SendAsync(request, cancel);
		byte[] array = await response.Content.ReadAsByteArrayAsync();
		if (array.Length > 20000 || response.Content.Headers.ContentType == null || response.Content.Headers.ContentType.MediaType != "application/json")
		{
			throw new InvalidOperationException("The account server is not ready. Your existing license is unchanged.");
		}
		Reply reply = Deserialize<Reply>(array);
		if (!response.IsSuccessStatusCode)
		{
			throw new AccountRequestException(reply.Error ?? "Account request failed.", reply.ErrorCode);
		}
		return reply;
	}

	internal static bool ValidAuthorizationUrl(string value, string state, string redirect, string challenge)
	{
		if (!Uri.TryCreate(value, UriKind.Absolute, out var result) || result.Scheme != "https" || result.Host != "accounts.google.com" || result.AbsolutePath != "/o/oauth2/v2/auth" || result.Port != 443 || result.UserInfo.Length > 0)
		{
			return false;
		}
		NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(result.Query);
		if (nameValueCollection["client_id"] == "301373648408-i9qr1vhoar086053vmkgda7btuqn384g.apps.googleusercontent.com" && nameValueCollection["state"] == state && nameValueCollection["redirect_uri"] == redirect && nameValueCollection["code_challenge"] == challenge && nameValueCollection["code_challenge_method"] == "S256" && nameValueCollection["response_type"] == "code")
		{
			return nameValueCollection["scope"] == "openid email";
		}
		return false;
	}

	internal static async Task<Reply> SignIn(CancellationToken cancel)
	{
		Interlocked.Increment(ref accountGeneration);
		AccessPolicy.ClearOnline();
		using CancellationTokenSource deadline = CancellationTokenSource.CreateLinkedTokenSource(cancel);
		HttpListener listener = new HttpListener();
		try
		{
			deadline.CancelAfter(TimeSpan.FromMinutes(5.0));
			TcpListener tcpListener = new TcpListener(IPAddress.Loopback, 0);
			tcpListener.Start();
			int port = ((IPEndPoint)tcpListener.LocalEndpoint).Port;
			tcpListener.Stop();
			string redirect = "http://127.0.0.1:" + port + "/callback/";
			listener.Prefixes.Add(redirect);
			listener.Start();
			using (deadline.Token.Register(() =>
			{
				listener.Close();
			}))
			{
				string verifier = Random();
				string challenge = Challenge(verifier);
				Reply start = await Send("/auth/google/start", new StartBody
				{
					RedirectUri = redirect,
					Challenge = challenge
				}, null, deadline.Token);
				if (string.IsNullOrEmpty(start.State) || !ValidAuthorizationUrl(start.AuthorizationUrl, start.State, redirect, challenge))
				{
					throw new InvalidOperationException("Invalid sign-in configuration.");
				}
				Process.Start(new ProcessStartInfo(start.AuthorizationUrl)
				{
					UseShellExecute = true
				});
				NameValueCollection query;
				bool valid;
				string code;
				do
				{
					HttpListenerContext context;
					try
					{
						context = await listener.GetContextAsync();
					}
					catch
					{
						deadline.Token.ThrowIfCancellationRequested();
						throw;
					}
					query = context.Request.QueryString;
					valid = context.Request.HttpMethod == "GET" && context.Request.Url.AbsolutePath == "/callback/" && query.GetValues("state") != null && query.GetValues("state").Length == 1 && query["state"] == start.State;
					code = (valid ? query["code"] : null);
					byte[] bytes = Encoding.UTF8.GetBytes("<!doctype html><meta charset=utf-8><title>KANBLAZ CLOUD</title><p>Return to KANBLAZ CLOUD to see the sign-in result. / Vuelve a KANBLAZ CLOUD para ver el resultado.</p>");
					context.Response.StatusCode = (valid ? 200 : 400);
					context.Response.ContentType = "text/html; charset=utf-8";
					context.Response.Headers["Cache-Control"] = "no-store";
					context.Response.Headers["Content-Security-Policy"] = "default-src 'none'";
					context.Response.ContentLength64 = bytes.Length;
					try
					{
						await context.Response.OutputStream.WriteAsync(bytes, 0, bytes.Length);
					}
					finally
					{
						context.Response.Close();
					}
				}
				while (!valid);
				if (query["error"] != null)
				{
					throw new OperationCanceledException("Google sign-in was canceled.");
				}
				if (string.IsNullOrEmpty(code) || code.Length > 4096 || query.GetValues("code").Length != 1)
				{
					throw new InvalidOperationException("Invalid Google response.");
				}
				Reply reply = await Send("/auth/google/finish", new FinishBody
				{
					State = start.State,
					Code = code,
					Verifier = verifier
				}, null, deadline.Token);
				if (string.IsNullOrEmpty(reply.AccountId) || string.IsNullOrEmpty(reply.Email) || !Regex.IsMatch(reply.Session ?? "", "^[A-Za-z0-9_-]{43}$"))
				{
					throw new InvalidOperationException("Incomplete account response.");
				}
				deadline.Token.ThrowIfCancellationRequested();
				Interlocked.Increment(ref accountGeneration);
				AccessPolicy.ClearOnline();
				Directory.CreateDirectory(Path.GetDirectoryName(SessionPath));
				File.WriteAllBytes(SessionPath, ProtectedData.Protect(Serialize(reply), Entropy, DataProtectionScope.CurrentUser));
				return reply;
			}
		}
		finally
		{
			if (listener != null)
			{
				((IDisposable)listener).Dispose();
			}
		}
	}

	private static Reply Load()
	{
		try
		{
			if (!File.Exists(SessionPath) || new FileInfo(SessionPath).Length > 40000)
			{
				return null;
			}
			return Deserialize<Reply>(ProtectedData.Unprotect(File.ReadAllBytes(SessionPath), Entropy, DataProtectionScope.CurrentUser));
		}
		catch
		{
			return null;
		}
	}

	internal static async Task<Reply> Current(CancellationToken cancel)
	{
		Reply reply = Load();
		if (reply == null)
		{
			return null;
		}
		return await Send("/auth/me", null, reply.Session, cancel);
	}

	internal static async Task SignOut(CancellationToken cancel)
	{
		Interlocked.Increment(ref accountGeneration);
		AccessPolicy.ClearOnline();
		Reply reply = Load();
		if (File.Exists(SessionPath))
		{
			File.Delete(SessionPath);
		}
		if (reply != null)
		{
			await Send("/auth/logout", new StartBody(), reply.Session, cancel);
		}
	}

	internal static async Task<Reply> RefreshAccess(CancellationToken cancel)
	{
		await AccessGate.WaitAsync(cancel);
		try
		{
			int generation = accountGeneration;
			Reply saved = Load();
			if (saved == null)
			{
				AccessPolicy.ClearOnline();
				return null;
			}
			long started = Stopwatch.GetTimestamp();
			Reply reply = await Send("/auth/access", new StartBody(), saved.Session, cancel);
			if (generation != accountGeneration)
			{
				return null;
			}
			if (reply.AccountId != saved.AccountId)
			{
				throw new InvalidOperationException("Account identity mismatch.");
			}
			AccessPolicy.AcceptOnline(reply.AccessMode, reply.AccessSource, reply.AccessPro, reply.AccessOg, reply.LiveAccess, reply.IssuedAt, reply.LeaseExpiresAt, started);
			return reply;
		}
		catch
		{
			AccessPolicy.ClearOnline();
			throw;
		}
		finally
		{
			AccessGate.Release();
		}
	}

	internal static async Task OpenAdmin(CancellationToken cancel)
	{
		Reply reply = Load();
		if (reply == null)
		{
			throw new InvalidOperationException("Sign in with Google first.");
		}
		Reply reply2 = await Send("/auth/admin/open", new StartBody(), reply.Session, cancel);
		if (!Uri.TryCreate(reply2.AdminUrl, UriKind.Absolute, out var result) || result.GetLeftPart(UriPartial.Path) != "https://kanblaz-memberships.kanblaz.workers.dev/admin/" || result.Query.Length != 0 || !Regex.IsMatch(result.Fragment, "^#[A-Za-z0-9_-]{43}$"))
		{
			throw new InvalidOperationException("Invalid Admin destination.");
		}
		Process.Start(new ProcessStartInfo(reply2.AdminUrl)
		{
			UseShellExecute = true
		});
	}

	internal static async Task<string> SubmitSuggestion(string category, string message, string requestId, CancellationToken cancel)
	{
		Reply reply = Load();
		if (reply == null)
		{
			throw new AccountRequestException("Sign in with Google first.", "sign_in_required");
		}
		Reply reply2 = await Send("/auth/suggestions", new SuggestionBody
		{
			Category = category,
			Message = message,
			RequestId = requestId,
			AppVersion = typeof(GoogleAccountLogin).Assembly.GetName().Version.ToString()
		}, reply.Session, cancel);
		if (!Guid.TryParse(reply2.Id, out var _))
		{
			throw new InvalidOperationException("Invalid submission receipt.");
		}
		return reply2.Id;
	}
}
