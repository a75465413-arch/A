using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace KanblazCloudShell;

internal static class BackgroundAudioExperiment
{
	internal static string ReadScript()
	{
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Kanblaz.BackgroundAudio.js");
		if (stream == null)
		{
			throw new InvalidOperationException("The background audio component is missing.");
		}
		using StreamReader streamReader = new StreamReader(stream);
		return streamReader.ReadToEnd();
	}

	internal static Task<string> InstallAsync(CoreWebView2 browser)
	{
		return browser.AddScriptToExecuteOnDocumentCreatedAsync(ReadScript());
	}
}
