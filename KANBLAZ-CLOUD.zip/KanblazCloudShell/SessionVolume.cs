using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class SessionVolume : IDisposable
{
	private delegate IntPtr MouseCallback(int code, IntPtr message, IntPtr data);

	private readonly Timer timer = new Timer
	{
		Interval = 5000
	};

	private readonly Timer applyDelay = new Timer
	{
		Interval = 120
	};

	private readonly Timer saveDelay = new Timer
	{
		Interval = 400
	};

	private bool pendingSave;

	private int lastAudible = 100;

	private readonly string path;

	private uint pid;

	private bool busy;

	private bool disposed;

	private bool dirty = true;

	private ContextMenuStrip menu;

	private Label volumeLabel;

	private TrackBar volumeSlider;

	private IntPtr mouseHook;

	private readonly MouseCallback mouseCallback;

	internal int Level { get; private set; }

	internal string Status { get; private set; }

	internal event Action Changed;

	[DllImport("Kanblaz.ProcessAudio.dll", CallingConvention = CallingConvention.StdCall)]
	private static extern int KanblazSetSessionVolume(uint pid, float level);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern IntPtr SetWindowsHookEx(int kind, MouseCallback callback, IntPtr module, uint thread);

	[DllImport("user32.dll")]
	private static extern bool UnhookWindowsHookEx(IntPtr hook);

	[DllImport("user32.dll")]
	private static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr message, IntPtr data);

	[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
	private static extern IntPtr GetModuleHandle(string name);

	private void StopMouseWatch()
	{
		if (mouseHook != IntPtr.Zero)
		{
			UnhookWindowsHookEx(mouseHook);
			mouseHook = IntPtr.Zero;
		}
	}

	internal static bool OutsideVolume(Rectangle popup, Point click)
	{
		return !popup.Contains(click);
	}

	private IntPtr ObserveMouse(int code, IntPtr message, IntPtr data)
	{
		try
		{
			int num = message.ToInt32();
			if (code >= 0 && (num == 513 || num == 516 || num == 519) && menu != null && !menu.IsDisposed && menu.Visible && OutsideVolume(click: new Point(Marshal.ReadInt32(data), Marshal.ReadInt32(data, 4)), popup: menu.Bounds))
			{
				ContextMenuStrip open = menu;
				open.BeginInvoke((Action)(() =>
				{
					if (!open.IsDisposed && open.Visible)
					{
						open.Close(ToolStripDropDownCloseReason.AppClicked);
					}
				}));
			}
		}
		catch (InvalidOperationException)
		{
		}
		return CallNextHookEx(mouseHook, code, message, data);
	}

	internal SessionVolume(Guid key)
	{
		mouseCallback = ObserveMouse;
		path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "volume", key.ToString("N") + ".txt");
		Level = 100;
		Status = "Waiting for game audio";
		try
		{
			if (File.Exists(path))
			{
				string[] array = File.ReadAllText(path).Split(':');
				if (int.TryParse(array[0], out var result) && result >= 0 && result <= 100)
				{
					Level = result;
				}
				if (array.Length > 1 && int.TryParse(array[1], out result) && result > 0 && result <= 100)
				{
					lastAudible = result;
				}
				else if (Level > 0)
				{
					lastAudible = Level;
				}
			}
		}
		catch (IOException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		timer.Tick += (object s, EventArgs e) =>
		{
			Apply();
		};
		applyDelay.Tick += (object s, EventArgs e) =>
		{
			applyDelay.Stop();
			Apply();
		};
		saveDelay.Tick += (object s, EventArgs e) =>
		{
			saveDelay.Stop();
			Save();
		};
	}

	internal void Start(uint process)
	{
		pid = process;
		timer.Start();
		Apply();
	}

	internal void Set(int level)
	{
		if (disposed)
		{
			return;
		}
		level = Math.Max(0, Math.Min(100, level));
		if (level != Level)
		{
			Level = level;
			if (level > 0)
			{
				lastAudible = level;
			}
			dirty = true;
			pendingSave = true;
			RefreshMenu();
			if (Changed != null)
			{
				Changed();
			}
			applyDelay.Stop();
			applyDelay.Start();
			saveDelay.Stop();
			saveDelay.Start();
		}
	}

	private void Save()
	{
		if (!pendingSave)
		{
			return;
		}
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(path));
			File.WriteAllText(path, Level + ":" + lastAudible);
			pendingSave = false;
		}
		catch (IOException)
		{
			Status = "Volume changed; setting could not be saved";
		}
		catch (UnauthorizedAccessException)
		{
			Status = "Volume changed; setting could not be saved";
		}
	}

	private async void Apply()
	{
		if (disposed || busy || pid == 0 || (!dirty && Level == 100))
		{
			return;
		}
		busy = true;
		int value = Level;
		uint process = pid;
		try
		{
			int num = await Task.Run(() => KanblazSetSessionVolume(process, (float)value / 100f));
			if (disposed)
			{
				return;
			}
			string text;
			if (num < 0)
			{
				text = "Audio mixer unavailable";
			}
			else
			{
				text = ((num == 0) ? "Waiting for game audio" : ("Game volume: " + value + "%"));
			}
			bool flag = Status != text;
			Status = text;
			if (num > 0 && value == Level)
			{
				dirty = false;
			}
			if (flag)
			{
				RefreshMenu();
				if (Changed != null)
				{
					Changed();
				}
			}
		}
		catch (Exception)
		{
			if (!disposed)
			{
				Status = "Audio mixer unavailable";
				if (Changed != null)
				{
					Changed();
				}
			}
		}
		finally
		{
			busy = false;
			if (!disposed && value != Level)
			{
				applyDelay.Stop();
				applyDelay.Start();
			}
		}
	}

	internal void ShowMenu(Control anchor, Action reset)
	{
		if (disposed || anchor == null || anchor.IsDisposed || !anchor.IsHandleCreated)
		{
			return;
		}
		if (menu == null)
		{
			menu = new ContextMenuStrip
			{
				ShowImageMargin = false,
				BackColor = Color.FromArgb(18, 27, 35),
				Padding = new Padding(4)
			};
			menu.Opened += (object s, EventArgs e) =>
			{
				StopMouseWatch();
				mouseHook = SetWindowsHookEx(14, mouseCallback, GetModuleHandle(null), 0u);
			};
			menu.Closed += (object s, ToolStripDropDownClosedEventArgs e) =>
			{
				StopMouseWatch();
			};
			Panel panel = new Panel
			{
				Size = new Size(110, 200),
				BackColor = menu.BackColor
			};
			volumeLabel = new Label
			{
				AutoSize = false,
				TextAlign = ContentAlignment.MiddleCenter,
				ForeColor = Color.White,
				Bounds = new Rectangle(0, 0, 110, 42)
			};
			volumeSlider = new TrackBar
			{
				Minimum = 0,
				Maximum = 100,
				Value = Level,
				Orientation = Orientation.Vertical,
				TickStyle = TickStyle.None,
				SmallChange = 5,
				LargeChange = 10,
				AutoSize = false,
				Bounds = new Rectangle(33, 46, 44, 150),
				BackColor = menu.BackColor,
				AccessibleName = "Game volume"
			};
			volumeSlider.ValueChanged += (object s, EventArgs e) =>
			{
				Set(volumeSlider.Value);
				RefreshMenu();
			};
			panel.Controls.Add(volumeLabel);
			panel.Controls.Add(volumeSlider);
			menu.Items.Add(new ToolStripControlHost(panel)
			{
				Margin = Padding.Empty,
				Padding = Padding.Empty,
				AutoSize = false,
				Size = panel.Size
			});
		}
		RefreshMenu();
		menu.Show(anchor, new Point(0, -menu.GetPreferredSize(Size.Empty).Height));
	}

	private void RefreshMenu()
	{
		if (menu != null && !menu.IsDisposed)
		{
			volumeLabel.Text = "Game volume\n" + Level + "%";
			volumeSlider.AccessibleDescription = Status;
			if (volumeSlider.Value != Level)
			{
				volumeSlider.Value = Level;
			}
		}
	}

	public void Dispose()
	{
		if (disposed)
		{
			return;
		}
		StopMouseWatch();
		Save();
		disposed = true;
		timer.Stop();
		timer.Dispose();
		applyDelay.Stop();
		applyDelay.Dispose();
		saveDelay.Stop();
		saveDelay.Dispose();
		ContextMenuStrip owned = menu;
		menu = null;
		if (owned == null || owned.IsDisposed)
		{
			return;
		}
		if (owned.IsHandleCreated)
		{
			try
			{
				owned.BeginInvoke((Action)(() =>
				{
					owned.Dispose();
				}));
				return;
			}
			catch (InvalidOperationException)
			{
			}
		}
		owned.Dispose();
	}
}
