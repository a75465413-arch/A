using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Automation;

namespace KanblazCloudShell;

internal static class GlobalShortcutFocus
{
	private static Task<bool> pending;

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr window, out uint process);

	[DllImport("kernel32.dll")]
	private static extern uint GetCurrentProcessId();

	internal static bool IsOurWindow(IntPtr window)
	{
		GetWindowThreadProcessId(window, out var process);
		return process == GetCurrentProcessId();
	}

	internal static bool IsSafeControl(int type, bool password, bool writable)
	{
		if (password | writable)
		{
			return false;
		}
		if (type != 50000 && type != 50002 && type != 50007 && type != 50008 && type != 50009 && type != 50010 && type != 50011 && type != 50013 && type != 50018 && type != 50019 && type != 50021 && type != 50023 && type != 50024 && type != 50032)
		{
			return type == 50033;
		}
		return true;
	}

	internal static async Task<bool> AllowsAsync(IntPtr foreground)
	{
		if (foreground == IntPtr.Zero || foreground != NativeInputOwnership.ForegroundWindow || IsOurWindow(foreground))
		{
			return false;
		}
		if (pending != null && !pending.IsCompleted)
		{
			return false;
		}
		Task<bool> query = (pending = Task.Run(() =>
		{
			try
			{
				AutomationElement focusedElement = AutomationElement.FocusedElement;
				if (focusedElement == null)
				{
					return false;
				}
				AutomationElement.AutomationElementInformation current = focusedElement.Current;
				bool writable = focusedElement.TryGetCurrentPattern(ValuePattern.Pattern, out var patternObject) && !((ValuePattern)patternObject).Current.IsReadOnly;
				return IsSafeControl(current.ControlType.Id, current.IsPassword, writable);
			}
			catch
			{
				return false;
			}
		}));
		if (await Task.WhenAny(query, Task.Delay(250)) != query)
		{
			return false;
		}
		return await query && foreground == NativeInputOwnership.ForegroundWindow;
	}
}
