namespace KanblazCloudShell;

internal enum SessionLayoutMode
{
	Mosaic,
	Grid,
	Focus,
	Individual,
	Custom
}
