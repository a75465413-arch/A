using System;
using System.Diagnostics;
using System.Drawing;

namespace KanblazCloudShell;

internal sealed class TouchpadGesture
{
	private bool initialized;

	private bool down;

	private bool click;

	private bool suppressMovement;

	private bool activated;

	private int contact;

	private int x;

	private int y;

	private int originX;

	private int originY;

	private long touchStarted;

	private double remainderX;

	private double remainderY;

	private readonly Func<long> clock;

	internal TouchpadGesture()
		: this(() => Stopwatch.GetTimestamp() * 1000 / Stopwatch.Frequency)
	{
	}

	internal TouchpadGesture(Func<long> clock)
	{
		this.clock = clock;
	}

	internal void Reset()
	{
		initialized = (down = (click = (suppressMovement = (activated = false))));
		remainderX = (remainderY = 0.0);
	}

	internal Point Update(TouchpadSample value, out bool release)
	{
		bool mouseClick;
		return Update(value, out release, out mouseClick);
	}

	internal Point Update(TouchpadSample value, out bool release, out bool mouseClick)
	{
		mouseClick = initialized && value.Click && !click && value.Down;
		release = false;
		bool flag = !initialized || !down || value.Contact != contact;
		if (!value.Down | flag)
		{
			activated = false;
			remainderX = (remainderY = 0.0);
			touchStarted = clock();
			originX = value.X;
			originY = value.Y;
		}
		if (!value.Down)
		{
			suppressMovement = false;
		}
		else if (mouseClick || (!initialized && value.Click))
		{
			suppressMovement = true;
		}
		Point result = Point.Empty;
		if (!suppressMovement && !value.Click && initialized && down && value.Down && value.Contact == contact)
		{
			int num = value.X - x;
			int num2 = value.Y - y;
			if (Math.Abs(num) <= 240 && Math.Abs(num2) <= 240)
			{
				if (!activated && (clock() - touchStarted >= 180 || Math.Abs(value.X - originX) + Math.Abs(value.Y - originY) >= 24))
				{
					activated = true;
					release = true;
				}
				else if (activated)
				{
					remainderX += (double)num * 0.6;
					remainderY += (double)num2 * 0.6;
					result = new Point((int)remainderX, (int)remainderY);
					remainderX -= result.X;
					remainderY -= result.Y;
				}
			}
		}
		initialized = true;
		down = value.Down;
		click = value.Click;
		contact = value.Contact;
		x = value.X;
		y = value.Y;
		return result;
	}
}
