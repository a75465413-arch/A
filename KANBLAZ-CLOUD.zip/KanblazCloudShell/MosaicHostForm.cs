using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class MosaicHostForm : Form
{
	private readonly Panel mosaic = new Panel();

	private readonly Image brandImage;

	private readonly SessionLayoutPreferences preferences;

	private readonly Timer customSaveTimer = new Timer
	{
		Interval = 350
	};

	private readonly HashSet<CloudSessionForm> monitoredSessions = new HashSet<CloudSessionForm>();

	private List<CloudSessionForm> arrangedSessions = new List<CloudSessionForm>();

	private bool applyingLayout;

	private SessionLayoutMode mode;

	private bool borderless;

	private bool editing;

	internal void SetEditing(bool enabled)
	{
		editing = enabled;
		foreach (CloudSessionForm arrangedSession in arrangedSessions)
		{
			arrangedSession.SetLayoutEditing(enabled);
		}
	}

	private void SwapSessions(Guid source, Guid target)
	{
		if (!editing || source == target)
		{
			return;
		}
		int num = arrangedSessions.FindIndex((CloudSessionForm s) => s.ProfileKey == source);
		int num2 = arrangedSessions.FindIndex((CloudSessionForm s) => s.ProfileKey == target);
		if (num < 0 || num2 < 0)
		{
			return;
		}
		CloudSessionForm value = arrangedSessions[num];
		arrangedSessions[num] = arrangedSessions[num2];
		arrangedSessions[num2] = value;
		foreach (CloudSessionForm arrangedSession in arrangedSessions)
		{
			if (!preferences.Order.Contains(arrangedSession.ProfileKey))
			{
				preferences.Order.Add(arrangedSession.ProfileKey);
			}
		}
		preferences.SwapOrder(source, target);
		preferences.Save();
		ApplyLayout();
	}

	internal MosaicHostForm(Icon appIcon, SessionLayoutPreferences preferences, SessionLayoutMode initialMode, bool initialBorderless)
	{
		MosaicHostForm mosaicHostForm = this;
		this.preferences = preferences;
		mode = initialMode;
		borderless = initialBorderless;
		Text = "KANBLAZ CLOUD";
		Icon = appIcon;
		StartPosition = FormStartPosition.CenterScreen;
		ClientSize = new Size(970, 546);
		MinimumSize = new Size(640, 360);
		FormBorderStyle = FormBorderStyle.Sizable;
		WindowState = FormWindowState.Maximized;
		BackColor = Color.Black;
		ForeColor = Color.White;
		ShowInTaskbar = true;
		mosaic.Dock = DockStyle.Fill;
		mosaic.Margin = Padding.Empty;
		mosaic.Padding = Padding.Empty;
		mosaic.BackColor = Color.Black;
		Controls.Add(mosaic);
		mosaic.Resize += delegate
		{
			mosaicHostForm.ApplyLayout();
		};
		mosaic.Paint += (object sender, PaintEventArgs e) =>
		{
			if (mosaicHostForm.mode != SessionLayoutMode.Grid)
			{
				return;
			}
			using Pen pen = new Pen(Color.White, 2f);
			foreach (Control control in mosaicHostForm.mosaic.Controls)
			{
				if (control.Visible)
				{
					Rectangle rectangle = Rectangle.Inflate(control.Bounds, 2, 2);
					e.Graphics.DrawRectangle(pen, rectangle.X, rectangle.Y, rectangle.Width - 1, rectangle.Height - 1);
				}
			}
		};
		customSaveTimer.Tick += delegate
		{
			mosaicHostForm.customSaveTimer.Stop();
			preferences.Save();
		};
		string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", "kanblaz-loading.png");
		if (File.Exists(text))
		{
			using Image original = Image.FromFile(text);
			brandImage = new Bitmap(original);
		}
		ApplyBorderless();
	}

	internal void ArrangeSessions(IList<CloudSessionForm> sessions)
	{
		arrangedSessions = sessions.OrderBy((CloudSessionForm s) =>
		{
			int num2 = preferences.Order.IndexOf(s.ProfileKey);
			return (num2 >= 0) ? num2 : int.MaxValue;
		}).ToList();
		foreach (CloudSessionForm arrangedSession in arrangedSessions)
		{
			if (!preferences.Order.Contains(arrangedSession.ProfileKey))
			{
				preferences.Order.Add(arrangedSession.ProfileKey);
			}
		}
		mosaic.SuspendLayout();
		foreach (Control item in (from Control control in mosaic.Controls
			where !(control is CloudSessionForm)
			select control).ToList())
		{
			item.Dispose();
		}
		foreach (CloudSessionForm item2 in mosaic.Controls.OfType<CloudSessionForm>().ToList())
		{
			if (!sessions.Contains(item2))
			{
				mosaic.Controls.Remove(item2);
			}
		}
		int count = arrangedSessions.Count;
		if (count == 0)
		{
			mosaic.ResumeLayout();
			return;
		}
		for (int num = 0; num < count; num++)
		{
			CloudSessionForm cloudSessionForm = arrangedSessions[num];
			cloudSessionForm.PrepareForMosaic(mode == SessionLayoutMode.Custom);
			if (cloudSessionForm.Parent != mosaic)
			{
				mosaic.Controls.Add(cloudSessionForm);
			}
			mosaic.Controls.SetChildIndex(cloudSessionForm, num);
			if (monitoredSessions.Add(cloudSessionForm))
			{
				cloudSessionForm.LayoutSwapRequested += SwapSessions;
				cloudSessionForm.LocationChanged += SessionBoundsChanged;
				cloudSessionForm.SizeChanged += SessionBoundsChanged;
			}
			cloudSessionForm.SetLayoutEditing(editing);
		}
		ApplyLayout();
		mosaic.ResumeLayout(performLayout: true);
	}

	internal void SetLayout(SessionLayoutMode mode)
	{
		this.mode = mode;
		preferences.Mode = mode;
		preferences.Save();
		ApplyLayout();
	}

	internal void SetPrimary(Guid profileId)
	{
		preferences.PrimaryProfileId = profileId;
		preferences.Save();
		ApplyLayout();
	}

	internal void SetBorderless(bool enabled)
	{
		borderless = enabled;
		preferences.Borderless = enabled;
		ApplyBorderless();
		preferences.Save();
	}

	private void ApplyBorderless()
	{
		Screen screen = Screen.FromControl(this);
		FormBorderStyle formBorderStyle = ((!borderless) ? FormBorderStyle.Sizable : FormBorderStyle.None);
		SuspendLayout();
		try
		{
			WindowState = FormWindowState.Normal;
			FormBorderStyle = formBorderStyle;
			TopMost = false;
			if (borderless)
			{
				Bounds = screen.Bounds;
				return;
			}
			Bounds = screen.WorkingArea;
			WindowState = FormWindowState.Maximized;
		}
		finally
		{
			ResumeLayout(performLayout: true);
		}
	}

	private void ApplyLayout()
	{
		if (applyingLayout || arrangedSessions.Count == 0 || mosaic.ClientSize.Width <= 0 || mosaic.ClientSize.Height <= 0)
		{
			return;
		}
		applyingLayout = true;
		try
		{
			foreach (Control item in (from Control control2 in mosaic.Controls
				where !(control2 is CloudSessionForm)
				select control2).ToList())
			{
				item.Dispose();
			}
			int num = arrangedSessions.FindIndex((CloudSessionForm session) => session.ProfileKey == preferences.PrimaryProfileId);
			if (num < 0)
			{
				num = 0;
				preferences.PrimaryProfileId = arrangedSessions[0].ProfileKey;
			}
			List<SessionLayoutSlot> list = SessionLayoutEngine.Build(mode, arrangedSessions.Count, num, mosaic.ClientSize);
			List<SessionLayoutSlot> list2 = SessionLayoutEngine.Build(SessionLayoutMode.Grid, arrangedSessions.Count, num, mosaic.ClientSize);
			for (int num2 = 0; num2 < arrangedSessions.Count; num2++)
			{
				CloudSessionForm cloudSessionForm = arrangedSessions[num2];
				cloudSessionForm.PrepareForMosaic(mode == SessionLayoutMode.Custom);
				Rectangle rectangle;
				if (mode == SessionLayoutMode.Custom)
				{
					rectangle = (preferences.CustomBounds.TryGetValue(cloudSessionForm.ProfileKey, out var value) ? SessionLayoutEngine.FromNormalized(value, mosaic.ClientSize) : list2[num2].Bounds);
					cloudSessionForm.Visible = true;
				}
				else
				{
					rectangle = list[num2].Bounds;
					cloudSessionForm.Visible = list[num2].Visible;
				}
				if (cloudSessionForm.Bounds != rectangle)
				{
					cloudSessionForm.Bounds = rectangle;
				}
				if (cloudSessionForm.Visible)
				{
					cloudSessionForm.Show();
				}
			}
			if (mode != SessionLayoutMode.Grid && mode != SessionLayoutMode.Mosaic)
			{
				return;
			}
			int num3 = (int)Math.Ceiling(Math.Sqrt(arrangedSessions.Count));
			int num4 = (int)Math.Ceiling((double)arrangedSessions.Count / (double)num3);
			for (int num5 = arrangedSessions.Count; num5 < num3 * num4; num5++)
			{
				Control control = CreateBrandTile();
				int num6 = num5 % num3;
				int num7 = num5 / num3;
				int num8 = num6 * (mosaic.Width / num3) + Math.Min(num6, mosaic.Width % num3);
				int num9 = num7 * (mosaic.Height / num4) + Math.Min(num7, mosaic.Height % num4);
				control.Bounds = new Rectangle(num8, num9, mosaic.Width / num3 + ((num6 < mosaic.Width % num3) ? 1 : 0), mosaic.Height / num4 + ((num7 < mosaic.Height % num4) ? 1 : 0));
				if (mode == SessionLayoutMode.Grid)
				{
					control.Bounds = SessionLayoutEngine.GridContentBounds(control.Bounds);
				}
				mosaic.Controls.Add(control);
			}
		}
		finally
		{
			applyingLayout = false;
			mosaic.Invalidate();
		}
	}

	private void SessionBoundsChanged(object sender, EventArgs args)
	{
		if (!applyingLayout && mode == SessionLayoutMode.Custom && sender is CloudSessionForm cloudSessionForm && cloudSessionForm.Parent == mosaic)
		{
			RectangleF bounds = SessionLayoutEngine.ToNormalized(cloudSessionForm.Bounds, mosaic.ClientSize);
			if (!(bounds.Width < 0.12f) && !(bounds.Height < 0.12f))
			{
				preferences.SetCustomBounds(cloudSessionForm.ProfileKey, bounds);
				customSaveTimer.Stop();
				customSaveTimer.Start();
			}
		}
	}

	private Control CreateBrandTile()
	{
		Panel panel = new Panel
		{
			Dock = DockStyle.None,
			BackColor = Color.Black,
			Margin = Padding.Empty
		};
		if (brandImage != null)
		{
			panel.Controls.Add(new PictureBox
			{
				Dock = DockStyle.Fill,
				Image = brandImage,
				SizeMode = PictureBoxSizeMode.Zoom,
				BackColor = Color.Black
			});
		}
		return panel;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			customSaveTimer.Stop();
			customSaveTimer.Dispose();
			if (brandImage != null)
			{
				brandImage.Dispose();
			}
		}
		base.Dispose(disposing);
	}
}
