using System;
using System.Drawing;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class WorkspaceGlassGrid : DataGridView
{
	internal WorkspaceGlassGrid()
	{
		DoubleBuffered = true;
	}

	protected override void OnScroll(ScrollEventArgs e)
	{
		base.OnScroll(e);
		Invalidate();
	}

	protected override void OnMouseWheel(MouseEventArgs e)
	{
		base.OnMouseWheel(e);
		Invalidate();
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		base.OnSizeChanged(e);
		Invalidate();
	}

	protected override void PaintBackground(Graphics graphics, Rectangle clipBounds, Rectangle gridBounds)
	{
		WorkspaceBackdrop.PaintBehind(this, graphics, clipBounds, 35);
	}
}
