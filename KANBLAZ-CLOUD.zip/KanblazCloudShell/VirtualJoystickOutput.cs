using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal sealed class VirtualJoystickOutput
{
	private readonly HashSet<char> held = new HashSet<char>();

	private readonly Func<bool, double, double, Task> send;

	private readonly Func<int, Task> delay;

	private bool engaged;

	internal VirtualJoystickOutput(Func<bool, double, double, Task> send, Func<int, Task> delay = null)
	{
		this.send = send;
		this.delay = delay ?? new Func<int, Task>(Task.Delay);
	}

	internal Task SetKeyAsync(char key, bool down)
	{
		if (key != 'W' && key != 'A' && key != 'S' && key != 'D')
		{
			throw new ArgumentOutOfRangeException("key");
		}
		if (down)
		{
			held.Add(key);
		}
		else
		{
			held.Remove(key);
		}
		double num = (held.Contains('D') ? 1 : 0) - (held.Contains('A') ? 1 : 0);
		double num2 = (held.Contains('S') ? 1 : 0) - (held.Contains('W') ? 1 : 0);
		double num3 = Math.Sqrt(num * num + num2 * num2);
		if (num3 > 1.0)
		{
			num /= num3;
			num2 /= num3;
		}
		engaged = true;
		return send(arg1: true, num, num2);
	}

	internal async Task ResetAsync()
	{
		held.Clear();
		if (engaged)
		{
			try
			{
				await send(arg1: true, 0.0, 0.0);
				await delay(60);
			}
			finally
			{
				await send(arg1: false, 0.0, 0.0);
				engaged = false;
			}
		}
	}
}
