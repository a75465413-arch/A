using System;
using System.Drawing;
using System.Windows.Forms;

namespace KanblazCloudShell;

internal sealed class SharedModeIndicator : Form
{
	protected override bool ShowWithoutActivation => true;

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams createParams = base.CreateParams;
			createParams.ExStyle |= 134217888;
			return createParams;
		}
	}

	internal SharedModeIndicator()
	{
		FormBorderStyle = FormBorderStyle.None;
		ShowInTaskbar = false;
		TopMost = false;
		StartPosition = FormStartPosition.Manual;
		AutoScaleMode = AutoScaleMode.None;
		BackColor = Color.FromArgb(16, 30, 34);
		ForeColor = Color.FromArgb(73, 236, 192);
		Text = "Shared active";
		AccessibleName = "Shared controller mode active";
		DoubleBuffered = true;
	}

	protected override void WndProc(ref Message m)
	{
		if (m.Msg == 132)
		{
			m.Result = new IntPtr(-1);
		}
		else if (m.Msg == 33)
		{
			m.Result = new IntPtr(3);
		}
		else
		{
			base.WndProc(ref m);
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
		TextRenderer.DrawText(e.Graphics, "● SHARED", SystemFonts.MessageBoxFont, ClientRectangle, ForeColor, TextFormatFlags.HorizontalCenter | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter);
	}
}
