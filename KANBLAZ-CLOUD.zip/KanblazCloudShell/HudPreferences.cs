using System;
using System.Drawing;
using System.Globalization;
using System.IO;

namespace KanblazCloudShell;

internal sealed class HudPreferences
{
	internal double X;

	internal double Y = 1.0;

	internal int Percent = 100;

	internal int Foreground = 15069944;

	internal bool Hidden;

	internal static readonly string DefaultPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Kanblaz", "Cloud Shell", "hud-settings.txt");

	internal static readonly HudPreferences Current = Load(DefaultPath);

	private bool Valid
	{
		get
		{
			if (X >= 0.0 && X <= 1.0 && Y >= 0.0 && Y <= 1.0 && Percent >= 80 && Percent <= 150 && Foreground >= 0)
			{
				return Foreground <= 16777215;
			}
			return false;
		}
	}

	internal event Action Changed;

	internal static HudPreferences Load(string path)
	{
		HudPreferences hudPreferences = new HudPreferences();
		try
		{
			if (!File.Exists(path) || new FileInfo(path).Length > 200)
			{
				return hudPreferences;
			}
			string[] array = File.ReadAllText(path).Split('|');
			if (array.Length != 6 || array[0] != "1")
			{
				return hudPreferences;
			}
			HudPreferences hudPreferences2 = new HudPreferences
			{
				X = double.Parse(array[1], CultureInfo.InvariantCulture),
				Y = double.Parse(array[2], CultureInfo.InvariantCulture),
				Percent = int.Parse(array[3]),
				Foreground = int.Parse(array[4]),
				Hidden = bool.Parse(array[5])
			};
			return hudPreferences2.Valid ? hudPreferences2 : hudPreferences;
		}
		catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is FormatException || ex is OverflowException)
		{
			return hudPreferences;
		}
	}

	internal void Save(string path)
	{
		if (!Valid)
		{
			throw new InvalidOperationException("Invalid HUD settings.");
		}
		Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
		string text = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			File.WriteAllText(text, string.Join("|", "1", X.ToString(CultureInfo.InvariantCulture), Y.ToString(CultureInfo.InvariantCulture), Percent, Foreground, Hidden));
			if (File.Exists(path))
			{
				File.Replace(text, path, null, ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(text, path);
			}
		}
		finally
		{
			if (File.Exists(text))
			{
				File.Delete(text);
			}
		}
	}

	internal void Apply()
	{
		try
		{
			Save(DefaultPath);
		}
		finally
		{
			Changed?.Invoke();
		}
	}

	internal Rectangle BoundsFor(Rectangle cell, float dpi)
	{
		if (cell.Width < 24 || cell.Height < 24)
		{
			return Rectangle.Empty;
		}
		float num = Math.Max(0.75f, Math.Min(4f, dpi / 96f)) * (float)Percent / 100f;
		int num2 = Math.Min(cell.Width, (int)Math.Round((float)(Hidden ? 20 : 120) * num));
		int num3 = Math.Min(cell.Height, (int)Math.Round(26f * num));
		int num4 = Math.Min(8, (cell.Width - num2) / 2);
		int num5 = Math.Min(8, (cell.Height - num3) / 2);
		return new Rectangle(cell.Left + num4 + (int)Math.Round((double)(cell.Width - num2 - 2 * num4) * X), cell.Top + num5 + (int)Math.Round((double)(cell.Height - num3 - 2 * num5) * Y), num2, num3);
	}

	internal void MoveTo(Rectangle cell, Size widget, Point topLeft)
	{
		int num = Math.Min(8, Math.Max(0, (cell.Width - widget.Width) / 2));
		int num2 = Math.Min(8, Math.Max(0, (cell.Height - widget.Height) / 2));
		X = Math.Max(0.0, Math.Min(1.0, (double)(topLeft.X - cell.Left - num) / (double)Math.Max(1, cell.Width - widget.Width - 2 * num)));
		Y = Math.Max(0.0, Math.Min(1.0, (double)(topLeft.Y - cell.Top - num2) / (double)Math.Max(1, cell.Height - widget.Height - 2 * num2)));
	}
}
