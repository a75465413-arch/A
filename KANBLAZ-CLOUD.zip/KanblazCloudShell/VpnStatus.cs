using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace KanblazCloudShell;

internal static class VpnStatus
{
	internal static VpnState Parse(string value)
	{
		if (!(value.Trim() == "connected"))
		{
			if (!(value.Trim() == "not-detected"))
			{
				return VpnState.Unknown;
			}
			return VpnState.NotDetected;
		}
		return VpnState.Detected;
	}

	internal static Task<VpnState> ReadAsync()
	{
		return Task.Run(() =>
		{
			try
			{
				using Process process = new Process
				{
					StartInfo = new ProcessStartInfo
					{
						FileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe"),
						Arguments = "-NoLogo -NoProfile -NonInteractive -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes("$ErrorActionPreference='Stop'; try { $connections=@(Get-VpnConnection)+@(Get-VpnConnection -AllUserConnection); if(@($connections | Where-Object ConnectionStatus -eq 'Connected').Count -gt 0){'connected'} else {'not-detected'} } catch {'unknown'}")),
						UseShellExecute = false,
						CreateNoWindow = true,
						WindowStyle = ProcessWindowStyle.Hidden,
						RedirectStandardOutput = true,
						RedirectStandardError = true
					}
				};
				process.Start();
				Task<string> task = process.StandardOutput.ReadToEndAsync();
				process.StandardError.ReadToEndAsync();
				if (!process.WaitForExit(5000))
				{
					try
					{
						process.Kill();
					}
					catch
					{
					}
					return VpnState.Unknown;
				}
				if (process.ExitCode != 0)
				{
					return VpnState.Unknown;
				}
				return Parse(task.GetAwaiter().GetResult());
			}
			catch
			{
				return VpnState.Unknown;
			}
		});
	}
}
