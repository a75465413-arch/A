using System.Threading.Tasks;

namespace KanblazCloudShell;

internal interface IActivationServer
{
	Task<string> ActivateAsync(string code, string device);
}
