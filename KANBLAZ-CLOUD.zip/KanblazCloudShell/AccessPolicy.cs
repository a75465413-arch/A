using System;
using System.Diagnostics;

namespace KanblazCloudShell;

internal sealed class AccessPolicy
{
	internal const int FreeConcurrentSessions = 2;

	internal const int FreeProfiles = 2;

	private readonly AccessTier baseTier;

	private bool useOnline;

	private static long onlineDeadline;

	private static string onlineSource = "free";

	private static readonly object OnlineLock = new object();

	private static string OnlineSource
	{
		get
		{
			lock (OnlineLock)
			{
				return (Stopwatch.GetTimestamp() < onlineDeadline) ? onlineSource : "free";
			}
		}
	}

	internal AccessTier Tier
	{
		get
		{
			if (baseTier != AccessTier.Pro && (!useOnline || !(OnlineSource != "free")))
			{
				return AccessTier.Free;
			}
			return AccessTier.Pro;
		}
	}

	internal string AccessName
	{
		get
		{
			string text = (useOnline ? OnlineSource : "free");
			if (!(text == "og"))
			{
				if (baseTier != AccessTier.Pro)
				{
					if (!(text == "gift"))
					{
						if (!(text == "subscription"))
						{
							return "FREE";
						}
						return "PRO SUBSCRIPTION";
					}
					return "ADMIN GRANTED";
				}
				return "LEGACY / LIFETIME";
			}
			return "LEGACY / LIFETIME · OG";
		}
	}

	internal int MaxConcurrentSessions
	{
		get
		{
			if (Tier != AccessTier.Pro)
			{
				return 2;
			}
			return int.MaxValue;
		}
	}

	internal int MaxProfiles
	{
		get
		{
			if (Tier != AccessTier.Pro)
			{
				return 2;
			}
			return int.MaxValue;
		}
	}

	internal bool HasUnlimitedProfiles => Tier == AccessTier.Pro;

	internal bool HasUnlimitedSessions => Tier == AccessTier.Pro;

	internal bool CanUseLayouts => Tier == AccessTier.Pro;

	internal bool CanUseGroups => Tier == AccessTier.Pro;

	internal bool CanUseColorThemes => Tier == AccessTier.Pro;

	internal string DisplayName
	{
		get
		{
			if (Tier != AccessTier.Pro)
			{
				return "FREE";
			}
			return "PRO";
		}
	}

	internal static void ClearOnline()
	{
		lock (OnlineLock)
		{
			onlineDeadline = 0L;
			onlineSource = "free";
		}
	}

	internal static void AcceptOnline(string mode, string source, bool pro, bool og, bool live, long issued, long expires, long requestStarted)
	{
		lock (OnlineLock)
		{
			onlineDeadline = 0L;
			onlineSource = "free";
			if (!(mode != "live") && live && pro && (!(source != "og") || !(source != "gift") || !(source != "subscription")) && og == (source == "og") && issued > 0 && expires > issued && expires - issued <= 300)
			{
				onlineDeadline = requestStarted + (expires - issued) * Stopwatch.Frequency;
				onlineSource = source;
			}
		}
	}

	internal AccessPolicy(AccessTier tier)
	{
		baseTier = tier;
	}

	internal static AccessPolicy ForCurrentUser()
	{
		return new AccessPolicy(LicenseStore.HasValidActivation() ? AccessTier.Pro : AccessTier.Free)
		{
			useOnline = true
		};
	}

	internal int AvailableSessionSlots(int openSessions)
	{
		if (HasUnlimitedSessions)
		{
			return int.MaxValue;
		}
		return Math.Max(0, MaxConcurrentSessions - Math.Max(0, openSessions));
	}

	internal int AvailableProfileSlots(int activeProfiles)
	{
		if (HasUnlimitedProfiles)
		{
			return int.MaxValue;
		}
		return Math.Max(0, MaxProfiles - Math.Max(0, activeProfiles));
	}
}
