using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.Web.WebView2.Core;

namespace KanblazCloudShell;

internal static class GamepadIsolation
{
	internal static string ReadScript(bool backgroundAudio, bool shared = false, bool hostManaged = false)
	{
		using Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Kanblaz.GamepadIsolation.js");
		if (stream == null)
		{
			throw new InvalidOperationException("The per-window controller isolation component is missing.");
		}
		using StreamReader streamReader = new StreamReader(stream);
		return streamReader.ReadToEnd().Replace("/*KANBLAZ_CONTROLLER_SHARED*/ false", shared ? "true" : "false").Replace("/*KANBLAZ_CONTROLLER_OWNED*/ null", hostManaged ? "false" : "null") + (backgroundAudio ? ("\n" + BackgroundAudioExperiment.ReadScript()) : string.Empty);
	}

	internal static Task<string> InstallAsync(CoreWebView2 browser, bool backgroundAudio, bool shared = false, bool hostManaged = false)
	{
		return browser.AddScriptToExecuteOnDocumentCreatedAsync(ReadScript(backgroundAudio, shared, hostManaged));
	}

	internal static string ChangeScript(bool shared)
	{
		return "(() => { const set = window.__kanblazControllerSharedV1; if (typeof set === 'function') { set(" + (shared ? "true" : "false") + "); return true; } return false; })()";
	}

	internal static string StateScript(bool shared, bool owned)
	{
		return "(() => { const set = window.__kanblazControllerStateV2; return typeof set === 'function' ? set(" + (shared ? "true" : "false") + "," + (owned ? "true" : "false") + ") : false; })()";
	}

	internal static string JoystickScript(bool active, double x, double y)
	{
		if (double.IsNaN(x) || double.IsNaN(y) || double.IsInfinity(x) || double.IsInfinity(y) || Math.Abs(x) > 1.0 || Math.Abs(y) > 1.0 || x * x + y * y > 1.000001)
		{
			throw new ArgumentOutOfRangeException("x");
		}
		return "(() => { const set = window.__kanblazVirtualJoystickV1; return typeof set === 'function' ? set(" + (active ? "true" : "false") + "," + x.ToString("R", CultureInfo.InvariantCulture) + "," + y.ToString("R", CultureInfo.InvariantCulture) + ") : false; })()";
	}
}
