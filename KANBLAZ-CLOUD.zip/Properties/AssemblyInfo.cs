using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("KANBLAZ CLOUD")]
[assembly: AssemblyProduct("KANBLAZ CLOUD")]
[assembly: AssemblyCompany("Kanblaz")]
[assembly: AssemblyCopyright("© 2026 Kanblaz. All rights reserved.")]
[assembly: AssemblyFileVersion("3.2.44.0")]
[assembly: AssemblyInformationalVersion("3.2.44")]
[assembly: AssemblyVersion("3.2.44.0")]
